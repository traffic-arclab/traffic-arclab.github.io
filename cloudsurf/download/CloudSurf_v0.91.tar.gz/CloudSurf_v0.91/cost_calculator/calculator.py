#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 15 dic 2015

@author: antonio
'''

import os, time, math

from ConfigParser import SafeConfigParser
from aws_utils import utils
from logger import setup_logging
from awspricingfull_master import awspricingfull


class PriceCalculatorException(Exception):
    '''
    Exception for PriceCalculator class
    '''
    def __init__(self, message):
        self.message = message
    def __str__(self):
        return str(self.message)


class PriceCalculator:
    '''
    Class for campaign's price calculation
    '''

    def __init__(self, pricing_parameters):
        '''
        PriceCalculator constructor:
        - pricing_parameters (dict):
                                    - provider (str): cloud service provider [aws or msa],
                                    - cloudsurf_mode (str): selected cloudsurf feature,
                                    - intra-datacenter_mode (str): public or private ip address
                                                                   towards traffic is generated,
                                    - sender_region (str): aws or msa sender region,
                                    - sender_type (str): aws or msa sender type,
                                    - receiver_region (str): aws or msa receiver region,
                                    - receiver_type (str): aws or msa receiver type,
                                    - experiments (list of dict):
                                                                - duration (int): experiment duration [s]
                                                                - bandwidth (int): experiment target bandwidth [bit/s]
                                                                - sleep_exp (int): wait time between experiments
                                    - repetitions (int): number of experiments repetitions,
                                    - sleep_rep (int): wait time between repetitions
        '''

        #Extract campaign's informations
        #TODO: Currently provider parameter isn't used
        self.provider = pricing_parameters.get('provider', 'aws')
        self.cloudsurf_mode = pricing_parameters['cloudsurf_mode'].lower()

        if self.cloudsurf_mode == 'intra-datacenter':
            self.intra_datacenter_mode = '_' + pricing_parameters.get('intra-datacenter_mode', 'public')
        else:
            self.intra_datacenter_mode = ""

        self.sender_region = pricing_parameters['sender_region']
        self.sender_type = pricing_parameters['sender_type']

        self.receiver_region = pricing_parameters['receiver_region']
        self.receiver_type = pricing_parameters['receiver_type']

        self.repetitions = pricing_parameters.get('repetitions', 1)
        self.sleep_rep = pricing_parameters.get('sleep_rep', 0)

        #Extract experiments' information
        self.experiments = pricing_parameters['experiments']

        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        self.except_retries = self.parser.getint('config_vm', 'except_retries')
        self.except_wait = self.parser.getint('config_vm', 'except_wait')

        self.info_log, self.debug_log = setup_logging.return_loggers()

        self.EC2Pricing = awspricingfull.EC2Prices()


    def __from_seconds_to_hours(self, seconds):
        '''
        Return the number of hours round up to the next integer, according to AWS pricing policies.
        '''

        return math.ceil(float(seconds)/3600)


    def __from_bits_to_GB(self, bits):
        '''
        Return data transfer volume from bits in GB.
        '''

        return (float(bits)/8)/math.pow(10, 9)


    def __calculate_instances_prices(self, local):
        '''
        Calculate per hour sender and receiver instances (VMs) prices.
        They depend on sender/receiver regions and VM types.
        '''

        self.debug_log.debug('Calculating on demand VMs prices')

        result = self.EC2Pricing.get_ondemand_linux_instances_prices(local)
        for result_region in result['regions']:

            if result_region['region'] == self.sender_region:
                for instance_type in result_region['instanceTypes']:
                    if instance_type['type'] == self.sender_type:
                        sender_hourly_price = instance_type['price']
                        break

            if result_region['region'] == self.receiver_region:
                for instance_type in result_region['instanceTypes']:
                    if instance_type['type'] == self.receiver_type:
                        receiver_hourly_price = instance_type['price']
                        break

        self.debug_log.debug('On demand VMs prices successfully calculated --> sender VM price: %s; receiver VM price: %s'\
                             % (sender_hourly_price, receiver_hourly_price))

        return sender_hourly_price, receiver_hourly_price


    def __calculate_data_transfer_prices(self, local):
        '''
        Calculate per GB data transfer costs.
        They depend on sender/receiver regions.
        '''

        self.debug_log.debug('Calculating data transfer price')

        result = self.EC2Pricing.get_data_transfer_prices(local)
        for result_region in result['regions']:

            if result_region['region'] == self.sender_region:
                for transfer_type in result_region['transferTypes']:
                    if ('%s_OUT' % (self.cloudsurf_mode + self.intra_datacenter_mode)) in transfer_type['type']:
                        outbound_data_transfer_perGB_price = transfer_type['price']
                        break

            if result_region['region'] == self.receiver_region:
                for transfer_type in result_region['transferTypes']:
                    if ('%s_IN' % (self.cloudsurf_mode + self.intra_datacenter_mode)) in transfer_type['type']:
                        inbound_data_transfer_perGB_price = transfer_type['price']
                        break

        self.debug_log.debug('Data transfer price successfully calculated --> sender data transfer price: %s; receiver data transfer price: %s'\
                             % (outbound_data_transfer_perGB_price, inbound_data_transfer_perGB_price))

        return outbound_data_transfer_perGB_price, inbound_data_transfer_perGB_price


    def __calculate_campaign_price(self, local):
        '''
        Calculate campaign's total instances (VMs) and transfer prices.
        '''

        try:
            sender_hourly_price, receiver_hourly_price = self.__calculate_instances_prices(local)
            outbound_data_transfer_perGB_price, inbound_data_transfer_perGB_price = self.__calculate_data_transfer_prices(local)

            instances_activation_time = 0
            traffic_generation_volume = 0
            for experiment in self.experiments:
                duration = experiment.get('duration', 60)
                bandwidth = experiment.get('bandwidth', 0)
                sleep_exp = experiment.get('sleep_exp', 0)

                instances_activation_time += (duration + sleep_exp)
                traffic_generation_volume += (duration * bandwidth)

            #In seconds
            instances_activation_time = (instances_activation_time + self.sleep_rep) * self.repetitions
            #In bits
            traffic_generation_volume = traffic_generation_volume * self.repetitions

            total_instances_price = self.__from_seconds_to_hours(instances_activation_time) * (sender_hourly_price + receiver_hourly_price)
            total_data_transfer_price = self.__from_bits_to_GB(traffic_generation_volume) * (outbound_data_transfer_perGB_price + inbound_data_transfer_perGB_price)

        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Error in price calculator: %s', m)
            raise

        return total_instances_price, total_data_transfer_price


    def calculate_campaign_price(self):
        '''
        Calculate campaign's total instances (VMs) and transfer prices.
        Raise an exception if calculation fails <except_retries> times.
        '''

        self.debug_log.info("Calculating campaign's total price")
        self.info_log.info("Calculating campaign's total price")

        calculated = False
        retries = self.except_retries

        while not calculated and retries > 0:
            try:
                total_instances_price, total_data_transfer_price = self.__calculate_campaign_price(False)
                calculated = True
            except Exception, e:
                m = utils.exception_parser(e)
                err_str = "Calculating campaign's price error: %s" % m
                self.debug_log.warning(err_str)
                retries = retries - 1
                time.sleep(self.except_wait)

        if not calculated:
            try:
                total_instances_price, total_data_transfer_price = self.__calculate_campaign_price(True)
            except Exception, e:
                m = utils.exception_parser(e)
                err_str = "Calculating campaign's price error: %s" % m
                self.debug_log.error(err_str)
                raise PriceCalculatorException(err_str)

        local = not calculated
        self.debug_log.info("Campaign's total price successfully calculated!")
        self.info_log.info("Campaign's total price successfully calculated!")

        return total_instances_price, total_data_transfer_price, local


if __name__ == '__main__':

    parameters_foo = {
                   'provider': 'amazon',
                   'cloudsurf_mode': 'intra-datacenter',
                   'intra-datacenter_mode': 'public',
                   'sender_region': 'us-east-1',
                   'sender_type': 'm3.medium',
                   'receiver_region': 'us-east-1',
                   'receiver_type': 'm3.medium',
                   'experiments': [
                                   {
                                    'duration': 300,
                                    'bandwidth': 2000000000,
                                    'sleep_exp': 60
                                    },
                                    {
                                    'duration': 300,
                                    'bandwidth': 1000000000,
                                    'sleep_exp': 0
                                    }
                                   ],
                   'repetitions': 24,
                   'sleep_rep': 2940
                   }

    calculator = PriceCalculator(parameters_foo)
    total_instances_price, total_data_transfer_price = calculator.calculate_campaign_price()
    print total_instances_price, total_data_transfer_price
