#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
from core.utils import clear
from core.banner import Banner
from core.prompt import Prompt
from core.colors import bcolors
from core.meta import Meta

import interactive

def main():

    msg = "\n We're sorry. This feature has not been implemented yet :-("
    msg = "%s%s%s%s" %(bcolors.BOLD, bcolors.YELLOW, msg, bcolors.ENDC)
    msg2 = "\n A team of highly trained monkeys is currently working\n to extend the features of %s" % Meta.name
    msg2 = "%s%s%s" %(bcolors.GREEN, msg2, bcolors.ENDC)
    clear()
    Banner.show_graphic_text()
    raw_input(Prompt.press_a_key(msg+msg2))
    return
