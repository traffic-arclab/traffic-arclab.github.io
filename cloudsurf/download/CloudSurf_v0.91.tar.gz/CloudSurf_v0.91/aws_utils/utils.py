#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 25 nov 2015

@author: antonio
'''

import time, boto
import xml.etree.ElementTree as XmlParser

def exception_parser(exception):
    if isinstance(exception, boto.exception.BotoServerError) or isinstance(exception, boto.exception.BotoClientError):
        root = XmlParser.fromstring(exception[2])
        message = [x[0].findall('Message')[0].text for x in [m.findall('Error')
                    for m in root.findall('Errors')]][0]
        exception_message = '%s %s: %s' % (exception[0], exception[1], message)
    else:
        exception_message = str(exception)

    return exception_message


def millis_time():
    return int(round(time.time() * 1000))


def eliminate_duplicate(l):
    '''
    Eliminate duplicates from a list maintaining order
    '''
    seen = set()
    seen_add = seen.add
    return [i for i in l if not (i in seen or seen_add(i))]
