#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
Created on 10 dic 2015

@author: antonio
'''

import os, sys, boto.ec2
import Queue

from threading import Thread
from ConfigParser import SafeConfigParser

from logger import setup_logging
from aws_setup import key_pair, security_group
from aws_utils import utils
from aws_vm_setup import management, preparation
from experiment import campaign
from results_parser import extract_json
from backend_interaction import upload_results
from print_results import print_results

from core.meta import Meta
from core.utils import clear
from core.banner import Banner
from core.colors import bcolors
from core.menus import generic_print


class AWSTasks:
    '''
    Obtain AWS common tasks from experiment management steps
    '''

    def __init__(self, parameters, exp_list_parameters):
        '''
        Constructor of AWSTasks class:
        - parameters (dict):
                             - cloudsurf_mode (str)
                             - provider (str)
                             - sender_type (str)
                             - sender_region (str)
                             - sender_placement (str)
                             - receiver_type (str)
                             - receiver_region (str)
                             - receiver_placement (srt)
        - exp_list_parameters (list of dict): list of experiments parameters dicts
        '''

        self.cloudsurf_mode = parameters['cloudsurf_mode']
        self.provider = parameters['provider']
        self.sender_type = parameters['sender_type']
        self.sender_region = parameters['sender_region']
        self.sender_placement = parameters['sender_placement']
        self.receiver_type = parameters['receiver_type']
        self.receiver_region = parameters['receiver_region']
        self.receiver_placement = parameters['receiver_placement']

        self.exp_list_parameters = exp_list_parameters

        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        self.thread_timeout = self.parser.getfloat('config_threading', 'thread_timeout')
        self.results_container = self.parser.get('config_experiment', 'results_container')

        self.backend_servlet_address = self.parser.get('config_upload', 'backend_servlet_address')
        self.backend_servlet_timeout = self.parser.getint('config_upload', 'backend_servlet_timeout')

        self.info_log, self.debug_log = setup_logging.return_loggers()


    def initialization(self, l, queue):
        '''
        Performs initialization tasks: key pair and security group creation
        '''
        try:
            if self.cloudsurf_mode == 'INTRA-DATACENTER':
                self.sender_ec2_connection = boto.ec2.connect_to_region(self.sender_region)
                self.receiver_ec2_connection = self.sender_ec2_connection

                self.kp_snd = key_pair.KeyPair(self.sender_ec2_connection)
                self.kp_snd.create_and_save()
                self.kp_rcv = self.kp_snd

                self.sg_snd = security_group.SecurityGroup(self.sender_ec2_connection)
                self.sg_snd.create()
                self.sg_rcv = self.sg_snd
            elif self.cloudsurf_mode == 'INTER-DATACENTER':
                self.sender_ec2_connection = boto.ec2.connect_to_region(self.sender_region)
                self.receiver_ec2_connection = boto.ec2.connect_to_region(self.receiver_region)

                self.kp_snd = key_pair.KeyPair(self.sender_ec2_connection)
                self.kp_snd.create_and_save()
                self.kp_rcv = key_pair.KeyPair(self.receiver_ec2_connection)
                self.kp_rcv.create_and_save()

                self.sg_snd = security_group.SecurityGroup(self.sender_ec2_connection)
                self.sg_snd.create()
                self.sg_rcv = security_group.SecurityGroup(self.receiver_ec2_connection)
                self.sg_rcv.create()
        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in initialization(): %s' % m)
            raise
        finally:
            l.release()
        queue.put_nowait(True)
        return True


    def VM_startup(self, l, queue):
        '''
        Performs sender and receiver VMs startup
        '''
        try:
            threads = []
            self.vm_mgmt_sender = management.VMManagement(self.sender_ec2_connection, self.sender_type, self.sender_placement, self.kp_snd.get_ssh_key_name(), self.sg_snd.get_security_group_name())
            self.vm_mgmt_receiver = management.VMManagement(self.receiver_ec2_connection, self.receiver_type, self.receiver_placement, self.kp_rcv.get_ssh_key_name(), self.sg_rcv.get_security_group_name())

            queue_launch_sender = Queue.Queue(maxsize=1)
            queue_launch_receiver = Queue.Queue(maxsize=1)
            threads.append(Thread(target=self.vm_mgmt_sender.launch_vm, args=(queue_launch_sender,), name='sender_vm_launch'))
            threads.append(Thread(target=self.vm_mgmt_receiver.launch_vm, args=(queue_launch_receiver,), name='receiver_vm_launch'))

            for thread in threads:
                thread.start()
                self.debug_log.debug('Start VM startup worker: %s' % thread.name)

            for thread in threads:
                while thread.isAlive() == True:
                    thread.join(self.thread_timeout)
                    self.debug_log.debug('Still waiting for VM startup worker [%s] to complete.' % thread.name)
                self.debug_log.debug("VM startup worker [%s] --> finish" % thread.name)

            launched_snd = False
            launched_rcv = False
            try:
                launched_snd = queue_launch_sender.get_nowait()
                launched_rcv = queue_launch_receiver.get_nowait()
            except Queue.Empty:
                self.debug_log.error('Raised Queue.Empty in launching VMs')
            finally:
                if not (launched_snd and launched_rcv):
                    if not launched_snd:
                        self.debug_log.error('Exception raised in VM startup worker [sender_vm_launch] --> launch_vm() returned %s' % launched_snd)
                    if not launched_rcv:
                        self.debug_log.error('Exception raised in VM startup worker [receiver_vm_launch] --> launch_vm() returned %s' % launched_rcv)
                    queue.put_nowait(False)
                    raise management.VMManagementException('launch_vm() returned False')

            threads = []
            queue_check_sender = Queue.Queue(maxsize=1)
            queue_check_receiver = Queue.Queue(maxsize=1)
            threads.append(Thread(target=self.vm_mgmt_sender.running_check_barrier, args=(queue_check_sender,), name='sender_vm_check_barrier'))
            threads.append(Thread(target=self.vm_mgmt_receiver.running_check_barrier, args=(queue_check_receiver,), name='receiver_vm_check_barrier'))

            for thread in threads:
                thread.start()
                self.debug_log.debug('Start VM startup worker: %s' % thread.name)

            for thread in threads:
                while thread.isAlive() == True:
                    thread.join(self.thread_timeout)
                    self.debug_log.debug('Still waiting for VM startup worker [%s] to complete.' % thread.name)
                self.debug_log.debug("VM startup worker [%s] --> finish" % thread.name)

            checked_snd = False
            checked_rcv = False
            try:
                checked_snd = queue_check_sender.get_nowait()
                checked_rcv = queue_check_receiver.get_nowait()
            except Queue.Empty:
                self.debug_log.error('Raised Queue.Empty in checking barrier for VMs')
            finally:
                if not (checked_snd and checked_rcv):
                    if not checked_snd:
                        self.debug_log.error('Exception raised in VM startup worker [sender_vm_check_barrier] --> running_check_barrier() returned %s' % checked_snd)
                    if not checked_rcv:
                        self.debug_log.error('Exception raised in VM startup worker [receiver_vm_check_barrier] --> running_check_barrier() returned %s' % checked_rcv)
                    queue.put_nowait(False)
                    raise management.VMManagementException('running_check_barrier() returned False')

        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in VM_startup(): %s' % m)
            raise
        finally:
            l.release()
        queue.put_nowait(True)
        return True


    def VM_configuration(self, l, queue):
        '''
        Configure sender and receiver VMs
        '''
        try:
            threads = []
            self.vm_prep_sender = preparation.VMPreparation(self.vm_mgmt_sender.get_vm(), self.kp_snd.get_ssh_key_name())
            self.vm_prep_receiver = preparation.VMPreparation(self.vm_mgmt_receiver.get_vm(), self.kp_rcv.get_ssh_key_name())

            queue_install_sender = Queue.Queue(maxsize=1)
            queue_install_receiver = Queue.Queue(maxsize=1)
            threads.append(Thread(target=self.vm_prep_sender.install_tools, args=(queue_install_sender,), name='sender_tools_installer'))
            threads.append(Thread(target=self.vm_prep_receiver.install_tools, args=(queue_install_receiver,), name='receiver_tools_installer'))

            for thread in threads:
                thread.start()
                self.debug_log.debug('Start VM configuration worker: %s' % thread.name)

            for thread in threads:
                while thread.isAlive() == True:
                    thread.join(self.thread_timeout)
                    self.debug_log.debug('Still waiting for VM configuration worker [%s] to complete.' % thread.name)
                self.debug_log.debug("VM configuration worker [%s] --> finish" % thread.name)

            installed_snd = False
            installed_rcv = False
            try:
                installed_snd = queue_install_sender.get_nowait()
                installed_rcv = queue_install_receiver.get_nowait()
            except Queue.Empty:
                self.debug_log.error('Raised Queue.Empty in installing tools')
            finally:
                if not (installed_snd and installed_rcv):
                    if not installed_snd:
                        self.debug_log.error('Exception raised in VM configuration worker [sender_tools_installer] --> install_tools() returned %s' % installed_snd)
                    if not installed_rcv:
                        self.debug_log.error('Exception raised in VM configuration worker [receiver_tools_installer] --> install_tools() returned %s' % installed_rcv)
                    queue.put_nowait(False)
                    raise preparation.VMPreparationException('install_tools() returned False')

            threads = []
            queue_agent_sender = Queue.Queue(maxsize=1)
            queue_agent_receiver = Queue.Queue(maxsize=1)
            threads.append(Thread(target=self.vm_prep_sender.launch_agent, args=(queue_agent_sender,), name='sender_launch_agent'))
            threads.append(Thread(target=self.vm_prep_receiver.launch_agent, args=(queue_agent_receiver,), name='receiver_launch_agent'))

            for thread in threads:
                thread.start()
                self.debug_log.debug('Start VM configuration worker: %s' % thread.name)

            for thread in threads:
                while thread.isAlive() == True:
                    thread.join(self.thread_timeout)
                    self.debug_log.debug('Still waiting for VM configuration worker [%s] to complete.' % thread.name)
                self.debug_log.debug("VM configuration worker [%s] --> finish" % thread.name)

            agent_snd = False
            agent_rcv = False
            try:
                agent_snd = queue_agent_sender.get_nowait()
                agent_rcv = queue_agent_receiver.get_nowait()
            except Queue.Empty:
                self.debug_log.error('Raised Queue.Empty in launching agent')
            finally:
                if not (agent_snd and agent_rcv):
                    if not agent_snd:
                        self.debug_log.error('Exception raised in VM configuration worker [sender_launch_agent] --> launch_agent() returned %s' % agent_snd)
                    if not agent_rcv:
                        self.debug_log.error('Exception raised in VM configuration worker [receiver_launch_agent] --> launch_agent() returned %s' % agent_rcv)
                    queue.put_nowait(False)
                    raise preparation.VMPreparationException('launch_agent() returned False')

        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in VM_configuration(): %s' % m)
            raise
        finally:
            l.release()
        queue.put_nowait(True)
        return True


    def start_experiment_template(self, l, queue):
        '''
        Start campaign between sender and receiver VMs
        '''
        try:
            self.exp = campaign.Campaign\
            (self.exp_list_parameters, self.vm_mgmt_sender.get_vm(), self.vm_mgmt_receiver.get_vm(), self.kp_snd.get_ssh_key_name(), self.kp_rcv.get_ssh_key_name())

            self.exp.run_experiment()
        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in start_experiment_template(): %s' % m)
            queue.put_nowait(False)
            raise
        finally:
            l.release()
        queue.put_nowait(True)
        return True


    def retrieve_results(self, l, queue):
        '''
        Retrieve campaign results
        '''
        try:
            pulled = False
            pulled = self.exp.store_results()
        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in retrieve_results(): %s' % m)
            raise
        finally:
            queue.put_nowait(pulled)
            l.release()
        return pulled


    def clean_cloud(self, l, queue):
        '''
        Take back cloud environment to its initial status
        '''
        try:
            self.vm_mgmt_sender.terminate_vm()
            self.vm_mgmt_receiver.terminate_vm()

            self.kp_snd.delete()
            self.sg_snd.delete()

            if self.cloudsurf_mode == 'INTER-DATACENTER':
                self.kp_rcv.delete()
                self.sg_rcv.delete()
        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in clean_cloud(): %s' % m)
            queue.put_nowait(False)
            raise
        finally:
            l.release()
        queue.put_nowait(True)
        return True


    def parse_results(self, l, queue):
        '''
        Perform parsing of campaign results in standard .json format
        '''
        try:
            parsed = False
            self.parser_json = extract_json.ResultsParser(self.exp.outdir)
            parsed = self.parser_json.extract_json()
        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in parse_results(): %s' % m)
            raise
        finally:
            l.release()
            queue.put_nowait(parsed)
        return parsed


    def upload_results(self):
        '''
        Perform upload of campaign results in .gz compressed format
        '''

        try:
            generic_print('Upload Results', bcolors.BOLD, 'Uploading, please wait...', bcolors.BLUE)
            
            uploaded = False
            self.uploader = upload_results.UploadResults(self.exp.get_outdir())
            uploaded = self.uploader.upload()
            
            after_upload_msg = 'Your results have been successfully uploaded!'
            after_upload_msg += '\n You can also download the results shared by the community at this link: %s' % Meta.repository
            print "%s%s %s%s\n" % (bcolors.BLUE, bcolors.BOLD, after_upload_msg, bcolors.ENDC) 
        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in upload_results(): %s' % m)
            raise
        return uploaded


    def print_results(self):
        '''
        Print campaign results on stdout
        '''
        try:
            clear()
            Banner.show_graphic_text()
            print "\n%s %s%s\n" % (bcolors.BOLD, 'Campaign Results', bcolors.ENDC)

            self.printer = print_results.PrintResults()
            printed = self.printer.print_results(self.exp.get_outdir())
        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception raised in print_results(): %s' % m)
            raise
        return printed


    def restore_cloud(self):
        '''
        Take back cloud environment to its initial status when an exception occurs
        '''
        self.debug_log.debug('Starting restore_cloud() --> Restores cloud environment after exception raising')
        try:
            print ' (1) Terminating sender VM...',
            sys.stdout.flush()
            self.vm_mgmt_sender.terminate_vm()
        except Exception, e:
            m = utils.exception_parser(e)
            if hasattr(self, 'vm_mgmt_sender') and self.vm_mgmt_sender.is_running():
                self.debug_log.error("restore_cloud() --> Exception raised: %s" % m)
                self.debug_log.error("restore_cloud() --> Cannot terminate sender VM, but it seems to be running. Check for it!")
            else:
                self.debug_log.warning("restore_cloud() --> Exception raised: %s" % m)
                self.debug_log.warning("restore_cloud() --> Sender VM doesn't seem to be running")
        finally:
            print 'OK!'
            sys.stdout.flush()

        try:
            print ' (2) Terminating receiver VM...',
            sys.stdout.flush()
            self.vm_mgmt_receiver.terminate_vm()
        except Exception, e:
            m = utils.exception_parser(e)
            if hasattr(self, 'vm_mgmt_receiver') and self.vm_mgmt_receiver.is_running():
                self.debug_log.error("restore_cloud() --> Exception raised: %s" % m)
                self.debug_log.error("restore_cloud() --> Cannot terminate receiver VM, but it seems to be running. Check for it!")
            else:
                self.debug_log.warning("restore_cloud() --> Exception raised: %s" % m)
                self.debug_log.warning("restore_cloud() --> Receiver VM doesn't seem to be running")
        finally:
            print 'OK!'
            sys.stdout.flush()

        try:
            print ' (3) Deleting sender key pair...',
            sys.stdout.flush()
            self.kp_snd.delete()
        except Exception, e:
            m = utils.exception_parser(e)
            if hasattr(self, 'kp_snd') and self.kp_snd.is_saved():
                self.debug_log.error("restore_cloud() --> Exception raised: %s" % m)
                self.debug_log.error("restore_cloud() --> Cannot eliminate sender key pair, but it seems to be still saved. Check for it!")
            else:
                self.debug_log.warning("restore_cloud() --> Exception raised: %s" % m)
                self.debug_log.warning("restore_cloud() --> Sender key pair doesn't seem to be saved anymore")
        finally:
            print 'OK!'
            sys.stdout.flush()

        try:
            print ' (4) Deleting sender security group...',
            sys.stdout.flush()
            self.sg_snd.delete()
        except Exception, e:
            m = utils.exception_parser(e)
            if hasattr(self, 'sg_snd') and self.sg_snd.is_created():
                self.debug_log.error("restore_cloud() --> Exception raised: %s" % m)
                self.debug_log.error("restore_cloud() --> Cannot eliminate sender security group, but it seems to be still defined. Check for it!")
            else:
                self.debug_log.warning("restore_cloud() --> Exception raised: %s" % m)
                self.debug_log.warning("restore_cloud() --> Sender security group doesn't seem to be defined anymore")
        finally:
            print 'OK!'
            sys.stdout.flush()

        if self.cloudsurf_mode == 'INTER-DATACENTER':
            try:
                print ' (5) Deleting receiver key pair...',
                sys.stdout.flush()
                self.kp_rcv.delete()
            except Exception, e:
                m = utils.exception_parser(e)
                if hasattr(self, 'kp_rcv') and self.kp_rcv.is_saved():
                    self.debug_log.error("restore_cloud() --> Exception raised: %s" % m)
                    self.debug_log.error("restore_cloud() --> Cannot eliminate receiver key pair, but it seems to be still saved. Check for it!")
                else:
                    self.debug_log.warning("restore_cloud() --> Exception raised: %s" % m)
                    self.debug_log.warning("restore_cloud() --> Receiver key pair doesn't seem to be saved anymore")
            finally:
                print 'OK!'
                sys.stdout.flush()

            try:
                print ' (6) Deleting receiver security group...',
                sys.stdout.flush()
                self.sg_rcv.delete()
            except Exception, e:
                m = utils.exception_parser(e)
                if hasattr(self, 'sg_rcv') and self.sg_rcv.is_created():
                    self.debug_log.error("restore_cloud() --> Exception raised: %s" % m)
                    self.debug_log.error("restore_cloud() --> Cannot eliminate receiver security group, but it seems to be still defined. Check for it!")
                else:
                    self.debug_log.warning("restore_cloud() --> Exception raised: %s" % m)
                    self.debug_log.warning("restore_cloud() --> Receiver security group doesn't seem to be defined anymore")
            finally:
                print 'OK!'
                sys.stdout.flush()

        self.debug_log.debug('Ending restore_cloud() --> Cloud environment restored. Check this file for more informations about operations performed')
        return
