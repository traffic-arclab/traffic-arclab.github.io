.. awspricingfull documentation master file, created by
   sphinx-quickstart on Fri Jun 12 17:13:08 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to awspricingfull's documentation!
==========================================

Contents:

.. toctree::
   :maxdepth: 2
.. automodule:: awspricingfull



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

