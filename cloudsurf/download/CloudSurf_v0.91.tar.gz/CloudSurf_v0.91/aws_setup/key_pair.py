#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 23 nov 2015

@author: antonio
'''

import os, boto

from aws_utils import utils
from logger import setup_logging
from ConfigParser import SafeConfigParser

class KeyPair:
    '''
    Manage key pair creation and deletion
    '''

    def __init__(self, ec2_connection):
        '''
        Initialize KeyPair object and define ssh_key_name and ssh_key_dir.
        '''

        self.ec2_connection = ec2_connection
        self.saved = False

        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        self.ssh_key_name = '%s_%s' % (self.parser.get('config_key_pair', 'ssh_key_name'), utils.millis_time())
        self.ssh_key_dir = os.path.expanduser('~/%s' % self.parser.get('config_key_pair', 'ssh_key_dir'))

        self.info_log, self.debug_log = setup_logging.return_loggers()


    def get_ssh_key_name(self):
        '''
        Return ssh_key_name value
        '''
        return self.ssh_key_name


    def is_saved(self):
        '''
        Return True or False depending on key pair has been created and saved or not
        '''
        return self.saved


    def create_and_save(self):
        '''
        Create a new key pair within the region to which <ec2_connection> has been established
        and save the resulting unencrypted PEM encoded RSA private key in $HOME/.cloudsurf_ssh/<ssh_key_name>.pem.
        Raise an exception if a key name <ssh_key_name> already exists.
        '''

        self.debug_log.info('Creating %s key pair in region %s' % (self.ssh_key_name, self.ec2_connection.region.name))
        self.info_log.info('Creating %s key pair in region %s' % (self.ssh_key_name, self.ec2_connection.region.name))

        try:
            key_obj = self.ec2_connection.create_key_pair(self.ssh_key_name)
            self.debug_log.debug('Key pair %s remotely created in region %s' % (self.ssh_key_name, self.ec2_connection.region.name))

            if not os.path.exists(self.ssh_key_dir):
                os.makedirs(self.ssh_key_dir)
            self.saved = key_obj.save(self.ssh_key_dir)
            self.debug_log.debug('Key pair %s.pem locally created in directory %s' % (self.ssh_key_name, self.ssh_key_dir))

        except boto.exception.EC2ResponseError, e: #key <ssh_key_name> remotely already exists
            m = utils.exception_parser(e)
            self.debug_log.warning(m)
            raise

        except boto.exception.BotoClientError, e:  #$HOME/.ssh/<ssh_key_name>.pem already exists
            m = utils.exception_parser(e)
            self.debug_log.error(m)
            raise

        self.debug_log.info('Key pair %s successfully created!' % self.ssh_key_name)
        self.info_log.info('Key pair %s successfully created!' % self.ssh_key_name)

        return self.saved


    def delete(self):
        '''
        Delete the key pair <ssh_key_name> from the region to which <ec2_connection> has been established
        and remove the associated unencrypted PEM encoded RSA private key in $HOME/.cloudsurf_ssh/<ssh_key_name>.pem.
        Raise an IO exception if the private key no more exists.
        '''

        self.debug_log.info('Deleting %s key pair from region %s' % (self.ssh_key_name, self.ec2_connection.region.name))
        self.info_log.info('Deleting %s key pair from region %s' % (self.ssh_key_name, self.ec2_connection.region.name))

        try:
            self.ec2_connection.delete_key_pair(self.ssh_key_name)
            self.debug_log.debug('Key pair %s remotely deleted from region %s' % (self.ssh_key_name, self.ec2_connection.region.name))
            os.remove('%s/%s.pem' % (self.ssh_key_dir, self.ssh_key_name))
            self.debug_log.debug('Key pair %s.pem locally deleted' % self.ssh_key_name)
        except OSError, e:
            m = utils.exception_parser(e)
            self.debug_log.warning(m)
            raise

        self.saved = False
        self.debug_log.info('Key pair %s successfully deleted!' % self.ssh_key_name)
        self.info_log.info('Key pair %s successfully deleted!' % self.ssh_key_name)
        return

