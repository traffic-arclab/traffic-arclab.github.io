#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 23 nov 2015

@author: antonio
'''

import os, time, boto

from aws_utils import utils
from logger import setup_logging
from ConfigParser import SafeConfigParser

class SecurityGroup:
    '''
    Manage security group creation and deletion
    '''

    def __init__(self, ec2_connection):
        '''
        Initialize SecurityGroup object and define security group name.
        '''

        self.ec2_connection = ec2_connection
        self.created = False

        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        self.security_group_name = '%s_%s' % (self.parser.get('config_security_group', 'security_group_name'), utils.millis_time())

        self.info_log, self.debug_log = setup_logging.return_loggers()


    def get_security_group_name(self):
        '''
        Return security_group_name value
        '''
        return self.security_group_name


    def is_created(self):
        '''
        Return True or False depending on security group as been created or not
        '''
        return self.created


    def create(self):
        '''
        Create <security_group_name> security group within the region
        to which <ec2_connection> has been established.
        Raise an exception if a security group named <security_group_name> already exists.
        '''

        self.debug_log.info('Creating %s security group in region %s' % (self.security_group_name, self.ec2_connection.region.name))
        self.info_log.info('Creating %s security group in region %s' % (self.security_group_name, self.ec2_connection.region.name))

        description = 'Security group %s created by cloudsurf on %s.' % (self.security_group_name, time.strftime('%X, %a %b %d %Y'))
        try:
            security_group = self.ec2_connection.create_security_group(self.security_group_name, description)
            self.debug_log.debug('Security group %s remotely created in region %s' % (self.security_group_name, self.ec2_connection.region.name))
            #Trivial solution: all protocols authorized, port range and IP addresses authorized
            #N.B. -1 is used in API to indicate all protocols (tcp, udp, icmp)
            security_group.authorize(ip_protocol='-1', from_port=0, to_port=65535, cidr_ip='0.0.0.0/0')
            self.debug_log.debug('Security group %s open_all authorizations added' % self.security_group_name)
        except boto.exception.EC2ResponseError, e: #security group named <name> already exists
            m = utils.exception_parser(e)
            self.debug_log.warning(m)
            raise

        self.created = True

        self.debug_log.info('Security group %s successfully created!' % self.security_group_name)
        self.info_log.info('Security group %s successfully created!' % self.security_group_name)
        return self.created


    #TODO: Implement non trivial solution rule authorization
    def __add_rule(self):
        pass


    def delete(self):
        '''
        Delete <security_group_name> security group from the region
        to which <ec2_connection> has been established.
        Raise an exception if a security group named <security_group_name> doesn't exist.
        '''

        self.debug_log.info('Deleting %s security group from region %s' % (self.security_group_name, self.ec2_connection.region.name))
        self.info_log.info('Deleting %s security group from region %s' % (self.security_group_name, self.ec2_connection.region.name))

        deleted = False
        try:
            deleted = self.ec2_connection.delete_security_group(self.security_group_name)
        except boto.exception.EC2ResponseError, e: #security group named <name> doesn't exists
            m = utils.exception_parser(e)
            self.debug_log.warning(m)
            raise

        self.created = not deleted

        self.debug_log.info('Security group %s successfully deleted!' % self.security_group_name)
        self.info_log.info('Security group %s successfully deleted!' % self.security_group_name)
        return deleted

