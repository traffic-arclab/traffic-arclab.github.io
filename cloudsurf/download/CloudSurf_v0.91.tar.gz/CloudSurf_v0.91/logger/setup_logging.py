#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 25 nov 2015

@author: antonio
'''

import os, logging, time

from logging.handlers import RotatingFileHandler
from ConfigParser import SafeConfigParser


def setup_logger(logger_name, log_file, level=logging.INFO):
    '''
    Return a log object associated to <log_file> with specific formatting and rotate handling.
    '''

    l = logging.getLogger(logger_name)

    if not getattr(l, 'handler_set', None):
        logging.Formatter.converter = time.gmtime
        formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')

        rotatehandler = RotatingFileHandler(log_file, mode='a', maxBytes=10485760, backupCount=10)
        rotatehandler.setFormatter(formatter)

        #TODO: Debug stream handler for development
        #streamHandler = logging.StreamHandler()
        #streamHandler.setFormatter(formatter)
        #l.addHandler(streamHandler)

        l.addHandler(rotatehandler)
        l.setLevel(level)
        l.handler_set = True

    elif not os.path.exists(log_file):
        logging.Formatter.converter = time.gmtime
        formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')

        rotatehandler = RotatingFileHandler(log_file, mode='a', maxBytes=10485760, backupCount=10)
        rotatehandler.setFormatter(formatter)

        #TODO: Debug stream handler for development
        #streamHandler = logging.StreamHandler()
        #streamHandler.setFormatter(formatter)
        #l.addHandler(streamHandler)

        l.addHandler(rotatehandler)
        l.setLevel(level)
        l.handler_set = True

    return l


def manage_log_dirs():
    '''
    Manages log files historical and current directories.
    '''

    cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    parser = SafeConfigParser()
    parser.read(cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

    log_dir = '%s/%s' % (cloudsurf_base_path, parser.get('config_logger', 'log_dir'))
    hist_dir = '%s/%s' % (cloudsurf_base_path, parser.get('config_logger', 'hist_dir'))

    if os.path.exists(log_dir):
        old_log_dir = ('%s_%s') % (log_dir, int(time.time()))
        os.rename(log_dir, old_log_dir)
        os.renames(old_log_dir, hist_dir + old_log_dir[old_log_dir.rfind('/'):])
    os.mkdir(log_dir)

    return


def return_loggers():
    '''
    Return info and debug log objects.
    '''

    cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    parser = SafeConfigParser()
    parser.read(cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

    log_dir = '%s/%s' % (cloudsurf_base_path, parser.get('config_logger', 'log_dir'))
    info_log_file = '%s/%s' % (log_dir, parser.get('config_logger', 'info_log_file_name'))
    debug_log_file = '%s/%s' % (log_dir, parser.get('config_logger', 'debug_log_file_name'))

    if not os.path.exists(log_dir):
        os.mkdir(log_dir)

    info_log = setup_logger('info', info_log_file, logging.INFO)
    debug_log = setup_logger('debug', debug_log_file, logging.DEBUG)

    return info_log, debug_log

