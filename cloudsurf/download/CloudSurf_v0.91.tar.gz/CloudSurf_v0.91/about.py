#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
from core.banner import Banner
from core.utils import clear
from core.meta import Meta
from core.colors import bcolors
from core.prompt import Prompt

import interactive

def main():
    msg = """\n %s allows public-cloud customers to benchmark the performance of the network of public cloud infrastructures in many different ways.""" % Meta.name
    msg += """\n It is the result of recent studies about non-cooperative approaches for the monitoring of the performance of the network of these complex systems."""
    msg += """\n For more information about our research, visit us at http://traffic.comics.unina.it/cloud."""
    msg = """%s""" % msg

    msg2 = """\n\n Main features:\n  * Support to public-cloud leader providers (Amazon, Azure)\n  * Ready to use (no need to manually setup cloud resources, measurement tools, etc.) \n  * Cost forecasting (know in advance how much your test will cost)"""
    msg2 = """%s%s%s%s""" %(bcolors.BOLD, bcolors.BLUE, msg2, bcolors.ENDC)


    msg3 = """\n\n Contributors:\n  > Valerio Persico (valerio.persico [a t !] unina \dot it)\n  > Antonio Montieri (montieri [a t !] nm-2 \dot com)"""
    msg3 = """%s%s%s""" %(bcolors.GREEN, msg3, bcolors.ENDC)

    clear()
    Banner.show_graphic_text()
    raw_input(Prompt.press_a_key(msg+msg2+msg3))
    return
