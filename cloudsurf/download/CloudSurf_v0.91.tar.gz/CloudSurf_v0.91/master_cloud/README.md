Master XMLRPC: 'master_cloud.py'
In questa prima versione permette l'esecuzione sequenziale di esperimenti specificati nel file 'XMLRPC_wrapper/master/campaign/CAMPAIGN_FILE.txt'.

Passi preliminari:
- Creare il file 'CAMPAIGN_FILE.txt' contenente la lista degli esperimenti della campagna da condurre. 
  La riga generica relativa al singolo esperimento ha la seguente sintassi:
	TOOL IP_RECEIVER IP_SENDER PORT_RECEIVER PORT_SENDER PORT PROTOCOL DURATION BANDWIDTH OUTDIR [INTERVAL] [METRIC] [CLIENT_TAG]

N.B. Per informazioni più dettagliate relative ai tool supportati, fare riferimento al codice di 'master_cloud.py'.

Utilizzo:
- Lanciare il client XMLRCP_wrapper/master/master_cloud_sequentially.py 'CAMPAIGN_FILE.txt'
- Per il prelievo dei risultati inserire in coda al file 'CAMPAIGN_FILE.txt' la seguente riga:
	PULL IP_SERVER KEY_PATH HOME_PATH_SERVER HOME_PATH_CLIENT OUTDIR
	(Es.: PULL 52.11.46.90 /home/ubuntu/key_name.pem /home/ubuntu /home/ubuntu exp_1424874538)
