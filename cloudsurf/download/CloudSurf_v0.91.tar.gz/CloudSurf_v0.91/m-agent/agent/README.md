Agent XMLRPC per il wrapping di diversi tool, eseguibili in remoto attraverso l'interfaccia XMLRPC implementata.
Passi preliminari:
- Creare nella cartella 'agent/script_tool' gli scripts 'TOOL.sh' per la gestione dell'esecuzione del/i 'TOOL' di interesse
- Creare un file di configurazione per il deployment dell'agent nella directory 'agent/conf', con la seguente sintassi:
	[config_agent]
	port = 30000
	interface = eth0
	tool_dir = script_tool
	res_dir = res
	log_dir = log

Utilizzo:
- Lanciare l'agent: sudo agent/agent_measurement.py 'ABSOLUTE_AGENT_PATH'
Dove con ABSOLUTE_AGENT_PATH si intende il path assoluto della directory 'agent' (Es. '/home/ubuntu/XMLRPC_wrapper/agent').
ATTENZIONE: Lanciare l'agent come superuser.

N.B Le informazioni di log vengono memorizzate nella cartella agent/log in tre files distinti:
	'command_log.log', 'state_log.log' ed 'error_log.log'
    Inoltre a ciascuna campagna sperimentale è associato un log file 'name_campaign.log' in cui sono memorizzate le informazioni temporali relative
    a ciascun esperimento costituente la campagna stessa.
