#! /bin/bash -x
#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

#DITG packager

if [[ $# -lt 4 ]];
   then echo "usage $0 <PROTO> <METER> <OUTDIR> <INDEX> <M|D>";
   echo "M: move DITG logs to $DITG_basket"
   echo "D delete DITG logs"
   exit 1 ;
fi

#ITGDEC=~/Desktop/Utility/D-ITG-new-features/bin/ITGDec
ITGDEC=~/D-ITG-new-features/bin/ITGDec

PROTO=$1
METER=$2
OUTDIR=$3
INDEX=$4
ACTION=$5

BASEDIR=.
DITG_basket=$BASEDIR/DITG_log_basket/log_basket_$INDEX
R_DATADIR=$BASEDIR/$OUTDIR/d-itg_$INDEX/receiver

R_FILENAME=$(echo $R_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )_$PROTO'_'$METER

if [ -d $DITG_basket ]; then
    echo "$DITG_basket exists."
else
    mkdir -p $DITG_basket
fi

if [ -d $R_DATADIR ]; then
    echo "$R_DATADIR exists."
else
    echo "ERROR: $R_DATADIR doesn't exists."
	exit 1
fi

#sudo chmod -R 777 $BASEDIR/$OUTDIR

NEWNAME=$(echo $R_DATADIR/$R_FILENAME.log | sed -e s/.log/.dat/g)

sudo $ITGDEC $R_DATADIR/$R_FILENAME.log -c 100 $NEWNAME &
echo $! 1>$R_DATADIR/$R_FILENAME'_packager.pid'

sleep 3

if [[ $ACTION == 'D' ]];
then
rm $R_DATADIR/$R_FILENAME.log
else
mv $R_DATADIR/$R_FILENAME.log $DITG_basket
fi

exit 0
