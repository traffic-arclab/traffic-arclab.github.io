#! /bin/bash -x

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

if [[ $# -lt 3 ]];
	then echo "usage $0 <DESTINATION> <PROTO> <PORT> <OUTDIR> <INDEX> ";
	exit 1 ;
fi

DESTINATION=$1
PROTO=$2
PORT=$3
OUTDIR=$4
INDEX=$5

PARIS=paris-traceroute

#MARGINE=10		#10s
#DURATION=$(((DURATION / 1000)+MARGINE))

BASEDIR=.

S_DATADIR=$BASEDIR/$OUTDIR/paris_$INDEX/sender
LOGDIR=$BASEDIR/$OUTDIR/paris_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_')_$PROTO

if [ -d $S_DATADIR ]; then		#Se la cartella $S_DATADIR esiste... Stampo un messaggio
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR			#Altrimenti la creo
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi


$PARIS -n -M 10 -T 1000 --algo=exhaustive -p $PROTO -d $PORT $DESTINATION 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &

echo $! 1>$S_DATADIR/$S_FILENAME.pid

wait
exit 0
