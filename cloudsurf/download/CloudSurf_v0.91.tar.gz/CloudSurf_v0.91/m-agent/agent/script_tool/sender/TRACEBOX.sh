#! /bin/bash

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

set -eu
DESTINATION=invalid
PARAMS=invalid
OUTDIR=invalid

usage () { # {{
cat <<-USAGE
usage: $0 -d DESTINATION -p PARAMS -o OUTDIR [-h]
DESTINATION is a targeted IP. PARAMS is the string to use as argument of
tracebox [-p] option. OUTDIR specifies where storing the results.
USAGE
exit 1
} # }}}

while getopts "d:p:o:h" OPTNAME ; do # {{{
case $OPTNAME in
d)
DESTINATION=$OPTARG
;;
p)
PARAMS=$OPTARG
;;
o)
OUTDIR=$OPTARG
;;
h|*)
usage
;;
esac
done # }}}

if [ $DESTINATION = invalid ] ; then usage ; fi
if [ $PARAMS = invalid ] ; then usage ; fi
if [ $OUTDIR = invalid ] ; then usage ; fi

TRACEBOX=~/tracebox/tracebox

BASEDIR=.

S_DATADIR=$BASEDIR/$OUTDIR/tracebox_sender
LOGDIR=$BASEDIR/$OUTDIR/tracebox_log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_')

if [ -d $S_DATADIR ]; then		#Se la cartella $S_DATADIR esiste... Stampo un messaggio
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR			#Altrimenti la creo
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

$TRACEBOX -n -p $PARAMS 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out

echo $! 1>$S_DATADIR/$S_FILENAME.pid

wait
exit 0
