#! /bin/bash -x

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

if [[ $# -lt 5 ]];
	then echo "usage $0 <MESSAGE SIZE [B,K,M]> <DESTINATION> <PORT> <DURATION [r]> <OUTDIR> <INDEX>";
	exit 1 ;
fi

MSGSIZE=$1
DESTINATION=$2
PORT=$3
DURATION=$4
OUTDIR=$5
INDEX=$6

UDPTEST=~/tools/udp/udptest

DURATION=$((DURATION))

BASEDIR=.

S_DATADIR=$BASEDIR/$OUTDIR/udptest_$INDEX/sender
LOGDIR=$BASEDIR/$OUTDIR/udptest_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_')

if [ -d $S_DATADIR ]; then		#Se la cartella $S_DATADIR esiste... Stampo un messaggio
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR			#Altrimenti la creo
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

# dovrebbe essere -t $DURATION ma non funziona, r considera le ripetizioni dei test, che avvengono ogni secondo
# application.out viene creato solo se tutto va a buon fine
CMD="$UDPTEST -ah $DESTINATION -p $PORT -A $MSGSIZE -r $DURATION -P -o $S_DATADIR/application.out"
timeout -s 2 -k 5 $DURATION tcpdump -i eth0 -w $S_DATADIR/$S_FILENAME.pcap &
timeout -s 2 -k 5 $DURATION $CMD 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &
#timeout -s 2 invia un segnale SIGINT (ctrl+c) dopo DURATION

echo $! 1>$S_DATADIR/$S_FILENAME.pid


wait
exit 0
