#! /bin/bash -x

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

if [[ $# -lt 3 ]];
  	then echo "usage $0 <DESTINATION> <PORT> <OUTDIR> <INDEX>";
	exit 1 ;
fi

YAZ=~/Desktop/Utility/yaz-master/yaz
#YAZ=~/yaz-master-src/yaz

DESTINATION=$1
PORT=$2
OUTDIR=$3
INDEX=$4

BASEDIR=.
S_DATADIR=$BASEDIR/$OUTDIR/yaz_$INDEX/sender
LOGDIR=$BASEDIR/$OUTDIR/yaz_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )

if [ -d $S_DATADIR ]; then
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi


$YAZ -S $DESTINATION -p 3000 -P $PORT -m 1 -r 10000.0 1> $S_DATADIR/$S_FILENAME.out 2> $LOGDIR/$S_FILENAME.err &

echo $! 1>$S_DATADIR/$S_FILENAME.pid

wait
exit 0
