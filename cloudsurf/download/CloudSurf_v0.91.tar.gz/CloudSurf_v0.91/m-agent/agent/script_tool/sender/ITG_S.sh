#! /bin/bash -x

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

if [[ $# -lt 7 ]];
  	then echo "usage $0 <DESTINATION> <PORT> <PROTO> <DURATION [s]> <BANDWIDTH [bits/s]> <METER> <OUTDIR> <INDEX>";
	exit 1 ;
fi

#ITG_S=~/Desktop/Utility/D-ITG-new-features/bin/ITGSend
ITG_S=~/D-ITG-new-features/bin/ITGSend

DESTINATION=$1
PORT=$2
PROTO=$3
DURATION=$4
BANDWIDTH=$5
METER=$6
OUTDIR=$7
INDEX=$8

BWDT=$((BANDWIDTH/8))
PSIZE=1500

DURATION=$((DURATION*1000))

#setting packet size
if [[ $PROTO == "udp" ]]
then
	PSIZE=$((PSIZE - 28)); #eth MTU = 1500; IP = 20; UDP=8;
elif [[ $PROTO == "tcp" ]]
then
	PSIZE=$((PSIZE - 72)); # eth MTU = 1500; IP = 20; TCP=20+12; +20Byte tolleranza per evitare frammentazione
else
	exit 1;
fi;

PRATE=$(((BWDT/PSIZE)+1))

BASEDIR=.
S_DATADIR=$BASEDIR/$OUTDIR/d-itg_$INDEX/sender
R_DATADIR=$BASEDIR/$OUTDIR/d-itg_$INDEX/receiver

LOGDIR=$BASEDIR/$OUTDIR/d-itg_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )_$PROTO'_'$METER
R_FILENAME=$(echo $R_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )_$PROTO'_'$METER

if [ -d $S_DATADIR ]; then
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR
fi

#if [ -d $R_DATADIR ]; then
#    echo "$R_DATADIR exists."
#else
#    mkdir -p $R_DATADIR
#fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi


if [[ $PROTO == "udp" ]]
then
	$ITG_S -poll -T $PROTO -a $DESTINATION -m $METER -Sdp 4001 -rp $PORT -c $PSIZE -C $PRATE -t $DURATION -l $S_DATADIR/$S_FILENAME.log -x $R_DATADIR/$R_FILENAME.log 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &
	echo $! 1>$S_DATADIR/$S_FILENAME.pid

elif [[ $PROTO == "tcp" ]]
then
	$ITG_S -poll -T $PROTO -a $DESTINATION -m $METER -Sdp 4000 -rp $PORT -c $PSIZE -C $PRATE -t $DURATION -l $S_DATADIR/$S_FILENAME.log -x $R_DATADIR/$R_FILENAME.log 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &
	echo $! 1>$S_DATADIR/$S_FILENAME.pid

else
	exit 1;
fi;

wait
exit 0
