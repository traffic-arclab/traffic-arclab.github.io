#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 26 gen 2016

@author: antonio
'''

from core.banner import Banner
from core.utils import clear
from core.meta import Meta
from core.colors import bcolors
from core.prompt import Prompt

def main():
    msg = """\n %sDetailed information about first time configuration of %s can be get at:%s""" % (bcolors.BLUE, Meta.name, bcolors.ENDC)
    msg += """\n %s%s%s%s""" % (bcolors.BOLD, bcolors.BLUE, Meta.first_time, bcolors.ENDC)
    msg += """\n\n %sIf you don't have an AWS account check %s%s%s%s to create a free account and try %s for free!%s""" % (bcolors.GREEN, bcolors.BOLD, Meta.aws, bcolors.ENDC, bcolors.GREEN, Meta.name, bcolors.ENDC)
    msg = """%s""" % msg

    clear()
    Banner.show_graphic_text()
    raw_input(Prompt.press_a_key(msg))
    return