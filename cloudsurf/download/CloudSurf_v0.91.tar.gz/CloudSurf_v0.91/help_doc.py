#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 26 gen 2016

@author: antonio
'''

from core.banner import Banner
from core.utils import clear
from core.meta import Meta
from core.colors import bcolors
from core.prompt import Prompt

def main():
    msg = """\n %s%s documentation containing information about: \n * Supported modes\n * Preconfigured experiments\n * Output format\n * ...and much more\n can be found at """ % (bcolors.BLUE, Meta.name)
    msg += """%s%s%s""" % (bcolors.BOLD, Meta.documentation, bcolors.ENDC)
    msg += """\n\n %sFor specific issues contact developers:""" % bcolors.GREEN
    msg += """\n  > Valerio Persico (valerio.persico [a t !] unina \dot it)\n  > Antonio Montieri (montieri [a t !] nm-2 \dot com)%s""" % bcolors.ENDC
    msg = """%s""" % msg

    clear()
    Banner.show_graphic_text()
    raw_input(Prompt.press_a_key(msg))
    return