#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import re
import sys
import core.utils

from logger import setup_logging
from core.meta import Meta
from core.banner import Banner
from core.menus import Menu, Menus
from core.prompt import Prompt
from core.colors import bcolors

import about
import intra_datacenter
import inter_datacenter
import check_previous_results
import first_time
import help_doc
import not_implemented

# interactive vs from_file
# conf_file = "%s/%s/%s" % (os.path.dirname(os.path.abspath(__file__)), "conf", "app_master.ini")


def exit():
    Banner.show_exit_banner()
    sys.exit(0)


def main():
    try:
        info_log, debug_log = setup_logging.return_loggers()
        while True:
            Banner.show_banner(Meta.name, Meta.version, Meta.authors, Meta.affiliation, Meta.contact, Meta.home, Meta.visit)
            mm = Menu(Menus.main["head"], Menus.main["body"])
            mm.show()

            # special case of list item 99
            print '\n  99) Exit\n'

            # main core menu
            main_menu_choice = (raw_input(Prompt.simple()))

            # quit out
            if main_menu_choice == 'exit' or main_menu_choice == "99" or main_menu_choice == "quit":
                debug_log.info('Exit from CloudSurf')
                info_log.info('Exit from CloudSurf')
                exit()

            elif main_menu_choice == '1':
                try:
                    intra_datacenter.main()
                except KeyboardInterrupt:
                    pass
                except SystemExit:
                    sys.exit(0)
                except:
                    debug_log.error('Something went wrong in Intra-Datacenter mode!')
                    err_str = "\n Something went wrong in Intra-Datacenter mode!\n More information on occurred errors are in "\
                    + bcolors.UNDERL +"cloudsurf/log/debug.log" + bcolors.ENDC + "."
                    err_str = "%s%s%s" %(bcolors.RED_BOLD, err_str, bcolors.ENDC)
                    raw_input(Prompt.press_a_key(err_str))

            elif main_menu_choice == '2':
                try:
                    inter_datacenter.main()
                except KeyboardInterrupt:
                    pass
                except SystemExit:
                    sys.exit(0)
                except:
                    debug_log.error('Something went wrong in Inter-Datacenter mode!')
                    err_str = "\n Something went wrong in Inter-Datacenter mode!\n More information on occurred errors are in "\
                    + bcolors.UNDERL +"cloudsurf/log/debug.log" + bcolors.ENDC + "."
                    err_str = "%s%s%s" %(bcolors.RED_BOLD, err_str, bcolors.ENDC)
                    raw_input(Prompt.press_a_key(err_str))
                    
            elif main_menu_choice == '3':
                try:
                    not_implemented.main()
                except:
                    pass
            
            elif main_menu_choice == '4':
                try:
                    not_implemented.main()
                except:
                    pass
                
            elif main_menu_choice == '5':
                try:
                    not_implemented.main()
                except:
                    pass
            
            elif main_menu_choice == '6':
                try:
                    check_previous_results.main()
                except:
                    pass
                    
            elif main_menu_choice == '7':
                try:
                    first_time.main()
                except:
                    pass
                
            elif main_menu_choice == '8':
                try:
                    help_doc.main()
                except:
                    pass

            elif main_menu_choice == '9':
                try:
                    about.main()
                except:
                    pass

            #elif main_menu_choice == '10':
                #try:
                    #page_template.main()
                #except
                #    print "ECCEZZZZZZZZZIONE"
                #    raw_input()
                #    pass

            else:
                try:
                    continue
                except:
                    pass


    # handle keyboard interrupts
    except KeyboardInterrupt:
        debug_log.info('Exit from CloudSurf')
        info_log.info('Exit from CloudSurf')
        exit()

# handle exceptions
#    except Exception, error:
#        print "\n\n[!] Something went wrong, printing the error: "+ str(error)


if __name__ == "__main__":
    main()
