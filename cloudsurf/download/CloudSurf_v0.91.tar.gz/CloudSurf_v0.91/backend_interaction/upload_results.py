#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 13 gen 2016

@author: antonio
'''

import os, time
import gzip, shutil, requests

from ConfigParser import SafeConfigParser
from bs4 import BeautifulSoup

from aws_utils import utils
from logger import setup_logging


class UploadResultsException(Exception):
    '''
    Exception for UploadResults class
    '''
    def __init__(self, message):
        self.message = message
    def __str__(self):
        return str(self.message)


class UploadResults(object):
    '''
    Facilities for uploading campaigns results on the back-end server
    '''


    def __init__(self, outdir):
        '''
        Constructor for UploadResults class
        '''

        self.outdir = outdir

        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        self.results_container = self.parser.get('config_experiment', 'results_container')

        self.backend_servlet_address = self.parser.get('config_upload', 'backend_servlet_address')
        self.backend_servlet_timeout = self.parser.getint('config_upload', 'backend_servlet_timeout')

        self.except_retries = self.parser.getint('config_upload', 'except_retries')
        self.except_wait = self.parser.getint('config_upload', 'except_wait')

        self.campaign_base_path = '%s/%s/%s' % (self.cloudsurf_base_path, self.results_container, self.outdir)
        self.res_json_filename = '%s/%s_results.json' % (self.campaign_base_path, self.outdir)
        self.gzip_filename = '%s.gz' % self.res_json_filename

        self.info_log, self.debug_log = setup_logging.return_loggers()

    def compress(self):
        '''
        Campaign results .json file compression with .gz extension
        '''

        self.debug_log.debug('Compressing campaign results file: %s' % self.res_json_filename)

        with open(self.res_json_filename, 'rb') as res_json_file, gzip.open(self.gzip_filename, 'wb') as gzip_file:
            shutil.copyfileobj(res_json_file, gzip_file)

        self.debug_log.debug('Campaign results file successfully compressed: %s' % self.res_json_filename)
        return


    def upload(self):
        '''
        Upload campaign results in .gz compressed format
        '''

        self.debug_log.info('Uploading campaign results file: %s' % self.gzip_filename)
        self.info_log.info('Uploading campaign results file: %s' % self.gzip_filename)

        self.compress()

        uploaded = False
        retries = self.except_retries
        while not uploaded and retries > 0:
            try:
                #Compressed .gz file upload
                with open(self.gzip_filename, 'rb') as upload_file:
                    files = {'file': upload_file}
                    response = requests.post(self.backend_servlet_address, files=files, timeout=self.backend_servlet_timeout)

                #Raise an exception if response.status_code isn't successful
                response.raise_for_status()

                soup = BeautifulSoup(response.content, 'html.parser')
                if soup.title.get_text() == 'CloudSurf back-end upload':
                    if soup.body.get_text().count('Uploaded Filename: %s' % os.path.basename(self.gzip_filename)) == 1:
                        uploaded = True
                    elif soup.body.get_text() == 'No file uploaded':
                        err_str = "Invalid POST request: it doesn't contain multipart content"
                        raise UploadResultsException(err_str)
                    elif soup.body.get_text() == 'Filename %s is not a valid JSON file' % os.path.basename(self.gzip_filename):
                        err_str = "Invalid JSON file"
                        raise UploadResultsException(err_str)
                    else:
                        err_str = "Malformed POST response body"
                        raise UploadResultsException(err_str)

                elif soup.title.get_text() == 'CloudSurf back-end exception raised':
                    err_str = "CloudSurf BackEnd raised exception: %s" % soup.body.get_text()
                    raise UploadResultsException(err_str)

                else:
                    err_str = "Malformed POST response"
                    raise UploadResultsException(err_str)

            except Exception, e:
                m = utils.exception_parser(e)
                err_str = 'Upload results error [%s]: %s' % (self.gzip_filename, m)
                self.debug_log.warning(err_str)
                retries = retries - 1
                time.sleep(self.except_wait)

        if os.path.exists(self.gzip_filename):
            os.remove(self.gzip_filename)
        
        if not uploaded:
            self.debug_log.error(err_str)
            raise UploadResultsException(err_str)

        self.debug_log.info('Campaign results file successfully uploaded: %s' % self.gzip_filename)
        self.info_log.info('Campaign results successfully uploaded: %s' % self.gzip_filename)
        return uploaded
