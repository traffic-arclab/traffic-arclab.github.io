#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
import sys
import os
from banner import Banner
from colors import bcolors
from progressbar import ProgressBar, AnimatedMarker, BouncingBar, Timer, UnknownLength

def spinner():
    pbar = ProgressBar(widgets=['Working: ', AnimatedMarker()])
    for _ in pbar((i for i in range(50))):
        time.sleep(.08)

def task_resume(head, task_list, task_index, not_finished):
    widgets = [Timer(), BouncingBar()]
    pbar = ProgressBar(widgets=widgets, maxval=UnknownLength, fd=sys.stderr).start()
    i = 0

    done_list = task_list[:task_index]
    todo_list = task_list[task_index+1:]

    while not_finished.locked():
        i += 1
        pbar.update(i+1)
        time.sleep(0.05)
        os.system("clear")

        Banner.show_graphic_text()
        print "%s\n %s%s\n" %(bcolors.BOLD, head, bcolors.ENDC)
        if task_index > 0:
            print "%s%s%s" % (bcolors.GREEN, u" [\u2713]", bcolors.ENDC),
        print u"%s%s%s" %(bcolors.GREEN, u"\n [\u2713] ".join(done_list), bcolors.ENDC)
        print u" %s[-] %s%s" %(bcolors.YELLOW, task_list[task_index], bcolors.ENDC)
        if todo_list:
            print u" %s[ ] %s%s" %(bcolors.GRAY," \n [ ] ".join(todo_list), bcolors.ENDC)
        print u"\n Experiment in progress, please wait...\n"
    pbar.finish()


if __name__ == "__main__":
    pass
