# -*- coding: utf-8 -*-

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from utils import clear
from colors import bcolors
import os
from meta import Meta
class Banner:

    width = 60/2

    @staticmethod
    def show_banner(name, version, author, affiliation, contact, home, visit, graphic=True):
        if graphic:
            clear()
            Banner.show_graphic_text()
            Banner.show_graphic()

        name = "%s" % name
        version = "*version %s*" % version
        author = "Created by %s" % author
        affiliation = affiliation
        contact = "Contact me at %s" % contact
        home = "Homepage: %s" % home
        visit = "Visit us at %s" % visit

        k = Banner.width
        head1 = "%s%s" % ((k-len(name)/2)*" ", name )
        head2 = "%s%s" % ((k-len(version)/2)*" ", version)
        head3 = "%s%s" % ((k-len(author)/2)*" ", author)
        head33 = "%s%s" % ((k-len(affiliation)/2)*" ", affiliation)
        head4 = "%s%s" % ((k-len(contact)/2)*" ", contact)
        head5 = "%s%s" % ((k-len(home)/2)*" ", home)
        head6 = "%s%s" % ((k-len(visit)/2)*" ", visit)

        banner = "%s%s%s%s\n" %(bcolors.BOLD, bcolors.CYAN, head1, bcolors.ENDC)
        banner += "%s%s%s\n" %(bcolors.RED, head2, bcolors.ENDC)
        banner += "%s%s%s\n" %(bcolors.YELLOW, head3, bcolors.ENDC)
        banner += "%s%s%s\n" %(bcolors.YELLOW, head33, bcolors.ENDC)
        banner += "%s%s%s\n" %(bcolors.GREEN, head6, bcolors.ENDC)
        banner += "%s%s%s\n" %(bcolors.BLUE, head4, bcolors.ENDC)
        banner += "%s%s%s\n" %(bcolors.BLUE, head5, bcolors.ENDC)
        print banner

    @staticmethod
    def show_graphic_text():
        print bcolors.YELLOW + """  _____  ____   _____  __ __  _____  _____  __ __  _____  _____
 /     \/  _/  /  _  \/  |  \|  _  \/  ___>/  |  \/  _  \/   __\\
 |  |--||  |---|  |  ||  |  ||  |  ||___  ||  |  ||  _  <|   __|
 \_____/\_____/\_____/\_____/|_____/<_____/\_____/\__|\_/\__/""" +  bcolors.ENDC


    @staticmethod
    def show_graphic():
        print bcolors.RED + """
                  ____    o__    Surfing the Cloud...
                   ----   /\\
                    ¯¯¯ ,__<\__
                        °``¯¯``¯   """+bcolors.CYAN+"""
              (`  ).                   _
             (     ).              .:(`  )`.
            _(       '`.          :(   .    )
        .=(`(      .   )     .--  `.  (    ) )
       ((    (..__.:'-'   .+(   )   ` _`  ) )
       `(       ) )       (   .  )     (   )  ._
         ` __.:'   )     (   (   ))     `-'.-(`  )
      ( )       --'       `- __.'         :(      ))
     (_.'          .')                    `(    )  ))
                  (_  )                     ` __.:'""" + bcolors.ENDC + bcolors.GREEN + """
--..,___.--,--'`,---..-.--+--.,,-,,..._.--..-._.---..-_.-.""" + bcolors.ENDC


    @staticmethod
    def show_exit_banner():
        print """\n\nThank you for having """ + bcolors.BLUE+"""surfed""" + bcolors.ENDC+""" with us!"""


    @staticmethod
    def show_graphic2():
        print bcolors.RED + r"""
                      ..:::::::::..
                  ..:::aad8888888baa:::..
              .::::d:?88888888888?::8b::::.
            .:::d8888:?88888888??a888888b:::.
          .:::d8888888a8888888aa8888888888b:::.
         ::::dP::::::::88888888888::::::::Yb::::
        ::::dP:::::::::Y888888888P:::::::::Yb::::
       ::::d8:::::::::::Y8888888P:::::::::::8b::::
      .::::88::::::::::::Y88888P::::::::::::88::::.
      :::::Y8baaaaaaaaaa88P:T:Y88aaaaaaaaaad8P:::::
      :::::::Y88888888888P::|::Y88888888888P:::::::
      ::::::::::::::::888:::|:::888::::::::::::::::
      `:::::::::::::::8888888888888b::::::::::::::'
       :::::::::::::::88888888888888::::::::::::::
        :::::::::::::d88888888888888:::::::::::::
         ::::::::::::88::88::88:::88::::::::::::
          `::::::::::88::88::88:::88::::::::::'
            `::::::::88::88::P::::88::::::::'
              `::::::88::88:::::::88::::::'
                 ``:::::::::::::::::::''
                      ``:::::::::''""" + bcolors.ENDC






if __name__ == "__main__":

    Banner.show_banner(Meta.name, Meta.version, Meta.authors, Meta.affiliation, Meta.contact, Meta.home, Meta.visit)
