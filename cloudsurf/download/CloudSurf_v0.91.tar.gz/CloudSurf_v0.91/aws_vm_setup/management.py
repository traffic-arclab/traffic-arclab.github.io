#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 25 nov 2015

@author: antonio
'''

import os, time

from aws_utils import utils
from logger import setup_logging
from ConfigParser import SafeConfigParser


class VMManagementException(Exception):
    '''
    Exception for VMManagement class
    '''
    def __init__(self, message):
        self.message = message
    def __str__(self):
        return str(self.message)


class VMManagement:
    '''
    Class for life cycle management of a single Amazon EC2 VM (instance)
    '''

    def __init__(self, ec2_connection, vm_type, placement, key_name, security_group_name):
        '''
        Initialize VMManagement object.
        '''

        self.ec2_connection = ec2_connection
        self.vm_type = vm_type
        self.placement = placement
        self.key_name = key_name
        self.security_group_name = security_group_name
        self.running = False

        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        self.except_retries = self.parser.getint('config_vm', 'except_retries')
        self.except_wait = self.parser.getint('config_vm', 'except_wait')

        self.info_log, self.debug_log = setup_logging.return_loggers()


    def __select_ami(self):
        '''
        Return a boto.ec2.image.Image object based on selected AMI
        '''

        ami_architecture = self.parser.get('config_vm', 'ami_architecture')
        ami_name = self.parser.get('config_vm', 'ami_name')
        ami_owner = self.parser.get('config_vm', 'ami_owner')
        #Canonical: '099720109477'

        self.debug_log.debug('Retrieving AMI ID of image %s' % ami_name)

        filters = {
            'architecture': ami_architecture,
            'name': ami_name
        }

        selected_ami = self.ec2_connection.get_all_images(owners=[ami_owner], filters=filters)[0]
        self.debug_log.debug('AMI ID retrieved: %s' % selected_ami)

        return selected_ami


    def get_vm(self):
        '''
        Return boto.ec2.instance object obtained from launch_vm
        '''
        return self.vm


    def is_running(self):
        '''
        Return True or False depending on VM is running or not
        '''
        return self.running


    def launch_vm(self, queue):
        '''
        Launch VM with selected option.
        Raise an exception if launch fails <except_retries> times.
        '''

        self.debug_log.info('Launching VM - type: %s, placement: %s' % (self.vm_type, self.placement))
        self.info_log.info('Launching VM - type: %s, placement: %s' % (self.vm_type, self.placement))

        launched = False
        retries = self.except_retries

        while not launched and retries > 0:
            try:
                reservation = self.__select_ami().run(
                    key_name = self.key_name,
                    instance_type = self.vm_type,
                    placement = self.placement,
                    security_groups = [self.security_group_name],
                    monitoring_enabled = True,
                    instance_initiated_shutdown_behavior = 'terminate'
                    )
                launched = True
            except Exception, e:
                m = utils.exception_parser(e)
                err_str = 'Launch VM Error [%s - %s]: %s' % (self.vm_type, self.placement, m)
                self.debug_log.warning(err_str)
                retries = retries - 1
                time.sleep(self.except_wait)

        if not launched:
            self.debug_log.error(err_str)
            raise VMManagementException(err_str)

        self.vm = reservation.instances[0]
        self.running = launched
        queue.put_nowait(launched)

        self.debug_log.info("VM successfully launched - id: %s, type: %s, placement: %s" % (self.vm.id, self.vm.instance_type, self.vm.placement))
        self.info_log.info("VM successfully launched - id: %s, type: %s, placement: %s" % (self.vm.id, self.vm.instance_type, self.vm.placement))

        return self.vm


    def running_check_barrier(self, queue):
        '''
        Check if VM is completely running, that is it passes both status checks.
        Status check is performed every check_interval seconds.
        '''

        self.debug_log.info('Status check on VM - id: %s, type: %s, placement: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement))
        self.info_log.info('Status check on VM - id: %s, type: %s, placement: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement))

        check_interval = self.parser.getint('config_vm', 'running_check_wait')
        max_check_retries = self.parser.getint('config_vm', 'running_check_retries')
        check_retries = max_check_retries
        except_retries = self.except_retries

        while check_retries > 0 and except_retries > 0:
            try:
                status_check = 0
                state = self.vm.update()
                if state == 'running':
                    statuses = self.ec2_connection.get_all_instance_status(instance_ids=[self.vm.id])[0]
                    status_check = [
                        statuses.instance_status.details['reachability'] == 'passed',
                        statuses.system_status.details['reachability'] == 'passed'].count(True)

                current_check_retry = max_check_retries - check_retries + 1
                self.debug_log.debug("Check %s: [%s - %s] - status check: %s/2" % (current_check_retry, self.vm.id, state, status_check))

                if status_check == 2:
                    break
                else:
                    check_retries -= 1
                    time.sleep(check_interval)

            except Exception, e:
                m = utils.exception_parser(e)
                err_str = 'Checking VM status error [%s - %s - %s]: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement, m)
                self.debug_log.warning(err_str)
                except_retries -= 1
                time.sleep(self.except_wait)

        if status_check != 2 and except_retries == 0:
            self.debug_log.error(err_str)
            raise VMManagementException(err_str)
        elif status_check != 2 and except_retries > 0:
            self.debug_log.error('Maximum number of status checks retries reached: [%s - %s - %s]' % (self.vm.id, self.vm.instance_type, self.vm.placement))
            raise VMManagementException('Maximum number of status checks retries reached: [%s - %s - %s]' % (self.vm.id, self.vm.instance_type, self.vm.placement))

        queue.put_nowait(True)

        self.debug_log.info('Checked status of VM - id: %s, type: %s, placement: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement))
        self.info_log.info('Checked status of VM - id: %s, type: %s, placement: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement))
        return


    def terminate_vm(self):
        '''
        Terminate VM managed by current object.
        Raise an exception if termination fails <except_retries> times.
        '''

        self.debug_log.info('Terminating VM - id: %s, type: %s, placement: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement))
        self.info_log.info('Terminating VM - id: %s, type: %s, placement: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement))

        terminated_check_wait = self.parser.getint('config_vm', 'terminated_check_wait')
        retries = self.except_retries

        while self.vm.state != 'terminated' and retries > 0:
            try:
                self.vm.terminate()
                time.sleep(terminated_check_wait)
                self.vm.update()
            except Exception, e:
                m = utils.exception_parser(e)
                err_str = 'Terminate VM Error [%s - %s - %s]: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement, m)
                self.debug_log.warning(err_str)
                retries = retries - 1
                time.sleep(self.except_wait)

        if self.vm.state != 'terminated':
            self.debug_log.error(err_str)
            raise VMManagementException(err_str)

        self.running = False

        self.debug_log.info('VM successfully terminated - id: %s, type: %s, placement: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement))
        self.info_log.info('VM successfully terminated - id: %s, type: %s, placement: %s' % (self.vm.id, self.vm.instance_type, self.vm.placement))
        return
