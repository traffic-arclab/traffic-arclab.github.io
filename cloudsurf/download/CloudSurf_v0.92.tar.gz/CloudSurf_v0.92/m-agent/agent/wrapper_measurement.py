#! /usr/bin/python

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.


import os,sys,time,subprocess
import traceback
import logging
import threading
import json

from logging.handlers import RotatingFileHandler

def setup_logger(logger_name, log_file, level=logging.INFO):
	'''
	Funzione d'utilita' per la gestione dei log files.
	'''

	l = logging.getLogger(logger_name)

	logging.Formatter.converter = time.gmtime
	formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')
	#fileHandler = logging.FileHandler(log_file, mode='a')
	#fileHandler.setFormatter(formatter)
	streamHandler = logging.StreamHandler()
	streamHandler.setFormatter(formatter)
	rotatehandler = RotatingFileHandler(log_file, mode='a', maxBytes=10485760, backupCount=10)
	rotatehandler.setFormatter(formatter)

	l.setLevel(level)
	#l.addHandler(fileHandler)
	l.addHandler(streamHandler)
	l.addHandler(rotatehandler)

	return l


def get_next_dir_path(campaign_folder, tool_folder):
	'''
	Riceve in ingresso il nome della directory relativa alla campagna corrente ed il base name della directory
	che conterra' i file di output ed error del tool di interesse.
	Restituisce un indice incrementale INDEX per la creazione di una directory "tool_folder_INDEX", in modo da evitare
	sovrascritture in caso di molteplici esperimenti effettuati con il medesimo tool.
	'''
	highest_num = 0

	print campaign_folder

	if not os.path.exists(campaign_folder):
		return highest_num + 1

	for f in os.listdir(campaign_folder):
		if os.path.isdir(os.path.join(campaign_folder, f)):
			dir_name = os.path.splitext(f)[0]
			try:
				dir_base = dir_name[:(dir_name.rfind('_'))]
				if dir_base == tool_folder:
					dir_num = int(dir_name[(dir_name.rfind('_') + 1):])
					if dir_num > highest_num:
						highest_num = dir_num
			except ValueError:
				'The file name "%s" is not an integer. Skipping' % dir_name

	return highest_num + 1


def write_campaign_log(campaign_folder, exp_dict):
	'''
	Scrive, creandolo se non esiste, un file di log relativo ad una certa campagna, al fine di memorizzare
	le informazioni temporali associate a ciascun esperimento costituente la campagna stessa.
	'''
	campaign_log_name = campaign_folder[(campaign_folder.rfind('/') + 1):]
	campaign_log_path = ('%s/%s.json')%(campaign_folder,campaign_log_name)

	if os.path.exists(campaign_log_path):
		with open(campaign_log_path, 'r') as campaign_log:
			log_dict = json.load(campaign_log)

		log_dict[exp_dict['exp_name']] = exp_dict

		with open(campaign_log_path, 'w') as campaign_log:
			json.dump(log_dict, campaign_log)
	else:
			log_dict = {}
			log_dict[exp_dict['exp_name']] = exp_dict
			with open(campaign_log_path, 'w') as campaign_log:
				json.dump(log_dict, campaign_log)

	return


class wrapper_measurement:

	def __init__(self, ip_agent, path_tool, res_dir, command_log, state_log, error_log):
		self.exit = False
		self.ip_agent = ip_agent
		self.path_tool = path_tool.rstrip('/')
		self.res_dir = res_dir.rstrip('/')
		self.state_dict = {}
		self.lock = threading.RLock()
		self.c_log = setup_logger('command', command_log, logging.INFO)
		self.s_log = setup_logger('setup', state_log, logging.INFO)
		self.e_log = setup_logger('error', error_log, logging.ERROR)


	#################################
	# 			SENDER
	#################################

	def ping_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, protocol, duration, outdir, interval=1, client_tag='exp'):
		'''
		Wrapper lato sender per lo script PING_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'ping')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/PING_S.sh '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(duration) + ' '
		cmd += str(interval) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('ping_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		#Costruzione dizionario per log file esperimento
		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'PING_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': protocol,
			'granularity': interval
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'PING_S', duration, 'running')
		except:
			self.e_log.error("Function PING_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def hping_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, protocol, port, packet_size, duration, outdir, flags=None, interval=1, client_tag='exp'):
		'''
		Wrapper lato sender per lo script HPING_S.sh
			e.g. 	hping_sender('1.2.3.4', 'tcp', '80', '90', '5', 'out_folder', 'SA')
					hping_sender('1.2.3.4', 'udp', '53', '64', '5', 'out_folder', None)
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'hping')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/HPING_S.sh '
		cmd += str(protocol) + ' '
		cmd += str(flags) + ' '
		cmd += str(port) + ' '
		cmd += str(packet_size) + ' '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(duration) + ' '
		cmd += str(interval) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('hping_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		#Costruzione dizionario per log file esperimento
		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'HPING_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': protocol,
			'flags':flags,
			'port': port,
			'pkt_size': packet_size,
			'granularity': interval
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'HPING_S', duration, 'running')
		except:
			self.e_log.error("Function HPING_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def nping_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, protocol, port, packet_size, duration, outdir, flags=None, interval=1, client_tag='exp'):
		'''
		Wrapper lato sender per lo script NPING_S.sh
			e.g. 	nping_sender('1.2.3.4', 'tcp', '80', '90', '5', 'out_folder', 'SYN')
					nping_sender('1.2.3.4', 'udp', '53', '64', '5', 'out_folder', None)
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'nping')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/NPING_S.sh '
		cmd += str(protocol) + ' '
		cmd += str(flags) + ' '
		cmd += str(port) + ' '
		cmd += str(packet_size) + ' '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(duration) + ' '
		cmd += str(interval) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('nping_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'NPING_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': protocol,
			'flags':flags,
			'port': port,
			'pkt_size': packet_size,
			'granularity': interval
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'NPING_S', duration, 'running')
		except:
			self.e_log.error("Function NPING_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def nuttcp_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, proto, duration, bandwidth, outdir, client_tag='exp'):
		'''
		Wrapper lato sender per lo script NUTTCP_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'nuttcp')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/NUTTCP_S.sh '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(port) + ' '
		cmd += str(proto) + ' '
		cmd += str(duration) + ' '
		cmd += str(bandwidth) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('nuttcp_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender_%s.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'NUTTCP_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': proto,
			'port': port,
			'target_bwd': bandwidth,
			'granularity': 0.1
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'NUTTCP_S', duration, 'running')
		except:
			self.e_log.error("Function NUTTCP_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def ditg_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, proto, duration, bandwidth, outdir, meter='owdm', client_tag='exp'):
		'''
		Wrapper lato sender per lo script ITG_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'd-itg')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/ITG_S.sh '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(port) + ' '
		cmd += str(proto) + ' '
		cmd += str(duration) + ' '
		cmd += str(bandwidth) + ' '
		cmd += str(meter) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('d-itg_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender_%s_%s.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto,meter)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'DITG_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': proto,
			'port': port,
			'target_bwd': bandwidth,
			'meter': meter,
			'granularity': 0.1
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'ITG_S', duration, 'running')
		except:
			self.e_log.error("Function DITG_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def yaz_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, outdir, client_tag='exp'):
		'''
		Wrapper lato sender per lo script YAZ_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'yaz')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/YAZ_S.sh '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(port) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('yaz_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'YAZ_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'protocol': proto
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'YAZ_S', 'NaN', 'running')
		except:
			self.e_log.error("Function YAZ_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def pathload_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, outdir, client_tag='exp'):
		'''
		Wrapper lato sender per lo script PATHLOAD_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'pathload')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/PATHLOAD_S.sh '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('pathload_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'PATHLOAD_S',
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'PATHLOAD_S', 'NaN', 'running')
		except:
			self.e_log.error("Function PATHLOAD_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def traceroute_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, proto, port, outdir, client_tag='exp'):
		'''
		Wrapper lato sender per lo script TRACEROUTE_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'traceroute')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/TRACEROUTE.sh '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(proto) + ' '
		cmd += str(port) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('traceroute_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender_%s.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'TRACEROUTE',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'protocol': proto,
			'port': port
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'TRACEROUTE', 'NaN', 'running')
		except:
			self.e_log.error("Function TRACEROUTE_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id

	#TODO - agent tracebox
	def tracebox(self, destination, params, outdir, client_tag='exp'):
		"""
		Collects a tracebox trace towards "destination" using params as -p string
		"""

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/TRACEBOX.sh '
		cmd += ' -d ' + str(destination)
		cmd += ' -p ' + str(proto)
		cmd += ' -o ' + str(outdir) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		pid_file = ('%s/%s/tracebox/%s_tracebox_%s.pid')%(os.getcwd(),outdir,outdir,proto)
		pid = open(pid_file, 'r').readline().rstrip('\n')
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		#Critical section
		self.lock.acquire()
		try:
		    self.c_log.info('%s: command: %s', exp_id, cmd)
		    self.set_state(exp_id, pid, timestamp, 'TRACEBOX', 'NaN', 'running')
		except:
			self.e_log.error("Function TRACEBOX() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()

		#End of critical section

		return exp_id


	def paris_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, proto, src_port, dst_port, outdir, client_tag='exp'):
		'''
		Wrapper lato sender per lo script PARIS_TRACEROUTE_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'paris')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/PARIS_TRACEROUTE.sh '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(proto) + ' '
		cmd += str(src_port) + ' '
		cmd += str(dst_port) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('paris_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender_%s.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'PARIS_TRACEROUTE',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'protocol': proto,
			'src_port': src_port,
			'dst_port': dst_port
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'PARIS_TRACEROUTE', 'NaN', 'running')
		except:
			self.e_log.error("Function PARIS_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def nuttcp_paris_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, proto, duration, bandwidth, outdir, client_tag='exp'):
		'''
		Wrapper lato sender per lo script NUTTCP_PARIS_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'nuttcp-paris')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/NUTTCP_PARIS_S.sh '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(port) + ' '
		cmd += str(proto) + ' '
		cmd += str(duration) + ' '
		cmd += str(bandwidth) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &' #BACKGROUND

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('nuttcp-paris_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender_%s.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'NUTTCP_PARIS_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': proto,
			'port': port,
			'target_bwd': bandwidth,
			'granularity': 0.1
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'NUTTCP_PARIS_S', duration, 'running')
		except:
			self.e_log.error("Function NUTTCP_PARIS_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def ditg_packager_on_sender(self, proto, meter, outdir, index, action='M', client_tag='exp'):
		'''
		Wrapper lato sender per lo script ITG_PACK_S.sh
		N.B. Il parametro index viene passato in ingresso per elaborare il .log relativo all'esperimento d-itg index-esimo.
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/ITG_PACK_S.sh '
		cmd += str(proto) + ' '
		cmd += str(meter) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' '
		cmd += str(action) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('d-itg_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender_%s_%s_packager.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto,meter)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, timestamp, ('d-itg-packager_%s')%(index))
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'ITG_PACK_S', 'NaN', 'running')
		except:
			self.e_log.error("Function DITG_PACKAGER_ON_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id

	def udptest_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, message_size, duration, outdir, client_tag='exp'):
		'''
		Wrapper lato sender per lo script UDPTEST_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'udptest')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/UDPTEST_S.sh '
		cmd += str(message_size) + ' '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(port) + ' '
		cmd += str(duration) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('udptest_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'UDPTEST_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'port': port,
			'msg_size': message_size,
			'granularity': 0.1
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'UDPTEST_S', duration, 'running')
		except:
			self.e_log.error("Function UDPTEST_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def tcptest_sender(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, message_size, duration, outdir, client_tag='exp'):
		'''
		Wrapper lato sender per lo script TCPTEST_S.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'tcptest')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/sender/TCPTEST_S.sh '
		cmd += str(message_size) + ' '
		cmd += str(ip_exp_receiver) + ' '
		cmd += str(port) + ' '
		cmd += str(duration) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('tcptest_%s')%(index)
		pid_file = ('%s/%s/%s/sender/%s_%s_sender.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'TCPTEST_S',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'port': port,
			'msg_size': message_size,
			'granularity': 0.1
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'TCPTEST_S', duration, 'running')
		except:
			self.e_log.error("Function TCPTEST_SENDER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id



	#################################
	# 			RECEIVER
	#################################

	def nuttcp_receiver(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, proto, duration, outdir, client_tag='exp'):
		'''
		Wrapper lato receiver per lo script NUTTCP_R.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'nuttcp')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/receiver/NUTTCP_R.sh '
		cmd += str(port) + ' '
		cmd += str(proto) + ' '
		cmd += str(duration) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('nuttcp_%s')%(index)
		pid_file = ('%s/%s/%s/receiver/%s_%s_receiver_%s.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'NUTTCP_R',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': proto,
			'port': port
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'NUTTCP_R', duration, 'running')
		except:
			self.e_log.error("Function NUTTCP_RECEIVER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def ditg_receiver(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, proto, duration, outdir, client_tag='exp'):
		'''
		Wrapper lato receiver per lo script ITG_R.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'd-itg')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/receiver/ITG_R.sh '
		cmd += str(port) + ' '
		cmd += str(proto) + ' '
		cmd += str(duration) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('d-itg_%s')%(index)
		pid_file = ('%s/%s/%s/receiver/%s_%s_receiver_%s.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'DITG_R',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': proto,
			'port': port
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'ITG_R', duration, 'running')
		except:
			self.e_log.error("Function DITG_RECEIVER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def yaz_receiver(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, outdir, client_tag='exp'):
		'''
		Wrapper lato receiver per lo script YAZ_R.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'yaz')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/receiver/YAZ_R.sh '
		cmd += str(port) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('yaz_%s')%(index)
		pid_file = ('%s/%s/%s/receiver/%s_%s_receiver.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'YAZ_R',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'port': port
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'YAZ_R', 'NaN', 'running')
		except:
			self.e_log.error("Function YAZ_RECEIVER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def pathload_receiver(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, outdir, client_tag='exp'):
		'''
		Wrapper lato receiver per lo script PATHLOAD_R.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'pathload')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/receiver/PATHLOAD_R.sh '
		cmd += str(ip_exp_sender) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('pathload_%s')%(index)
		pid_file = ('%s/%s/%s/receiver/%s_%s_receiver.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'PATHLOAD_S',
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'PATHLOAD_R', 'NaN', 'running')
		except:
			self.e_log.error("Function PATHLOAD_RECEIVER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def ditg_packager_on_receiver(self, proto, meter, outdir, index, action='M', client_tag='exp'):
		'''
		Wrapper lato receiver per lo script ITG_PACK_R.sh
		N.B. Il parametro index viene passato in ingresso per elaborare il .log relativo all'esperimento d-itg index-esimo.
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/receiver/ITG_PACK_R.sh '
		cmd += str(proto) + ' '
		cmd += str(meter) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' '
		cmd += str(action) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('d-itg_%s')%(index)
		pid_file = ('%s/%s/%s/receiver/%s_%s_receiver_%s_%s_packager.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto,meter)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, timestamp, ('d-itg-packager_%s')%(index))
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'ITG_PACK_R', 'NaN', 'running')
		except:
			self.e_log.error("Function DITG_PACKAGER_ON_RECEIVER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def udptest_receiver(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, duration, outdir, client_tag='exp'):
		'''
		Wrapper lato receiver per lo script UDPTEST_R.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'udptest')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/receiver/UDPTEST_R.sh '
		cmd += str(port) + ' '
		cmd += str(duration) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('udptest_%s')%(index)
		pid_file = ('%s/%s/%s/receiver/%s_%s_receiver.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'UDPTEST_R',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'port': port
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'UDPTEST_R', duration, 'running')
		except:
			self.e_log.error("Function UDPTEST_RECEIVER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id

	def tcptest_receiver(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, duration, outdir, client_tag='exp'):
		'''
		Wrapper lato receiver per lo script TCPTEST_R.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'tcptest')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/receiver/TCPTEST_R.sh '
		cmd += str(port) + ' '
		cmd += str(duration) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('tcptest_%s')%(index)
		pid_file = ('%s/%s/%s/receiver/%s_%s_receiver.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'TCPTEST_R',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'port': port
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'TCPTEST_R', duration, 'running')
		except:
			self.e_log.error("Function TCPTEST_RECEIVER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def nuttcp_paris_receiver(self, ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, proto, duration, outdir, client_tag='exp'):
		'''
		Wrapper lato receiver per lo script NUTTCP_PARIS_R.sh
		'''

		#Costruzione outdir per raccolta risultati
		outdir = self.res_dir + '/' + outdir

		#Calcolo indice esperimento corrente per evitare sovrascritture
		index = get_next_dir_path(outdir, 'nuttcp-paris')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/receiver/NUTTCP_PARIS_R.sh '
		cmd += str(port) + ' '
		cmd += str(proto) + ' '
		cmd += str(duration) + ' '
		cmd += str(outdir) + ' '
		cmd += str(index) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		tool_dir = ('nuttcp-paris_%s')%(index)
		pid_file = ('%s/%s/%s/receiver/%s_%s_receiver_%s.pid')%(os.getcwd(),outdir,tool_dir,outdir.replace('/','_'),tool_dir,proto)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		exp_dict = {
			'exp_name': tool_dir,
			'start_time': int(timestamp),
			'tool': 'NUTTCP_PARIS_R',
			'ip_receiver': ip_receiver,
			'ip_sender': ip_sender,
			'ip_exp_receiver': ip_exp_receiver,
			'ip_exp_sender': ip_exp_sender,
			'ip_agent': self.ip_agent,
			'duration': duration,
			'protocol': proto,
			'port': port
			}

		#Critical section
		self.lock.acquire()
		try:
			write_campaign_log(outdir, exp_dict)
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'NUTTCP_PARIS_R', duration, 'running')
		except:
			self.e_log.error("Function NUTTCP_PARIS_RECEIVER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	#################################
	#		ALIAS RESOLUTION
	#################################

	def iffinder_wrapper(self, ips, outdir, client_tag='exp'):
		'''
		Wrapper per lo script iffinder.sh
		'''

		#Rimozione del precedente file di input
		os.system("sudo rm " + self.path_tool + '/deploy-iffinder/ips_file.txt')

		#Creazione del file di ips da analizzare
		for ip in ips:
			os.system("echo "+ip+" 1>> "+self.path_tool + '/deploy-iffinder/ips_file.txt')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/deploy-iffinder/iffinder.sh '
		cmd += self.path_tool + '/deploy-iffinder/ips_file.txt '
		cmd += str(outdir) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		pid_file = ('%s/%s/iffinder/%s_iffinder.pid')%(os.getcwd(),outdir,outdir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		#Critical section
		self.lock.acquire()
		try:
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'IFFINDER', 'NaN', 'running')
		except:
			self.e_log.error("Function IFFINDER_WRAPPER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def midar_wrapper(self, ips, outdir, client_tag='exp'):
		'''
		Wrapper per lo script launch_midar.sh
		'''

		#Rimozione del precedente file di input
		os.system("sudo rm " + self.path_tool + '/deploy-midar/ips_file.txt')

		#Crezione del file di ips da analizzare
		for ip in ips:
			os.system("echo " + ip + " 1>> " + self.path_tool + '/deploy-midar/ips_file.txt')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/deploy-midar/launch_midar.sh '
		cmd += self.path_tool + '/deploy-midar/ips_file.txt '
		cmd += str(outdir) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		pid_file = ('%s/%s/midar/%s_midar.pid')%(os.getcwd(),outdir,outdir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		#Critical section
		self.lock.acquire()
		try:
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'MIDAR', 'NaN', 'running')
		except:
			self.e_log.error("Function MIDAR_WRAPPER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	def pythia_wrapper(self, ips, outdir, client_tag='exp'):
		'''
		Wrapper per lo script pythia.sh
		'''

		#Rimozione del precedente file di input
		os.system("sudo rm " + self.path_tool + '/deploy-pythia/ips_file.txt')

		#Creazione del file di ips da analizzare
		for ip in ips:
			os.system("echo " + ip + " 1>> " + self.path_tool + '/deploy-pythia/ips_file.txt')

		#Costruzione del comando da lanciare
		cmd = 'sudo ' + self.path_tool + '/deploy-pythia/pythia.sh '
		cmd += self.path_tool + '/deploy-pythia/ips_file.txt '
		cmd += str(outdir) + ' &'

		#Definizione identificativo esperimento
		timestamp = time.time()
		exp_id = ('%s_%s')%(client_tag,timestamp)

		os.system(cmd)
		time.sleep(0.5)

		#Lettura PID del processo relativo all'esperimento avviato
		pid_file = ('%s/%s/pythia/%s_pythia.pid')%(os.getcwd(),outdir,outdir)
		opened = False
		i = 3
		while opened == False and i > 0:
			try:
				pid = open(pid_file, 'r').readline().rstrip('\n')
				opened = True
			except Exception, e:
				if i == 1:
					sys.stderr.write("Error:" + str(e))
					traceback.print_exc(file = sys.stderr)
				i = i-1
				time.sleep(2)
				continue
		#print pid #DEBUG

		#Critical section
		self.lock.acquire()
		try:
			self.c_log.info('%s: command: %s', exp_id, cmd)
			self.set_state(exp_id, pid, timestamp, 'PYTHIA', 'NaN', 'running')
		except:
			self.e_log.error("Function PYTHIA_WRAPPER() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		#Rimozione pid file
		os.system(('sudo rm %s')%(pid_file))

		return exp_id


	#################################
	# 			UTILITY
	#################################

	def update_state(self, exp_id):
		'''
		Restitusce lo stato dell'esperimento <exp_id> al chiamante, aggiornandolo nel caso in cui sia cambiato.
		'''

		#Critical section
		self.lock.acquire()
		try:
			pid = self.state_dict[exp_id]['pid']
			state = self.check_status(pid)
			if self.state_dict[exp_id]['status'] != state:
				self.state_dict[exp_id]['status'] = state
				self.s_log.info('update_state(): exp_id=%s => [%s] %s %s %s %s', exp_id, self.state_dict[exp_id]['start_time'], self.state_dict[exp_id]['pid'],  self.state_dict[exp_id]['tool'], self.state_dict[exp_id]['duration'], self.state_dict[exp_id]['status'])
		except:
			self.e_log.error("Function UPDATE_STATE() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		return self.state_dict[exp_id]


	def set_state(self, exp_id, pid, start_time, tool, duration, status):
		'''
		Setting dello stato relativo all'esperimento avviato.
		'''

		#Critical section
		self.lock.acquire()
		try:
			self.state_dict[exp_id] = {
			'pid': pid,
			'start_time': start_time,
			'tool': tool,
			'duration': duration,
			'status': status
			}
			#print self.state_dict #DEBUG
	 		self.s_log.info('set_state(): exp_id=%s => [%s] %s %s %s %s', exp_id, start_time, pid, tool, duration, status)
		except:
			self.e_log.error("Function SET_STATE() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.lock.release()
		#End of critical section

		return


	def get_state(self, exp_id):
		'''
		Restitusce lo stato dell'esperimento <exp_id> al chiamante.
		'''

		return self.state_dict[exp_id]


	def check_status(self, pid):
		'''
		Legge lo stato del processo dal file /proc/<pid>/status associato, se questi non e' terminato.
		In tal caso restitusce 'terminated'.
		'''

		if os.path.exists(('/proc/%s')%(pid)):
			cmd = ('cat /proc/%s/status | grep State')%(pid)
			state_task = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
			state = state_task.stdout.read()
			return state.split('(')[1].rstrip(')\n')
		else:
			return 'terminated'


	def updating_busy_check(self):
		'''
		Restituisce un dizionario con tutti gli esperimenti che non si trovano nello stato 'terminated'.
		Aggiorna lo stato di ciascun esperimento tramite la update_state.
		'''

		active_process = {}

		#Critical section
		self.lock.acquire()
		try:
			self.c_log.info('updating_busy_check() ---> START')
			for exp_id in self.state_dict.keys():
				self.update_state(exp_id)
				if self.state_dict[exp_id]['status'] != 'terminated':
					active_process[exp_id] = self.state_dict[exp_id]
		except:
			self.e_log.error("Function UPDATING_BUSY_CHECK() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.c_log.info('updating_busy_check() ---> END')
			self.lock.release()
		#End of critical section

		return active_process


	def busy_check(self):
		'''
		Restituisce un dizionario con tutti gli esperimenti che non si trovano nello stato 'terminated'.
		'''

		active_process = {}

		#Critical section
		self.lock.acquire()
		try:
			self.c_log.info('busy_check() ---> START')
			for exp_id in self.state_dict.keys():
				#self.get_state(exp_id)
				if self.state_dict[exp_id]['status'] != 'terminated':
					active_process[exp_id] = self.state_dict[exp_id]
		except:
			self.e_log.error("Function BUSY_CHECK() : error in critical section")
			traceback.print_exc(file = sys.stderr)
		finally:
			self.c_log.info('busy_check() ---> END')
			self.lock.release()
		#End of critical section

		return active_process


	def rename_campaign_log_file(self, outdir, new_log_name):
		'''
		Funzione di utilita' per il renaming del log file relativo ad una data campagna.
		Utilizzata dal master per distinguere i log file di sender e receiver in fase di download e merging
		dei risultati della campagna.
		'''

		campaign_log_path = ('%s/%s/%s.json')%(self.res_dir, outdir, outdir)
		new_campaign_log_path = ('%s/%s/%s.json')%(self.res_dir, outdir, new_log_name)

		if os.path.exists(campaign_log_path):
			os.system('mv %s %s' % (campaign_log_path, new_campaign_log_path))
		elif not os.path.exists(new_campaign_log_path):
			raise IOError('%s not found!' % campaign_log_path)


	def is_alive(self, message="I'm alive!!"):
		'''
		Funzione di utilita' che testa l'operativita' del server XMLRCP.
		Restituisce al client, un messaggio inviato al server dal client stesso.
		'''

		return message


	def terminate_server(self):
		'''
		Termina il server attraverso il setting di un apposito flag di controllo.
		'''

		self.exit = True
		return self.exit



