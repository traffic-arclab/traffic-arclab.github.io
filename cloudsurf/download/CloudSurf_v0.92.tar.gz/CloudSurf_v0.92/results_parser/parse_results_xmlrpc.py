#! /usr/bin/python

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

# generic parser

import os, sys
import re
import json
import glob
import numpy

tool_side_type = {
	'ping' : 'one-side',
	'hping' : 'one-side',
	'paris' : 'one-side',
	'iperf' : 'two-side',
	'nuttcp' : 'two-side',
	'ditg' : 'two-side',
	'nuttcp-paris' : 'two-side'
	}

tool_to_result_format = {
	'ping' : 'PING',
	'hping' : 'HPING',
	'paris' : 'PARIS',
	'iperf' : 'IPERFR',
	'nuttcp' : 'NUTTCP',
	'ditg' : 'DITGCS',
	'nuttcp-paris' : 'NUTTCP-PARIS'
	}

class BadParams(Exception):
	"""bad parameters"""


#################################
# 	GENERAL PURPOUSE PARSER
#################################

def outfile_parser_evolution(filenames, result_format, metric='TPUT', proto='tcp', meter='owdm', granularity=10, interval=1, raw_stat=False):
	#Per PING:
	#interval rappresenta l'intervallo di attesa in secondi tra l'invio di ciascun pacchetto ed il successivo (opt. -i <interval>);
	#di default e' settato ad 1 secondo.
	#raw_stat == False ---> Calcola le statistiche sui dati aggregati con granularita' richiesta
	#raw_stat == True ---> Calcola le statistiche sul file di output grezzo del tool di interesse, senza mediare con la granularita' richiesta

	filenames_R, filenames_S = filenames

	if result_format == 'DITGCS':
		if meter == 'owdm':
			values, duration = ditg_parser(filenames_R[0], metric)
		elif meter == 'rttm':
			values, duration = ditg_parser(filenames_S[0], metric)
		else:
			raise BadParams("Invalid params: meter not supported for ditg") # METER NOT SUPPORTED

	elif result_format == 'IPERFR':
		values, duration = iperf_parser(filenames_R[0], metric)

	elif result_format == 'NUTTCP':
		if metric != 'DELAY':
			values, duration = nuttcp_parser(filenames_S[0], metric, proto)
		else:
			mu = nuttcp_parser(filenames_S[0], metric, proto)
			return pack_stat_sintetiche(mu, None, None, None, None, None, None, None, None), None

	elif result_format == 'PING':
		values, duration = ping_parser(filenames_S[0], metric, interval)

	elif result_format == 'HPING':
		values, duration = hping3_parser(filenames_S[0], metric, proto, interval)

	elif result_format == 'PARIS':
		values = parse_paris_output(read_traces_from_file(filenames_S[0], metric))
		synt = parse_paris_synt(values)

	elif result_format == 'NUTTCP-PARIS':
		values, duration = nuttcp_paris_parser(filenames_S, metric, proto)

	else:
		raise BadParams("Invalid params: tool not supported yet!") # TOOL NOT SUPPORTED

	if metric == 'ROUTE':
		return synt, values

	intervals = int (duration/granularity)
	detailed = {}

	for k in range(0,intervals):
		tmp = [values[t] for t in values if (t >= k*granularity and  t <(k+1)*granularity)]
		detailed[k*granularity] =  numpy.mean(tmp)

	#calcola le statistiche sui valori del file di output del tool di interesse
	if raw_stat == True:
		vals = values.values()
	else:
	#calcola le statistiche sulle medie a granularita' data
		vals = detailed.values()

	mu = numpy.mean(vals)
	sigma = numpy.std(vals)
	med = numpy.median(vals)
	Max = numpy.max(vals)
	Min = numpy.min(vals)
	pctl25 = numpy.percentile(vals, 25)
	pctl75 = numpy.percentile(vals, 75)
	pctl5 = numpy.percentile(vals, 5)
	pctl95 = numpy.percentile(vals, 95)

	return pack_stat_sintetiche(mu, sigma, med, Max, Min, pctl25, pctl75, pctl5, pctl95), detailed


def ping_parser(filename, metric='DELAY', interval=1):
	if metric != 'DELAY':
		raise BadParams("Invalid params: only delay metric supported for ping") # METRIC NOT SUPPORTED

	#64 bytes from 54.93.45.89: icmp_seq=1 ttl=47 time=154 ms
	#tscol = 0
	col = 6
	init_lines_to_skip = 1
	end_lines_to_skip = 4
	separatore = ' '
	#ms
	divfact = 1
	mulfact = 1

	f = open(filename, 'r')
	F = f.readlines()
	end = -end_lines_to_skip
	F = F [init_lines_to_skip : end]

	values =  {}
	ping_cnt = 0
	for line in F:
		val = line.strip().split(separatore)[col]
		val = val.split('=')[1]
		val = mulfact*float(val)/divfact
		values[ping_cnt] = val
		ping_cnt += interval

	duration = max(values) - min(values) + interval

	return values, duration


def hping3_parser(filename, metric='DELAY', proto='tcp', interval=1):
	if metric != 'DELAY':
		raise BadParams("Invalid params: only delay metric supported for hping3") # METRIC NOT SUPPORTED

	if proto == 'tcp':
		#len=40 ip=54.165.81.145 ttl=51 DF id=49714 sport=18100 flags=RA seq=0 win=0 rtt=126.0 ms
		#tscol = 4
		col = 9
		init_lines_to_skip = 1
		#end_lines_to_skip = 0
		separatore = ' '
		#ms
		divfact = 1
		mulfact = 1
	elif proto == 'icmp':
		#len=28 ip=54.165.81.145 ttl=51 id=50050 icmp_seq=0 rtt=125.6 ms
		#tscol = 4
		col = 5
		init_lines_to_skip = 1
		#end_lines_to_skip = 0
		separatore = ' '
		#ms
		divfact = 1
		mulfact = 1
	else:
		raise BadParams("Invalid params: hping3 not supported protocol")

	f = open(filename,'r')
	F = f.readlines()
	end = len(F)
	F = F [init_lines_to_skip : end]

	values =  {}
	ping_cnt = 0
	for line in F:
		if 'len' not in line.split()[0]:
			continue
		val = line.strip().split(separatore)[col]
		val = val.split('=')[1]
		val = mulfact*float(val)/divfact
		values[ping_cnt] = val
		ping_cnt += interval

	duration = max(values) - min(values) + interval

	return values, duration


def nuttcp_parser(filename, metric='TPUT', proto='tcp'):
	#3.3340 MB /   0.10 sec =  279.6749 Mbps  2691 /  6105 ~drop/pkt 44.08 ~%loss # UDP
	#4.3750 MB /   0.10 sec =  366.7705 Mbps     0 retrans #TCP
	if metric == 'TPUT':
		tscol = 3
		col = 6
		init_lines_to_skip = 0
		end_lines_to_skip = 2
		#separatore = ''
		#Mbit-->Mbit
		divfact = 1
		mulfact = 1
	elif metric == 'LOSS':
		tscol = 3
		col = -2 # %loss UDP, retrans TCP
		init_lines_to_skip = 0
		end_lines_to_skip = 2
		#separatore = ''
		# %packet loss
		divfact = 1
		mulfact = 1
	elif metric == 'DELAY' and proto == 'tcp':
		f = open(filename,'r')
		F = f.readlines()
		return float(F[-1].split()[-2])	# 2281.9375 MB / 300.32 sec =   63.7396 Mbps 0 %TX 3 %RX 0 retrans 196.11 msRTT
	else:
		raise BadParams("Invalid params: metric not supported for nuttcp") # METRIC NOT SUPPORTED

	if proto == 'tcp':
		line_length = 10
	elif proto == 'udp':
		line_length = 14
	else:
		raise BadParams("Invalid params: nuttcp not supported protocol")

	f = open(filename,'r')
	F = f.readlines()
	end = -end_lines_to_skip
	F = F [init_lines_to_skip : end]

	values =  {}
	nuttcp_cnt = 0
	for line in F:
		ln = line.strip().split()
		try:
			if len(ln) != line_length:
				raise Exception
			ts = ln[tscol]
			val = ln[col]
			ts = float(ts)
			val = mulfact*float(val)/divfact
			values[nuttcp_cnt] = val
			nuttcp_cnt += ts
		except:
			print "Spurious line: pass"
			pass # linee spurie, e.g.:0.0312 MB /   0.1    0.5000 MB /   0.10 sec =   41.9422 Mbps  1675 /  1739 ~drop/pkt 96.32 ~%loss

	duration = max(values) -  min(values)

	return values, duration


def iperf_parser(filename, metric='TPUT'):
	if metric != 'TPUT':
		raise BadParams("Invalid params: only throughput metric supported for iperf") # METRIC NOT SUPPORTED

	#date,sender-ip,sender-port,receiver-ip,receiver-port,id,interval,transfer,bandwidth
	#20140617095034,172.31.27.16,10123,54.76.165.216,34307,4,0.0-0.5,43513848,696221568
	tscol = 6
	col = 8
	init_lines_to_skip = 0
	end_lines_to_skip = 1
	separatore = ','
	#bit-->Mbit
	divfact = 1000000
	mulfact = 1

	f = open(filename,'r')
	F = f.readlines()
	end = -end_lines_to_skip
	F = F [init_lines_to_skip : end]

	values =  {}
	for line in F:
		ts = line.strip().split(separatore)[tscol]
		val = line.strip().split(separatore)[col]
		ts = ts.split('-')[0]
		ts = float(ts)
		val = mulfact*float(val)/divfact
		values[ts] = val

	duration = max(values) -  min(values)

	return values, duration


def ditg_parser(filename, metric='TPUT'):
	#"Time", "Bitrate", "Delay", "Jitter", "Packet loss"
	if metric == 'TPUT':
		tscol = 0
		col = 1
		init_lines_to_skip = 0
		#end_lines_to_skip = 0
		separatore = ' '
		#Kbit-->Mbit
		divfact = 1000
		mulfact = 1
	elif metric == 'DELAY':
		tscol = 0
		col = 2
		init_lines_to_skip = 0
		#end_lines_to_skip = 0
		separatore = ' '
		#ms #???
		divfact = 1
		mulfact = 1
	elif metric == 'JITTER':
		tscol = 0
		col = 3
		init_lines_to_skip = 0
		#end_lines_to_skip = 0
		separatore = ' '
		#ms #???
		divfact = 1
		mulfact = 1
	elif metric == 'LOSS':
		tscol = 0
		col = 4
		init_lines_to_skip = 0
		#end_lines_to_skip = 0
		separatore = ' '
		# number of packets
		divfact = 1
		mulfact = 1
	else:
		raise BadParams("Invalid params: metric not supported for ditg") # METRIC NOT SUPPORTED

	values =  {}
	f = open(filename,'r')
	F = f.readlines()
	end = len(F)
	F = F [init_lines_to_skip : end]

	nuttcp_cnt = 0
	ping_cnt = 0
	for line in F:
		ts = line.strip().split(separatore)[tscol]
		val = line.strip().split(separatore)[col]
		ts = float(ts)
		val = mulfact*float(val)/divfact
		values[ts] = val

	duration = max(values) -  min(values)

	return values, duration


def nuttcp_paris_parser(filenames, metric='TPUT'):
	values = {}
	duration = 0

	if metric == 'TPUT' or metric == 'LOSS':
		values, duration = nuttcp_parser(filenames[1], metric)
	elif metric == 'ROUTE':
		values = parse_paris_output(read_traces_from_file(filenames[0], metric))
	else:
		raise BadParams("Invalid params: only tput and route metric supported for nuttcp-paris") # METRIC NOT SUPPORTED

	return values, duration


#################################
# 	PARIS-TRACEROUTE UTILITY
#################################

def read_traces_from_file(file_name, metric):
	"""
	Return a list containing the lines of a traceroute as list of lines [i.e. a list of lists].
	"""

	if metric != 'ROUTE':
		raise BadParams("Invalid params: metric not supported for paris-traceroute") # METRIC NOT SUPPORTED

	all_traces = []
	c_trace = []

	for line in open(file_name):

		if len(line.strip()) == 0 or line.startswith("#"):
			continue

		if "traceroute" in line:
			if len(c_trace) != 0:
				all_traces.append(c_trace)
			c_trace = [line]
		else:
			c_trace.append(line)

		if "Round" in line:
			if len(c_trace) != 0:
				all_traces.append(c_trace[:-1])

	return c_trace


def parse_paris_output(block_lines):
	"""
	parse mda output

	traceroute [(143.225.229.55:33456) -> (12.2.2.123:33457)], protocol icmp, algo exhaustive, duration 21 s
	 1  P(6, 6) 143.225.170.254  0.243/0.269/0.314/0.024 ms
	 2  P(6, 6) 143.225.190.98  0.226/4.679/26.866/9.922 ms
	 3  P(6, 6) 193.206.130.5  0.379/2.922/15.183/5.484 ms
	 4  P(6, 6) 90.147.80.165  4.257/6.121/14.814/3.889 ms
	   MPLS Label 302640 TTL=1
	 5  P(6, 6) 90.147.80.53  4.212/4.265/4.467/0.091 ms
	 6  P(6, 6) 149.6.22.73  34.604/96.729/190.207/54.621 ms
	 7  P(6, 6) 130.117.2.9  45.545/139.955/202.966/55.098 ms
	 8  P(6, 6) 130.117.0.25  14.671/14.725/14.929/0.092 ms
	 9  P(6, 6) 130.117.51.22  16.846/16.937/17.122/0.119 ms
	10  P(6, 6) 130.117.1.157  27.890/29.829/36.010/2.914 ms
	11  P(6, 6) 130.117.49.117  35.490/35.986/37.706/0.789 ms
	12  P(6, 6) 154.54.44.177  111.396/113.055/115.088/1.531 ms
	   MPLS Label 289616 TTL=255
	13  P(6, 6) 154.54.30.13  110.215/110.418/110.700/0.165 ms
	14  P(6, 6) 154.54.44.218  110.528/111.292/114.452/1.417 ms
	15  P(6, 6) 154.54.10.98  111.011/112.737/114.486/1.163 ms
	16  P(6, 6) 12.122.105.14  130.593/132.068/133.356/1.143 ms
	   MPLS Label 16591 TTL=255
	17  P(6, 6) 12.122.1.2  133.440/135.135/136.337/1.057 ms !T2
	   MPLS Label 0 TTL=255 | 16609
	18  P(6, 6) 12.122.132.110  132.126/134.190/135.820/1.236 ms !T3
	   MPLS Label 0 TTL=255 | 16035
	19  P(0, 6)
	20  P(0, 6)
	21  P(0, 6)

	parse hopbyhop output

	traceroute [(172.31.47.73:33456) -> (143.225.229.145:18100)], protocol icmp, algo hopbyhop, duration 12 s
	 1  * * *
	 2  * * *
	 3  * * *
	 4  100.64.16.9  0.388 ms   0.344 ms   0.374 ms
	 5  205.251.232.164  0.578 ms   0.906 ms   0.585 ms
	   MPLS Label 350483 TTL=1
	 6  205.251.232.158  0.786 ms   1.471 ms   0.657 ms
	 7  205.251.232.95  6.876 ms   6.976 ms   7.937 ms
	 8  205.251.225.185  7.140 ms   28.729 ms   7.156 ms
	 9  62.115.34.101  7.860 ms   7.794 ms   7.790 ms
	10  213.248.86.146  27.941 ms   27.963 ms   27.923 ms
	11  154.54.2.198  36.415 ms   36.163 ms   36.349 ms
	12  154.54.25.65  68.398 ms   68.473 ms   68.437 ms
	13  154.54.25.174  68.691 ms   68.492 ms   68.452 ms
	14  154.54.6.86  58.592 ms   58.635 ms   58.583 ms
	15  154.54.44.86  161.489 ms   161.409 ms   161.483 ms
	   MPLS Label 52126 TTL=255
	16  154.54.25.89  162.237 ms !T2   162.091 ms !T2   162.023 ms !T2
	   MPLS Label 43177 TTL=255
	17  154.54.43.9  161.416 ms !T3   161.289 ms !T3   161.208 ms !T3
	   MPLS Label 38266 TTL=255
	18  154.54.44.162  161.871 ms !T4   161.816 ms !T4   162.489 ms !T4
	   MPLS Label 47197 TTL=255
	19  154.54.39.149  161.151 ms !T5   161.191 ms !T5   161.197 ms !T5
	   MPLS Label 53709 TTL=255
	20  154.54.39.66  165.822 ms   165.842 ms   165.592 ms
	21  130.117.1.158  171.261 ms   170.906 ms   170.849 ms
	22  130.117.51.21  171.430 ms   171.609 ms   171.727 ms
	23  130.117.0.26  169.978 ms   169.894 ms   170.231 ms
	24  130.117.2.10  177.078 ms   177.061 ms  *
	25  149.6.22.74  182.531 ms   182.498 ms   182.353 ms
	26  90.147.80.58  186.323 ms   186.316 ms   188.538 ms
	   MPLS Label 458017 TTL=1
	27  90.147.82.73  186.036 ms   186.026 ms   186.055 ms
	   MPLS Label 709600 TTL=1
	28  90.147.80.169  185.674 ms   185.629 ms   185.635 ms
	29  * * *
	30  * * *

	Return a dict of per hop ip addresses contained in a paris-traceroute trace.
	"""

	for st_l in range(0,len(block_lines)):
		ll = block_lines[st_l]
		if ll.startswith("traceroute"):
			break

	block_lines = block_lines[st_l:]

	if "traceroute" not in block_lines[0]:
		return {}

	result = {}

	src,dst = re.findall(r'(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})', block_lines[0])

	result['src'] = src
	result['dst'] = dst

	result['hops'] = {}

	#Checking for spurious lines
	for line in block_lines[1:]:

		if "MPLS" in line:
			continue

		if "traceroute" in line:
			break

		if len(line.strip())==0:
			continue

		pattern = re.compile('^((\s\d\s P\(\d*,)|(\d*\s P\(\d*,))')
		if not pattern.match(line):
			i = block_lines.index(line)
			block_lines[i-1] = block_lines[i-1].rstrip('\n')
			block_lines[i-1:i+1] = [''.join(block_lines[i-1:i+1])]

	for line in block_lines[1:]:

		if "MPLS" in line:
			continue

		if "traceroute" in line:
			break

		if len(line.strip())==0:
			continue

		tmp = line.split()
		hop = int(tmp[0])

		ips = re.findall(r'(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})', line)

		if len(ips)==0:
			ips = ['*']
			#continue

		result['hops'][hop] = ips

	return result


def parse_paris_output_as_list(block_lines):
	"""
	parse mda output as list

	traceroute [(143.225.229.55:33456) -> (12.2.2.123:33457)], protocol icmp, algo exhaustive, duration 21 s
	 1  P(6, 6) 143.225.170.254  0.243/0.269/0.314/0.024 ms
	 2  P(6, 6) 143.225.190.98  0.226/4.679/26.866/9.922 ms
	 3  P(6, 6) 193.206.130.5  0.379/2.922/15.183/5.484 ms
	 4  P(6, 6) 90.147.80.165  4.257/6.121/14.814/3.889 ms
	   MPLS Label 302640 TTL=1
	 5  P(6, 6) 90.147.80.53  4.212/4.265/4.467/0.091 ms
	 6  P(6, 6) 149.6.22.73  34.604/96.729/190.207/54.621 ms
	 7  P(6, 6) 130.117.2.9  45.545/139.955/202.966/55.098 ms
	 8  P(6, 6) 130.117.0.25  14.671/14.725/14.929/0.092 ms
	 9  P(6, 6) 130.117.51.22  16.846/16.937/17.122/0.119 ms
	10  P(6, 6) 130.117.1.157  27.890/29.829/36.010/2.914 ms
	11  P(6, 6) 130.117.49.117  35.490/35.986/37.706/0.789 ms
	12  P(6, 6) 154.54.44.177  111.396/113.055/115.088/1.531 ms
	   MPLS Label 289616 TTL=255
	13  P(6, 6) 154.54.30.13  110.215/110.418/110.700/0.165 ms
	14  P(6, 6) 154.54.44.218  110.528/111.292/114.452/1.417 ms
	15  P(6, 6) 154.54.10.98  111.011/112.737/114.486/1.163 ms
	16  P(6, 6) 12.122.105.14  130.593/132.068/133.356/1.143 ms
	   MPLS Label 16591 TTL=255
	17  P(6, 6) 12.122.1.2  133.440/135.135/136.337/1.057 ms !T2
	   MPLS Label 0 TTL=255 | 16609
	18  P(6, 6) 12.122.132.110  132.126/134.190/135.820/1.236 ms !T3
	   MPLS Label 0 TTL=255 | 16035
	19  P(0, 6)
	20  P(0, 6)
	21  P(0, 6)

	parse hopbyhop output

	traceroute [(172.31.47.73:33456) -> (143.225.229.145:18100)], protocol icmp, algo hopbyhop, duration 12 s
	 1  * * *
	 2  * * *
	 3  * * *
	 4  100.64.16.9  0.388 ms   0.344 ms   0.374 ms
	 5  205.251.232.164  0.578 ms   0.906 ms   0.585 ms
	   MPLS Label 350483 TTL=1
	 6  205.251.232.158  0.786 ms   1.471 ms   0.657 ms
	 7  205.251.232.95  6.876 ms   6.976 ms   7.937 ms
	 8  205.251.225.185  7.140 ms   28.729 ms   7.156 ms
	 9  62.115.34.101  7.860 ms   7.794 ms   7.790 ms
	10  213.248.86.146  27.941 ms   27.963 ms   27.923 ms
	11  154.54.2.198  36.415 ms   36.163 ms   36.349 ms
	12  154.54.25.65  68.398 ms   68.473 ms   68.437 ms
	13  154.54.25.174  68.691 ms   68.492 ms   68.452 ms
	14  154.54.6.86  58.592 ms   58.635 ms   58.583 ms
	15  154.54.44.86  161.489 ms   161.409 ms   161.483 ms
	   MPLS Label 52126 TTL=255
	16  154.54.25.89  162.237 ms !T2   162.091 ms !T2   162.023 ms !T2
	   MPLS Label 43177 TTL=255
	17  154.54.43.9  161.416 ms !T3   161.289 ms !T3   161.208 ms !T3
	   MPLS Label 38266 TTL=255
	18  154.54.44.162  161.871 ms !T4   161.816 ms !T4   162.489 ms !T4
	   MPLS Label 47197 TTL=255
	19  154.54.39.149  161.151 ms !T5   161.191 ms !T5   161.197 ms !T5
	   MPLS Label 53709 TTL=255
	20  154.54.39.66  165.822 ms   165.842 ms   165.592 ms
	21  130.117.1.158  171.261 ms   170.906 ms   170.849 ms
	22  130.117.51.21  171.430 ms   171.609 ms   171.727 ms
	23  130.117.0.26  169.978 ms   169.894 ms   170.231 ms
	24  130.117.2.10  177.078 ms   177.061 ms  *
	25  149.6.22.74  182.531 ms   182.498 ms   182.353 ms
	26  90.147.80.58  186.323 ms   186.316 ms   188.538 ms
	   MPLS Label 458017 TTL=1
	27  90.147.82.73  186.036 ms   186.026 ms   186.055 ms
	   MPLS Label 709600 TTL=1
	28  90.147.80.169  185.674 ms   185.629 ms   185.635 ms
	29  * * *
	30  * * *

	Return a single list of ip addresses contained in a paris-traceroute trace.
	"""

	for st_l in range(0,len(block_lines)):
		ll = block_lines[st_l]
		if ll.startswith("traceroute"):
			break

	block_lines = block_lines[st_l:]

	if "traceroute" not in block_lines[0]:
		return []

	result = []

	src,dst = re.findall(r'(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})', block_lines[0])

	result.append(src)
	result.append(dst)

	#Checking for spurious lines
	for line in block_lines[1:]:

		if "MPLS" in line:
			continue

		if "traceroute" in line:
			break

		if len(line.strip())==0:
			continue

		pattern = re.compile('^((\s\d\s P\(\d*,)|(\d*\s P\(\d*,))')
		if not pattern.match(line):
			i = block_lines.index(line)
			block_lines[i-1] = block_lines[i-1].rstrip('\n')
			block_lines[i-1:i+1] = [''.join(block_lines[i-1:i+1])]

	for line in block_lines[1:]:

		if "MPLS" in line:
			continue

		if "traceroute" in line:
			break

		if len(line.strip())==0:
			continue

		tmp = line.split()
		hop = int(tmp[0])

		ips = re.findall(r'(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})\.(?:[\d]{1,3})', line)

		if len(ips)==0:
			ips = ['*']
			#continue

		for ip in ips:
			result.append(ip)

	return result


def parse_whois_cymru_output(whois_cymru_file):
	'''
	Restituisce un dizionario ottenuto a partire dall'output di whois cymru,
	che associa a ciascun indirizzo IP le informazioni relative all'AS di appartenenza:
	- AS Number
	- AS Name
	- Subnet
	- Country
	- Registry
	'''

	whois_dict = {}

	for line in open(whois_cymru_file):

		if len(line.strip()) == 0 or line.startswith("#"):
			continue

		if 'Bulk' in line:
			continue

		spl = line.split('|')

		as_num = spl[0].strip()
		ip_address = spl[1].strip()
		subnet = spl[2].strip()
		country = spl[3].strip()
		registry = spl[4].strip()
		as_name = spl[6].strip()

		whois_dict[ip_address] = {
			'as_number': as_num,
			'as_name': as_name,
			'subnet': subnet,
			'country': country,
			'registry': registry
			}

	return whois_dict


def paris_to_whois(paris_file_name, whois_cymru_file_name):
	'''
	Restituisce un dizionario ottenuto a partire dall'output di paris-traceroute paris e di whois cymru,
	che associa a ciascun hop le informazioni relative agli indirizzi IP rilevati e ai corrispondenti AS di appartenenza:
	- AS Number
	- AS Name
	- Subnet
	- Country
	- Registry
	'''

	paris_dict = parse_paris_output(read_traces_from_file(paris_file_name))
	whois_dict = parse_whois_cymru_output(whois_cymru_file_name)

	hops_as_dict = {}

	for hop in paris_dict:
		if hop == 'dst' or hop == 'src':
			hops_as_dict[hop] = whois_dict[paris_dict[hop]]
			hops_as_dict[hop]['ip_address'] = paris_dict[hop]
		else:
			for hop_num in paris_dict[hop]:
				for ip in paris_dict[hop][hop_num]:
					if hop not in hops_as_dict:
						hops_as_dict[hop] = {}
					if hop_num not in hops_as_dict[hop]:
						hops_as_dict[hop][hop_num] = []
					whois_dict[ip]['ip_address'] = ip
					hops_as_dict[hop][hop_num].append(whois_dict[ip])

	return hops_as_dict


def hash_paris(json_campaign_file):
	"""
	Prende il ingresso il file .json relativo alla campagna di interesse e restituisce due dizionari:
	- paris_path ---> contiene l'associazione tra: protocollo, start time dell'esperimento e hash key associato al path.
	- paris_detailed_path ---> contiene l'associazione tra hash key e hop-by-hop path.
	"""

	campaign_dir = os.path.abspath(os.path.join(json_campaign_file, os.pardir))

	paris_dict = {}
	paris_detailed_dict = {}

	with open(json_campaign_file, 'r') as json_log_file:
		log_dicts = json.load(json_log_file)

	for log_dict in log_dicts:

		if 'paris' in log_dict['exp_name']:
			if os.path.exists(('%s/%s')%(campaign_dir, log_dict['exp_name'])):

				paris_file = glob.glob(('%s/%s/sender/*.out')%(campaign_dir, log_dict['exp_name']))[0]

				c_trace = read_traces_from_file(paris_file)
				ips_list = parse_paris_output_as_list(c_trace)

				ips_tuple = tuple(sorted(set(ips_list)))
				hash_value = hash(ips_tuple)

				if log_dict['protocol'] not in paris_dict:
					paris_dict[log_dict['protocol']] = {}

				paris_dict[log_dict['protocol']][log_dict['start_time']] = hash_value
				paris_detailed_dict[hash_value] = parse_paris_output(c_trace)

			else:
				sys.stderr.write('Attenzione: risultati esperimento %s mancanti!\n'%log_dict['exp_name'])

	return paris_dict, paris_detailed_dict


def parse_paris_synt(paris_dict):
	"""
	Prende in ingresso il dizionario ottenuto a valle del parsing dell'output di paris-traceroute
	e restituisce in uscita un dizionario:
	- paris_synt: {
		'max_width' : max_width,
		'path_length' : path_length
		}
	"""
	
	max_width = 0
	path_length = 0
	for hop in paris_dict['hops']:
		if '*' not in paris_dict['hops'][hop]:
			current_len = len(paris_dict['hops'][hop])
			if current_len > max_width:
				max_width = current_len
			path_length = hop
		else:
			if (hop + 1) not in paris_dict['hops']:
				path_length = '*'
				
	return {
		'max_width' : max_width,
		'path_length' : path_length
		}
	
	
#################################
# 			UTILITY
#################################

def log_dict_verifier(log_dict_sender, log_dict_receiver):
	sender_two_side = [exp for exp in log_dict_sender if tool_side_type[exp.split('_')[0]] == 'two-side']
	#print sender_two_side
	exps_set_diff = set(sender_two_side).symmetric_difference(set(log_dict_receiver))
	#print exps_set_diff
	missing_list = list(exps_set_diff)
	return missing_list


def campaign_parser(campaign_base_path):
	#<SENDER>_<RECEIVER>_<TIMESTAMP>
	#us-east-1a-medium_eu-east-1a-medium_<TIMESTAMP>

	campaign_dir = campaign_base_path.split('/')[-1]
	#print campaign_dir
	provider_snd = campaign_dir.split('_')[0][:(campaign_dir.split('_')[0].find('-'))]
	region_snd = campaign_dir.split('_')[0]\
				 [(campaign_dir.split('_')[0].find('-') + 1):(campaign_dir.split('_')[0].rfind('-'))]
	size_snd = campaign_dir.split('_')[0][(campaign_dir.split('_')[0].rfind('-') + 1):]

	provider_rcv = campaign_dir.split('_')[1][:(campaign_dir.split('_')[1].find('-'))]
	region_rcv = campaign_dir.split('_')[1]\
				 [(campaign_dir.split('_')[1].find('-') + 1):(campaign_dir.split('_')[1].rfind('-'))]
	size_rcv = campaign_dir.split('_')[1][(campaign_dir.split('_')[1].rfind('-') + 1):]

	campaign_dict = {
		'provider_snd': provider_snd,
		'region_snd' : region_snd,
		'region_rcv' : region_rcv,
		'provider_rcv': provider_rcv,
		'size_snd' : size_snd,
		'size_rcv' : size_rcv
		}

	return campaign_dict


def exp_info_split(exp_info):
	exp_name = exp_info['exp_name']
	start = exp_info['start_time']
	if 'protocol' in exp_info:
		proto = exp_info['protocol']
	else:
		proto = None
	if 'meter' in exp_info:
		meter = exp_info['meter']
	else:
		meter = None
	if 'duration' in exp_info:
		duration = int(exp_info['duration'])
	else:
		duration = None
	if 'granularity' in exp_info:
		interval = float(exp_info['granularity'])
	else:
		interval = None

	return exp_name, proto, meter, start, duration, interval


def logitem_to_filename(campaign_base_path, exp_info):
	exp_name, proto, meter, start, duration, interval = exp_info_split(exp_info)
	#print exp_name, proto, meter, start, duration

	tool_side_receiver = 'receiver'
	tool_side_sender = 'sender'
	campaign_dir = campaign_base_path.split('/')[-1]

	filename_receiver = campaign_base_path + '/'+ exp_name + '/' + tool_side_receiver
	filename_receiver += '/res_'+ campaign_dir + '_'+ exp_name + '_' + tool_side_receiver + '*.out'

	filename_sender = campaign_base_path + '/'+ exp_name + '/' + tool_side_sender
	filename_sender += '/res_'+ campaign_dir + '_'+ exp_name + '_' + tool_side_sender + '*.out'

	filenames_receiver = glob.glob(filename_receiver)
	filenames_sender = glob.glob(filename_sender)

	ff_exist = [len(filenames_receiver), len(filenames_sender)]
	filenames = []

	if ff_exist[0]:
		filenames.append(filenames_receiver)
	else:
		filenames.append(None)

	if ff_exist[1]:
		filenames.append(filenames_sender)
	else:
		filenames.append(None)

	return filenames, ff_exist


def logitem_to_result_format(exp_info):
	exp_name, proto, meter, start, duration, interval = exp_info_split(exp_info)
	tool = exp_name[:(exp_name.rfind('_'))]

	if tool in tool_to_result_format:
		return tool_to_result_format[tool], True
	else:
		return None, False


def byte_min2Mbit_s(B):
	#return float(B)*8/(60*1000000)
	return float(B)*8/(60*1048576)


def pack_experiment(campagna, info_snd, info_rcv, exp_name, proto, start, duration, interval, results):
#campaign_log_file --> results_json
	return {
		'camp' : campagna, #dict
		'info_snd' : info_snd, #dict
		'info_rcv' : info_rcv, #dict
		'exp_name' : exp_name,
		'proto' : proto,
		'start': start,
		'duration': duration,
		'granularity': interval,
		'results' : results #dict
		}


def pack_stat_sintetiche(mu, sigma, med, Max, Min, pctl25, pctl75, pctl5, pctl95):
	return {
		'mean' : mu,
		'std' : sigma,
		'median' : med,
		'max' : Max,
		'min' : Min,
		'pctl5' : pctl5,
		'pctl25' : pctl25,
		'pctl75' : pctl75,
		'pctl95' : pctl95
		}


def shift_tstamps(res_timeseries, START):
	# input:: {ts1:val1, ts2:val2}
	datapoints = {}
	for x in res_timeseries:
		datapoints[START + x] = res_timeseries[x]
	return datapoints



