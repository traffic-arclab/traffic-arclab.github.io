#! /usr/bin/python

#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import json

from pprint import pprint

from ConfigParser import SafeConfigParser
from logger import setup_logging
import parse_results_xmlrpc as ppr


class ResultsParserException(Exception):
	'''
	Exception for ResultsParser class
	'''
	def __init__(self, message):
		self.message = message
	def __str__(self):
		return str(self.message)


class ResultsParser:
	'''
	Class for parsing results in standard json format
	'''

	metrics = {
			'tput' : 'TPUT',
			'delay' : 'DELAY',
			'jitter' : 'JITTER',
			'loss' : 'LOSS',
			'route' : 'ROUTE'
			}


	def __init__(self, outdir):
		'''
		Constructor for class ResultsParser:
		- outdir (str): campaign results directory
		'''

		self.outdir = outdir

		self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
		self.parser = SafeConfigParser()
		self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

		self.results_container = self.parser.get('config_experiment', 'results_container')
		self.campaign_base_path = '%s/%s/%s' % (self.cloudsurf_base_path, self.results_container, self.outdir)

		self.info_log, self.debug_log = setup_logging.return_loggers()


	def extract_json(self, granularity=1):
		'''
		Extract campaign results json file from sender and receiver json log files and experiments raw data.
		'''

		self.debug_log.info('Extracting results json file --> Start analysis of campaign: %s' % self.outdir)
		self.info_log.info('Extracting results json file --> Start analysis of campaign: %s' % self.outdir)

		res_json_filename = '%s/%s_results.json' % (self.campaign_base_path, self.outdir)

		if os.path.isfile(res_json_filename):
			os.rename(res_json_filename, res_json_filename + '~')

		log_file_sender = '%s/%s_sender.json' % (self.campaign_base_path, self.outdir)
		log_file_receiver = '%s/%s_receiver.json' % (self.campaign_base_path, self.outdir)

		log_dict_sender = {}
		log_dict_receiver = {}

		log_file_sender_exists = os.path.exists(log_file_sender)
		log_file_receiver_exists = os.path.exists(log_file_receiver)

		if not (log_file_sender_exists or log_file_receiver_exists):
			err_str = "Campaign json logs don't exist!"
			self.debug_log.error(err_str)
			raise ResultsParserException(err_str)
		else:
			if log_file_sender_exists:
				with open(log_file_sender, 'r') as file_snd:
					log_dict_sender = json.load(file_snd)

			if log_file_receiver_exists:
				with open(log_file_receiver, 'r') as file_rcv:
					log_dict_receiver = json.load(file_rcv)

		missing_list = ppr.log_dict_verifier(log_dict_sender, log_dict_receiver)
		if len(missing_list) != 0:
			err_str = 'Error in campaign json logs --> Removing experiment dicts missing: ['
			for miss in missing_list:
				err_str += ('%s, ' % miss)
				if miss in log_dict_sender:
					del log_dict_sender[miss]
				elif miss in log_dict_receiver:
					del log_dict_receiver[miss]
			err_str = err_str.rstrip(', ') + ']'
			self.debug_log.warning(err_str)

		res_list = []
		parsed = False
		campaign_dict = ppr.campaign_parser(self.campaign_base_path)

		for exp_dict in log_dict_sender:
			exp_info_sender = log_dict_sender[exp_dict]

			exp_info_receiver = None
			if exp_dict in log_dict_receiver:
				exp_info_receiver = log_dict_receiver[exp_dict]

			filenames, fileexists = ppr.logitem_to_filename(self.campaign_base_path, exp_info_sender)
			resformat, resformatexists = ppr.logitem_to_result_format(exp_info_sender)

			#print filenames
			#print fileexists
			#print resformat
			#print resformatexists

			exp_name, proto, meter, start, duration, interval = ppr.exp_info_split(exp_info_sender)

			#pprint(exp_name)
			#pprint(proto)
			#pprint(start)
			#pprint(duration)
			#pprint(interval)

			if fileexists[1] and resformatexists:
				risultati = {}
				for m in self.metrics:
					#print m
					#raw_input()
					try:

						if m != 'route':
							sint, dett = ppr.outfile_parser_evolution(filenames, resformat, self.metrics[m], proto, meter, granularity, interval, False)
							if dett:
								dett = ppr.shift_tstamps(dett, start)
						else:
							sint, dett = ppr.outfile_parser_evolution(filenames, resformat, self.metrics[m], proto, meter, granularity, interval, False)

						self.debug_log.debug('Experiment %s: elaborated metric %s.' % (exp_name, m))

					except ppr.BadParams:
						sint = None
						dett = None
					except Exception:
						sint = None
						dett = None
						self.debug_log.warning("Experiment %s: error during metric %s elaboration." % (exp_name, m))

					#print filenames, resformat, metrics[m]
					#pprint(sint)
					#pprint(dett)
					#raw_input()

					risultati[m] = {'synt' : sint, 'detailed' : dett}

				risultati_esperimento = ppr.pack_experiment(campaign_dict, exp_info_sender, exp_info_receiver, exp_name, proto, start, duration, interval, risultati)

				self.debug_log.debug('Elaborated experiment %s.' % exp_name)
				#print risultati_esperimento['exp_name']
				res_list.append(risultati_esperimento)
				parsed = True

			elif not fileexists[1]:
				self.debug_log.warning("Experiment %s: filename not found..." % exp_dict)
			else:
				self.debug_log.warning("Experiment %s: result format not found..." % exp_dict)

		#print json.dumps(res_list)
		#raw_input()
		#res_json_filename = campaign_base_path + '/' + campaign_base_path.split('/')[-1] + '_results.json'

		with open(res_json_filename, 'w') as res_json_file:
			json.dump(res_list, res_json_file)

		self.debug_log.info('Extracted results json file --> Terminated analysis of campaign: %s' % self.outdir)
		self.info_log.info('Extracted results json file --> Terminated analysis of campaign: %s' % self.outdir)
		return parsed

if __name__ == "__main__":

	rp = ResultsParser('aws-eu-west-1b-m3.medium_aws-eu-west-1b-m3.medium_1450432999')
	rp.extract_json(1)
