#!/bin/bash

if [ "$(id -u)" != "0" ]; then
	echo "Setup script must be lauched with root privileges."
	exit 1
fi

read -rep "This script will substitute the installed version of Azure SDK for Python, if any, with the latest release.
Do you want to continue? [y/N] " response

if [[ $response =~ ^([yY][eE][sS]|[yY])$ ]]

then

    pip list | grep azure | awk '{print $1}' > azure_requirements.txt	#List current Azure SDK packages
	yes | sudo pip uninstall -r azure_requirements.txt					#Remove current Azure SDK packages
	sudo pip install --pre azure										#Install latest Azure SDK packages
	sudo pip install --pre --upgrade azure								#Upgrade latest Azure SDK packages

	rm azure_requirements.txt

	echo "The Azure SDK for Python has been correctly upgraded."

else

	echo "Warning! Nothing has been changed. The CloudSurf suite might not operate properly until the latest release of Azure SDK for Python is installed."
    exit 1

fi
