#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from colors import bcolors

class Prompt:

    p = "CloudSurF"

    @staticmethod
    def simple(text=""):
        sep = ""
        if text != "":
            sep = ": "
        text += ">"
        return " %s%s%s%s%s%s " % (bcolors.UNDERL, bcolors.DARKCYAN, Prompt.p, sep, text, bcolors.ENDC)

    
    @staticmethod
    def yesno(text):
        is_valid_response = False
        valid_responses = ["n", "y","no", "yes"]
        while not is_valid_response:
            response = raw_input(Prompt.simple(text))
            response = str.lower(response.strip())
            is_valid_response = response in valid_responses
            if not is_valid_response:
                print "valid responses are: %s" % ("|".join(valid_responses))
                continue
            else:
                if response in ["y", "yes"]:
                    return True
                elif response in ["n", "no"]:
                    return False

    
    @staticmethod
    def press_a_key(text=""):
        text += "\n\n Press " + bcolors.RED + "<return> " + bcolors.ENDC + "to continue..."
        return text
    
    
    @staticmethod
    def please_insert(parameter="name"):
        text = " Please insert your " + bcolors.BLUE + parameter + bcolors.ENDC + " and press " + bcolors.RED + "<return> " + bcolors.ENDC + "to confirm: "
        return text


if __name__ == "__main__":
    scelta = raw_input(Prompt.simple("Hello, world!"))

    print scelta

    scelta2 = raw_input(Prompt.yesno("Are you sure?"))

    print scelta2

    scelta3 = raw_input(Prompt.press_a_key())

    print scelta3
