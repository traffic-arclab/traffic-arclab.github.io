#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

class Meta:
    name =  "The CloudSurf Suite"
    nick = "CS2"
    version = "0.92"
    authors = "The Traffic Research Group"
    affiliation = "University of Napoli 'Federico II'"
    contact = "valerio.persico [a t !] unina \dot it"
    visit = "http://traffic.comics.unina.it"
    first_time = "http://traffic.comics.unina.it/cloudsurf/detailed_howto.html"
    documentation = "http://traffic.comics.unina.it/cloudsurf/documentation.html"
    repository = "http://143.225.229.177:8080/CloudSurfData"
    home = "http://wpage.unina.it/valerio.persico"
    aws = "http://aws.amazon.com/it/free"
    license = "AGPL"
