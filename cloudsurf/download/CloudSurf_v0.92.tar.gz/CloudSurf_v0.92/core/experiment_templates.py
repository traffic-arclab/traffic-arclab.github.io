#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 11 dic 2015

@author: antonio
'''

class ExperimentTemplates:
    '''
    Class for experiment templates management.
    Experiment templates are lists of parameters dicts.
    In this way every template describes more single experiments (formally a campaign)
    '''

    tcp_throughput_latency = [{
                               'tool': 'NUTTCP',
                               'port': 18100,
                               'proto': 'tcp',
                               'duration': 300,
                               'bandwidth': 1000000000,
                               'client_tag': 'tcp_throughput_latency_cloudsurf_template',
                               'sleep_exp': 0
                               }
                              ]

    udp_throughput = [{
                       'tool': 'NUTTCP',
                       'port': 18200,
                       'proto': 'udp',
                       'duration': 300,
                       'bandwidth': 1000000000,
                       'client_tag': 'udp_throughput_cloudsurf_template',
                       'sleep_exp': 0
                       }
                      ]

    icmp_latency = [{
                       'tool': 'PING',
                       'duration': 300,
                       'interval': 0.1,
                       'client_tag': 'icmp_latency_cloudsurf_template',
                       'sleep_exp': 0
                      }
                     ]
    
    path_characterization = [{
                               'tool': 'PARIS_TRACEROUTE',
                               'src_port': 33456,
                               'dst_port': 33457,
                               'proto': 'udp',
                               'duration': 120,     #Estimate only for visualization purposes
                               'client_tag': 'path_characterization_cloudsurf_template',
                               'sleep_exp': 0
                               },
                             {
                               'tool': 'PARIS_TRACEROUTE',
                               'src_port': 33456,
                               'dst_port': 33457,
                               'proto': 'tcp',
                               'duration': 120,     #Estimate only for visualization purposes
                               'client_tag': 'path_characterization_cloudsurf_template',
                               'sleep_exp': 0
                               },
                             {
                               'tool': 'PARIS_TRACEROUTE',
                               'src_port': 33456,
                               'dst_port': 33457,
                               'proto': 'icmp',
                               'duration': 120,     #Estimate only for visualization purposes
                               'client_tag': 'path_characterization_cloudsurf_template',
                               'sleep_exp': 0
                               }
                             ]

    template_choice = {
                       '1': tcp_throughput_latency,
                       '2': udp_throughput,
                       '3': icmp_latency,
                       '4': path_characterization
                       }
