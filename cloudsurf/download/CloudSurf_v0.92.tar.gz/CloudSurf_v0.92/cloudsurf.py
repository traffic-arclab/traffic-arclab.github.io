#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import argparse
import sys
import os

from logger import setup_logging
from core.utils import clear
from core.meta import Meta
from core.prompt import Prompt
from core.banner import Banner
from core.colors import bcolors
from core.menus import generic_print

__version__ = Meta.version
sys.tracebacklimit=0

def check_credentials(provider='aws'):
    home = os.path.expanduser("~")

    # aws credentials stored in $HOME/.boto
    credentials_exist = os.path.exists("%s/.boto" % home)

    return credentials_exist


def check_identity():
    '''
    Check for user identify file and create it if necessary
    '''
    
    if not os.path.exists(".cloudsurf_user"):
        create_identity_file(True)
    return


def create_identity_file(first_time):
    '''
    Create user identity file
    '''
    
    clear()
    Banner.show_graphic_text()
    
    if first_time:
        body_msg = 'The first time you run %s, it will ask you for some information.\n' % Meta.name
        head_msg = 'First Time Identification'
    else:
        body_msg = 'This feature allows you to change provided user information.\n'
        head_msg = 'User identity information Update'
    
    body_msg += ' Information will be confidential and used only for statistical purposes.'
    generic_print(head_msg, bcolors.BOLD, body_msg, bcolors.BLUE)
    
    with open(".cloudsurf_user", 'w') as identity_file:
        identity_file.write('Name = %s\n' % raw_input(Prompt.please_insert('name')))
        identity_file.write('Surname = %s\n' % raw_input(Prompt.please_insert('surname')))
        identity_file.write('Country = %s\n' % raw_input(Prompt.please_insert('country')))
        identity_file.write('Affiliation = %s\n' % raw_input(Prompt.please_insert('research affiliation')))
        identity_file.write('Email = %s\n' % raw_input(Prompt.please_insert('email address')))
    raw_input(Prompt.press_a_key('\n Thanks for your collaboration. Enjoy %ssurfing%s with us!' % (bcolors.BLUE, bcolors.ENDC)))
    return
        
        
def print_check_credentials():
    cc = check_credentials()
    if cc:
        print "Cloud provider credential check passed!"
    else:
        home = os.path.expanduser("~")
        print "Cloud provider credential check failed!"
        print "Please check if %s/.boto exists. More information can be found at %s" % (home, Meta.first_time)
        print "Exiting..."
    return cc


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='The CloudSurf Suite.')

    parser.add_argument('--version', action='version', version='%(prog)s {version}'.format(version=__version__))

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-i', '--interactive', action='store_true', dest='interactive_mode', default=True, help='start the interactive mode')
    group.add_argument('-b', '--batch', action='store', dest='campaign_file', default=None, help='start the batch mode')
    group.add_argument('-c', '--check-configuration', action='store_true', dest='credential_check_only', default=False, help='check cloud provider configuration and exit')
    group.add_argument('-u', '--change-user', action='store_true', dest='change_user_only', default=False, help='allow to change user identity file and exit')

    args = parser.parse_args()

    if args.credential_check_only:
        print_check_credentials(False)
        sys.exit(0)

    cc = print_check_credentials()
    
    setup_logging.manage_log_dirs() # log files setup
    info_log, debug_log = setup_logging.return_loggers()
    
    if not cc:  # credential check failed
        debug_log.info('Exit from CloudSurf: cloud provider credential check failed!')
        info_log.info('Exit from CloudSurf: cloud provider credential check failed!')
        sys.exit(1)

    else:  # credential check passed  
        
        if args.change_user_only:
            create_identity_file(False)
            sys.exit(0)
            
        check_identity()
        
        if args.interactive_mode:  # interactive mode
            
            debug_log.info('CloudSurf started in interactive mode!')
            info_log.info('CloudSurf started in interactive mode!')

            import interactive
            interactive.main()

        else: # batch mode
            debug_log.info('CloudSurf started in batch mode!')
            info_log.info('CloudSurf started in batch mode!')
            print 'batch mode not implemented yet!'
            debug_log.info('Exit from CloudSurf')
            info_log.info('Exit from CloudSurf')
