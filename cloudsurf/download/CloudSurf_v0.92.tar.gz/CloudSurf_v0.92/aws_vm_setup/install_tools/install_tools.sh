#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

#	 update repository
sudo apt-get --assume-yes update

#	 build-essential
sudo apt-get --assume-yes install build-essential

#	 nuttcp
sudo apt-get --assume-yes install nuttcp

#	 paris-traceroute
tar zxvf install_tools/paris-traceroute-0.92-dev.tar.gz -C install_tools
cd install_tools/paris-traceroute-current; sudo make install
