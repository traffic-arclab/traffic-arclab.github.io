#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 01 dic 2015

@author: antonio
'''

import os, subprocess, time, glob

from aws_utils import utils
from logger import setup_logging
from ConfigParser import SafeConfigParser

class VMPreparationException(Exception):
    '''
    Exception for VMPreparation class
    '''
    def __init__(self, message):
        self.message = message
    def __str__(self):
        return str(self.message)


class VMPreparation(object):
    '''
    Prepare experimental environment for <vm> VM.
    '''

    def __init__(self, vm, ssh_key_name):
        '''
        Constructor
        '''

        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        self.vm = vm
        self.ssh_key_path = os.path.expanduser('~/%s/%s.pem' % (self.parser.get('config_key_pair', 'ssh_key_dir'), ssh_key_name))

        self.tools_installer_dir = '%s/%s' % (os.path.dirname(os.path.realpath(__file__)), self.parser.get('config_vm', 'tools_installer_dir'))
        self.tools_installer = '%s/%s/%s' % (os.path.dirname(os.path.realpath(__file__)), self.tools_installer_dir, self.parser.get('config_vm', 'tools_installer'))
        self.scp_connection_timeout = self.parser.getint('config_vm', 'scp_connection_timeout')
        self.except_retries = self.parser.getint('config_vm', 'except_retries')
        self.except_wait = self.parser.getint('config_vm', 'except_wait')

        self.agent_container = '%s/%s' % (os.path.dirname(os.path.dirname(os.path.realpath(__file__))), self.parser.get('config_agent', 'agent_container'))
        self.agent_err_log = self.parser.get('config_agent', 'agent_err_log')

        self.info_log, self.debug_log = setup_logging.return_loggers()


    def __copy_installer(self):
        '''
        Copy <tools_installer> on <vm> VM.
        Raise an exception if copy fails <except_retries> times.
        '''

        self.debug_log.debug("Copying tools installer to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))

        cmd = "scp -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o ConnectTimeout=%s -i %s -r %s ubuntu@%s:~/" % \
        (self.scp_connection_timeout, self.ssh_key_path, self.tools_installer_dir, self.vm.ip_address)
        cmd = cmd.split()

        FNULL = open(os.devnull, 'w')

        copied = False
        retries = self.except_retries
        while not copied and retries > 0:
            try:
                subprocess.check_call(cmd, stdout=FNULL, stderr=FNULL)
                copied = True
            except Exception, e:
                m = utils.exception_parser(e)
                err_str = 'Error scp copying tools installer to %s [VM: %s]: %s' % (self.vm.ip_address, self.vm.id, m)
                self.debug_log.warning(err_str)
                retries = retries - 1
                time.sleep(self.except_wait)

        if not copied:
            self.debug_log.error(err_str)
            raise VMPreparationException(err_str)

        self.debug_log.debug("Tools installer copied to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))
        return copied


    def __copy_agent(self):
        '''
        Copy XMLRPC agent on <vm> VM. Agent is contained in <agent_container> directory.
        Raise an exception if copy fails <except_retries> times.
        '''

        self.debug_log.debug("Copying measurement agent to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))

        agent_dirs = glob.glob('%s/*' % self.agent_container)
        cmd = "scp -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o ConnectTimeout=%s -i %s -r %s ubuntu@%s:~/" % (self.scp_connection_timeout, self.ssh_key_path, ' '.join(agent_dirs), self.vm.ip_address)
        cmd = cmd.split()

        FNULL = open(os.devnull, 'w')

        copied = False
        retries = self.except_retries
        while not copied and retries > 0:
            try:
                subprocess.check_call(cmd, stdout=FNULL, stderr=FNULL)
                copied = True
            except Exception, e:
                m = utils.exception_parser(e)
                err_str = 'Error scp copying measurement agent to %s [VM: %s]: %s' % (self.vm.ip_address, self.vm.id, m)
                self.debug_log.warning(err_str)
                retries = retries - 1
                time.sleep(self.except_wait)

        if not copied:
            self.debug_log.error(err_str)
            raise VMPreparationException(err_str)

        self.debug_log.debug("Measurement agent copied to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))
        return copied


    def install_tools(self, queue):
        '''
        Install required tools on <vm> VM. Configuration script is copied on VM by __copy_installer().
        Raise an exception if copy or installation fails <except_retries> times.
        '''

        self.debug_log.info("Installing tools to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))
        self.info_log.info("Installing tools to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))

        installed = False
        try:
            copied = self.__copy_installer()
        except Exception:
            raise
        if copied:
            install_cmd = 'sudo bash ~/%s/%s' % (os.path.basename(self.tools_installer_dir), os.path.basename(self.tools_installer))
            ssh_cmd = "ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o ConnectTimeout=%s -i %s ubuntu@%s" % (self.scp_connection_timeout, self.ssh_key_path, self.vm.ip_address)
            cmd = ssh_cmd.split()
            cmd.append(install_cmd)

            FNULL = open(os.devnull, 'w')

            retries = self.except_retries
            while not installed and retries > 0:
                try:
                    subprocess.check_call(cmd, stdout=FNULL, stderr=FNULL)
                    installed = True
                except Exception, e:
                    m = utils.exception_parser(e)
                    err_str = 'Error ssh launching tools installer to %s [VM: %s]: %s' % (self.vm.ip_address, self.vm.id, m)
                    self.debug_log.warning(err_str)
                    retries = retries - 1
                    time.sleep(self.except_wait)

        if not installed:
            self.debug_log.error(err_str)
            raise VMPreparationException(err_str)

        queue.put_nowait(installed)

        self.debug_log.info("Tools installed to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))
        self.info_log.info("Tools installed to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))
        return installed


    def launch_agent(self, queue):
        '''
        Launch XMLRPC agent on <vm> VM. Software agent is copied on VM by __copy_agent().
        Raise an exception if copy or installation fails <except_retries> times.
        '''

        self.debug_log.info("Launching measurement agent to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))
        self.info_log.info("Launching measurement agent to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))

        launched = False
        try:
            copied = self.__copy_agent()
        except Exception:
            raise
        if copied:
            launch_cmd = 'screen -dmS "agent" bash -c "sudo ~/agent/agent_measurement.py ~/agent/ 2>&1 | tee -a ~/%s"' % (self.agent_err_log)
            ssh_cmd = "ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o ConnectTimeout=%s -i %s ubuntu@%s" % (self.scp_connection_timeout, self.ssh_key_path, self.vm.ip_address)
            cmd = ssh_cmd.split()
            cmd.append(launch_cmd)

            FNULL = open(os.devnull, 'w')

            retries = self.except_retries
            while not launched and retries > 0:
                try:
                    subprocess.check_call(cmd, stdout=FNULL, stderr=FNULL)
                    launched = True
                except Exception, e:
                    m = utils.exception_parser(e)
                    err_str = 'Error ssh launching measurement agent to %s [VM: %s]: %s' % (self.vm.ip_address, self.vm.id, m)
                    self.debug_log.warning(err_str)
                    retries = retries - 1
                    time.sleep(self.except_wait)

        if not launched:
            self.debug_log.error(err_str)
            raise VMPreparationException(err_str)

        queue.put_nowait(launched)

        self.debug_log.info("Measurement agent launched to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))
        self.info_log.info("Measurement agent launched to %s [VM: %s]" % (self.vm.ip_address, self.vm.id))
        return launched
