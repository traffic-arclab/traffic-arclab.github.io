#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 28 dic 2015

@author: antonio
'''

import os, json, datetime, numpy
from ConfigParser import SafeConfigParser
from operator import itemgetter

from logger import setup_logging
from aws_utils import utils
from results_parser import extract_json, parse_results_xmlrpc

from core.colors import bcolors
from core.colors import experiment_colors
from core.utils import udm

class PrintResults:
    '''
    Printing facilities for campaigns results
    '''

    MEAN_INDEX = 0
    STD_INDEX = 1
    INFO_INDEX = 2

    def __init__(self):
        '''
        Constructor for PrintResults class
        '''

        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        self.results_container = self.parser.get('config_experiment', 'results_container')

        self.info_log, self.debug_log = setup_logging.return_loggers()


    def print_results(self, outdir):
        '''
        Print inter-experiments campaign summary and detailed experiments results
        '''
        try:
            self.debug_log.debug('Printing results of campaign: %s' % outdir)

            self.campaign_base_path = '%s/%s/%s' % (self.cloudsurf_base_path, self.results_container, outdir)

            res_json_filename = '%s/%s_results.json' % (self.campaign_base_path, outdir)
            if not os.path.exists(res_json_filename):
                err_str = "Campaign results json file doesn't exist!"
                self.debug_log.error(err_str)
                raise extract_json.ResultsParserException(err_str)

            with open(res_json_filename, 'r') as res_json_file:
                campaign_res_dict = json.load(res_json_file)
            campaign_res_dict = sorted(campaign_res_dict, key=itemgetter('start'))

            provider_snd = campaign_res_dict[0]['camp']['provider_snd'].upper()
            provider_rcv = campaign_res_dict[0]['camp']['provider_rcv'].upper()
            start_time = datetime.datetime.fromtimestamp(int(outdir.split('_')[-1])).strftime('%d/%m/%Y, %H:%M')


            campaing_info = parse_results_xmlrpc.campaign_parser(self.campaign_base_path)

            sender_placement = campaing_info.get('region_snd', 'None')
            receiver_placement = campaing_info.get('region_rcv', 'None')

            sender_type = campaing_info.get('size_snd', 'None')
            receiver_type = campaing_info.get('size_rcv', 'None')

            categorized_exps_lists, inter_experiments_summary_stats = \
            self.extract_categorize_experiments(campaign_res_dict)

            printable_str = u'\n%s Campaign %s%s%s summary:\n' % (bcolors.WHITE, bcolors.BOLDUNDERL, outdir, bcolors.ENDC)
            printable_str += u' [%s]: [%s] %s @ %s \u2192 [%s] %s @ %s%s\n' %\
            (start_time, provider_snd, sender_type, sender_placement, provider_rcv, receiver_type, receiver_placement, bcolors.ENDC)

            for inter_exp_summary_stats in inter_experiments_summary_stats:
                index = inter_experiments_summary_stats.index(inter_exp_summary_stats)
                cindex = index
                while cindex >= len(experiment_colors.colors_list):
                    cindex = cindex - len(experiment_colors.colors_list)
                proto = inter_exp_summary_stats['proto']
                if not proto:
                    proto = '-'
                printable_str += u'%s    %s x [%s]: ' %\
                (experiment_colors.colors_list[cindex], len(categorized_exps_lists[index]), proto.upper())

                for key in inter_exp_summary_stats:
                    if key in extract_json.ResultsParser.metrics:
                        if key == 'route':
                            printable_str += u'paris-traceroute from %s to %s' %\
                            (inter_exp_summary_stats[key][0], inter_exp_summary_stats[key][1])
                        else:
                            printable_str += u'(%.2f \u00b1 %.2f) %s | ' %\
                            (inter_exp_summary_stats[key][0], inter_exp_summary_stats[key][1], udm[key].get(proto, udm[key]['default']))
                printable_str = printable_str.rstrip('| ')
                printable_str += u'%s\n' % (bcolors.ENDC)

            printable_str += u"    \u21b3 Experiments details:\n"

            for exps_list in categorized_exps_lists:

                index = categorized_exps_lists.index(exps_list)
                cindex = index
                while cindex >= len(experiment_colors.colors_list):
                    cindex = cindex - len(experiment_colors.colors_list)
                printable_str += u"%s" % experiment_colors.colors_list[cindex]

                for exp_info in exps_list:
                    duration = exp_info[self.INFO_INDEX]['duration']
                    bandwidth = exp_info[self.INFO_INDEX]['bandwidth']
                    interval = exp_info[self.INFO_INDEX]['interval']
                    proto = exp_info[self.INFO_INDEX]['proto']
                    start_time = datetime.datetime.fromtimestamp(int(exp_info[self.INFO_INDEX]['start'])).strftime('%d/%m/%Y, %H:%M')

                    exp_results_str = u''
                    for metric in exp_info[self.MEAN_INDEX]:
                        if metric == 'route':
                            exp_results_str += u' MW = %s %s - PL = %s %s | ' %\
                            (exp_info[self.MEAN_INDEX][metric], udm[metric].get(proto, udm[metric]['default']), exp_info[self.STD_INDEX][metric], udm[metric].get(proto, udm[metric]['default']))
                        else:
                            if metric in exp_info[self.STD_INDEX]:
                                exp_results_str += u' (%.2f \u00b1 %.2f) %s | ' %\
                                (exp_info[self.MEAN_INDEX][metric], exp_info[self.STD_INDEX][metric], udm[metric].get(proto, udm[metric]['default']))
                            else:
                                exp_results_str += u' %.2f %s | ' %\
                                (exp_info[self.MEAN_INDEX][metric], udm[metric].get(proto, udm[metric]['default']))

                    if bandwidth != '-':
                        bw = (float(bandwidth))/numpy.power(10, 6)
                        printable_str += u'         [%s]: %s s @ %.2f Mbit/s w %s \u21d2 %s\n' %\
                        (start_time, duration, bw, proto.upper(), exp_results_str.rstrip('| '))
                    elif interval != '-':
                        pps = 1/(float(interval))
                        printable_str += u'         [%s]: %s s @ %.2f pps w %s \u21d2 %s\n' %\
                        (start_time, duration, pps, proto.upper(), exp_results_str.rstrip('| '))
                    elif duration:
                        printable_str += u'         [%s]: %s s w %s \u21d2 %s\n' %\
                        (start_time, duration, proto.upper(), exp_results_str.rstrip('| '))
                    else:
                        printable_str += u'         [%s]: %s probe pkts \u21d2 %s\n' %\
                        (start_time, proto.upper(), exp_results_str.rstrip('| '))

                printable_str += u"%s" % bcolors.ENDC

            print printable_str

        except Exception, e:
            m = utils.exception_parser(e)
            self.debug_log.error('Exception Raised: %s' % m)
            raise

        self.debug_log.debug('Campaign %s results successfully printed!' % outdir)
        return True


    def extract_categorize_experiments(self, campaign_res_dict):
        '''
        Categorize experiments by configurable parameters list and extract inter-experiments informations
        '''
        parameters_list = self.parser.get('config_inter_exp', 'parameters_list')
        parameters_list = parameters_list.split(',')

        categorizer_list = []
        for exp_res_dict in campaign_res_dict:
            parameters_tuple = []
            for parameter in parameters_list:
                parameters_tuple.append(exp_res_dict['info_snd'].get(parameter, '-'))
            categorizer_list.append(tuple(parameters_tuple))
        categorizer_set = utils.eliminate_duplicate(categorizer_list)

        inter_exps_list = [[] for _ in range(0, len(categorizer_set))]
        for exp_res_dict in campaign_res_dict:
            current_tuple = []
            for parameter in parameters_list:
                current_tuple.append(exp_res_dict['info_snd'].get(parameter, '-'))
            current_tuple = tuple(current_tuple)

            for categorizer_tuple in categorizer_set:
                if current_tuple == categorizer_tuple:
                    corresponding = True
                    break
                else:
                    corresponding = False
                    continue

            if corresponding:
                info = {}
                info['duration'] = exp_res_dict.get('duration', '-')
                info['bandwidth'] = exp_res_dict['info_snd'].get('target_bwd', '-')
                info['interval'] = exp_res_dict['info_snd'].get('granularity', '-')
                info['ip_sender'] = exp_res_dict['info_snd'].get('ip_sender', '0.0.0.0')
                info['ip_receiver'] = exp_res_dict['info_snd'].get('ip_receiver', '0.0.0.0')
                info['start'] = exp_res_dict.get('start', 0)
                info['proto'] = exp_res_dict.get('proto', '-')
                if not info['proto']:
                    info['proto'] = '-'

                exp_means = {}
                exp_stds = {}
                for metric in exp_res_dict['results']:
                    if exp_res_dict['results'][metric]['synt']:
                        if metric == 'route':
                            if exp_res_dict['results'][metric]['synt']['max_width'] is not None\
                            and exp_res_dict['results'][metric]['synt']['path_length'] is not None:
                                exp_means[metric] = exp_res_dict['results'][metric]['synt']['max_width']
                                exp_stds[metric] = exp_res_dict['results'][metric]['synt']['path_length']
                        else:
                            if exp_res_dict['results'][metric]['synt']['mean'] is not None\
                            and exp_res_dict['results'][metric]['synt']['std'] is not None:
                                exp_means[metric] = exp_res_dict['results'][metric]['synt']['mean']
                                exp_stds[metric] = exp_res_dict['results'][metric]['synt']['std']
                            elif exp_res_dict['results'][metric]['synt']['mean'] is not None:
                                exp_means[metric] = exp_res_dict['results'][metric]['synt']['mean']
                inter_exps_list[categorizer_set.index(categorizer_tuple)].append((exp_means, exp_stds, info))

        inter_exps_stats = []
        for metric in extract_json.ResultsParser.metrics:
            for inter_exps in inter_exps_list:

                index = inter_exps_list.index(inter_exps)
                if index >= len(inter_exps_stats):
                    inter_exps_stats.append({})

                if 'proto' not in inter_exps_stats[index]:
                    inter_exps_stats[index]['proto'] = inter_exps[0][self.INFO_INDEX]['proto']

                #if you have at least one "route" information
                if metric == 'route' and inter_exps[0][self.MEAN_INDEX].get(metric, None):
                    #For paris-traceroute, the inter-experiments summary reports source and destination of traceroute/s
                    inter_exps_stats[index][metric] = \
                    (inter_exps[0][self.INFO_INDEX]['ip_sender'], inter_exps[0][self.INFO_INDEX]['ip_receiver'])
                else:
                    inter_exps_means = []
                    for inter_exp_mean in inter_exps:
                        inter_exps_means.append(inter_exp_mean[self.MEAN_INDEX].get(metric, None))
                    if None not in inter_exps_means:
                        inter_exps_stats[index][metric] = (numpy.mean(inter_exps_means), numpy.std(inter_exps_means))

        return inter_exps_list, inter_exps_stats
