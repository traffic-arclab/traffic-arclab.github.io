#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
Created on 28 dic 2015

@author: antonio
'''

import os, glob, time
import shutil, gzip

from ConfigParser import SafeConfigParser

from logger import setup_logging
from aws_utils import utils
from print_results import print_results
from core.utils import clear
from core.banner import Banner
from core.prompt import Prompt
from core.colors import bcolors


def try_extract_timestamp(cdir):
    try:
        timestamp = int(cdir.split('_')[-1])
        time.ctime(timestamp)
        return timestamp
    except ValueError:
        pass
    
    try:
        timestamp = int(cdir.split('_')[-2])
        time.ctime(timestamp)
        return timestamp
    except ValueError:
        pass
    
    
def decompress(gzip_filename, res_json_filename, res_json_dir):
    '''
    Decompress downloaded .gz campaign results file
    '''
    
    try:
        os.makedirs(res_json_dir)
        with gzip.open(gzip_filename, 'rb') as gzip_file, open('%s/%s.json' % (res_json_dir, os.path.basename(res_json_filename)), 'wb') as res_json_file:
            shutil.copyfileobj(gzip_file, res_json_file)
        os.remove(gzip_filename)
    except OSError:
        if os.path.exists('%s/%s.json' % (res_json_dir, os.path.basename(res_json_filename))):
            os.remove(gzip_filename)
    return
    
    
def check_previous_results(step_chain):
    cloudsurf_base_path = os.path.dirname(os.path.realpath(__file__))
    parser = SafeConfigParser()
    parser.read(cloudsurf_base_path + '/conf/conf_cloudsurf.ini')
    results_container = parser.get('config_experiment', 'results_container')

    step_chain.append('Print Campaigns Results')
    clear()
    Banner.show_graphic_text()
    where_am_i = "\n "+" > ".join(step_chain)+"\n"
    where_am_i = "%s%s%s" % (bcolors.RED, where_am_i, bcolors.ENDC)
    print where_am_i
    print "%s %s%s\n" % (bcolors.BOLD, 'Campaigns Results', bcolors.ENDC)

    printer = print_results.PrintResults()
    campaigns_dirs = glob.glob('%s/*' % results_container)

    for campaign_dir in sorted(campaigns_dirs, key=lambda cdir: try_extract_timestamp(cdir)):
        if os.path.isdir(campaign_dir):
            try:
                printer.print_results(os.path.basename(campaign_dir))
            except Exception, e:
                m = utils.exception_parser(e)

                summary_str = '\n%s Campaign %s%s%s summary:\n' %\
                (bcolors.WHITE, bcolors.BOLDUNDERL, os.path.basename(campaign_dir), bcolors.ENDC)
                err_str = bcolors.RED_BOLD + " Checking results failed: " + m +\
                "\n Please check campaign directory: " + bcolors.UNDERL + os.path.basename(campaign_dir) + bcolors.ENDC +\
                bcolors.RED_BOLD + "\n More information on occurred errors are in " +\
                bcolors.UNDERL + "cloudsurf/log/debug.log" + bcolors.ENDC + ".\n"

                print ('%s%s') % (summary_str, err_str)
                  
        elif os.path.splitext(campaign_dir)[-1].lower() == '.gz':
            try:
                res_json_encoded = os.path.splitext(campaign_dir)[-2]
                res_json_filename = res_json_encoded[:res_json_encoded.rfind('_')]
                res_json_dir = res_json_filename[:res_json_filename.rfind('_')]
                decompress(campaign_dir, res_json_filename, res_json_dir)
                printer.print_results(os.path.basename(res_json_dir))
            except Exception, e:
                m = utils.exception_parser(e)

                summary_str = '\n%s Campaign %s%s%s summary:\n' %\
                (bcolors.WHITE, bcolors.BOLDUNDERL, os.path.basename(campaign_dir), bcolors.ENDC)
                err_str = bcolors.RED_BOLD + " Checking results failed: " + m +\
                "\n Please check campaign directory: " + bcolors.UNDERL + os.path.basename(campaign_dir) + bcolors.ENDC +\
                bcolors.RED_BOLD + "\n More information on occurred errors are in " +\
                bcolors.UNDERL + "cloudsurf/log/debug.log" + bcolors.ENDC + ".\n"

                print ('%s%s') % (summary_str, err_str)
    return


def main():
    sid = "Check Previous Results"  # step id
    step_chain = []
    step_chain.append(sid)

    where_am_i = "\n "+" > ".join(step_chain)+"\n"
    where_am_i = "%s%s%s" % (bcolors.RED, where_am_i, bcolors.ENDC)

    intro = "\n This feature allows you to check previous\n results distinguished by " + bcolors.UNDERL + "different campaigns" + bcolors.ENDC+"."
    intro = "%s%s%s" %(bcolors.BOLD, intro, bcolors.ENDC)

    info_log, debug_log = setup_logging.return_loggers()
    debug_log.info('Selected CloudSurf feature: Check Previous Results (6)')
    info_log.info('Selected CloudSurf feature: Check Previous Results (6)')

    clear()
    Banner.show_graphic_text()
    print where_am_i
    raw_input(Prompt.press_a_key(intro))

    check_previous_results(step_chain)

    raw_input(Prompt.press_a_key('\033[F'))
    return


if __name__ == "__main__":
    main()
