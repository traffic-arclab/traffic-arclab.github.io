#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 29 dic 2015

@author: antonio
'''

import sys, math, Queue
import not_implemented
import interactive

from termios import tcflush, TCIFLUSH
from aws_utils import utils
from threading import Lock, Thread
from core.prompt import Prompt
from core.colors import bcolors
from core.menus import Menus, step_template, please_wait, generic_print
from core.progress import task_resume
from core.experiment_templates import ExperimentTemplates

from cost_calculator import calculator
from tasks import aws_tasks


class EC2SelectionException(Exception):
    '''
    Exception for EC2Selection class
    '''
    def __init__(self, message):
        self.message = message
    def __str__(self):
        return str(self.message)


class EC2Selection:
    '''
    Class for management of user choices in EC2 scenarios
    '''

    def __init__(self, cloudsurf_mode, input_dict):
        '''
        Constructor for class EC2Selection
        '''

        self.cloudsurf_mode = cloudsurf_mode
        self.input_dict = input_dict


    def extract_user_choices(self):
        '''
        Extract user choices from interactive menus
        '''

        if self.cloudsurf_mode.upper() == 'INTRA-DATACENTER':
            region = Menus.amazon_regions['body'][int(self.input_dict['REGION'])-1].split('[')[1].rstrip(']')
            parameters = {
                          'cloudsurf_mode': 'INTRA-DATACENTER',
                          'provider': 'aws',
                          'sender_type': Menus.get_ec2_instance_type(region)['body'][int(self.input_dict['SENDER_TYPE'])-1],
                          'sender_region': region,
                          'sender_placement': None,
                          'receiver_type': Menus.get_ec2_instance_type(region)['body'][int(self.input_dict['RECEIVER_TYPE'])-1],
                          'receiver_region': region,
                          'receiver_placement': None
                          }

        elif self.cloudsurf_mode.upper() == 'INTER-DATACENTER':
            sender_region = Menus.amazon_regions['body'][int(self.input_dict['SENDER_REGION'])-1].split('[')[1].rstrip(']')
            receiver_region = Menus.get_receiver_regions(sender_region)['body'][int(self.input_dict['RECEIVER_REGION'])-1].split('[')[1].rstrip(']')
            parameters = {
                          'cloudsurf_mode': 'INTER-DATACENTER',
                          'provider': 'aws',
                          'sender_type': Menus.get_ec2_instance_type(sender_region)['body'][int(self.input_dict['SENDER_TYPE'])-1],
                          'sender_region': sender_region,
                          'sender_placement': None,
                          'receiver_type': Menus.get_ec2_instance_type(receiver_region)['body'][int(self.input_dict['RECEIVER_TYPE'])-1],
                          'receiver_region': receiver_region,
                          'receiver_placement': None
                          }

        else:
            err_str = 'Error in CloudSurf mode selection: %s is not supported!' % self.cloudsurf_mode
            raise EC2SelectionException(err_str)

        exp_list_parameters = ExperimentTemplates.template_choice[self.input_dict['EXPERIMENT']]
        return parameters, exp_list_parameters
    
    
    def get_total_minutes_duration(self, exp_list_parameters):
        '''
        Get campaign duration in minutes
        '''
        
        total_duration = 0
        for parameters in exp_list_parameters:
            total_duration += parameters.get('duration', 0)
        return int(math.ceil(total_duration/60.0))


    def get_goto_menu(self, menu_list, where_to_go, step_chain):
        '''
        Dynamically build goto menu
        '''

        menu = {}
        for choice in range(1, len(menu_list) + 1):
            menu[str(choice)] = {"f": where_to_go, "a": (step_chain,)}
        menu["default"] = {"f": not_implemented.main, "a": ()}
        menu["99"] = {"f": interactive.main, "a": ()}
        return menu


    def start_execution(self):
        '''
        Start campaign execution and manage its progression
        '''

        resume_header = " %s" % self.cloudsurf_mode
        parameters, exp_list_parameters = self.extract_user_choices()
        


        task_operations = aws_tasks.AWSTasks(parameters, exp_list_parameters)
        task_list = [
                     "Initialization",
                     "VM startup (Around 5 minutes needed)",
                     "VM configuration",
                     "Synthetic traffic generation (Around %s minutes needed)" % (self.get_total_minutes_duration(exp_list_parameters)),
                     "Data retrieval",
                     "Cleaning up",
                     "Parsing Results"
                    ]
        task_functions = [
                        task_operations.initialization,
                        task_operations.VM_startup,
                        task_operations.VM_configuration,
                        task_operations.start_experiment_template,
                        task_operations.retrieve_results,
                        task_operations.clean_cloud,
                        task_operations.parse_results
                        ]

        not_finished = Lock()
        queue = Queue.Queue(maxsize=1)
        for task in task_list:
            try:
                not_finished.acquire()
                task_index = task_list.index(task)
                Thread(target=task_functions[task_index], args=(not_finished, queue)).start()
                task_resume(resume_header, task_list, task_index, not_finished)
                returned_outcome = queue.get_nowait()
                if not returned_outcome:
                    err_str = 'Task %s raised an exception' % task
                    raise EC2SelectionException(err_str)
            except KeyboardInterrupt:
                head = 'Cloud Restoration'
                body = 'Beware! Exiting via Control-C could leave your cloud environment in an inconsistent status.'
                body += '\n We will try to restore your cloud environment... Check for termination of unwanted resources.'
                generic_print(head, bcolors.BOLD, body, bcolors.YELLOW_BOLD)
                task_operations.restore_cloud()
                raise
            except Exception, e:
                m = utils.exception_parser(e)
                head = 'Cloud Restoration'
                body = '%s... Cloud environment will be restored now!' % m
                generic_print(head, bcolors.BOLD, body, bcolors.YELLOW_BOLD)
                task_operations.restore_cloud()
                raise
            
        before_upload_msg = 'Your results have been saved locally. You can check them via "Check Previous Results" feature.'
        before_upload_msg += '\n Your results are going to be uploaded to the community database...'
        print "\n\n%s%s %s%s\n" % (bcolors.GREEN, bcolors.BOLD, before_upload_msg, bcolors.ENDC)

        tcflush(sys.stdin, TCIFLUSH)
        raw_input(Prompt.press_a_key('\033[F'))
        
        returned_outcome = task_operations.upload_results()
        if not returned_outcome:
            err_str = 'Exception raised: upload_results returned %s!' % returned_outcome
            raise EC2SelectionException(err_str)

        tcflush(sys.stdin, TCIFLUSH)
        raw_input(Prompt.press_a_key('\033[F'))

        returned_outcome = task_operations.print_results()
        if not returned_outcome:
            err_str = 'Exception raised: print_results returned %s!' % returned_outcome
            raise EC2SelectionException(err_str)

        tcflush(sys.stdin, TCIFLUSH)
        raw_input(Prompt.press_a_key('\033[F'))


    def select_provider(self, step_chain):
        '''
        Provider selection
        '''

        input_key = "PROVIDER"
        class Goto:
            main = self.get_goto_menu(Menus.providers["body"], self.select_experiment, step_chain)
        sid = "Provider Selection"
        step_template(sid, step_chain, Menus.providers["head"], Menus.providers["body"], Goto.main, self.input_dict, input_key)


    def select_experiment(self, step_chain):
        '''
        Experiment template selection
        '''

        input_key = "EXPERIMENT"
        sid = "Experiment Selection"

        if self.cloudsurf_mode.upper() == 'INTRA-DATACENTER':
            class Goto:
                main = self.get_goto_menu(Menus.intradatacenter_experiments["body"], self.select_region, step_chain)
            step_template(sid, step_chain, Menus.intradatacenter_experiments["head"], Menus.intradatacenter_experiments["body"], Goto.main, self.input_dict, input_key)

        elif self.cloudsurf_mode.upper() == 'INTER-DATACENTER':
            class Goto:
                main = self.get_goto_menu(Menus.interdatacenter_experiments["body"], self.select_region_s, step_chain)
            step_template(sid, step_chain, Menus.interdatacenter_experiments["head"], Menus.interdatacenter_experiments["body"], Goto.main, self.input_dict, input_key)

        else:
            err_str = 'Error in CloudSurf mode selection: %s is not supported!' % self.cloudsurf_mode
            raise EC2SelectionException(err_str)


    def select_region(self, step_chain):
        '''
        Region selection for intra-datacenter feature
        '''

        input_key = "REGION"
        class Goto:
            main = self.get_goto_menu(Menus.amazon_regions["body"], self.select_type_s, step_chain)
        sid = "Region Selection"
        step_template(sid, step_chain, Menus.amazon_regions["head"], Menus.amazon_regions["body"], Goto.main, self.input_dict, input_key)


    def select_region_s(self, step_chain):
        '''
        Sender region selection for inter-datacenter feature
        '''

        input_key = "SENDER_REGION"
        class Goto:
            main = self.get_goto_menu(Menus.amazon_regions["body"], self.select_region_r, step_chain)
        sid = "Sender Region Selection"
        step_template(sid, step_chain, Menus.amazon_regions["head"], Menus.amazon_regions["body"], Goto.main, self.input_dict, input_key)


    def select_region_r(self, step_chain):
        '''
        Receiver region selection for inter-datacenter feature
        '''

        input_key = "RECEIVER_REGION"
        sender_region = Menus.amazon_regions['body'][int(self.input_dict['SENDER_REGION'])-1].split('[')[1].rstrip(']')
        amazon_receiver_regions = Menus.get_receiver_regions(sender_region)
        class Goto:
            main = self.get_goto_menu(amazon_receiver_regions['body'], self.select_type_s, step_chain)
        sid = "Receiver Region Selection"
        step_template(sid, step_chain, amazon_receiver_regions["head"], amazon_receiver_regions["body"], Goto.main, self.input_dict, input_key)


    def select_type_s(self, step_chain):
        '''
        Sender VM type selection
        '''

        input_key = "SENDER_TYPE"
        try:
            sender_region = Menus.amazon_regions['body'][int(self.input_dict['REGION'])-1].split('[')[1].rstrip(']')
        except KeyError:
            sender_region = Menus.amazon_regions['body'][int(self.input_dict['SENDER_REGION'])-1].split('[')[1].rstrip(']')
        class Goto:
            main = self.get_goto_menu(Menus.get_ec2_instance_type(sender_region)["body"], self.select_type_r, step_chain)
        sid = "Sender Selection"
        step_template(sid, step_chain, Menus.get_ec2_instance_type(sender_region)["head"], Menus.get_ec2_instance_type(sender_region)["body"], Goto.main, self.input_dict, input_key)


    def select_type_r(self, step_chain):
        '''
        Receiver VM type selection
        '''

        input_key = "RECEIVER_TYPE"
        try:
            receiver_region = Menus.amazon_regions['body'][int(self.input_dict['REGION'])-1].split('[')[1].rstrip(']')
        except KeyError:
            sender_region = Menus.amazon_regions['body'][int(self.input_dict['SENDER_REGION'])-1].split('[')[1].rstrip(']')
            amazon_receiver_regions = Menus.get_receiver_regions(sender_region)
            receiver_region = amazon_receiver_regions['body'][int(self.input_dict['RECEIVER_REGION'])-1].split('[')[1].rstrip(']')
        class Goto:
            main = self.get_goto_menu(Menus.get_ec2_instance_type(receiver_region)["body"], self.calculate_price, step_chain)
        sid = "Receiver Selection"
        step_template(sid, step_chain, Menus.get_ec2_instance_type(receiver_region)["head"], Menus.get_ec2_instance_type(receiver_region)["body"], Goto.main, self.input_dict, input_key)


    def calculate_price(self, step_chain):
        '''
        Estimate prices for current campaign
        '''

        wait_str = ' Please wait... We are calculating experimental campaign prices for you!'
        sid = "Price Calculation"
        step_chain.append(sid)
        please_wait(step_chain, wait_str)

        try:
            parameters, exp_list_parameters = self.extract_user_choices()
            pricing_parameters = {
                                  'cloudsurf_mode': self.cloudsurf_mode,
                                  'provider': parameters['provider'],
                                  'intra-datacenter_mode': 'public',
                                  'sender_region': parameters['sender_region'],
                                  'sender_type': parameters['sender_type'],
                                  'receiver_region': parameters['receiver_region'],
                                  'receiver_type': parameters['receiver_type'],
                                  'experiments': exp_list_parameters
                                  }

            price_calculator = calculator.PriceCalculator(pricing_parameters)
            total_instances_price, total_data_transfer_price, local = price_calculator.calculate_campaign_price()

            price_str = "The cost estimated for the campaign is:\n"
            price_str += "   - Virtual machines: %s $\n" % total_instances_price
            price_str += "   - Data transfer: %s $\n" % total_data_transfer_price
            price_str += "   - Total: %s $\n" % (total_instances_price + total_data_transfer_price)

            if local:
                price_str += '   BEWARE! Costs are calculated based on out-of-date information!\n'

            self.price_confirmation(step_chain, price_str)

        except calculator.PriceCalculatorException:
            err_str = "\n Price calculation failed!"
            err_str = "%s%s%s" %(bcolors.RED_BOLD, err_str, bcolors.ENDC)
            print err_str
            raise


    def price_confirmation(self, step_chain, price_str):
        '''
        Print estimated campaign prices and prompt user to continue or not
        '''

        input_key = "PRICE_CONFIRMATION"
        class Goto:
            main = {
                    "1": {"f": self.start_execution, "a": ()},
                    "2": {"f": interactive.main, "a": ()},
                    "default": {"f": not_implemented.main, "a": ()},
                    "99": {"f": interactive.main, "a": ()}
                }
        sid = ""
        step_template(sid, step_chain, Menus.price_yes_no_choice["head"], Menus.price_yes_no_choice["body"], Goto.main, self.input_dict, input_key, price_str)
