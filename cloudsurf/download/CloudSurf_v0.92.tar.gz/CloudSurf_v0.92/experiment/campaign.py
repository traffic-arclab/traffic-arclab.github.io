#    CloudSurf is a platform to easily perform network monitoring tasks in public cloud infrastructures from the general user angle.
#
#    Copyright (C) 2016  Valerio Persico, Antonio Montieri
#    email: valerio.persico@unina.it, montieri@nm-2.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
Created on 03 dic 2015

@author: antonio
'''

import os, time, boto.ec2

from aws_utils import utils
from logger import setup_logging
from ConfigParser import SafeConfigParser
from master_cloud import master_cloud


class CampaignException(Exception):
    '''
    Exception for Campaign class
    '''
    def __init__(self, message):
        self.message = message
    def __str__(self):
        return str(self.message)


class Campaign:
    '''
    Campaign management class
    '''

    TOOL_SIDE_TYPE = {
    'PING' : 'one-side',
    'NUTTCP' : 'two-side',
    'PARIS_TRACEROUTE': 'one-side'
    }


    def __init__(self, parameters_list, vm_sender, vm_receiver, sender_ssh_key_name, receiver_ssh_key_name):
        '''
        Constructor for class Campaign.
        Input:
        - parameters_list (list): each element is a dict containing experimental parameters
                                  (e.g. tool, port, proto, duration, bandwidth, sleep_exp);
                                  experiments will be executed between the same VMs
        - vm_sender (boto.ec2.instance object): sender VM boto object
        - vm_receiver (boto.ec2.instance object): receiver VM boto object
        - ssh_key_name (str): ssh private key name
        '''

        #Example parameters list
        #NUTTCP receiver sender 30000 30000 exp_receiver exp_sender 18100 tcp 300 2000000000 outdir_sr nuttcp_sr
        #NUTTCP receiver sender 30000 30000 exp_receiver exp_sender 18200 udp 300 2000000000 outdir_sr nuttcp_sr
        self.parameters_list = parameters_list
        self.sender = vm_sender
        self.receiver = vm_receiver

        #CloudSurf parser
        self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        self.parser = SafeConfigParser()
        self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')

        #ssh_key_paths definition
        self.sender_ssh_key_path = os.path.expanduser('~/%s/%s.pem' % (self.parser.get('config_key_pair', 'ssh_key_dir'), sender_ssh_key_name))
        self.receiver_ssh_key_path = os.path.expanduser('~/%s/%s.pem' % (self.parser.get('config_key_pair', 'ssh_key_dir'), receiver_ssh_key_name))

        #Results directories' container
        self.results_container = self.parser.get('config_experiment', 'results_container')

        #Exception parameters
        self.except_retries = self.parser.getint('config_experiment', 'except_retries')
        self.except_wait = self.parser.getint('config_experiment', 'except_wait')

        #Agent configuration parameters
        self.agent_container = '%s/%s' % (os.path.dirname(os.path.dirname(os.path.realpath(__file__))), self.parser.get('config_agent', 'agent_container'))
        self.agent_dir = '%s/%s' % (self.agent_container, self.parser.get('config_agent', 'agent_dir'))
        self.agent_config_file = '%s/%s/%s' % (self.agent_dir, self.parser.get('config_agent', 'agent_config_dir'), self.parser.get('config_agent', 'agent_config_file'))
        self.agent_err_log = self.parser.get('config_agent', 'agent_err_log')

        #Parser agent configuration parameters
        self.parser_agent = SafeConfigParser()
        self.parser_agent.read(self.agent_config_file)

        #Agent results and logs directories' paths
        self.remote_agent_res_path = '~/%s' % self.parser_agent.get('config_agent', 'res_dir')
        self.remote_agent_log_path = '~/%s/%s' % (self.parser.get('config_agent', 'agent_dir'), self.parser_agent.get('config_agent', 'log_dir'))

        #IP addresses and ports identifying sender and receiver XMLRPC agents
        self.service_ip_sender = self.sender.ip_address
        self.service_ip_receiver = self.receiver.ip_address
        self.service_port_sender = self.parser_agent.getint('config_agent', 'port')
        self.service_port_receiver = self.parser_agent.getint('config_agent', 'port')

        #Experimental sender and receiver IP addresses
        #TODO: Trivial solution --> Experimental addresses are the same of XMLRPC agents addresses
        self.exp_ip_sender = self.sender.ip_address
        self.exp_ip_receiver = self.receiver.ip_address

        #Determine sender and receiver providers
        if isinstance(self.sender, boto.ec2.instance.Instance):
            self.sender_provider = 'aws'
        else:
            self.sender_provider = 'msa'

        if isinstance(self.receiver, boto.ec2.instance.Instance):
            self.receiver_provider = 'aws'
        else:
            self.receiver_provider = 'msa'

        #Directory where agent will save results
        timestamp = int(time.time())
        self.outdir = '%s-%s-%s_%s-%s-%s_%s'\
        % (self.sender_provider, self.sender.placement, self.sender.instance_type,\
           self.receiver_provider, self.receiver.placement, self.receiver.instance_type, timestamp)

        #Setup logger objects
        self.info_log, self.debug_log = setup_logging.return_loggers()

        #Allocate a MasterCloud object
        self.mc = master_cloud.MasterCloud()

        #Experiments' sequence is one side, if all used tools are one side
        self.one_side = all(self.TOOL_SIDE_TYPE[parameters['tool'].upper()] == 'one-side' for parameters in self.parameters_list)


    def __str__(self):
        '''
        Return experiment printable representation.
        '''

        i = 1
        exp_string = ''
        for parameters in self.parameters_list:
            exp_string += '%s) Tool %s: from %s [%s:%s] to %s [%s:%s] with parameters: ' % \
            (i, parameters['tool'], self.exp_ip_sender, self.service_ip_sender, self.service_port_sender, \
             self.exp_ip_receiver, self.service_ip_receiver, self.service_port_receiver)

            for parameter in sorted(parameters, key=parameters.get):
                if parameter != 'tool':
                    exp_string += '%s = %s, ' % (parameter, parameters[parameter])

            exp_string = exp_string.rstrip(', ') +  '; '
            i += 1
        return exp_string.rstrip('; ')


    def __test_agent_activation(self):
        '''
        Test XMLRPC agent activation calling mc.test_agent().
        Raise an exception if activation testing fails <except_retries> times.
        '''

        active = False
        retries = self.except_retries

        while not active and retries > 0:
            try:
                message_sender = self.mc.test_agent(self.service_ip_sender, self.service_port_sender, 'sender_activated')
                self.debug_log.debug('[%s:%s] Message received by sender: %s' % \
                (self.service_ip_sender, self.service_port_sender, message_sender))
                if not self.one_side:
                    message_receiver = self.mc.test_agent(self.service_ip_receiver, self.service_port_receiver, 'receiver_activated')
                    self.debug_log.debug('[%s:%s] Message received by receiver: %s' % \
                    (self.service_ip_receiver, self.service_port_receiver, message_receiver))
                else:
                    message_receiver = 'receiver_activated'
                if message_sender == 'sender_activated' and message_receiver == 'receiver_activated':
                    active = True
                else:
                    retries = retries - 1
                    err_str = '[%s:%s - %s:%s] Waiting for agents starting: wrong return messages --> Remaining attempts: %s' % \
                    (self.service_ip_sender, self.service_port_sender, self.service_ip_receiver, self.service_port_receiver, retries)
                    self.debug_log.warning(err_str)
                    time.sleep(self.except_wait)
            except Exception, e:
                retries = retries - 1
                m = utils.exception_parser(e)
                err_str = '[%s:%s - %s:%s] Waiting for agents starting: %s --> Remaining attempts: %s' % \
                (self.service_ip_sender, self.service_port_sender, self.service_ip_receiver, self.service_port_receiver, m, retries)
                self.debug_log.warning(err_str)
                time.sleep(self.except_wait)

        if not active:
            self.debug_log.error(err_str)
            raise CampaignException(err_str)

        return active


    def get_outdir(self):
        '''
        Return campaign outdir
        '''

        return self.outdir


    def get_parameters_list(self):
        '''
        Return experimental parameters list
        '''

        return self.parameters_list


    def run_experiment(self):
        '''
        Run the experiments between sender e receiver VMs.
        '''

        self.debug_log.info('Running experiment between VMs %s and %s --> %s' % \
        (self.sender.id, self.receiver.id, str(self)))
        self.info_log.info('Running experiment between VMs %s and %s --> %s' % \
        (self.sender.id, self.receiver.id, str(self)))

        experiments_list = []
        for parameters in self.parameters_list:
            #Create a new dict to maintain information on external parameters
            experiment = parameters.copy()
            experiment['service_ip_sender'] = self.service_ip_sender
            experiment['service_ip_receiver'] = self.service_ip_receiver
            experiment['service_port_sender'] = self.service_port_sender
            experiment['service_port_receiver'] = self.service_port_receiver

            #TODO: Trivial solution --> Experimental addresses are the same of XMLRPC agents addresses
            #If you would like to make them different (e.g. private addresses in intra-datacenter)
            #they must be 'parameters' of the experiment.
            experiment['exp_ip_sender'] = self.exp_ip_sender
            experiment['exp_ip_receiver'] = self.exp_ip_receiver

            experiment['outdir'] = self.outdir
            experiment['client_tag'] = 'cloudsurf_%s' % parameters['tool'].lower()

            #TODO: Trivial solution --> Experiments list composed by only one parameter
            experiments_list.append(experiment)

        try:
            self.__test_agent_activation()
        except Exception:
            raise

        try:
            self.mc.run_experiments(experiments_list, mode=0, repetitions=1, sleep_rep=0)
        except Exception:
            raise

        self.debug_log.info('Completed experiment between VMs %s and %s --> %s' % \
        (self.sender.id, self.receiver.id, str(self)))
        self.info_log.info('Completed experiment between VMs %s and %s --> %s' % \
        (self.sender.id, self.receiver.id, str(self)))
        return


    def store_results(self):
        '''
        Merge and store sender and receiver results' directories
        '''

        sender_parameters = {
        'ip_agent' : self.sender.ip_address,
        'port_agent' : self.service_port_sender,
        'key_path' : self.sender_ssh_key_path,
        'res_path_agent' : self.remote_agent_res_path,
        'log_path_agent' : self.remote_agent_log_path,
        'agent_err' : self.agent_err_log,
        'res_path_master' : self.results_container,
        'outdir' : self.outdir,
        'new_log_name' : '%s_sender' % self.outdir
        }

        receiver_parameters = {
        'ip_agent' : self.receiver.ip_address,
        'port_agent' : self.service_port_receiver,
        'key_path' : self.receiver_ssh_key_path,
        'res_path_agent' : self.remote_agent_res_path,
        'log_path_agent' : self.remote_agent_log_path,
        'agent_err' : self.agent_err_log,
        'res_path_master' : self.results_container,
        'outdir' : self.outdir,
        'new_log_name' : '%s_receiver' % self.outdir
        }

        try:
            self.debug_log.info('Pulling results from %s [VM: %s]' % (self.sender.ip_address, self.sender.id))
            self.info_log.info('Pulling results from %s [VM: %s]' % (self.sender.ip_address, self.sender.id))
            pulled = self.mc.pull_results(sender_parameters)
            self.debug_log.info('Results successfully pulled from %s [VM: %s]' % (self.sender.ip_address, self.sender.id))
            self.info_log.info('Results successfully pulled from %s [VM: %s]' % (self.sender.ip_address, self.sender.id))
            if not self.one_side and pulled:
                self.debug_log.info('Pulling results from %s [VM: %s]' % (self.receiver.ip_address, self.receiver.id))
                self.info_log.info('Pulling results from %s [VM: %s]' % (self.receiver.ip_address, self.receiver.id))
                pulled = self.mc.pull_results(receiver_parameters)
                self.debug_log.info('Results successfully pulled from %s [VM: %s]' % (self.receiver.ip_address, self.receiver.id))
                self.info_log.info('Results successfully pulled from %s [VM: %s]' % (self.receiver.ip_address, self.receiver.id))
        except Exception:
            raise

        return pulled
