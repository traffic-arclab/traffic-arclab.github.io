#########################################
# The CloudSurf Suite                   #
# Written by:                           #
#########################################
import os
import re
import sys
# check operating system
def check_os():
    if os.name == "nt":
        operating_system = "windows"
    if os.name == "posix":
        operating_system = "posix"
    return operating_system


#
# Class for colors
#
if check_os() == "posix":
    class bcolors:
        PURPLE = '\033[95m'
        CYAN = '\033[96m'
        DARKCYAN = '\033[36m'
        BLUE = '\033[94m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        RED = '\033[91m'
        BOLD = '\033[1m'
        UNDERL = '\033[4m'
        ENDC = '\033[0m'
        backBlack = '\033[40m'
        backRed = '\033[41m'
        backGreen = '\033[42m'
        backYellow = '\033[43m'
        backBlue = '\033[44m'
        backMagenta = '\033[45m'
        backCyan = '\033[46m'
        backWhite = '\033[47m'

        def disable(self):
            self.PURPLE = ''
            self.CYAN = ''
            self.BLUE = ''
            self.GREEN = ''
            self.YELLOW = ''
            self.RED = ''
            self.ENDC = ''
            self.BOLD = ''
            self.UNDERL = ''
            self.backBlack = ''
            self.backRed = ''
            self.backGreen = ''
            self.backYellow = ''
            self.backBlue = ''
            self.backMagenta = ''
            self.backCyan = ''
            self.backWhite = ''
            self.DARKCYAN = ''

# if we are windows or something like that then define colors as nothing
else:
    class bcolors:
        PURPLE = ''
        CYAN = ''
        DARKCYAN = ''
        BLUE = ''
        GREEN = ''
        YELLOW = ''
        RED = ''
        BOLD = ''
        UNDERL = ''
        ENDC = ''
        backBlack = ''
        backRed = ''
        backGreen = ''
        backYellow = ''
        backBlue = ''
        backMagenta = ''
        backCyan = ''
        backWhite = ''

        def disable(self):
            self.PURPLE = ''
            self.CYAN = ''
            self.BLUE = ''
            self.GREEN = ''
            self.YELLOW = ''
            self.RED = ''
            self.ENDC = ''
            self.BOLD = ''
            self.UNDERL = ''
            self.backBlack = ''
            self.backRed = ''
            self.backGreen = ''
            self.backYellow = ''
            self.backBlue = ''
            self.backMagenta = ''
            self.backCyan = ''
            self.backWhite = ''
            self.DARKCYAN = ''



# this will be the home for the set menus
def prompt(category, text):
    # if no special prompt and no text, return plain prompt
    if category == '0' and text == "":
        #return bcolors.UNDERL + bcolors.DARKCYAN + meta.prompt + bcolors.ENDC + "> "
        return bcolors.UNDERL + bcolors.DARKCYAN + meta.prompt + bcolors.ENDC + "> "
    # if the loop is here, either category or text was positive
    # if it's the category that is blank...return prompt with only the text
    if category == '0':
        return bcolors.UNDERL + bcolors.DARKCYAN + "set" + bcolors.ENDC + "> " + text + ": "
    # category is NOT blank
    
    else:  # abbiamo bisogno di categoria?
        # initialize the base 'set' prompt
        prompt = bcolors.UNDERL + bcolors.DARKCYAN + "set" + bcolors.ENDC
        # if there is a category but no text
        if text == "":
            for level in category:
                level = dictionaries.category(level)
                prompt += ":" + bcolors.UNDERL + bcolors.DARKCYAN + level + bcolors.ENDC
            promptstring = str(prompt)
            promptstring += ">"
            return promptstring
        # if there is both a category AND text
        else:
            # iterate through the list received
            for level in category:
                level = dictionaries.category(level)
                prompt += ":" + bcolors.UNDERL + bcolors.DARKCYAN + level + bcolors.ENDC
            promptstring = str(prompt)
            promptstring = promptstring + "> " + text + ":"
            return promptstring

def yesno_prompt(category,text):
    valid_response = False
    while not valid_response:
        response = raw_input(setprompt(category,text))
        response = str.lower(response)
        if response == "no" or response == "n":
            response = "NO"
            valid_response = True
        elif response == "yes" or response == "y":
            response = "YES"
            valid_response = True
        else:
            print_warning("valid responses are 'n|y|N|Y|no|yes|No|Yes|NO|YES'")
    return response

def return_continue():
    print ("\n      Press " + bcolors.RED + "<return> " + bcolors.ENDC + "to continue")
    pause = raw_input()

class create_menu:
    def __init__(self, text, menu):
        self.text = text
        self.menu = menu
        print text
        for i, option in enumerate(menu):

            menunum = i + 1
            # Check to see if this line has the 'return to main menu' code
            match = re.search("0D", option)
            # If it's not the return to menu line:
            if not match:
                if menunum < 10:
                    print('   %s) %s' % (menunum,option))
                else:
                    print('  %s) %s' % (menunum,option))
            else:
                print '\n  99) Return to Main Menu\n'
        return

# interactive vs from_file
# conf_file = "%s/%s/%s" % (os.path.dirname(os.path.abspath(__file__)), "conf", "app_master.ini")

class meta:
    name =  "The CoudSurf Suite"
    nick = "CS2"
    prompt = "CSurf"
    version = "0.1"
    authors = ["Valerio Persico", "Antonio Montieri"]
    license = "XXX"

main_menu = [
             "Intra-Datacenter",
             "Inter-Datacenter",
             "Inter-Cloud",
             "Cloud-to-user",
             "Cloud Storage",
             "Configuration",
             "Help",
             "Credits and About"
            ]

def show_banner(define_version, graphic):

    if graphic == "1": 
        if check_os() == "posix":
            os.system("clear")
        if check_os() == "windows":
            os.system("cls")
        show_graphic()
    else:
        os.system("clear")

    print bcolors.BLUE + """
[---]        The CloudSurf Suite ("""+bcolors.YELLOW+meta.nick+bcolors.BLUE+""")         [---]
[---]        Created by:""" + bcolors.RED+""" Valerio Persico """+bcolors.BLUE+"""         [---]
[---]                 Version: """+bcolors.RED+"""%s""" % (meta.version) +bcolors.BLUE+"""                   [---]
[---]               Codename: '""" + bcolors.YELLOW + """Hack-a-pockj-a""" + bcolors.BLUE + """'              [---]
[---]        Contact me at: """ + bcolors.PURPLE+ """valerio.persico [aat!] unina.it""" + bcolors.BLUE+"""         [---]
[---]       Homepage: """ + bcolors.YELLOW + """https://wpage.unina.it/valerio.persico""" + bcolors.BLUE+"""       [---]

""" + bcolors.GREEN+"""        Welcome to the %s (%s). 
""" % (meta.name, meta.nick)
    print bcolors.BOLD + """ Visit: """ + bcolors.GREEN + """http://traffic.comics.unina.it\n""" + bcolors.ENDC

def show_graphic():
        print bcolors.RED + r"""
                      ..:::::::::..
                  ..:::aad8888888baa:::..
              .::::d:?88888888888?::8b::::.
            .:::d8888:?88888888??a888888b:::.
          .:::d8888888a8888888aa8888888888b:::.
         ::::dP::::::::88888888888::::::::Yb::::
        ::::dP:::::::::Y888888888P:::::::::Yb::::
       ::::d8:::::::::::Y8888888P:::::::::::8b::::
      .::::88::::::::::::Y88888P::::::::::::88::::.
      :::::Y8baaaaaaaaaa88P:T:Y88aaaaaaaaaad8P:::::
      :::::::Y88888888888P::|::Y88888888888P:::::::
      ::::::::::::::::888:::|:::888::::::::::::::::
      `:::::::::::::::8888888888888b::::::::::::::'
       :::::::::::::::88888888888888::::::::::::::
        :::::::::::::d88888888888888:::::::::::::
         ::::::::::::88::88::88:::88::::::::::::
          `::::::::::88::88::88:::88::::::::::'
            `::::::::88::88::P::::88::::::::'
              `::::::88::88:::::::88::::::'
                 ``:::::::::::::::::::''
                      ``:::::::::''""" + bcolors.ENDC


def show_graphic():
    print bcolors.CYAN + """

                _                                  
              (`  ).                   _           
             (     ).              .:(`  )`.       
)           _(       '`.          :(   .    )      
        .=(`(      .   )     .--  `.  (    ) )      
       ((    (..__.:'-'   .+(   )   ` _`  ) )                 
`.     `(       ) )       (   .  )     (   )  ._   
  )      ` __.:'   )     (   (   ))     `-'.-(`  ) 
)  )  ( )       --'       `- __.'         :(      )) 
.-'  (_.'          .')                    `(    )  ))
                  (_  )                     ` __.:'""" + bcolors.ENDC + bcolors.GREEN + """
--..,___.--,--'`,---..-.--+--.,,-,,..._.--..-._.---.""" + bcolors.ENDC



if __name__ == "__main__":

    try:
        while True:
            show_banner(1,'1')
            show_main_menu = create_menu("Select a function\n", main_menu)

            # special case of list item 99
            print '\n  99) Exit\n'

            # main core menu
            main_menu_choice = (raw_input(prompt("0", "")))

            # quit out
            if main_menu_choice == 'exit' or main_menu_choice == "99" or main_menu_choice == "quit":
                sys.exit(0)

            if main_menu_choice == '1':
                print "ciao"
#                try:
#                    reload(src.core.set)
#                except:
#                    import src.core.set



# handle keyboard interrupts
    except KeyboardInterrupt:
        print "\n\nThank you for " + bcolors.BLUE+"surfing" + bcolors.ENDC+" with us!"
        # print "Forza Napoli!"

# handle exceptions
#    except Exception, error:
#        print "\n\n[!] Something went wrong, printing the error: "+ str(error)

# cleanup routine
#    cleanup_routine()

