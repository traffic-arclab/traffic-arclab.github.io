'''
Created on 25 nov 2015

@author: antonio
'''

import time, boto
import xml.etree.ElementTree as XmlParser    
    
def exception_parser(exception):
    if isinstance(exception, boto.exception.BotoServerError) or isinstance(exception, boto.exception.BotoClientError):
        root = XmlParser.fromstring(exception[2])
        message = [x[0].findall('Message')[0].text for x in [m.findall('Error') 
                    for m in root.findall('Errors')]][0]
        exception_message = '%s %s: %s' % (exception[0], exception[1], message)
    else:
        exception_message = str(exception)
    
    return exception_message


def millis_time():
    return int(round(time.time() * 1000))


def eliminate_duplicate(l):
    '''
    Eliminate duplicates from a list maintaining order
    '''
    seen = set()
    seen_add = seen.add
    return [i for i in l if not (i in seen or seen_add(i))]