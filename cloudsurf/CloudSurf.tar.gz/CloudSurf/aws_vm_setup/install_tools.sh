sudo apt-get --assume-yes update; sudo apt-get --assume-yes install nuttcp
