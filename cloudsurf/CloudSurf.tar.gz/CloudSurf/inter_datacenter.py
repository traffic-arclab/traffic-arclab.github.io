'''
Created on 30 dic 2015

@author: antonio
'''

from logger import setup_logging
from selection_menus import ec2_selection
from core.utils import clear
from core.banner import Banner
from core.prompt import Prompt
from core.colors import bcolors


def start_inter_datacenter(sid, input_dict, step_chain):
    inter_datacenter_selection = ec2_selection.EC2Selection(sid, input_dict)
    inter_datacenter_selection.select_provider(step_chain)
    

def main():
    input_dict = {}
    sid = "Inter-Datacenter"  # step id
    step_chain = []
    step_chain.append(sid)

    where_am_i = "\n "+" > ".join(step_chain)+"\n"
    where_am_i = "%s%s%s" % (bcolors.RED, where_am_i, bcolors.ENDC)

    intro = "\n This feature allows you to benchmark the network\n interconnecting two VMs deployed into " + bcolors.UNDERL + "different geographic regions" + bcolors.ENDC+"."
    intro = "%s%s%s" %(bcolors.BOLD, intro, bcolors.ENDC)
    
    info_log, debug_log = setup_logging.return_loggers()
    debug_log.info('Selected CloudSurf feature: Inter-Datacenter (2)')
    info_log.info('Selected CloudSurf feature: Inter-Datacenter (2)')

    clear()
    Banner.show_graphic_text()
    print where_am_i
    raw_input(Prompt.press_a_key(intro))

    start_inter_datacenter(sid, input_dict, step_chain)
    return


if __name__ == '__main__':
    main()