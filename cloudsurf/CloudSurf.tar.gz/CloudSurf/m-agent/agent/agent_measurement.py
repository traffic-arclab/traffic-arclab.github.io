#! /usr/bin/python

import sys,os,subprocess
import time
import logging

import SocketServer
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
from ConfigParser import SafeConfigParser
from wrapper_measurement import *

def updating_thread(wrapper):
	'''
	Thread che aggiorna lo stato degli esperimenti sull'agent ogni 'update_sec' secondi.
	'''
	update_sec = parser.getfloat('config_agent', 'update_sec')

	while wrapper.exit == False:	
		time.sleep(update_sec)
		wrapper.updating_busy_check()


#XMLRPCServer multithread
class ThreadedXMLRPCServer(SocketServer.ThreadingMixIn, SimpleXMLRPCServer):
	pass


if __name__ == "__main__":

	if len(sys.argv) < 2 or os.geteuid() != 0:
		print "usage: %s <ABSOLUTE_AGENT_PATH>\nATTENTION: Run the agent as superuser!"%(sys.argv[0])
		sys.exit(0)

	base_path = str(sys.argv[1])

	#Struttura file di configurazione del'agent:
	#[config_agent]
	#port = 30000
	#interface = eth0
	#tool_dir = script_tool
	#res_dir = res
	#log_dir = log
	#hist_dir = history

	#Parser per file di configurazione
	parser = SafeConfigParser()
	parser.read(('%s/conf/conf_agent.ini')%base_path)

	port_server = parser.getint('config_agent', 'port')
	interface = parser.get('config_agent', 'interface')
	path_tool = base_path + '/' + parser.get('config_agent', 'tool_dir')
	res_dir = parser.get('config_agent', 'res_dir')

	#Sottoprocesso comando shell per ottenere indirizzo ip dell'interfaccia 'interface'
	cmd = ("/sbin/ifconfig %s | grep inet | head -1 | sed 's/\:/ /' | awk '{print $3}'")%(interface)
	task = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	ip_agent = task.stdout.read().rstrip('\n')

	#Gestione e creazione log
	log_dir = base_path + '/' + parser.get('config_agent', 'log_dir')
	hist_dir = base_path + '/' + parser.get('config_agent', 'hist_dir')
	if os.path.exists(log_dir):
		old_log_dir = ('%s_%s')%(log_dir,int(time.time()))
		os.rename(log_dir, old_log_dir)
		os.renames(old_log_dir, hist_dir + old_log_dir[old_log_dir.rfind('/'):])
	os.mkdir(log_dir)
	command_log = log_dir + '/command_log.log'
	state_log = log_dir + '/state_log.log'
	error_log = log_dir + '/error_log.log'

	server = ThreadedXMLRPCServer((ip_agent, port_server), SimpleXMLRPCRequestHandler, logRequests=True, allow_none=True)
	server.register_introspection_functions()

	wrapper = wrapper_measurement(ip_agent, path_tool, res_dir, command_log, state_log, error_log)
	server.register_instance(wrapper)

	t = threading.Thread(target=updating_thread, args=(wrapper,))
	t.daemon = True
	t.start()

	try:
		wrapper.c_log.info('Agent Started: use Control-C to exit...')

		while wrapper.exit == False:
			if(wrapper.exit == True):
				break
			server.handle_request()		#N.B. server.serve_forever() richiama la server.handle_request() in un loop infinito.
		
		wrapper.c_log.info('Agent Exiting...')
	
	except KeyboardInterrupt:
		wrapper.c_log.info('Agent Exiting...')



