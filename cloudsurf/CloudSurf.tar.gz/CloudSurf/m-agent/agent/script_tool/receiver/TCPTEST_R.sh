#! /bin/bash -x

if [[ $# -lt 3 ]];
  	then echo "usage $0 <PORT> <DURATION> <OUTDIR> <INDEX>"; 
	exit 1 ;
fi

TCPSERVER=~/tools/tcp/tcpserver

PORT=$1
DURATION=$2
OUTDIR=$3
INDEX=$4

BASEDIR=.
R_DATADIR=$BASEDIR/$OUTDIR/tcptest_$INDEX/receiver
LOGDIR=$BASEDIR/$OUTDIR/tcptest_$INDEX/log

R_FILENAME=$(echo $R_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )

if [ -d $R_DATADIR ]; then
    echo "$R_DATADIR exists."
else
    mkdir -p $R_DATADIR
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

CMD="$TCPSERVER -v -p $PORT"

timeout -s 2 -k 5 $DURATION $CMD 1> $R_DATADIR/$R_FILENAME.out 2> $LOGDIR/$R_FILENAME.err &

echo $! 1>$R_DATADIR/$R_FILENAME.pid

#wait
exit 0
