#! /bin/bash -x

if [[ $# -lt 2 ]];
  	then echo "usage $0 <DESTINATION> <OUTDIR> <INDEX>"; 
	exit 1 ;
fi

#PATHLOAD_RCV=~/Desktop/Utility/pathload_1.3.2/pathload_rcv
PATHLOAD_RCV=~/pathload_1.3.2/pathload_rcv

DESTINATION=$1
OUTDIR=$2
INDEX=$3

BASEDIR=.
R_DATADIR=$BASEDIR/$OUTDIR/pathload_$INDEX/receiver
LOGDIR=$BASEDIR/$OUTDIR/pathload_$INDEX/log

R_FILENAME=$(echo $R_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )

if [ -d $R_DATADIR ]; then
    echo "$R_DATADIR exists."
else
    mkdir -p $R_DATADIR
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

$PATHLOAD_RCV -v -s $DESTINATION 1> $R_DATADIR/$R_FILENAME.out 2> $LOGDIR/$R_FILENAME.err &
#$PATHLOAD_RCV -v -s $DESTINATION 1> $R_DATADIR/$R_FILENAME.out 2> $LOGDIR/$R_FILENAME.err

echo $! 1>$R_DATADIR/$R_FILENAME.pid

#wait
exit 0
