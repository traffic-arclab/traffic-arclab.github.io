#! /bin/bash -x

if [[ $# -lt 4 ]]; 
	then echo "usage $0 <PORT> <PROTO> <DURATION> <OUTDIR> <INDEX>"; 
	exit 1 ; 
fi

PORT=$1
PROTO=$2
DURATION=$3
OUTDIR=$4
INDEX=$5

NUTTCP=nuttcp

MARGINE=60 #60s
DURATION=$((DURATION+MARGINE))

BASEDIR=.
# DITG_S_DATADIR=./$(dirname $OUTBASE)/sender

# R_DATADIR=$BASEDIR/$(dirname $OUTDIR)/receiver
# LOGDIR=$BASEDIR/$(dirname $OUTDIR)/log

R_DATADIR=$BASEDIR/$OUTDIR/nuttcp_$INDEX/receiver
LOGDIR=$BASEDIR/$OUTDIR/nuttcp_$INDEX/log

# DITG_S_FILENAME=$(echo $DITG_S_DATADIR | tr '/' '_')_$PROTO
R_FILENAME=$(echo $R_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_')_$PROTO

if [ -d $R_DATADIR ]; then		#Se la cartella $R_DATADIR esiste... Stampo un messaggio
    echo "$R_DATADIR exists."
else
    mkdir -p $R_DATADIR			#Altrimenti la creo
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi


if [[ $PROTO == "udp" ]]
then
	timeout -s 15 -k 5 $DURATION $NUTTCP -1 -P 8001 2>$LOGDIR/$R_FILENAME.err 1>$R_DATADIR/$R_FILENAME.out &
	echo $(($!+2)) 1>$R_DATADIR/$R_FILENAME.pid
elif [[ $PROTO == "tcp" ]]
then
	timeout -s 15 -k 5 $DURATION $NUTTCP -1 -P 8000 2>$LOGDIR/$R_FILENAME.err 1>$R_DATADIR/$R_FILENAME.out &
	echo $(($!+2)) 1>$R_DATADIR/$R_FILENAME.pid
else 
	exit 1;
fi;

wait
exit 0
