#! /bin/bash -x

if [[ $# -lt 2 ]];
  	then echo "usage $0 <PORT> <OUTDIR> <INDEX>"; 
	exit 1 ;
fi

YAZ=~/Desktop/Utility/yaz-master/yaz
#YAZ=~/yaz-master-src/yaz

PORT=$1
#DURATION=$2
OUTDIR=$2
INDEX=$3

#MARGINE=60 #60s
#DURATION=$((DURATION+MARGINE))

BASEDIR=.
R_DATADIR=$BASEDIR/$OUTDIR/yaz_$INDEX/receiver
LOGDIR=$BASEDIR/$OUTDIR/yaz_$INDEX/log

R_FILENAME=$(echo $R_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )

if [ -d $R_DATADIR ]; then
    echo "$R_DATADIR exists."
else
    mkdir -p $R_DATADIR
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

#timeout -s 15 -k 5 $DURATION $YAZ -R -P 3000 -p $PORT 1> $S_DATADIR/$S_FILENAME.out 2> $LOGDIR/$S_FILENAME.err &
$YAZ -R -p 3000 -P $PORT 1> $R_DATADIR/$R_FILENAME.out 2> $LOGDIR/$R_FILENAME.err &

echo $! 1>$R_DATADIR/$R_FILENAME.pid

#wait
exit 0
