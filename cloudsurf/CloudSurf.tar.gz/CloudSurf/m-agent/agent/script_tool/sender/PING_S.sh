#! /bin/bash -x

if [[ $# -lt 4 ]]; 
	then echo "usage $0 <DESTINATION> <DURATION [s]> <INTERVAL> <OUTDIR> <INDEX>"; 
	exit 1 ; 
fi

DESTINATION=$1
DURATION=$2
INTERVAL=$3
OUTDIR=$4
INDEX=$5

PING=ping

DURATION=$((DURATION))

#MARGINE=10		#10s
#DURATION=$(((DURATION / 1000)+MARGINE))

BASEDIR=.

S_DATADIR=$BASEDIR/$OUTDIR/ping_$INDEX/sender
LOGDIR=$BASEDIR/$OUTDIR/ping_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_')

if [ -d $S_DATADIR ]; then		#Se la cartella $S_DATADIR esiste... Stampo un messaggio
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR			#Altrimenti la creo
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi


timeout -s 2 -k 5 $DURATION tcpdump -i eth0 -w $S_DATADIR/$S_FILENAME.pcap &
timeout -s 2 -k 5 $DURATION $PING -i $INTERVAL $DESTINATION 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &
#timeout -s 2 invia un segnale SIGINT (ctrl+c) dopo DURATION

echo $! 1>$S_DATADIR/$S_FILENAME.pid


wait
exit 0
