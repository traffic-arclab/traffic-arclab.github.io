#! /bin/bash -x

if [[ $# -lt 3 ]]; 
	then echo "usage $0 <DESTINATION> <PROTO> <PORT> <OUTDIR> <INDEX>"; 
	exit 1 ; 
fi

DESTINATION=$1
PROTO=$2
PORT=$3
OUTDIR=$4
INDEX=$5

TRACE=traceroute

#MARGINE=10		#10s
#DURATION=$(((DURATION / 1000)+MARGINE))

BASEDIR=.

S_DATADIR=$BASEDIR/$OUTDIR/traceroute_$INDEX/sender
LOGDIR=$BASEDIR/$OUTDIR/traceroute_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_')_$PROTO

if [ -d $S_DATADIR ]; then		#Se la cartella $S_DATADIR esiste... Stampo un messaggio
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR			#Altrimenti la creo
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi


if [[ $PROTO == "udp" ]] 
then
	$TRACE -n -A -m 50 -p $PORT $DESTINATION 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &
	echo $! 1>$S_DATADIR/$S_FILENAME.pid
elif [[ $PROTO == "tcp" ]] 
then
	$TRACE -n -A -T -m 50 -p $PORT $DESTINATION 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &
	echo $! 1>$S_DATADIR/$S_FILENAME.pid
elif [[ $PROTO == "icmp" ]]
then
	$TRACE -n -A -I -m 50 -p $PORT $DESTINATION 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &
	echo $! 1>$S_DATADIR/$S_FILENAME.pid
else 
	exit 1;
fi;

wait
exit 0
