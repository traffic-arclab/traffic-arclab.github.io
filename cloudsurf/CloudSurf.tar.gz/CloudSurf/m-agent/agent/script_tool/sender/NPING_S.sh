#! /bin/bash -x

if [[ $# -lt 8 ]]; 
	then echo "usage $0 <PROTOCOL> <FLAGS> <PORT> <PACKET SIZE [B]> <DESTINATION> <DURATION [s]> <INTERVAL> <OUTDIR> <INDEX>"; 
	exit 1 ; 
fi

PROTOCOL=$1
FLAGS=$2
PORT=$3
PKTSIZE=$4
DESTINATION=$5
DURATION=$6
INTERVAL=$7
OUTDIR=$8
INDEX=$9

PING=nping

DURATION=$((DURATION))

BASEDIR=.

S_DATADIR=$BASEDIR/$OUTDIR/nping_$INDEX/sender
LOGDIR=$BASEDIR/$OUTDIR/nping_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_')

# Se TCP considero i FLAG, altrimenti ignoro -> stringa vuota
if [ "$PROTOCOL" = "tcp" ]
then
    PROTOCOL="--tcp"
    FLAGS="--flags $FLAGS"
else
    PROTOCOL="--$PROTOCOL"
    FLAGS=""
fi

if [ -d $S_DATADIR ]; then		#Se la cartella $S_DATADIR esiste... Stampo un messaggio
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR			#Altrimenti la creo
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

CMD="$PING $PROTOCOL $FLAGS -p $PORT $DESTINATION --delay $INTERVAL --data-length $PKTSIZE -c $DURATION"

timeout -s 2 -k 5 $DURATION tcpdump -i eth0 -w $S_DATADIR/$S_FILENAME.pcap &
timeout -s 2 -k 5 $DURATION $CMD 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out &
#HPING stampa sullo stderr il sommario dei risultati
#timeout -s 2 -k 5 $DURATION $CMD > $S_DATADIR/$S_FILENAME.out 2>&1 &
#timeout -s 2 invia un segnale SIGINT (ctrl+c) dopo DURATION

echo $! 1>$S_DATADIR/$S_FILENAME.pid


wait
exit 0
