#! /bin/bash -x

if [[ $# -lt 3 ]];
  	then echo "usage $0 <DESTINATION> <PORT> <OUTDIR> <INDEX>"; 
	exit 1 ;
fi

YAZ=~/Desktop/Utility/yaz-master/yaz
#YAZ=~/yaz-master-src/yaz

DESTINATION=$1
PORT=$2
OUTDIR=$3
INDEX=$4

BASEDIR=.
S_DATADIR=$BASEDIR/$OUTDIR/yaz_$INDEX/sender
LOGDIR=$BASEDIR/$OUTDIR/yaz_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )

if [ -d $S_DATADIR ]; then
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi


$YAZ -S $DESTINATION -p 3000 -P $PORT -m 1 -r 10000.0 1> $S_DATADIR/$S_FILENAME.out 2> $LOGDIR/$S_FILENAME.err &

echo $! 1>$S_DATADIR/$S_FILENAME.pid

wait
exit 0
