#! /bin/bash -x

if [[ $# -lt 6 ]];
  	then echo "usage $0 <DESTINATION> <PORT> <PROTO> <DURATION [s]> <BANDWIDTH [bits/s]> <OUTDIR> <INDEX>"; 
	exit 1 ;
fi

NUTTCP=nuttcp
PARIS=paris-traceroute

DESTINATION=$1
PORT=$2
PROTO=$3
DURATION=$4
BANDWIDTH=$5
OUTDIR=$6
INDEX=$7

# target bandwidth calculation
# if [[ $PROTO == "udp" ]] 
# then
BWDT=$((BANDWIDTH/1000000))
# fi;

DURATION=$((DURATION))
#DURATION=$((DURATION/1000))

BASEDIR=.
# S_DATADIR=$BASEDIR/$(dirname $OUTDIR)/sender
# R_DATADIR=$BASEDIR/$(dirname $OUTDIR)/receiver
S_DATADIR=$BASEDIR/$OUTDIR/nuttcp-paris_$INDEX/sender
#R_DATADIR=$BASEDIR/$OUTDIR/nuttcp_receiver

# LOGDIR=$BASEDIR/$(dirname $OUTDIR)/log
LOGDIR=$BASEDIR/$OUTDIR/nuttcp-paris_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )_$PROTO
#R_FILENAME=$(echo $R_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )_$PROTO

if [ -d $S_DATADIR ]; then
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

sudo timeout -s 15 -k 5 10 tcpdump -s 50 -w $S_DATADIR/$S_FILENAME.pcap -i eth0 -P out dst host $DESTINATION and dst port $PORT and $PROTO &

if [[ $PROTO == "udp" ]] 
then
	$NUTTCP -i 0.1 -P 8001 -p $PORT -u -T $DURATION -R $BWDT"m" $DESTINATION 1> $S_DATADIR/$S_FILENAME"_nuttcp.out" 2> $LOGDIR/$S_FILENAME."_nuttcp.err" &
	echo $! 1>$S_DATADIR/$S_FILENAME.pid
elif [[ $PROTO == "tcp" ]] 
then
	$NUTTCP -i 0.1 -P 8000 -p $PORT -T $DURATION -R $BWDT"m" $DESTINATION 1> $S_DATADIR/$S_FILENAME"_nuttcp.out" 2> $LOGDIR/$S_FILENAME"_nuttcp.err" &
	echo $! 1>$S_DATADIR/$S_FILENAME.pid
else 
	exit 1;
fi;

sleep $(($DURATION+30))

SRC_PORT=$(tshark -r $S_DATADIR/$S_FILENAME.pcap -Y 'frame.number eq 1' -e $PROTO.srcport -T fields)

$PARIS -n -M 10 -T 1000 --algo=hopbyhop -p $PROTO -s $SRC_PORT -d $PORT $DESTINATION 2>$LOGDIR/$S_FILENAME"_paris.err" 1>$S_DATADIR/$S_FILENAME"_paris.out" &

wait
exit 0
