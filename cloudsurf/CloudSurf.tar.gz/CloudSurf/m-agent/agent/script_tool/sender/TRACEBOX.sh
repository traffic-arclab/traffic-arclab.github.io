#! /bin/bash 

set -eu
DESTINATION=invalid
PARAMS=invalid
OUTDIR=invalid

usage () { # {{
cat <<-USAGE
usage: $0 -d DESTINATION -p PARAMS -o OUTDIR [-h]
DESTINATION is a targeted IP. PARAMS is the string to use as argument of 
tracebox [-p] option. OUTDIR specifies where storing the results.
USAGE
exit 1
} # }}}

while getopts "d:p:o:h" OPTNAME ; do # {{{
case $OPTNAME in
d)
DESTINATION=$OPTARG
;;
p)
PARAMS=$OPTARG
;;
o)
OUTDIR=$OPTARG
;;
h|*)
usage
;;
esac
done # }}}

if [ $DESTINATION = invalid ] ; then usage ; fi
if [ $PARAMS = invalid ] ; then usage ; fi
if [ $OUTDIR = invalid ] ; then usage ; fi

TRACEBOX=~/tracebox/tracebox

BASEDIR=.

S_DATADIR=$BASEDIR/$OUTDIR/tracebox_sender
LOGDIR=$BASEDIR/$OUTDIR/tracebox_log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_')

if [ -d $S_DATADIR ]; then		#Se la cartella $S_DATADIR esiste... Stampo un messaggio
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR			#Altrimenti la creo
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

$TRACEBOX -n -p $PARAMS 2>$LOGDIR/$S_FILENAME.err 1>$S_DATADIR/$S_FILENAME.out

echo $! 1>$S_DATADIR/$S_FILENAME.pid

wait
exit 0
