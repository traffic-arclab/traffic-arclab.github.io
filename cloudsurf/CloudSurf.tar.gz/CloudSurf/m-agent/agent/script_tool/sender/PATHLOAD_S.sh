#! /bin/bash -x

if [[ $# -lt 1 ]];
  	then echo "usage $0 <OUTDIR> <INDEX>"; 
	exit 1 ;
fi

#PATHLOAD_SND=~/Desktop/Utility/pathload_1.3.2/pathload_snd
PATHLOAD_SND=~/pathload_1.3.2/pathload_snd

OUTDIR=$1
INDEX=$2

BASEDIR=.
S_DATADIR=$BASEDIR/$OUTDIR/pathload_$INDEX/sender
LOGDIR=$BASEDIR/$OUTDIR/pathload_$INDEX/log

S_FILENAME=$(echo $S_DATADIR | sed -e s:./::| sed -e s://:/:| tr '/' '_' )

if [ -d $S_DATADIR ]; then
    echo "$S_DATADIR exists."
else
    mkdir -p $S_DATADIR
fi

if [ -d $LOGDIR ]; then
    echo "$LOGDIR exists."
else
    mkdir -p $LOGDIR
fi

$PATHLOAD_SND 1> $S_DATADIR/$S_FILENAME.out 2> $LOGDIR/$S_FILENAME.err &

echo $! 1>$S_DATADIR/$S_FILENAME.pid

wait
exit 0
