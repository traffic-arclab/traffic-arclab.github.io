'''
Created on 27 nov 2015

@author: antonio
'''

import os, time, subprocess
import socket, httplib, xmlrpclib

from aws_utils import utils
from logger import setup_logging
from ConfigParser import SafeConfigParser


class MasterCloudException(Exception):
	'''
	Exception for MasterCloud class
	'''
	def __init__(self, message):
		self.message = message
	def __str__(self):
		return str(self.message)


class TimeoutTransport(xmlrpclib.Transport):
	'''
	Custom XMLRPC transport class for HTTP connections,
	allowing a timeout in the base connection.
	'''
	
	def __init__(self, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, use_datetime=0):
		'''
		Initialize XMLRPC TimeoutTransport object with custom timeout.
		'''
				
		xmlrpclib.Transport.__init__(self, use_datetime)
		self._timeout = timeout


	def set_timeout(self, timeout):
		'''
		Set timeout for custom XMLRPC transport.
		'''
		self._timeout = timeout
		
		
	def get_timeout(self):
		'''
		Get timeout value for custom XMLRPC transport.
		'''
		return self._timeout
	
	
	def make_connection(self, host):
		'''
		Establish connection with custom XMLRPC transport.
		'''
		connection = httplib.HTTPConnection(host, timeout=self._timeout)
		return connection


class MasterCloud:
	'''
	Class for Master CloudSurf component that represents the client side of XMLRPC platform.
	'''
	
	def __init__(self):
		'''
		Master CloudSurf constructor
		'''
		
		self.cloudsurf_base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
		self.parser = SafeConfigParser()
		self.parser.read(self.cloudsurf_base_path + '/conf/conf_cloudsurf.ini')
		
		self.transport_timeout = self.parser.getfloat('config_master', 'transport_timeout')
		
		self.termination_check_attempts = self.parser.getint('config_master', 'termination_check_attempts')
		self.termination_check_wait = self.parser.getint('config_master', 'termination_check_wait')
		self.termination_check_exception_wait = self.parser.getint('config_master', 'termination_check_exception_wait')
		
		self.nuttcp_activation_wait = self.parser.getint('config_master', 'nuttcp_activation_wait')
		
		self.pull_results_termination_wait = self.parser.getint('config_master', 'pull_results_termination_wait')
		self.pull_results_except_retries = self.parser.getint('config_master', 'pull_results_except_retries')
		self.pull_results_except_wait = self.parser.getint('config_master', 'pull_results_except_wait')
		self.scp_connection_timeout = self.parser.getint('config_vm', 'scp_connection_timeout')
		
		self.info_log, self.debug_log = setup_logging.return_loggers()
		
		
	def _print_experiment(self, experiment):
		'''
		Print experiment dict in a format similar to Experiment class representation.
		'''
		
		exp_string = 'Tool %s: from %s [%s:%s] to %s [%s:%s] with parameters: ' % \
		(experiment['tool'], experiment['exp_ip_sender'], experiment['service_ip_sender'], experiment['service_port_sender'], \
		 experiment['exp_ip_receiver'], experiment['service_ip_receiver'], experiment['service_port_receiver'])
		
		for parameter in sorted(experiment, key=experiment.get):
			if parameter not in exp_string:
				exp_string += '%s = %s, ' % (parameter, experiment[parameter])
				
		return exp_string.rstrip(', ')
	
	
	def _termination_check(self, proxy, exp_id):
		'''
		Periodically verifies if experiment identified by <exp_id> is terminated. 
		'''
	
		attempts = self.termination_check_attempts
		while attempts > 0:
			try:
				state = proxy.get_state(exp_id)
				self.debug_log.debug('[%s] Current state: %s' %(exp_id, str(state)))
	
				if state['status'] == 'terminated' or state['status'] == 'stopped':
					break
	
				time.sleep(self.termination_check_wait)
	
			except Exception, e:
				attempts -= 1
				m = utils.exception_parser(e)
				err_str = 'Error in termination check: %s --> Remaining attempts: %s' % (m, attempts)
				if attempts == 0:
					self.debug_log.error(err_str)
					raise
				self.debug_log.warning(err_str)
				time.sleep(self.termination_check_exception_wait)
		return
	
	
	def run_experiments(self, exp_file_or_list, mode=0, repetitions=1, sleep_rep=0):
		'''
		Funzione principale del master XMLRPC per il lancio di esperimenti, con diverse modalita'.
		- exp_file_or_list puo' essere un file con esperimenti o una lista di esperimenti
			nel primo caso, ciascuna riga determina un esperimento
			nel secondo caso, ciascun esperimento e' splitted, es. [["HPING,"param1", "param2", ...], ["PING","param1","param2", ...], ...]	
		
		Se mode == 0:
		- Lancia una serie di esperimenti in sequenza, elencati nel file 'exp_file'. Prima di lanciare l'esperimento successivo,
		  verifica che il precedente sia terminato tramite la funzione termination_check, che utilizza un polling periodico 
		  basato sul pid del processo relativo all'esperimento in esecuzione.
	
		Se mode == 1:
		- Lancia una serie di esperimenti in concorrenza, elencati nel file 'exp_file'. Prima di lanciare l'esperimento successivo,
		  non verifica l'avvenuta terminazione dell'esperimento precedente.
		  
		In entrambi i casi:
		- Si attende un tempo di "sleep_exp" secondi tra l'invio di un esperimento ed il successivo. 
		- L'intera sequenza di esperimenti viene ripetuta per un numero di volte pari a "repetitions".
		- Per ciascuna ripetizione si attende un tempo pari a "sleep_rep" prima di eseguire la successiva ripetizione.
	
		Riga generica di 'exp_file', relativa ad un singolo esperimento:
		TOOL IP_RCV IP_SND IP_EXP_RCV IP_EXP_SND PORT_RCV PORT_SND PORT PROTOCOL DURATION BANDWIDTH OUTDIR <INTERVAL> <METRIC> <CLIENT_TAG>
	
		N.B. INTERVAL per ping ---> opzione -i <INTERVAL>
			 METRIC (rttm, owdm) per D-ITG delay ---> opzione -m <METER>
			 CLIENT_TAG e' l'identificativo dell'esperimento lato master; l'agent, aggiungendo il timestamp corrente, costruisce
			 l'identificativo univoco dell'esperimento.
			 IP_RCV e IP_SND sono gli indirizzi ip, rispettivamente lato receiver e sender, identificanti l'agent XMLRPC.
			 PORT_RCV e PORT_SND sono le porte, rispettivamente lato receiver e sender, su cui e' in ascolto l'agent XMLRPC.
			 IP_EXP_RCV e IP_EXP_SND sono gli indirizzi ip, delle entita', rispettivamente receiver e sender, dell'esperimento.
			 PORT e' la porta utilizzata dal tool considerato; generalmente e' la porta destinazione del flusso dati.
		'''
	
		if isinstance(exp_file_or_list, file):
			experiments = [exp.strip().split() for exp in exp_file_or_list if not (exp.startswith("#") or exp.startswith("PULL"))]
		elif isinstance(exp_file_or_list, list):
			experiments = exp_file_or_list
		else:
			raise TypeError("Input must be a file or a list of experiments")
				
		proxy = None
		exp_id = None
	
		for _ in range(repetitions):
			for experiment in experiments:
				try:
					tool = experiment['tool'].upper()
					sleep_exp = experiment.get('sleep_exp', 0)
					proxy, exp_id = self.TOOL_DICT[tool](self, experiment)
					
					if mode == 0:
						self.debug_log.debug('Running experiment in mode 0: ' + self._print_experiment(experiment) + ' --> Checking for termination')
						if proxy is not None and exp_id is not None:
							self._termination_check(proxy, exp_id)
					
					elif mode == 1:
						self.debug_log.debug('Running experiment in mode 1: ' + self._print_experiment(experiment) + ' --> RUN!')
					
					else:
						err_str = 'Mode %s not allowed!' % mode
						self.debug.error(err_str)
						raise MasterCloudException(err_str)
					
					time.sleep(sleep_exp)
	
				except Exception, e:
					m = utils.exception_parser(e)
					self.debug_log.error('Running experiment: %s --> Error: %s' % (self._print_experiment(experiment), m))
					#TODO: if experiment run fails continue with next experiment in list or next repetition
					if len(experiments) == 1 and repetitions == 1:
						raise
					
			time.sleep(sleep_rep)
	
		return
	
	
	def ping_measurement(self, parameters):
		'''
		Required and <optional> parameters:
		PING IP_RCV IP_SND PORT_SND IP_EXP_RCV IP_EXP_SND DURATION OUTDIR <INTERVAL> <CLIENT_TAG>
		'''
		
		ip_receiver = parameters['service_ip_receiver']
		ip_sender = parameters['service_ip_sender']
		port_sender = parameters['service_port_sender']
		ip_exp_receiver = parameters['exp_ip_receiver']
		ip_exp_sender = parameters['exp_ip_sender']
		protocol = 'icmp'
		duration = parameters['duration']
		outdir = parameters['outdir']
	
		trans = TimeoutTransport(self.transport_timeout)
	
		sender_proxy = xmlrpclib.ServerProxy('http://%s:%s/'%(ip_sender,port_sender), transport=trans)
	
		if 'client_tag' in parameters:
			client_tag = parameters['client_tag']
		else:
			client_tag = 'ping_cloudsurf'
			
		if 'interval' in parameters:
			interval = parameters['interval']
		else:
			interval = 1
		
		exp_id = sender_proxy.ping_sender(ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, protocol, duration, outdir, interval, client_tag)
		
		return sender_proxy, exp_id

	
	def nuttcp_measurement(self, parameters):
		'''
		Required and <optional> parameters:
		NUTTCP IP_RCV IP_SND PORT_RCV PORT_SND IP_EXP_RCV IP_EXP_SND PORT PROTO DURATION BANDWIDTH OUTDIR <CLIENT_TAG>
		'''
		
		ip_receiver = parameters['service_ip_receiver']
		ip_sender = parameters['service_ip_sender']
		port_receiver = parameters['service_port_receiver']
		port_sender = parameters['service_port_sender']
		ip_exp_receiver = parameters['exp_ip_receiver']
		ip_exp_sender = parameters['exp_ip_sender']
		port = parameters['port']
		proto = parameters['proto']
		duration = parameters['duration']
		bandwidth = parameters['bandwidth']
		outdir = parameters['outdir']
	
		trans = TimeoutTransport(self.transport_timeout)
		
		receiver_proxy = xmlrpclib.ServerProxy('http://%s:%s/' % (ip_receiver,port_receiver), transport=trans)
		sender_proxy = xmlrpclib.ServerProxy('http://%s:%s/' % (ip_sender,port_sender), transport=trans)
	
		if 'client_tag' in parameters:
			client_tag = parameters['client_tag']
		else:
			client_tag = 'nuttcp_cloudsurf'

		receiver_proxy.nuttcp_receiver(ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, proto, duration, outdir, client_tag)
		time.sleep(self.nuttcp_activation_wait)
		exp_id = sender_proxy.nuttcp_sender(ip_receiver, ip_sender, ip_exp_receiver, ip_exp_sender, port, proto, duration, bandwidth, outdir, client_tag)
		
		return sender_proxy, exp_id
	
	
	def pull_results(self, parameters):
		'''
		Method for pull campaign results directory by MasterCloud from VM running a XMLRPC agent
		Required parameters:
		- ip_agent: XMLRPC agent IP address
		- port_agent: XMLRPC agent listening port
		- key_path: key path for scp campaign results directory
		- res_path_agent: path of campaign results directories' container on agent
		- log_path_agent: path logs' directory on agent
		- agent_err: agent stderr log file
		- res_path_master: path of campaign results directories' container on master
		- outdir: campaign results' directory
		- new_log_name: new log file name; renaming is needed to avoid overwrites
	 	'''
		
		ip_agent = parameters['ip_agent']
		port_agent = parameters['port_agent']
		key_path = parameters['key_path']
		res_path_agent = parameters['res_path_agent']
		log_path_agent = parameters['log_path_agent']
		agent_err = parameters['agent_err']
		res_path_master = parameters['res_path_master']
		outdir = parameters['outdir']
		new_log_name = parameters['new_log_name']
	
		res_dir_master = ('%s/%s') % (res_path_master, outdir)
		
		scp_commands = []
		cmd_res = 'scp -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o ConnectTimeout=%s -i %s -r ubuntu@%s:%s/%s/* %s' % (self.scp_connection_timeout, key_path, ip_agent, res_path_agent, outdir, res_dir_master)
		cmd_res = cmd_res.split()
		scp_commands.append(cmd_res)
		
		cmd_log = "scp -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o ConnectTimeout=%s -i %s -r ubuntu@%s:%s %s" % (self.scp_connection_timeout, key_path, ip_agent, log_path_agent, res_dir_master)
		cmd_log = cmd_log.split()
		scp_commands.append(cmd_log)
		
		cmd_err_log = "scp -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o ConnectTimeout=%s -i %s ubuntu@%s:%s %s" % (self.scp_connection_timeout, key_path, ip_agent, agent_err, res_dir_master)
		cmd_err_log = cmd_err_log.split()
		scp_commands.append(cmd_err_log)
		
		FNULL = open(os.devnull, 'w')
		
		pulled = False
		attempts = self.pull_results_except_retries
		while not pulled and attempts > 0:
			try:
				if not os.path.exists(res_dir_master):
					os.makedirs(res_dir_master)
		
				proxy = xmlrpclib.ServerProxy('http://%s:%s/' % (ip_agent, port_agent))
		
				while len(proxy.busy_check()) > 0:
					self.debug_log.info('Master CloudSurf pull_results() on %s:%s ---> Waiting for experiments termination...')
					time.sleep(self.pull_results_termination_wait)
		
				proxy.rename_campaign_log_file(outdir, new_log_name)
				
				for cmd in scp_commands:
					subprocess.check_call(cmd, stdout=FNULL, stderr=FNULL)
				
				pulled = True
				
			except Exception, e:
				m = utils.exception_parser(e)
				attempts = attempts - 1
				err_str = 'Error pulling results from agent %s: %s --> Remaining attempts: %s' % (ip_agent, m, attempts)	
				if attempts == 0:
					self.debug_log.error(err_str)
					raise
				self.debug_log.warning(err_str)
				time.sleep(self.pull_results_except_wait)
	
		return pulled
	
		
	def test_agent(self, ip_agent, port_agent, message):
		'''
		Test agent activation.
		'''
		agent_proxy = xmlrpclib.ServerProxy('http://%s:%s/' % (ip_agent, port_agent))
		return agent_proxy.is_alive(message)
	
	
	TOOL_DICT = {
	'PING' : ping_measurement,
	'NUTTCP' : nuttcp_measurement
	}