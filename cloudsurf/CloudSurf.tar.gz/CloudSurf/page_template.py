import os
from core.utils import clear
from core.banner import Banner
from core.prompt import Prompt
from core.colors import bcolors
from core.menus import Menus, Menu, MenuManager

import not_implemented
import interactive




def main():

    class Goto:

        def goto1(self, a, b):
            print "GOTO1 REDIRECTS to NOWHERE < %s %s " % (a, b)
            raw_input()

        def goto2(self, a, b):
            print "GOTO2 REDIRECTS to NOWHERE >>>> %s %s" % (a, b)
            raw_input()

        def goto3(self, a, b):
            print "GOTO3 %s REDIRECTS to NOWHERE %s" %(a, b)
            raw_input()
    
        template = {
                "1": {"f": goto1, "a": ("ciccio", "paperino")},
                "2": {"f": goto2, "a": ("ciccia", "paperina")},
                "3": {"f": goto3, "a": ("pluto", "paperino")},
                "99": {"f": interactive.main, "a": ()}
            }


    where_am_i = "\n Template Page\n"
    where_am_i = "%s%s%s" % (bcolors.RED, where_am_i, bcolors.ENDC)

    intro = "\n Brief explanation of what this feature is goes here\n blabla bla."
    intro = "%s%s%s" %(bcolors.BOLD, intro, bcolors.ENDC)

    clear()
    Banner.show_graphic_text()
    print where_am_i
    raw_input(Prompt.press_a_key(intro))


    while True:
        clear()
        Banner.show_graphic_text()
        print where_am_i
        MenuManager(Menus.template["head"], Menus.template["body"], Goto.template).start()
    return

