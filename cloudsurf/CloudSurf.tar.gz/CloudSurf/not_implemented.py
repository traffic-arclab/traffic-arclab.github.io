import os
from core.utils import clear
from core.banner import Banner
from core.prompt import Prompt
from core.colors import bcolors
from core.meta import Meta

import interactive

def main():

    msg = "\n We're sorry. This feature has not been implemented yet :-("
    msg = "%s%s%s%s" %(bcolors.BOLD, bcolors.YELLOW, msg, bcolors.ENDC)
    msg2 = "\n A team of highly trained monkeys is currently working\n to extend the features of %s" % Meta.name
    msg2 = "%s%s%s" %(bcolors.GREEN, msg2, bcolors.ENDC)
    clear()
    Banner.show_graphic_text()
    raw_input(Prompt.press_a_key(msg+msg2))
    return
