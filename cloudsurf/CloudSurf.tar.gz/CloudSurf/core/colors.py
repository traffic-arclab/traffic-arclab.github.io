from utils import check_os

#
# Class for colors
#
if check_os() == "posix":
    class bcolors:
        WHITE = '\033[0m'
        PURPLE = '\033[95m'
        CYAN = '\033[96m'
        DARKCYAN = '\033[36m'
        BLUE = '\033[94m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        YELLOW_BOLD = '\033[93;1m'
        RED = '\033[91m'
        RED_BOLD = '\033[91;1m'
        BROWN = '\O33[0;33m'
        GRAY = '\033[0;37m'
        BOLD = '\033[1m'
        UNDERL = '\033[4m'
        BOLDUNDERL = '\033[1;4m'
        ENDC = '\033[0m'
        backBlack = '\033[40m'
        backRed = '\033[41m'
        backGreen = '\033[42m'
        backYellow = '\033[43m'
        backBlue = '\033[44m'
        backMagenta = '\033[45m'
        backCyan = '\033[46m'
        backWhite = '\033[47m'

        def disable(self):
            self.WHITE = ''
            self.PURPLE = ''
            self.CYAN = ''
            self.BLUE = ''
            self.GREEN = ''
            self.YELLOW = ''
            self. YELLOW_BOLD = ''
            self.RED = ''
            self.RED_BOLD = ''
            self.BROWN = ''
            self.GRAY = ''
            self.ENDC = ''
            self.BOLD = ''
            self.UNDERL = ''
            self.BOLDUNDERL = ''
            self.backBlack = ''
            self.backRed = ''
            self.backGreen = ''
            self.backYellow = ''
            self.backBlue = ''
            self.backMagenta = ''
            self.backCyan = ''
            self.backWhite = ''
            self.DARKCYAN = ''

# if we are windows or something like that then define colors as nothing
else:
    class bcolors:
        WHITE = ''
        PURPLE = ''
        CYAN = ''
        DARKCYAN = ''
        BLUE = ''
        GREEN = ''
        YELLOW = ''
        YELLOW_BOLD = ''
        RED = ''
        RED_BOLD = ''
        BROWN = ''
        GRAY = ''
        BOLD = ''
        UNDERL = ''
        BOLDUNDERL = ''
        ENDC = ''
        backBlack = ''
        backRed = ''
        backGreen = ''
        backYellow = ''
        backBlue = ''
        backMagenta = ''
        backCyan = ''
        backWhite = ''

        def disable(self):
            self.WHITE = ''
            self.PURPLE = ''
            self.CYAN = ''
            self.BLUE = ''
            self.GREEN = ''
            self.YELLOW = ''
            self.YELLOW_BOLD = ''
            self.RED = ''
            self.RED_BOLD = ''
            self.BROWN = ''
            self.GRAY = ''
            self.ENDC = ''
            self.BOLD = ''
            self.UNDERL = ''
            self.BOLDUNDERL = ''
            self.backBlack = ''
            self.backRed = ''
            self.backGreen = ''
            self.backYellow = ''
            self.backBlue = ''
            self.backMagenta = ''
            self.backCyan = ''
            self.backWhite = ''
            self.DARKCYAN = ''

#class for associate to each experiment a different color
class experiment_colors():
    colors_dict = {
                   'nuttcp': {
                            'tcp': bcolors.GREEN,
                            'udp': bcolors.RED,
                            'default': bcolors.DARKCYAN
                            },
                   'ping': {
                            'default': bcolors.BLUE
                            }
                   }
    
    colors_list = [
                    bcolors.GREEN,
                    bcolors.RED,
                    bcolors.DARKCYAN,
                    bcolors.YELLOW,
                    bcolors.CYAN,
                    bcolors.PURPLE,
                    bcolors.BLUE,
                    bcolors.BROWN
                    ]