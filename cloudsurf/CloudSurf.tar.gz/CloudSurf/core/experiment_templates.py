'''
Created on 11 dic 2015

@author: antonio
'''

class ExperimentTemplates:
    '''
    Class for experiment templates management
    '''
    
    #TODO: experiment templates are lists of parameters dicts, so every template could have more single experiments
    #TODO: set correct parameters for release
    tcp_throughput_latency = [{
                               'tool': 'NUTTCP',
                               'port': 18100,
                               'proto': 'tcp',
                               'duration': 300,
                               'bandwidth': 1000000000,
                               'client_tag': 'tcp_throughput_latency_cloudsurf_template',
                               'sleep_exp': 0
                               }
                              ]
    
    udp_throughput = [{
                       'tool': 'NUTTCP',
                       'port': 18200,
                       'proto': 'udp',
                       'duration': 300,
                       'bandwidth': 1000000000,
                       'client_tag': 'udp_throughput_cloudsurf_template',
                       'sleep_exp': 0
                       }
                      ]
    
    icmp_latency = [{
                       'tool': 'PING',
                       'duration': 300,
                       'interval': 0.1,
                       'client_tag': 'icmp_latency_cloudsurf_template'
                      }
                     ]
    
    template_choice = {
                       '1': tcp_throughput_latency,
                       '2': udp_throughput,
                       '3': icmp_latency
                       }
