import os
# check the operating system
def check_os():
    if os.name == "nt":
        operating_system = "windows"
    if os.name == "posix":
        operating_system = "posix"
    return operating_system

def clear():
    if check_os() == "posix":
        os.system("clear")
    if check_os() == "windows":
        os.system("cls")
    
udm = {
       'tput': {
                'default': 'Mbit/s'
                },
       'delay': {
                 'default': 'msRTT'
                 },
       'loss': {
                 'tcp': 'retrans',
                 'udp': '%loss',
                 'default': '%loss'
                }
       }

