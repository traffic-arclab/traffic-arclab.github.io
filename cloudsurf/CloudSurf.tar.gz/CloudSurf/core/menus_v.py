from colors import bcolors
from prompt import Prompt
import re
from utils import clear
from banner import Banner

class Menus:

    main = {"body":
                [
                "Intra-Datacenter*",
                "Inter-Datacenter*",
                "Inter-Cloud",
                "User-to-Cloud",
                "Cloud Storage",
                "Check Previous Results",
                "First-Time Configuration",
                "Help",
                "Credits and About*",
                ],
            "head": " Select from the menu"
            }

    providers = {"body": [
                        "Amazon",
                        "Azure",
                        "0D"
                        ],
                "head": "Select a provider"
                } 

    template = {"body":
                    [
                    "first choice",
                    "second choice",
                    "third choice",
                    "0D"  # go back to main manu
                    ],
                "head": "chevvuofa?"
                }

    intradatacenter_experiments = {"body": [
                                            "TCP throughput and latency",
                                            "UDP throughput",
                                            "ICMP latency",
                                            "Available Link-Capacity Estimation",
                                            "0D"
                                            ],
                                    "head": "Select an experiment"
            }

    interdatacenter_experiments = {"body": [
                                            "TCP throughput and latency",
                                            "UDP throughput",
                                            "Available Link-Capacity Estimation",
                                            "Characterization of the path",
                                            "0D"
                                            ],
                                    "head": "Select an experiment"
            }


    amazon_types = {"body": [
                                "m3.medium",
                                "m3.large",
                                "c3.2xlarge",
                                "0D"
                            ],
                    "head": "VM type"}

    amazon_regions = {"body": [
                                "North Virginia [us-east-1]",
                                "Ireland [eu-west-1]",
                                "Singapore [ap-southeast-1]",
                                "0D"
                            ],
                    "head": "Regions"}
    
    price_yes_no_choice = {"body": [
                                "Yes",
                                "No",
                                "0D"
                            ],
                    "head": "Would you like to continue?"}


class Menu:

    def __init__(self, text, menu, opt_message=""):
        self.opt_message = opt_message
        self.text = text
        self.menu = menu

    def show(self):
        print "   %s%s%s" %(bcolors.YELLOW_BOLD, self.opt_message, bcolors.ENDC)
        print "   %s%s%s" %(bcolors.BOLD, self.text, bcolors.ENDC)
        for i, option in enumerate(self.menu):
            menunum = i + 1
            # Check to see if this line has the 'return to main menu' code
            match = re.search("0D", option)
            # If it's not the return to menu line:
            if not match:
                if menunum < 10:
                    print('   %s) %s' % (menunum,option))
                else:
                    print('  %s) %s' % (menunum,option))
            else:
                print '\n  99) Return to Main Menu\n'
        return


class MenuManager:

    def __init__(self, text, menu, to_do_dict, input_dict=None, input_key=None, opt_message=""):
        self.text = text
        self.menu = menu
        self.to_do_dict = to_do_dict
        self.input_dict = input_dict
        self.input_key = input_key
        self.opt_message = opt_message

    def start(self):

        while True:

            #print to_do_dict

            m = Menu(self.text, self.menu, self.opt_message)
            m.show()
            valid_choices = [str(x) for x in range(1, len(self.menu))]
            valid_choices.append("99")
            #print valid_choices
            choice = raw_input(Prompt.simple())
            #print choice
            #raw_input()
            if choice in valid_choices:
                #print to_do_dict[choice]
                #raw_input()
                if self.input_key:
                    self.input_dict[self.input_key] = choice
                if choice in self.to_do_dict:
                    self.to_do_dict[choice]["f"](*self.to_do_dict[choice]["a"])  # "f"-->function, "a"-->args
                else:
                    self.to_do_dict["default"]["f"](*self.to_do_dict["default"]["a"])
                #raw_input()
                break
            else:
                continue
        return

def step_template(sid, step_chain, head, body, next_dict, input_dict=None, input_key=None, opt_message="", mode=1):
    """
    sid: step_id (string)
    step_chain: (list)
    head: header of the menu (string)
    body: body of the menu (list)
    next_dict: pointer to next steps (dict, see the example bolow for the format)
        template = {
                    "1": {"f": goto1, "a": ("ciccio", "paperino")},
                    "2": {"f": goto2, "a": ("ciccia", "paperina")},
                    "3": {"f": goto3, "a": ("pluto", "paperino")},
                    "99": interactive.main  # if needed
                }
    input_dict: saves user's choices - TODO
    mode: selects the step implmentation (int)
    """
    if mode == 1:
        if sid != '':
            step_chain.append(sid)
        where_am_i = "\n " + " > ".join(step_chain) + "\n"
        where_am_i = "%s%s%s" % (bcolors.RED, where_am_i, bcolors.ENDC)
        clear()
        Banner.show_graphic_text()
        print where_am_i
        MenuManager(head, body, next_dict, input_dict, input_key, opt_message).start()
        return
    
      
def please_wait(step_chain, wait_str):
    where_am_i = "\n " + " > ".join(step_chain) + "\n"
    where_am_i = "%s%s%s" % (bcolors.RED, where_am_i, bcolors.ENDC)
    clear()
    Banner.show_graphic_text()
    print where_am_i
    print "%s%s%s" %(bcolors.YELLOW_BOLD, wait_str, bcolors.ENDC)



class PageManager:
    # head
    # Where am I?
    # Menu manager
    pass

if __name__ == "__main__":

    def foo1():
        print "foo1"
    def foo2():
        print "foo2"
    def foo3():
        print "foo3!"

    def goto1(a, b):
            print "GOTO1 REDIRECTS to NOWHERE < %s %s " % (a, b)
            raw_input()

    def goto2(a, b):
            print "GOTO2 REDIRECTS to NOWHERE >>>> %s %s" % (a, b)
            raw_input()

    def goto3(a, b):
            print "GOTO3 %s REDIRECTS to NOWHERE %s" %(a, b)
            raw_input()
    
    template = {
                "1": {"f": goto1, "a": ("ciccio", "paperino")},
                "2": {"f": goto2, "a": ("ciccia", "paperina")},
                "3": {"f": goto3, "a": ("pluto", "paperino")},
               # "99": interactive.main
            }




    MenuManager("daje", Menus.main["body"], template).start()
#    CreateMenu("daje", Menu.main)


