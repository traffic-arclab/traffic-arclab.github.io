from colors import bcolors
import utils

class Prompt:

    p = "CloudSurF>"

    @staticmethod
    def simple(text=""):
        sep = ""
        if text != "":
            sep = ":"
        return " %s%s%s%s%s%s " % (bcolors.UNDERL, bcolors.DARKCYAN, Prompt.p, text, sep, bcolors.ENDC)

    @staticmethod
    def yesno(text):
        is_valid_response = False
        valid_responses = ["n", "y","no", "yes"]
        while not is_valid_response:
            response = raw_input(Prompt.simple(text))
            response = str.lower(response.strip())
            is_valid_response = response in valid_responses
            if not is_valid_response:
                print "valid responses are: %s" % ("|".join(valid_responses))
                continue
            else:
                if response in ["y", "yes"]:
                    return True
                elif response in ["n", "no"]:
                    return False

    @staticmethod
    def press_a_key(text=""):
        text += "\n\n Press " + bcolors.RED + "<return> " + bcolors.ENDC + "to continue..."
        return text



if __name__ == "__main__":
    scelta = raw_input(Prompt.simple("ciao bello"))

    print scelta

    scelta2 = raw_input(Prompt.yesno("sissicur?"))

    print scelta2

    scelta3 = raw_input(Prompt.press_a_key())

    print scelta3
