import time
import sys
import os
from banner import Banner
from colors import bcolors
from progressbar import ProgressBar, AnimatedMarker, BouncingBar, FormatLabel, Timer, UnknownLength
def spinner():
    pbar = ProgressBar(widgets=['Working: ', AnimatedMarker()])
    for i in pbar((i for i in range(50))):
        time.sleep(.08)

def task_resume(head, task_list, task_index, not_finished):
    widgets = [Timer(), BouncingBar()]
    pbar = ProgressBar(widgets=widgets, maxval=UnknownLength, fd=sys.stderr).start()
    i = 0

    done_list = task_list[:task_index]
    todo_list = task_list[task_index+1:]

    while not_finished.locked():
        i += 1
        pbar.update(i+1)
        time.sleep(0.05)
        os.system("clear")

        Banner.show_graphic_text()
        print "%s\n %s%s\n" %(bcolors.BOLD, head, bcolors.ENDC)
        if task_index > 0:
            print "%s%s%s" % (bcolors.GREEN, u" [\u2713]", bcolors.ENDC),
        print u"%s%s%s" %(bcolors.GREEN, u"\n [\u2713] ".join(done_list), bcolors.ENDC)
        print u" %s[-] %s%s" %(bcolors.YELLOW, task_list[task_index], bcolors.ENDC)
        if todo_list:
            print u" %s[ ] %s%s" %(bcolors.GRAY," \n [ ] ".join(todo_list), bcolors.ENDC)
        print "\n "
    pbar.finish()


if __name__ == "__main__":
    pass
    #task_resume("PROVA! please wait", ["prima operazione", "seconda operazione", "Terza operazione", "Quarta operazione"], 2, not_finished)
