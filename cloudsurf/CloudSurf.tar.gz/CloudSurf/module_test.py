'''
Created on 27 nov 2015

@author: antonio
'''

import sys, time, traceback, boto.ec2

from logger import setup_logging as log
from aws_setup import key_pair as kp
from aws_setup import security_group as sc
from aws_utils import utils as utils
from aws_vm_setup import management as mgmt
from aws_vm_setup import preparation as prep
from experiment import campaign as exp

if __name__ == '__main__':
    
    log.manage_log_dirs()
    ec2_connection = boto.ec2.connect_to_region('us-east-1')
    
    key_pair = kp.KeyPair(ec2_connection)
    security_group = sc.SecurityGroup(ec2_connection) 
    
    parameters = [{
        'tool' : 'PING',
        'port' : 18100,
        'proto' : 'tcp',
        'duration' : 30,
        'bandwidth' : 1000000,
        'interval' : 0.5
        }]
    
    try:
        key_name = key_pair.create_and_save()
        sg_name = security_group.create()
        vm_mgmt_1 = mgmt.VMManagement(ec2_connection, 'm3.medium', None, key_name, sg_name)
        vm_mgmt_2 = mgmt.VMManagement(ec2_connection, 'm3.medium', None, key_name, sg_name)
        vm_1 = vm_mgmt_1.launch_vm()
        vm_2 = vm_mgmt_2.launch_vm()
#         key_name = 'cloudsurf_key_1449677415513'
#         vm_1 = ec2_connection.get_all_instances(['i-9b8d612a'])[0].instances[0]
#         vm_2 = ec2_connection.get_all_instances(['i-708c60c1'])[0].instances[0]
        vm_mgmt_1.running_check_barrier()
        print 'running_check_barrier() vm_1 passed!'
        vm_mgmt_2.running_check_barrier()
        print 'running_check_barrier() vm_2 passed!'
        vm_prep_1 = prep.VMPreparation(vm_1, key_name)
        vm_prep_1.install_tools()
        vm_prep_1.launch_agent()
        vm_prep_2 = prep.VMPreparation(vm_2, key_name)
        vm_prep_2.install_tools()
        vm_prep_2.launch_agent()
#        time.sleep(30)
        experiment = exp.Campaign(parameters, vm_1, vm_2, key_name)
        experiment.run_experiment()
        pulled = experiment.store_results()
        if pulled:
            print 'results stored!'
    except Exception, e:
        traceback.print_exc(e)
        m = utils.exception_parser(e)
        sys.stderr.write('Exception Raised: %s' % m)
        #vm_mgmt.terminate_vm()
        #key_pair.delete()
        #security_group.delete()
    finally:
        pass
        #time.sleep(120)
        vm_mgmt_1.terminate_vm()
        vm_mgmt_2.terminate_vm()
        key_pair.delete()
        security_group.delete()
        
        