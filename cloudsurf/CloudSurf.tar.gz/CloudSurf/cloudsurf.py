import argparse
import sys
import os

from logger import setup_logging
from core.meta import Meta

__version__ = Meta.version
sys.tracebacklimit=0

def check_credentials(provider='aws'):
    home = os.path.expanduser("~")
    
    # aws credentials stored in $HOME/.boto
    credentials_exist = os.path.exists("%s/.boto" % home)
    
    return credentials_exist


def print_check_credentials():
    cc = check_credentials()
    if cc:
        print "cloud provider credential check passed"
    else:
        print "cloud provider credential check failed"
    return cc


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='The CloudSurf Suite.')

    parser.add_argument('--version', action='version', version='%(prog)s {version}'.format(version=__version__))

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-i', '--interactive', action='store_true', dest='interactive_mode', default=True, help='start the interactive mode')
    group.add_argument('-b', '--batch', action='store', dest='campaign_file', default=None, help='start the batch mode')
    group.add_argument('-c', '--check-configuration', action='store_true', dest='credential_check_only', default=False, help='check cloud provider configuration and  exit')

    args = parser.parse_args()


    if args.credential_check_only:
        print_check_credentials()
        sys.exit(0)

    cc = print_check_credentials()
    if not cc:  # credential check failed
        sys.exit(1)
    
    else:  # credential check passed
        setup_logging.manage_log_dirs() # log files setup
        info_log, debug_log = setup_logging.return_loggers()
        
        if args.interactive_mode:  # interactive mode
            
            debug_log.info('CloudSurf started in interactive mode!')
            info_log.info('CloudSurf started in interactive mode!')
            
            import interactive
            interactive.main()

        else: # batch mode
            debug_log.info('CloudSurf started in batch mode!')
            info_log.info('CloudSurf started in batch mode!')
            print 'batch mode not implemented yet!'
            debug_log.info('Exit from CloudSurf')
            info_log.info('Exit from CloudSurf')
            