var class_general_option =
[
    [ "GeneralOption", "class_general_option.html#ac1b5a361d7f013d57be8cd2f3efbde98", null ],
    [ "~GeneralOption", "class_general_option.html#a7cbc8c34c5402b8734cf7c7b63f17aed", null ],
    [ "dst_port", "class_general_option.html#a5a9a8b0d66e6f7077aaa10dccb873780", null ],
    [ "eth", "class_general_option.html#a4fb542702e6ef63d51b97d3cf5656075", null ],
    [ "ip_id", "class_general_option.html#a5fe33215f3db3e564852ea972d9b89b0", null ],
    [ "lock", "class_general_option.html#a1eee0a891df3bb6cc74f85005724c56c", null ],
    [ "protocol_number", "class_general_option.html#aa749d139efe4cf770577bcfd79736d5a", null ],
    [ "retries", "class_general_option.html#a7be006a04774e4f852a4f84357c9ccac", null ],
    [ "set_delay_between_probes", "class_general_option.html#ae5b81b3c9fae21052ea5245994d948f8", null ],
    [ "set_eth", "class_general_option.html#a342593fef63a376b3d57950029da6b84", null ],
    [ "set_lock", "class_general_option.html#a000a98ca8e47546a8947e586a43f5f88", null ],
    [ "set_protocol_number", "class_general_option.html#ad9af5903d6798c1a0b123c0b80c3850a", null ],
    [ "set_retries", "class_general_option.html#a2073bc0f5a636e67616c44b2df7b29d4", null ],
    [ "set_socketudp", "class_general_option.html#a3210cc382c150492c22fcf7fa4211dbc", null ],
    [ "set_timeout", "class_general_option.html#a242e392c5b16efdc9495ebf6550307b4", null ],
    [ "set_ttl", "class_general_option.html#a1273f938aecdc9b09286a7ebca647228", null ],
    [ "set_verbose_mode", "class_general_option.html#a8eae7298739de3345a8f93d82b944409", null ],
    [ "socketudp", "class_general_option.html#af1831b0feab8b2d1d109a8a30371328f", null ],
    [ "timeout", "class_general_option.html#a239b5c58b541a6091cb7884bbe4add32", null ],
    [ "ttl", "class_general_option.html#a2c8fa769a3012bd0c499f487b7a2d50a", null ],
    [ "verbose_mode", "class_general_option.html#a8bc077c0e6562255d6c8e49cccbb8d85", null ]
];