var searchData=
[
  ['nips',['NIPS',['../ippolib_8h.html#ab52a5e4c8352cf43bae890d6fe1ac756',1,'ippolib.h']]],
  ['no_5fresponse',['NO_RESPONSE',['../probereply_8h.html#a5f137187c6a892935c5acd036f609b22',1,'probereply.h']]]
];
