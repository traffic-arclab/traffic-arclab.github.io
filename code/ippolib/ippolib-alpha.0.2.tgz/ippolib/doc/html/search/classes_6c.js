var searchData=
[
  ['localoptions',['LocalOptions',['../struct_local_options.html',1,'']]]
];
