var searchData=
[
  ['gopts',['gOpts',['../struct_local_options.html#a6ec4ea8edba3b2d0692e0b1f30d0c92a',1,'LocalOptions']]]
];
