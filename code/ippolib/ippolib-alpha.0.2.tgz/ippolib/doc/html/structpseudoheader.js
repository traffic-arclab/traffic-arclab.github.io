var structpseudoheader =
[
    [ "dip", "structpseudoheader.html#a506d817e0bbf075f67c5a1e0272dd78e", null ],
    [ "protocol", "structpseudoheader.html#a72aa740c2d919f0738d510426258a4a8", null ],
    [ "sip", "structpseudoheader.html#a04c7ba367a465621b64d4629a2b55ff4", null ],
    [ "tcplen", "structpseudoheader.html#ad7a6d686cb8d77a9ef58f6c8a7ab954f", null ],
    [ "zero", "structpseudoheader.html#a98891613bf2fe130db9deb613e3d3415", null ]
];