var generaloption_8h =
[
    [ "GeneralOption", "class_general_option.html", "class_general_option" ],
    [ "uint16", "generaloption_8h.html#a05f6b0ae8f6a6e135b0e290c25fe0e4e", null ],
    [ "uint32", "generaloption_8h.html#a1134b580f8da4de94ca6b1de4d37975e", null ]
];