#include "TPScan.h"

TPScan::TPScan()
{
}
