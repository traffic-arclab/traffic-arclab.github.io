#ifndef TPSCAN_H
#define TPSCAN_H

class TPScan
{
public:
    TPScan();
};

#endif // TPSCAN_H
