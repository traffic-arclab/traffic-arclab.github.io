function [y,x]=generate_src(A,g,th,L);
% [y,x]=generate_src(A,g,th,L);

% come distribuzione iniziale si assume la distribuzione stazionaria
[V,D]=eig(A'); % calcola autovettori ed autovalori di A trasposto
d=diag(D);dif=abs(d-1);
k=find(dif==min(dif)); % trova l'indice dell'autovalore unitario
ps=V(:,k)/sum(V(:,k)); % trova l'autovettore corrispondente e lo normalizza
% ps � il vettore delle probabilit� stazionarie
A0=[zeros(length(A),1),A];
for k=1:length(ps)
    Sps(k)=sum(ps(1:k));
    SA(:,k)=(sum(A0(:,1:k+1)'))';
end

y=zeros(L,2);
n=sign(rand(1,1)-Sps);
jn=find(n==-1);
jn=jn(1);% � lo stato corrente
x(1)=jn;
for t=1:L
   y(t,:)=gamrnd(g(jn,:),th(jn,:));
   n=sign(rand(1,1)-SA(jn,:));
   jn=find(n==-1);
   jn=jn(1);
   x=[x;jn];
end
x=x(1:end-1);
