function b=pdf_src(y,g,th);
% b=pdf_src(y,g,th);

b=gampdf(y(1),g(:,1),th(:,1)).*gampdf(y(2),g(:,2),th(:,2));
