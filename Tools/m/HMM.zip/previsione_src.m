function []=previsione_src(A,g,th,y,W,S,Ksd);
% previsione_src(A,g,th,y,W,S,Ksd);
% previsione_src(A,g,th,y,W);

if nargin==5
    S=1;
    Ksd=1;
end

% CALCOLO DELLA DISTRIBUZIONE STAZIONARIA
[V,D]=eig(A'); % calcola autovettori ed autovalori di A trasposto
d=diag(D);dif=abs(d-1);
k=find(dif==min(dif)); % trova l'indice dell'autovalore unitario
ssp=V(:,k)/sum(V(:,k)); % trova l'autovettore corrispondente e lo normalizza
% ssp � il vettore delle probabilit� stazionarie
clear V D d dif k

prev=NaN*ones(size(y));
sdprev=NaN*ones(size(y));
stime=NaN*ones(size(y));
%dstim=NaN*ones(size(y));

stop=0;t=1;
%IPT=g(1,1)*th(1,1);sdIPT=g(1,1)*th(1,1)*th(1,1);
%PS=g(1,2)*th(1,2);sdPS=g(1,2)*th(1,2)*th(1,2);
while stop==0
    tvit=t+W-1;
    stime(t:tvit,1)=0;
    stime(t:tvit,2)=0;
    Y=y(t:tvit,:);
    x=viterbi_src(A,g,th,Y);
    j=x(end);
    IPT=g(j,1)*th(j,1);
    sdIPT=sqrt(g(j,1)*th(j,1)*th(j,1));
    PS=g(j,2)*th(j,2);
    sdPS=sqrt(g(j,2)*th(j,2)*th(j,2));
    %duration=ceil( S*(ssp(j)/(1-A(j,j))) );
    duration=ceil( S*(1/(1-A(j,j))) );
    nt=min(length(y),tvit+duration); 
    prev(tvit:nt,1)=IPT;sdprev(tvit:nt,1)=sdIPT;
    prev(tvit:nt,2)=PS;sdprev(tvit:nt,2)=sdPS;
    t=nt+1;
    if t+W>length(y)
        stop=1;
    end
end


figure
subplot(2,1,1),plot(1:size(y,1),y(:,1),'b*-',1:size(y,1),stime(:,1),'ro'),hold on,
errorbar(1:size(y,1),prev(:,1),Ksd*sdprev(:,1),Ksd*sdprev(:,1),'gd'),
axis([0,size(y,1)+1,0,max(y(:,1))+40])
hnd=title('IPT sequence');set(hnd,'Fontsize',14);
hnd=ylabel('10 log_1_0(IPT/1\mus)');set(hnd,'Fontsize',14);
hnd=xlabel('sequence number');set(hnd,'Fontsize',14);
hnd=legend('data','monitoring','prediction');set(hnd,'Fontsize',10);
subplot(2,1,2),
plot(1:size(y,1),y(:,2),'b*-',1:size(y,1),stime(:,2),'ro'),hold on,
errorbar(1:size(y,1),prev(:,2),Ksd*sdprev(:,2),Ksd*sdprev(:,2),'gd'),
axis([0,size(y,1)+1,0,max(y(:,2))+700])
hnd=title('PS sequence');set(hnd,'Fontsize',14);
hnd=ylabel('PS (bytes)');set(hnd,'Fontsize',14);
hnd=xlabel('sequence number');set(hnd,'Fontsize',14);
hnd=legend('data','monitoring','prediction');set(hnd,'Fontsize',10);

close %%%

figure
subplot(2,1,1),plot(1:size(y,1),y(:,1)-60,'b*-',1:size(y,1),stime(:,1),'ro'),hold on,
errorbar(1:size(y,1),prev(:,1)-60,Ksd*sdprev(:,1),Ksd*sdprev(:,1),'gd'),
axis([0,size(y,1)+1,0,max(y(:,1)-60)+40])
hnd=title('IPT sequence');set(hnd,'Fontsize',14);
hnd=ylabel('10 log_1_0(IPT/1\mus)');set(hnd,'Fontsize',14);
hnd=xlabel('sequence number');set(hnd,'Fontsize',14);
hnd=legend('data','monitoring','prediction');set(hnd,'Fontsize',10);
subplot(2,1,2),
plot(1:size(y,1),y(:,2),'b*-',1:size(y,1),stime(:,2),'ro'),hold on,
errorbar(1:size(y,1),prev(:,2),Ksd*sdprev(:,2),Ksd*sdprev(:,2),'gd'),
axis([0,size(y,1)+1,0,max(y(:,2))+700])
hnd=title('PS sequence');set(hnd,'Fontsize',14);
hnd=ylabel('PS (bytes)');set(hnd,'Fontsize',14);
hnd=xlabel('sequence number');set(hnd,'Fontsize',14);
hnd=legend('data','monitoring','prediction');set(hnd,'Fontsize',10);
