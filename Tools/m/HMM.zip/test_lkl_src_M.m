function yc=test_lkl_src_M(nA,ng,nth,y,A,g,th);
% yc=test_lkl_src_M(nA,ng,nth,y,A,g,th);
% yc=test_lkl_src_M(nA,ng,nth,y,y_tr);

%SL=-2*1000;
SL=input('inserire SL: ');

if nargin==5
    y_tr=A; clear A,
    [A,g,th]=starting_src_M(length(nA),y_tr);
end

edges=find(y(:,1)==Inf);
Lseq=length(edges)-1;
for k=1:Lseq
    j1=edges(k)+1;
    j2=edges(k+1)-1;
    yk=y(j1:j2,:);
    L(k)=loglikelihood_src(A,g,th,yk);
    nL(k)=loglikelihood_src(nA,ng,nth,yk);
end

j=find(~isfinite(L))
if isempty(j)==0
    indici=1:k;
    indici(j)=[];
    L(j)=[];
    L=interp1(indici,L,1:k,'linear','extrap');
end
nj=find(~isfinite(nL))
if isempty(nj)==0
    indici=1:k;
    indici(nj)=[];
    nL(nj)=[];
    nL=interp1(indici,nL,1:k,'linear','extrap');
end

yc=[Inf,Inf];
c=find(nL>=SL)
for k=1:length(c)
    j1=edges(c(k))+1;
    j2=edges(c(k)+1);
    yk=y(j1:j2,:);
    yc=[yc;yk];
end

figure
%plot(0:k-1,L,'bo--',0:k-1,nL,'b*-')
semilogy(0:Lseq-1,L,'g.:',0:Lseq-1,nL,'b.-',[0,Lseq-1],[SL,SL],'r')
%grid on, zoom on
hnd=title([int2str(length(nA)),' states']);set(hnd,'Fontsize',14);
hnd=xlabel('sequence number');set(hnd,'Fontsize',14);
hnd=ylabel('log-likelihood');set(hnd,'Fontsize',14);
hnd=legend('starting','trained',4);set(hnd,'Fontsize',14);
axis([0,Lseq-1,min(L),max(nL)])