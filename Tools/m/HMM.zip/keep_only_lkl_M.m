function [q,snq]=keep_only_lkl_M(y,snum,A,g,th,ll);
% [q,snq]=keep_only_lkl_M(y,A,g,th,ll);
%
% y: sequenze di IPT e PS separate da [Inf,Inf]
% A,g,th: modello HMM source
% ll: valore di soglia per la verosimiglianza
% 
% q: contiene solo le sequenze di "y" tali che:
%     L(y|A,g,th)>=ll

edges=find(y(:,1)==Inf);
Lseq=length(edges)-1;
q=[Inf,Inf];
snq=[];
for k=1:Lseq
    j1=edges(k)+1;
    j2=edges(k+1)-1;
    yk=y(j1:j2,:);
    l=loglikelihood_src(A,g,th,yk);
    if l>=ll
        q=[q;yk;Inf,Inf];
        snq=[snq;snum(k)];
    end
end