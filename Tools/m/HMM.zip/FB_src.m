function [c,alpha,beta]=FB_src(A,g,th,y);
% [c,alpha,beta]=FB_src(A,g,th,y);

% inizializzazione della variabile Forward e del vettore di Scaling
c=zeros(length(y),1);
alpha=zeros(length(A),length(y));
c(1)=1;
alpha(1,1)=1;

% calcolo iterativo della variabile Forward e del vettore di Scaling
for t=2:length(y)
    b=pdf_src(y(t,:),g,th);
    c(t)= sum((A'*alpha(:,t-1)).*b);
    alpha(:,t)=((A'*alpha(:,t-1)).*b)/c(t);
%    if ~isfinite(c(t))|~isfinite(alpha(:,t))  disp('***INF***'),t,end
end

% inizializzazione della variavile Backward
beta=zeros(length(A),length(y));
beta(:,end)=ones(length(A),1)/c(end);

% calcolo iterativo della variabile Backward
for t=2:length(y)
    tt=length(y)-t+1;
    b=pdf_src(y(tt+1,:),g,th);
    beta(:,tt)=(A*(b.*beta(:,tt+1)))/c(tt);
end