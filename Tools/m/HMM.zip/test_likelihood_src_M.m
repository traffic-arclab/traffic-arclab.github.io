function [nL,L,nj,j]=test_likelihood_src_M(nA,ng,nth,y,A,g,th);
% [nL,L,nj,j]=test_likelihood_src_M(nA,ng,nth,y,A,g,th);
% [nL,L,nj,j]=test_likelihood_src_M(nA,ng,nth,y,y_tr);

if nargin==5
    y_tr=A; clear A,
    [A,g,th]=starting_src_M(length(nA),y_tr);
end
edges=find(y(:,1)==Inf);
Lseq=length(edges)-1;
for k=1:Lseq
    j1=edges(k)+1;
    j2=edges(k+1)-1;
    y_tst=y(j1:j2,:);
    L(k)=loglikelihood_src(A,g,th,y_tst);
    nL(k)=loglikelihood_src(nA,ng,nth,y_tst);
end

j=find(~isfinite(L))
if isempty(j)==0
    indici=1:Lseq;
    indici(j)=[];
    L(j)=[];
    L=interp1(indici,L,1:Lseq,'linear','extrap');
end
nj=find(~isfinite(nL))
if isempty(nj)==0
    indici=1:Lseq;
    indici(nj)=[];
    nL(nj)=[];
    nL=interp1(indici,nL,1:Lseq,'linear','extrap');
end

figure
semilogy(1:Lseq,L,'g.:',1:Lseq,nL,'b.-')
axis([1,Lseq,min(L),max(nL)])
h=title([int2str(length(nA)),'-state model before (dotted) and after (solid) learning']);set(h,'Fontsize',14);
h=ylabel('log-likelihood');set(h,'Fontsize',20);
h=xlabel('test sequence');set(h,'Fontsize',20);
%grid on, zoom on
