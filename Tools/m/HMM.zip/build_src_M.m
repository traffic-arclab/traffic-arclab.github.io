function [yup,ydw]=build_src_M(Yup,Ydw,informazioni,snum,updw);
% [yup,ydw]=build_src_M(Yup,Ydw,informazioni,snum,updw);
%
% seleziona da (Yup,Ydw,informazioni) le sessioni 
% individuate da snum (up AND/OR dw)
%
% updw = 'up','dw','both'


if strcmp(updw,'up')
    yup=[Inf,Inf];
    for k=1:length(snum)
        j=find(informazioni(:,1)==snum(k));
        ns=Yup(informazioni(j,4):informazioni(j,5),2:3);
        yup=[yup;ns;[Inf,Inf]];
    end
    ydw=[];
end
if strcmp(updw,'dw')
    ydw=[Inf,Inf];
    for k=1:length(snum)
        j=find(informazioni(:,1)==snum(k));
        ns=Ydw(informazioni(j,6):informazioni(j,7),2:3);
        ydw=[ydw;ns;[Inf,Inf]]; 
    end
    yup=[];
end
if strcmp(updw,'both')    
    yup=[Inf,Inf];
    ydw=[Inf,Inf];
    for k=1:length(snum)
        j=find(informazioni(:,1)==snum(k));
        ns=Yup(informazioni(j,4):informazioni(j,5),2:3);
        yup=[yup;ns;[Inf,Inf]];
        ns=Ydw(informazioni(j,6):informazioni(j,7),2:3);
        ydw=[ydw;ns;[Inf,Inf]];        
    end
end
