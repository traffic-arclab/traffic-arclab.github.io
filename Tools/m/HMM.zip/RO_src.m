function ro=RO_src(A,g,th,y,alpha);
% ro=RO_src(A,g,th,y,alpha);

SaA=[ones(length(A),1),A'*alpha(:,1:end-1)];
for t=1:length(y)
    b(:,t)=pdf_src(y(t,:),g,th);
end
ro=SaA.*b;
