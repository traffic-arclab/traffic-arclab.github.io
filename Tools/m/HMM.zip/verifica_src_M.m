function [PDF,nPDF,H,t1,t2]=verifica_src_M(nA,ng,nth,y,A,g,th);
% [PDF,nPDF,H,t1,t2]=verifica_src_M(nA,ng,nth,y,A,g,th);
% [PDF,nPDF,H,t1,t2]=verifica_src_M(nA,ng,nth,y);
% [PDF,nPDF,H,t1,t2]=verifica_src_M(nA,ng,nth,y,BinNum);

LR=20; % lunghezza della correlazione

if nargin==4
    [A,g,th]=starting_src_M(length(nA),y);
    BinNum=100;
elseif nargin==5
    BinNum=A;
    [A,g,th]=starting_src_M(length(nA),y);
else
    BinNum=100;
end

%hnd1=plot_src(y);

q1=y(:,1);q2=y(:,2);
q1=q1(isfinite(q1));q2=q2(isfinite(q2));
q=[q1,q2];

[ps,mu,sig]=average_src(A,g,th);
[nps,nmu,nsig]=average_src(nA,ng,nth);
mud=mean(q);sigd=std(q);

disp(''),
disp('mean'),[mud;mu;nmu]
disp('')
disp('stdev'),[sigd;sig;nsig]

DT1=(max(q(:,1))-min(q(:,1)))/(BinNum-1);
DT2=(max(q(:,2))-min(q(:,2)))/(BinNum-1);
t1=min(q(:,1)):DT1:max(q(:,1));
t2=min(q(:,2)):DT2:max(q(:,2));

h1=hist(q(:,1),t1);h2=hist(q(:,2),t2);
h1=h1/(length(y(:,1))*DT1);
h2=h2/(length(y(:,2))*DT2);

for k=1:BinNum
    pdf1(:,k)=gampdf(t1(k),g(:,1),th(:,1));
    npdf1(:,k)=gampdf(t1(k),ng(:,1),nth(:,1));
    pdf2(:,k)=gampdf(t2(k),g(:,2),th(:,2));
    npdf2(:,k)=gampdf(t2(k),ng(:,2),nth(:,2));
end
PDF1=(ps)'*pdf1;nPDF1=(nps)'*npdf1;
PDF2=(ps)'*pdf2;nPDF2=(nps)'*npdf2;

PDF=[PDF1',PDF2'];
nPDF=[nPDF1',nPDF2'];
H=[h1',h2'];

hnd2=figure;
subplot(2,2,1),bar(t1,h1,'w'),axis([t1(1),t1(end),0,max(h1)])
hnd=title('IPT histogram');set(hnd,'Fontsize',14);
hnd=xlabel('dB\mu');set(hnd,'Fontsize',14);
hnd=ylabel('occurrences');set(hnd,'Fontsize',14);
subplot(2,2,2),bar(t2,h2,'w'),axis([t2(1),t2(end),0,max(h2)])
hnd=title('PS histogram');set(hnd,'Fontsize',14);
hnd=xlabel('bytes');set(hnd,'Fontsize',14);
hnd=ylabel('occurrences');set(hnd,'Fontsize',14);

subplot(2,2,3),plot(t1,PDF1,'g--',t1,nPDF1,'k-'),axis([t1(1),t1(end),0,max(max(PDF1),max(nPDF1))])
hnd=title('IPT pdf');set(hnd,'Fontsize',14);
hnd=ylabel('occurrences');set(hnd,'Fontsize',14);
hnd=legend('starting','trained');set(hnd,'Fontsize',14);
hnd=xlabel('dB\mu');set(hnd,'Fontsize',14);
hold on,for k=1:length(nA) plot(t1,nps(k)*npdf1(k,:),'y:'),end,hold off
subplot(2,2,4),plot(t2,PDF2,'g--',t2,nPDF2,'k-'),axis([t2(1),t2(end),0,max(max(PDF2),max(nPDF2))])
hnd=title('PS pdf');set(hnd,'Fontsize',14);
hnd=ylabel('occurrences');set(hnd,'Fontsize',14);
hnd=legend('starting','trained');set(hnd,'Fontsize',14);
hnd=xlabel('bytes');set(hnd,'Fontsize',14);
hold on,for k=1:length(nA) plot(t2,nps(k)*npdf2(k,:),'y:'),end,hold off

%%% ------------------------

B1=diag(g(:,1).*th(:,1));nB1=diag(ng(:,1).*nth(:,1));
B2=diag(g(:,2).*th(:,2));nB2=diag(ng(:,2).*nth(:,2));
BII1=diag(g(:,1).*(1+g(:,1)).*th(:,1).*th(:,1));nBII1=diag(ng(:,1).*(1+ng(:,1)).*nth(:,1).*nth(:,1));
BII2=diag(g(:,2).*(1+g(:,2)).*th(:,2).*th(:,2));nBII2=diag(ng(:,2).*(1+ng(:,2)).*nth(:,2).*nth(:,2));

E1=A*B1;nE1=nA*nB1;
E2=A*B2;nE2=nA*nB2;

EII1=A*BII1;nEII1=nA*nBII1;
EII2=A*BII2;nEII2=nA*nBII2;

o=ones(length(nA),1);

R(1,1,1)=ps'*EII1*o;      nR(1,1,1)=nps'*nEII1*o;
R(1,2,1)=ps'*E1*B2*o;   nR(1,2,1)=nps'*nE1*nB2*o;
R(2,1,1)=ps'*E2*B1*o;   nR(2,1,1)=nps'*nE2*nB1*o;
R(2,2,1)=ps'*EII2*o;      nR(2,2,1)=nps'*nEII2*o;

for m=2:LR+1
    R(1,1,m)=ps'*E1*(A^(m-2))*E1*o;   nR(1,1,m)=nps'*nE1*(nA^(m-2))*nE1*o;
    R(1,2,m)=ps'*E1*(A^(m-2))*E2*o;   nR(1,2,m)=nps'*nE1*(nA^(m-2))*nE2*o;
    R(2,1,m)=ps'*E2*(A^(m-2))*E1*o;   nR(2,1,m)=nps'*nE2*(nA^(m-2))*nE1*o;
    R(2,2,m)=ps'*E2*(A^(m-2))*E2*o;   nR(2,2,m)=nps'*nE2*(nA^(m-2))*nE2*o;
end

%%%
%M=(length(q):-1:length(q)-LR)';
%rr=crosscorr(q(:,1),q(:,1),LR);   rS(1,1,:)=rr(LR+1:end);
%rr=crosscorr(q(:,1),q(:,2),LR);   rS(1,2,:)=rr(LR+1:end);
%rr=crosscorr(q(:,2),q(:,1),LR);   rS(2,1,:)=rr(LR+1:end);
%rr=crosscorr(q(:,2),q(:,2),LR);   rS(2,2,:)=rr(LR+1:end);
%%%
edges=find(y(:,1)==Inf);
Lseq=length(edges)-1;llseq=0;
r=zeros(2,2,LR+1);
for k=1:Lseq
    j1=edges(k)+1;
    j2=edges(k+1)-1;
    yk=y(j1:j2,:);    
    %if size(yk,1)<=20
    %    yk(21,:)=[0,0];
    %end
    if size(yk,1)>20
        CC1=prod(double(yk(:,1)==yk(1,1)*ones(size(yk,1),1)));
        CC2=prod(double(yk(:,2)==yk(1,2)*ones(size(yk,1),1)));
    if ~(CC1|CC2)
            rr=crosscorr(yk(:,1),yk(:,1),LR);   r(1,1,:)=r(1,1,:)+(reshape(rr(LR+1:end),[1,1,LR+1]));
            rr=crosscorr(yk(:,1),yk(:,2),LR);   r(1,2,:)=r(1,2,:)+(reshape(rr(LR+1:end),[1,1,LR+1]));
            rr=crosscorr(yk(:,2),yk(:,1),LR);   r(2,1,:)=r(2,1,:)+(reshape(rr(LR+1:end),[1,1,LR+1]));
            rr=crosscorr(yk(:,2),yk(:,2),LR);   r(2,2,:)=r(2,2,:)+(reshape(rr(LR+1:end),[1,1,LR+1]));   
            llseq=llseq+1;              
    end
    end
end
r=r/llseq;
%%%


hnd3=figure;
qd=squeeze(r(1,1,:));%qd=squeeze(rS(1,1,:));
q=(squeeze(R(1,1,:))-mu(1)*mu(1))/(sig(1)*sig(1));nq=(squeeze(nR(1,1,:))-nmu(1)*nmu(1))/(nsig(1)*nsig(1));
subplot(2,2,1),plot(0:LR,qd,'r.-',0:LR,q,'g--',0:LR,nq,'k-'),%zoom on,grid on,
hnd=title('between IPT and IPT');set(hnd,'Fontsize',14);
hnd=xlabel('Lag');set(hnd,'Fontsize',14);
hnd=ylabel('covariance');set(hnd,'Fontsize',14);
hnd=legend('data','starting','trained',4);set(hnd,'Fontsize',14);
axis([0 LR -1 1])
%
qd=squeeze(r(1,2,:));%qd=squeeze(rS(1,2,:));
q=(squeeze(R(1,2,:))-mu(1)*mu(2))/(sig(1)*sig(2));nq=(squeeze(nR(1,2,:))-nmu(1)*nmu(2))/(nsig(1)*nsig(2));
subplot(2,2,2),plot(0:LR,qd,'r.-',0:LR,q,'g--',0:LR,nq,'k-'),%zoom on,grid on,
hnd=title('between IPT and PS');set(hnd,'Fontsize',14);
hnd=xlabel('Lag');set(hnd,'Fontsize',14);
hnd=ylabel('covariance');set(hnd,'Fontsize',14);
hnd=legend('data','starting','trained',4);set(hnd,'Fontsize',14);
axis([0 LR -1 1])
%
qd=squeeze(r(2,1,:));%qd=squeeze(rS(2,1,:));
q=(squeeze(R(2,1,:))-mu(2)*mu(1))/(sig(2)*sig(1));nq=(squeeze(nR(2,1,:))-nmu(2)*nmu(1))/(nsig(2)*nsig(1));
subplot(2,2,3),plot(0:LR,qd,'r.-',0:LR,q,'g--',0:LR,nq,'k-'),%zoom on,grid on,
hnd=title('between PS and IPT');set(hnd,'Fontsize',14);
hnd=xlabel('Lag');set(hnd,'Fontsize',14);
hnd=ylabel('covariance');set(hnd,'Fontsize',14);
hnd=legend('data','starting','trained',4);set(hnd,'Fontsize',14);
axis([0 LR -1 1])
%
qd=squeeze(r(2,2,:));%qd=squeeze(rS(2,2,:));
q=(squeeze(R(2,2,:))-mu(2)*mu(2))/(sig(2)*sig(2));nq=(squeeze(nR(2,2,:))-nmu(2)*nmu(2))/(nsig(2)*nsig(2));
subplot(2,2,4),plot(0:LR,qd,'r.-',0:LR,q,'g--',0:LR,nq,'k-'),%zoom on,grid on,
hnd=title('between PS and PS');set(hnd,'Fontsize',14);
hnd=xlabel('Lag');set(hnd,'Fontsize',14);
hnd=ylabel('covariance');set(hnd,'Fontsize',14);
hnd=legend('data','starting','trained',4);set(hnd,'Fontsize',14);
axis([0 LR -1 1])


hnd10=plot_src(y(1:10000,:));

syT=generate_src(nA,ng,nth,5000);
hnd11=plot_src(syT);

S=input('salvare le figure e le tabelle ? (1/0) ');
if S
    %DY=input('inserire giorno (3 char): ');
    %ID=num2str(input('inserire numero sessione: '));
    ID=input('inserire nome sessione: ');
    name2=['PDF-',ID];
    name3=['COR-',ID];
    name10=['SEQ-',ID];
    name11=['SST-',ID];
    name4=['TAB-',ID,'.txt'];
%    print_figure(name1,hnd1)
    print_figure(name2,hnd2)
    print_figure(name3,hnd3)
    print_figure(name10,hnd10)
    print_figure(name11,hnd11)
    Tab=[mud;mu;nmu;Inf,Inf;sigd;sig;nsig];
    save(name4,'Tab','-ascii')
end





figure;
qd=squeeze(r(1,1,:));%qd=squeeze(rS(1,1,:));
q=(squeeze(R(1,1,:))-mu(1)*mu(1))/(sig(1)*sig(1));nq=(squeeze(nR(1,1,:))-nmu(1)*nmu(1))/(nsig(1)*nsig(1));
plot(0:LR,qd,'r.-',0:LR,q,'b--',0:LR,nq,'k-'),%zoom on,grid on,
hnd=title('between IPT and IPT');set(hnd,'Fontsize',20);
hnd=xlabel('Lag');set(hnd,'Fontsize',20);
hnd=ylabel('covariance');set(hnd,'Fontsize',20);
hnd=legend('data','starting','trained',1);set(hnd,'Fontsize',20);
axis([0 LR -.6 1])
%
figure;
qd=squeeze(r(2,2,:));%qd=squeeze(rS(2,2,:));
q=(squeeze(R(2,2,:))-mu(2)*mu(2))/(sig(2)*sig(2));nq=(squeeze(nR(2,2,:))-nmu(2)*nmu(2))/(nsig(2)*nsig(2));
plot(0:LR,qd,'r.-',0:LR,q,'b--',0:LR,nq,'k-'),%zoom on,grid on,
hnd=title('between PS and PS');set(hnd,'Fontsize',20);
hnd=xlabel('Lag');set(hnd,'Fontsize',20);
hnd=ylabel('covariance');set(hnd,'Fontsize',20);
hnd=legend('data','starting','trained',1);set(hnd,'Fontsize',20);
axis([0 LR -.6 1])
%
figure;
qd=squeeze(r(1,2,:));%qd=squeeze(rS(1,2,:));
q=(squeeze(R(1,2,:))-mu(1)*mu(2))/(sig(1)*sig(2));nq=(squeeze(nR(1,2,:))-nmu(1)*nmu(2))/(nsig(1)*nsig(2));
plot(0:LR,qd,'r.-',0:LR,q,'b--',0:LR,nq,'k-'),%zoom on,grid on,
hnd=title('between IPT and PS');set(hnd,'Fontsize',20);
hnd=xlabel('Lag');set(hnd,'Fontsize',20);
hnd=ylabel('covariance');set(hnd,'Fontsize',20);
hnd=legend('data','starting','trained',1);set(hnd,'Fontsize',20);
axis([0 LR -.6 1])

