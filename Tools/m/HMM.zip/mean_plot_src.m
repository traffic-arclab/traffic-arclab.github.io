function m=mean_plot_src(y,q);
% m=mean_plot_src(y);
% m=mean_plot_src(y,q);

edges=find(y(:,1)==Inf);
Lseq=length(edges)-1;
m=zeros(Lseq,2);
for k=1:Lseq
    j1=edges(k)+1;
    j2=edges(k+1)-1;
    yk=y(j1:j2,:);
    m(k,:)=mean(yk);
end

figure,plot(m(:,1),m(:,2),'b.'),%zoom on,grid on,
hnd=title('Session Mean Plot');set(hnd,'Fontsize',14);
hnd=xlabel('IDT');set(hnd,'Fontsize',14);
hnd=ylabel('PS');set(hnd,'Fontsize',14);

if nargin==2
edges=find(q(:,1)==Inf);
Lseq=length(edges)-1;
m=zeros(Lseq,2);
for k=1:Lseq
    j1=edges(k)+1;
    j2=edges(k+1)-1;
    qk=q(j1:j2,:);
    mq(k,:)=mean(qk);
end
hold on,
plot(mq(:,1),mq(:,2),'ro'),%zoom on,grid on,
end