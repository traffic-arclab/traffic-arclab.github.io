function [nA,ng,nth,L]=learning_src_M(A,g,th,y,kmax,e);
% [nA,ng,nth,L]=learning_src_M(A,g,th,y,kmax,e);
% [nA,ng,nth,L]=learning_src_M(A,g,th,y,kmax);
% [nA,ng,nth,L]=learning_src_M(A,g,th,y);
% [nA,ng,nth,L]=learning_src_M(y,Nstati,kmax);
% [nA,ng,nth,L]=learning_src_M(y,Nstati);

if nargin==5
    e=0;
elseif nargin==4
    kmax=10;
    e=0;
    elseif nargin==3
    y=A;
    Nstati=g;
    kmax=th;
    e=0;
    [A,g,th]=starting_src_M(Nstati,y);
elseif nargin==2
    y=A;
    Nstati=g;
    kmax=10;
    e=0;
    [A,g,th]=starting_src_M(Nstati,y);
end

%size(Nstati),size(y)

nA=A;
ng=g;
nth=th;
L=[];
k=0;
while k<kmax %( k<=2 ) | (( L(end) > L(end-1)+e )&(k<kmax)) 
    [nA,ng,nth,lkl]=step_src_M(nA,ng,nth,y);
    L=[L;lkl];
    k=k+1
    %
%    if ~isfinite(nA) 
    if (prod(double(isfinite(nA(1:end))))*prod(double(isfinite(ng(1:end))))*prod(double(isfinite(nth(1:end)))))==0% ~(prod(isfinite(nA(1:end)))*prod(isfinite(ng(1:end)))*prod(isfinite(nth(1:end))))
      k,break
   end
   %
end

%figure,semilogy(L)
%ylabel('log-likelihood'),xlabel('iterations'),ylabel('')
%grid on, zoom on