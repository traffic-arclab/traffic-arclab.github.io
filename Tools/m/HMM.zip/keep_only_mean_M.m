function q=keep_only_mean_M(y,Lt,Lp);
% q=keep_only_mean_M(y,Lt,Lp);
%
% y: sequenze di IPT e PS separate da [Inf,Inf]
% Lt=[mt1,mt2] 
% Lp=[mp1,mp2]
% 
% q: contiene solo le sequenze di "y" tali che:
%     mt1 <= mean(IDT) <= mt2
%     mp1 <= mean(PS) <= mp2
%

edges=find(y(:,1)==Inf);
Lseq=length(edges)-1;
q=[Inf,Inf];
for k=1:Lseq
    j1=edges(k)+1;
    j2=edges(k+1)-1;
    yk=y(j1:j2,:);
    m=mean(yk);
    if m(1)>=Lt(1) & m(1)<=Lt(2) & m(2)>=Lp(1) & m(2)<=Lp(2)
        q=[q;yk;Inf,Inf];
    end
end