function [A,g,th]=starting_src_M(N,y);
% [A,g,th]=starting_src_M(N,y);

j=find(isfinite(y(:,1)));
yM=max(y(j,:));
ym=min(y(j,:));

A=(1/N)*ones(N,N);

dd=(yM-ym)/(N+1);
mu(:,1)=(ym(:,1)+dd(:,1):dd(:,1):ym(:,1)+N*dd(:,1))';
s(:,1)=(dd(:,1)/5)*ones(N,1);
mu(:,2)=(ym(:,2)+dd(:,2):dd(:,2):ym(:,2)+N*dd(:,2))';
s(:,2)=(dd(:,2)/5)*ones(N,1);

g=(mu./s).^2;
th=(s.^2)./mu;