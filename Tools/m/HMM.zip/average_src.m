function [ps,ymean,ysigma,duration]=average_src(A,g,th);
% [ps,ymean,ysigma,duration]=average_src(A,g,th);

[V,D]=eig(A'); % calcola autovettori ed autovalori di A trasposto
d=diag(D);dif=abs(d-1);
k=find(dif==min(dif)); % trova l'indice dell'autovalore unitario
ps=V(:,k)/sum(V(:,k)); % trova l'autovettore corrispondente e lo normalizza
% ps � il vettore delle probabilit� stazionarie

ymean=ps'*(g.*th);
yrms2=ps'*(g.*(1+g).*th.*th);
ysigma=sqrt(yrms2-ymean.^2);
duration=1./(1-diag(A));