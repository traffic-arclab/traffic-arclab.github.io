function [nA,ng,nth,pr]=step_src_M(A,g,th,y);
% [nA,ng,nth,pr]=step_src_M(A,g,th,y);

N=length(A);

numA=zeros(size(A));
denA=zeros(N,1);

num1m=zeros(N,1);
num2m=zeros(N,1);
num1s=zeros(N,1);
num2s=zeros(N,1);
den=zeros(N,1);

pr=0;

controllo=0;

edges=find(y(:,1)==Inf);
L=length(edges)-1;
for k=1:L
   j1=edges(k)+1;
   j2=edges(k+1)-1;
   yk=y(j1:j2,:);
   [c,alpha,beta]=FB_src(A,g,th,yk);
   ro=RO_src(A,g,th,yk,alpha);
   Pk=sum(log(c));
   
   if (Pk~=0) & isfinite(Pk)
       controllo=1;
       pr=pr+Pk;
       
       Numk=zeros(size(A));
       for t=1:length(yk)-1
           b=pdf_src(yk(t+1,:),g,th);
           num=diag(alpha(:,t))*A*diag(b.*beta(:,t+1));
           %
           if ~isfinite(num)
               t
           end
           %
           Numk=Numk+num;
       end
       numA=numA+Numk/Pk;
       denA=denA+(sum(Numk'))'/Pk;
       %%%
       %Num1kOLD=(sum(((ro.*beta)*diag(yk(:,1)))'))'; % IAT %%%
       %Num2kOLD=(sum(((ro.*beta)*diag(yk(:,2)))'))'; % PS   %%%
       %
       yyy1=(yk(:,1)*ones(1,N))';
       yyy2=(yk(:,2)*ones(1,N))';
       Num1k=(sum((ro.*beta.*yyy1)'))';
       Num2k=(sum((ro.*beta.*yyy2)'))';
       %        
       Denk=(sum((ro.*beta)'))';
       
       %if ~isfinite(Denk)  disp('*** INF ***'),k,break,end
            
       % STIMA di MU
       num1m=num1m+Num1k/Pk;
       num2m=num2m+Num2k/Pk;
       den=den+Denk/Pk;
       % 
       ymuq1=((yk(:,1)*ones(1,length(g)))'-(g(:,1).*th(:,1))*ones(1,length(yk))).^2;
       Num1k=(sum(((ro.*beta).*ymuq1)'))';
       ymuq2=((yk(:,2)*ones(1,length(g)))'-(g(:,2).*th(:,2))*ones(1,length(yk))).^2;
       Num2k=(sum(((ro.*beta).*ymuq2)'))';
       % STIMA di S2
       num1s=num1s+Num1k/Pk;
       num2s=num2s+Num2k/Pk;
   end % if
end % for k

if controllo==1
    %
    pr=pr/L;
    %
    nA=diag(1./denA)*numA;
    %
    nmu1=num1m./den; % IAT
    nmu2=num2m./den; % PS
    nsq1=num1s./den; % IAT
    nsq2=num2s./den; %PS
    %
    ng(:,1)=(nmu1.^2)./nsq1;
    nth(:,1)=nsq1./nmu1;
    ng(:,2)=(nmu2.^2)./nsq2;
    nth(:,2)=nsq2./nmu2;
    %nA,ng,nth
    %
else
    pr=[];
    nA=A;
    ng=g;
    nth=th;
end
