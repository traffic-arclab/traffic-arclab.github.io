function h=plot_src(y);
% plot_src(y);

h=figure;

subplot(2,1,1),plot(y(:,1),'.k'),
axis([0,length(y)+1,min(y(:,1)),max(y(:,1))])
hnd=title('IPT sequence');set(hnd,'Fontsize',14);
hnd=ylabel('10 log_1_0(IPT/1\mus)');set(hnd,'Fontsize',14);
hnd=xlabel('sequence number');set(hnd,'Fontsize',14);

subplot(2,1,2),plot(y(:,2),'.k'),
axis([0,length(y)+1,0,max(y(:,2))])
hnd=title('PS sequence');set(hnd,'Fontsize',14);
hnd=ylabel('PS (bytes)');set(hnd,'Fontsize',14);
hnd=xlabel('sequence number');set(hnd,'Fontsize',14);

