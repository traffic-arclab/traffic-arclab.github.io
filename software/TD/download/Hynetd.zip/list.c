/******************************************************************************
                list.c
                List structure implementation

                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
 *******************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "list.h"
#include <string.h>
#include <stdio.h>

/************ Function Implementations ******************/

/*!
  \fn void listInit (List *list)

  \brief This function initializes the list structure

  \param the list pointer
*/
void
listInit (List *list)
{
	list->size = 0;
	list->empty = true;
	list->head = NULL;
	list->last = NULL;
}

/*!
  \fn void listReset (List *list, bool full)

  \brief This function frees all list elements

  \param list the list pointer
*/
void listReset (List *list, bool full)
{
	ListEntry *tmp;
	
	while (list->head != NULL) {
		tmp = list->head;
		list->head = tmp->next;
		if (full) free(tmp->element);
		free(tmp);
	}

	list->size = 0;
	list->empty = true;
	list->last = NULL;
}

/*!
  \fn void listPush (List *list, void *element)

  \brief This function adds an element at the end of the list

  \param list pointer to the head of the list
  \param element pointer to the element that must be added
*/
void
listPush (List *list, void *element)
{
	ListEntry *tmp = (ListEntry *) malloc (sizeof(ListEntry));

	// Inizialize new list entry
	tmp->next = NULL;
	tmp->element = element;

	if (list->empty) 
	{	// Insert as first element
		list->empty = false;
		list->head = tmp;
	}
	else
	{	// Insert as last element
		list->last->next = tmp;
	}

	list->last = tmp;
	list->size++;
}

/*!
  \fn void *listPop (List *list)

  \brief This function returns the first element of the list removing it from the list

  \param the list pointer
  \param pointer to the element removed
*/
void *
listPop (List *list)
{
	if (!list->empty) {
		ListEntry *tmp = list->head;
		void *element;

		list->head = tmp->next;
		list->size--;
		if (list->size == 0) {
			list->empty = true;
			list->last = NULL;
		}
		element = tmp->element;	

		free(tmp);
		return element;
	}
	else return NULL;
}

/*!
  \fn void *listGet (List *list,int i)

  \brief This function return the 'i'th element of the list

  \param the list pointer
  \param the element number
*/
void *
listGet (List *list, int i)
{
	if (i < list->size) {
		int j;
		ListEntry *tmp = list->head;
		
		// Search the list element i
		for (j=0; j<i ; j++) tmp = tmp->next;
		
		return tmp->element;
	}
	else return NULL;
}

/*!
  \fn void *listSearch (List *list, const void *element, bool(*compare)(const void *, const void *))

  \brief This function searchs element in the list comparing it using compare function

  \param list the list pointer
  \param element element to find in list
  \param compare function to compare list elements
  \return pointer to the element found, NULL if not found
*/
void *
listSearch (List *list, const void *element, bool(*compare)(const void *, const void *))
{
	ListEntry *current;

	for (current = list->head; current; current = current->next)
		if (compare (element, current->element)) return current->element;

	return NULL;
}
