/******************************************************************************
                list.h
                List structure and functions declaration

                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
 *******************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _LIST_H
#define _LIST_H

#include <stdlib.h>

/****************** Type definitions ******************/
#ifndef _BOOL_
#define _BOOL_
typedef enum {false, true} bool;	/*!< Boolean type */
#endif

// List element container
typedef struct ListEntry {
   void *element;          /*!< Pointer to element data */
   struct ListEntry *next; /*!< Next list entry */
} ListEntry;

// List base structure
typedef struct List {
   u_int16_t size;		/*!< List size */
   bool empty;			/*!< Empty flag */
   ListEntry *head;		/*!< First list element */
   ListEntry *last;		/*!< Last list element */
} List;
 
/************ Function Declarations ******************/

/*!
  \fn void listInit (List *list)

  \brief This function initializes the list structure

  \param list the list pointer
*/
void listInit (List *list);

/*!
  \fn void listReset (List *list, bool full)

  \brief This function frees all list elements

  \param list the list pointer
*/
void listReset (List *list, bool full);

/*!
  \fn void listPush (List *list, void *element)

  \brief This function adds an element at the end of the list

  \param list pointer to the head of the list
  \param element pointer to the element that must be add
*/
void listPush (List *list, void *element);

/*!
  \fn void *listPop (List *list)

  \brief This function returns the first element of the list removing it from the list

  \param list the list pointer
*/
void *listPop (List *list);

/*!
  \fn void *listGet (List *list, int i)

  \brief This function returns a pointer to the 'i'th element of the list

  \param list the list pointer
*/
void *listGet (List *list, int i);

/*!
  \fn void *listSearch (List *list, const void *element, bool(*compare)(const void *, const void *))

  \brief This function searchs element in the list comparing it using compare function

  \param list the list pointer
  \param element element to find in list
  \param compare function to compare list elements
  \return pointer to the element found, NULL if not found
*/
void *listSearch (List *list, const void *element, bool(*compare)(const void *, const void *));

#endif
