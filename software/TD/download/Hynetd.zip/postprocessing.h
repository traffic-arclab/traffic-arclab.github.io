/***************************************************************************
                postprocessing.h
                Network topology post processing functions definitions
 
                -------------------
    begin       : 26/05/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _POSTPROCESSING_H
#define _POSTPROCESSING_H

/********************* Included Libraries **********************/

#include "scanner.h"

/******************** Constants Declaration ********************/

#define MAX_SUBNET_LINK 4	/* Max acceptable subnet range in router links */

/******************** Types definition ********************/

typedef enum {PREC_HOP_RR, PREC_HOP, NO_PREC_HOP} SubExtPhase;	// Subnet extraction phases

/******************** Functions Declaration ********************/
/*!
  \fn void extractLinks (ThreadParam *params)
  \brief This function creates links from SNMP and IcmpTable data

  \param params pointer to generic thread parameters
*/
void extractLinks (ThreadParam *params);

/*!
  \fn void extractSubnets (ThreadParam *params)
  \brief This function creates subnets from IcmpTable data

  \param params pointer to generic thread parameters
*/
void extractSubnets (ThreadParam *params);

/*!
  \fn NetNode *icmpRow2NetNode (ThreadParam *params, IcmpRow *row)

  \brief This function creates a node from an IcmpTable row and associate them

  \param params pointer to generic thread parameters
  \param row IcmpTable row pointer
  \return pointer to new node
*/
NetNode *icmpRow2NetNode (ThreadParam *params, IcmpRow *row);

/*!
  \fn struct in_addr keshav (List *rows)

  \brief This function executes Keshav euristic to obtain a netmask from a list of ip addresses

  \param rows rows list pointer
  \return pointer to new node
*/
struct in_addr keshav (List *rows);

/*!
  \fn void icmpTabSubnetCmp (ThreadParam *params, bool allSubnets)

  \brief This function scans IcmpTab for rows not yet visited during subnet creation and tests if each one
  \brief belongs to an existing subnet.

  \param params pointer to generic thread parameters
*/
void icmpTabSubnetCmp (ThreadParam *params, bool allSubnets);

/*!
  \fn void icmpRow2Subnet (ThreadParam *params, ListEntry *current, SubExtPhase phase)

  \brief This function from a row extracts a subnet comparing precHops

  \param params pointer to generic thread parameters
  \param current pointer to current IcmpTable row
  \param phase subnet extraction phase
*/
void icmpRow2Subnet (ThreadParam *params, ListEntry *current, SubExtPhase phase);

/*!
  \fn void defaultGateway (IcmpRow *row, Subnet *net)

  \brief This function tries to assing a default gateway to a subnet

  \param row IcmpTable row pointer
  \param net Subnet pointer
*/
void defaultGateway (IcmpRow *row, Subnet *net);

#endif
