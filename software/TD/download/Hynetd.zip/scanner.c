/***************************************************************************
                scanner.c 
                Network discovery functions implementation
 
                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 
#include "scanner.h"

/******************** Global Variables ********************/

// Mutex variables used by threads
pthread_mutex_t mutex_options = PTHREAD_MUTEX_INITIALIZER;	
pthread_mutex_t mutex_params = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_icmpTab = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_topology = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_sync = PTHREAD_MUTEX_INITIALIZER;

/******************** Functions implementation ********************/


/*!
  \fn unsigned short cksum (unsigned short *addr, int len)

  \brief Calculates the checksum of an IP header.

  \param addr is the value to calculate the checksum.
  \param len is the lenght of the value.

  \return the checksum value.
*/
unsigned short
cksum (unsigned short *addr, int len)
{
	int nleft = len;
	int sum = 0;
	unsigned short *w = addr;
	unsigned short answer = 0;
	
	while (nleft > 1) {
		sum = sum + *w++;
		nleft = nleft - 2;
	}
	
	if (nleft == 1) {
		*(unsigned char *) (&answer) = *(unsigned char *) w;
		sum = sum + answer;
	}
	sum = (sum >> 16) + (sum & 0xffff);
	sum = sum + (sum >> 16);
	answer = ~sum;
	return answer;
}

/*!
  \fn u_int8_t getDefaultTTL (void)

  \brief Reads the default TTL value used for outgoing packets from /proc/sys/net/ipv4/ip_default_ttl.

  \return Returns the default TTL value used for outgoing packets.
*/
u_int8_t
getDefaultTTL (void)
{
	FILE *fp;
	int ttl;

	fp = fopen ("/proc/sys/net/ipv4/ip_default_ttl", "r");
	fscanf (fp, "%d", &ttl);
	fclose (fp);

	return ttl;
}

/*!
  \fn int traceroute (struct in_addr addr, Options *opt, Path *hops)

  \brief This function executes traceroute algorithm to destination addr and returns an array with the path discovered

  \param addr Address to send a traceroute
  \param opt Structure containing options values
  \param path Pointer to a path structure

  \return Return an exit status code (see scanner.h)
*/
int
traceroute (struct in_addr addr, Options *opt, Path *hops)
{
	int socketfd[2];					// socket file descriptors: [0]->ICMP - [1]->UDP
	char pkt_buf[MAX_PACKET];			// packet buffer
	struct sockaddr_in dst_addr;		// destination address 
	struct sockaddr_in src_addr;		// source address for incoming packets
	struct icmp *icmp_buf;				// ICMP header struct pointer
	struct iphdr *ip_buf;				// IP header struct pointer
	struct timeval tv;					// timeout value
	int ttl = 1;						// time to live
	u_int8_t retry = 0;					// retries counter
	TraceState state = SCANNING;		// traceroute scan process terminated
	bool icmp_filtered = false;			// ICMP packets filtered from some router through the path
	bool udp_filtered = false;			// UDP packets filtered from some router through the path
	u_int8_t mode = opt->gOpts->mode;	// traceroute mode: ICMP = 0 - UDP = 1

	// Path array allocation
	hops->array = (struct in_addr *) calloc (opt->gOpts->max_ttl, sizeof(struct in_addr));

#ifdef DEBUG
	char debugBuf[50];
	printf ("Thread %02d - Traceroute destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif

	// destination address configuration
	dst_addr.sin_family = AF_INET;	
	dst_addr.sin_addr = addr;
	dst_addr.sin_port = BIG_UDP_PORT;
	
	// socket creation for ICMP
	if ((socketfd[ICMP] = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {	
		perror ("traceroute: error in socket0 creation");
		return -1;
	}

	// socket creation for UDP
	if ((socketfd[UDP] = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {	
		perror ("traceroute: error in socket1 creation");
		return -1;
	}

	// ICMP socket timeout configuration
	tv.tv_sec = opt->gOpts->timeout / 1000;			// seconds
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	// micro-seconds
	setsockopt (socketfd[ICMP], SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));
	
	do {
		TraceMode turn = (retry + mode) % 2;
		
		// send ICMP packet
		if (!icmp_filtered && (turn == ICMP || (turn == UDP && udp_filtered)))
		{
			// set TTL value in IP header
			if (setsockopt (socketfd[ICMP], IPPROTO_IP, IP_TTL, (char *) &ttl, sizeof (ttl)) < 0) {
				perror ("traceroute: error in setsockopt IP_TTL");
				return -3;
			}
			
			// ICMP packet construction 
			icmp_buf = (struct icmp *) pkt_buf;
			icmp_buf->icmp_type = ICMP_ECHO;
			icmp_buf->icmp_code = 0;
			icmp_buf->icmp_id = getpid ();
			icmp_buf->icmp_seq = 0;
			icmp_buf->icmp_cksum = 0;
			icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
			
			// sending ICMP packet
			if (sendto(socketfd[ICMP], icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
				perror ("traceroute: error in sendto");
				return -4;
			}
#ifdef DEBUG
			sprintf (debugBuf, "Thread %02d - Sent ICMP (TTL %02d)-> ", opt->lOpts->threadNum, ttl);
#endif
		}
		// send UDP packet
		else if (!udp_filtered && (turn == UDP || (turn == ICMP && icmp_filtered)))
		{
			// set TTL value in IP header
			if (setsockopt (socketfd[UDP], IPPROTO_IP, IP_TTL, (char *) &ttl, sizeof (ttl)) < 0) {
				perror ("traceroute: error in setsockopt IP_TTL");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -3;
			}

			// set packet payload
			memset (&pkt_buf, 'X', UDP_SIZE);
			
			// sending UDP packet
			if (sendto(socketfd[UDP], pkt_buf, UDP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
				perror ("traceroute: error in sendto");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -4;
			}
#ifdef DEBUG
			sprintf (debugBuf, "Thread %02d - Sent UDP  (TTL %02d)-> ", opt->lOpts->threadNum, ttl);
#endif
		}
		// scan abort because all packets are filtered
		else state = DEST_FILTERED;
		
		// receive ICMP messages 
		while (!state) 
		{
			socklen_t lsock = sizeof(dst_addr);	// size of sockaddr struct
			
			if (recvfrom(socketfd[ICMP], &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock) < 0) 
			{
				// ICMP_TIMEOUT
#ifdef DEBUG
				printf ("%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				if (retry < opt->gOpts->retries) retry++;
				else {
					// store a null address in the path array
					hops->array[ttl-1].s_addr = (u_int32_t) 0;
					ttl++;
					retry = 0;
				}
				break;			
			}
			
			// retrieve packet informations
			ip_buf = (struct iphdr *) &pkt_buf[IP_SIZE + 8];	// IP header appended to ICMP packet
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		// ICMP header 
			
			// ICMP_TIME_EXCEEDED reply to Packet directed to current destination IP
			if (icmp_buf->icmp_type == ICMP_TIME_EXCEEDED && ip_buf->daddr == addr.s_addr) 
			{
#ifdef DEBUG
				printf ("%sReceived ICMP_TIME_EXCEEDED from %s\n", debugBuf, inet_ntoa(src_addr.sin_addr));
#endif
				// store the address in the path array
				hops->array[ttl-1].s_addr = src_addr.sin_addr.s_addr;
				hops->length = ttl;
				
				// the ICMP message is from destination
				if(src_addr.sin_addr.s_addr == addr.s_addr) {
					state = DEST_REACHED;
					break;
				}
				
				// switch preferred mode if necessary
				if (ip_buf->protocol == IPPROTO_UDP) mode = UDP;
				else mode = ICMP;
				
				ttl++;
				retry = 0;		
				break;
			}
			
			// ICMP_ECHOREPLY from destination 
			else if (icmp_buf->icmp_type == ICMP_ECHOREPLY && src_addr.sin_addr.s_addr == addr.s_addr) 
			{ 
#ifdef DEBUG
				printf ("%sReceived ICMP_ECHOREPLY from %s\n", debugBuf, inet_ntoa (src_addr.sin_addr));
#endif
				hops->array[ttl-1].s_addr = src_addr.sin_addr.s_addr;
				hops->length = ttl;
				state = DEST_REACHED;
				break;	      
			}

			// ICMP_DEST_UNREACH reply to Packet directed to current destination IP
			else if (icmp_buf->icmp_type == ICMP_DEST_UNREACH && ip_buf->daddr == addr.s_addr) 
			{
				// ICMP_PORT_UNREACH code
				if (icmp_buf->icmp_code == ICMP_PORT_UNREACH)
				{
#ifdef DEBUG
					printf ("%sReceived ICMP_PORT_UNREACH from %s\n", debugBuf, inet_ntoa (src_addr.sin_addr));
#endif
					hops->array[ttl-1].s_addr = src_addr.sin_addr.s_addr;
					hops->length = ttl;
					state = DEST_REACHED;
					break;	      

				}
				// ICMP_PKT_FILTERED code
				else if (icmp_buf->icmp_code == ICMP_PKT_FILTERED)
				{
#ifdef DEBUG
					printf ("%sReceived ICMP_PKT_FILTERED from %s (proto=%d)\n", 
							debugBuf, inet_ntoa (src_addr.sin_addr), ip_buf->protocol);
#endif
					// set as filtered involved protocol
					if (ip_buf->protocol == IPPROTO_UDP) udp_filtered = true;
					if (ip_buf->protocol == IPPROTO_ICMP) icmp_filtered = true;
					
					retry++;
					break;
				}
				// Other ICMP_DEST_UNREACH code type
				else
				{
#ifdef DEBUG
					printf ("%sReceived ICMP_DEST_UNREACH (code=%d) from %s\n", 
							debugBuf, icmp_buf->icmp_code, inet_ntoa (src_addr.sin_addr));
#endif
					hops->array[ttl-1].s_addr = src_addr.sin_addr.s_addr;
					hops->length = ttl;
					state = DEST_UNREACHABLE;
				}
			}
		}
		if (ttl > opt->gOpts->max_ttl) state = MAX_TTL_REACHED;
	} while (!state);

	close (socketfd[ICMP]);
	close (socketfd[UDP]);
	
#ifdef DEBUG
	switch (state) {
		case SCANNING: break;
		case DEST_REACHED:
			printf ("Thread %02d - Destination %s reached in %d hops\n",
					opt->lOpts->threadNum, inet_ntoa (addr), ttl);
		break;
		case MAX_TTL_REACHED:
			printf ("Thread %02d - Destination %s not reached in %d hops (MAX_TTL_REACHED)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), ttl);
		break;
		case DEST_FILTERED:
			printf ("Thread %02d - Destination %s not reached in %d hops (DEST_FILTERED)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
		case DEST_UNREACHABLE:
			printf ("Thread %02d - Destination %s not reached in %d hops (DEST_UNREACHABLE)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
	}
#endif

	return state;
}

/*! 
  \fn int pingrr (struct in_addr addr, Options *opt, Path *path)

  \brief This Function sends a Ping with Record Route Option to addr and returns the path recorded

  \param addr Destination address
  \param opt Structure containing options values
  \param path Pointer to a path structure

  \return Return an exit status code (0 on error, 1 on ok, 2 on alias)
*/
int
pingrr (struct in_addr addr, Options *opt, Path *hops)
{
	int socketfd;					// socket file descriptor
	char pkt_buf[MAX_PACKET];		// packet buffer
	struct sockaddr_in dst_addr;	// destination address 
	struct sockaddr_in src_addr;	// source address for incoming packets
	struct icmp *icmp_buf;			// ICMP header struct pointer
	struct timeval tv;				// timeout value
	u_int8_t retry = 0;				// retries counter
	char rspace[3 + 4*NROUTES + 1]; // Record route configuration buffer 
	bool done = false;
	bool alias = false;

	// Path array allocation
	hops->array = (struct in_addr *) calloc (NROUTES, sizeof(struct in_addr));
	hops->newRows = (IcmpRow **) calloc (NROUTES, sizeof(IcmpRow *));
	hops->length = 0;

#ifdef DEBUG
	char debugBuf[50];
	debugOut (PINGRR, "Thread %02d - PingRR destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif
	
	// destination address configuration
	dst_addr.sin_family = AF_INET;
	dst_addr.sin_addr.s_addr = addr.s_addr;
	
	// socket creation for ICMP
	if ((socketfd = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {	
		perror ("traceroute: error in socket creation");
		return -1;
	}
	
	// ICMP socket timeout configuration
	tv.tv_sec = opt->gOpts->timeout / 1000;				// seconds
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	// micro-seconds
	setsockopt (socketfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));
	
	// Record route option activation
	memset (rspace, 0, sizeof (rspace));
	rspace[IPOPT_OPTVAL] = IPOPT_RR;
	rspace[IPOPT_OLEN] = sizeof (rspace) - 1;
	rspace[IPOPT_OFFSET] = IPOPT_MINOFF;
	if (setsockopt (socketfd, IPPROTO_IP, IP_OPTIONS, rspace, sizeof (rspace)) < 0) {
		perror ("pingrr: error while setting record route option");
		close (socketfd);
		return -1;
	}
	
	while (retry <= opt->gOpts->retries && !done) {
		// ICMP packet construction 
		icmp_buf = (struct icmp *) pkt_buf;
		icmp_buf->icmp_type = ICMP_ECHO;
		icmp_buf->icmp_code = 0;
		icmp_buf->icmp_id = getpid ();
		icmp_buf->icmp_seq = 0;
		icmp_buf->icmp_cksum = 0;
		icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
		
		// sending ICMP packet
		if (sendto(socketfd, icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
			perror ("pingrr: error in sendto");
			close (socketfd);
			return -2;
		}
#ifdef DEBUG
		sprintf (debugBuf, "Thread %02d - Sent ICMP-> ", opt->lOpts->threadNum);
#endif
	
		// receive ICMP messages
		do {
			socklen_t lsock = sizeof(dst_addr);	// size of sockaddr struct
			int pkt_len;
			
			if ((pkt_len = recvfrom(socketfd, &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock)) < 0) 
			{
				// ICMP_TIMEOUT
#ifdef DEBUG
				debugOut (PINGRR, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				retry++;
				break;
			}
			
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE_RR];		// ICMP header 
			
			// ICMP_ECHOREPLY from destination 
			if (icmp_buf->icmp_type == ICMP_ECHOREPLY && src_addr.sin_addr.s_addr == addr.s_addr) 
			{ 
				u_int32_t *l;		// Pointer to address values recorded by RecordRoute option
				u_int32_t *myaddr;	// Pointer to my ip address value
				int i;
#ifdef DEBUG
				debugOut (PINGRR, "%sReceived ICMP_ECHOREPLY from %s (%d  bytes)\n",
							debugBuf, inet_ntoa (src_addr.sin_addr), pkt_len);
#endif
				l = (void *) (&pkt_buf) + IP_SIZE + 3;
				myaddr = (void *) (&pkt_buf) + IP_SIZE - 4;

				if (*myaddr == *l) l++;
				else return 0;
				
				// Explore recorded addresses
				for (i = 0; i < NROUTES-1; i++) {
					// null address
					if (*l == 0) {
						hops->length = i+1;
						if (i == 0) return 0;
						break;
					}
					// twice the same address
					else if (i > 0 && hops->array[i-1].s_addr == *l) {
						hops->length = i+1;
						alias = true;
#ifdef DEBUG
						debugOut (PINGRR, "Thread %02d - TWICE\n", opt->lOpts->threadNum);
#endif
						break;
					}
					// destination address
					else if (addr.s_addr == *l || i == opt->lOpts->ttl - 1) {
						hops->array[i].s_addr = *l;
						hops->length = i+1;
#ifdef DEBUG
						debugOut (PINGRR, "Thread %02d - Hop #%d: %s\n", opt->lOpts->threadNum, i+1, inet_ntoa (hops->array[i]));
#endif
						if (addr.s_addr != *l) alias = true;
						break;
					}
					else {
						hops->array[i].s_addr = *l;
						hops->length = i+1;
#ifdef DEBUG
						debugOut (PINGRR, "Thread %02d - Hop #%d: %s\n", opt->lOpts->threadNum, i+1, inet_ntoa (hops->array[i]));
#endif
						// If preceding and next hop are in the same 255.255.255.252 subnet => Stop
						if ((*(l-1) & ntohl (0xFFFFFFFC)) == (*(l+1) & ntohl (0xFFFFFFFC))) {
							if (addr.s_addr != *l) alias = true;
							break;
						}
					}
					// point to next address
					l++;
				}
				
				// Record destination nextHopRR address
				if (i < NROUTES-2 && *(l+1) != *myaddr) {
					hops->array[i+1].s_addr = *(l+1);
#ifdef DEBUG
					debugOut (PINGRR, "Thread %02d - NextHopRR: %s\n", opt->lOpts->threadNum, inet_ntoa (hops->array[i+1]));
#endif
				}
				
				done = true;
			}
		} while (!done);	 
	}
	close (socketfd);
	
	if (done) {
		if (alias) return 2;
		else return 1;
	}	
	else return 0;
}

/*! 
  \fn bool ping (struct in_addr addr, Options *opt)
  \brief This Function sends a Ping to discover active nodes

  \param addr Destination address
  \param opt Structure containing options values
  \return Return if the node is active
*/
bool
ping (struct in_addr addr, Options *opt)
{
	int socketfd;					// socket file descriptor
	char pkt_buf[MAX_PACKET];		// packet buffer
	struct sockaddr_in dst_addr;	// destination address
	struct sockaddr_in src_addr;	// source address for incoming packets
	struct iphdr *ip_buf;			// IP header pointer
	struct icmp *icmp_buf;			// ICMP header struct pointer
	struct timeval tv;				// timeout value
	u_int8_t retry = 0;				// retries counter
	bool done = false;
	
#ifdef DEBUG
	char debugBuf[50];
	debugOut (PING, "Thread %02d - Ping destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif
	
	// destination address configuration
	dst_addr.sin_family = AF_INET;
	dst_addr.sin_addr.s_addr = addr.s_addr;
	
	// socket creation for ICMP
	if ((socketfd = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {
		perror ("ping: error in socket creation");
		return false;
	}

	// ICMP socket timeout configuration
	tv.tv_sec = opt->gOpts->timeout / 1000;				// seconds
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	// micro-seconds
	setsockopt (socketfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));

	while (retry <= opt->gOpts->retries && !done) {
		// ICMP packet construction 
		icmp_buf = (struct icmp *) pkt_buf;
		icmp_buf->icmp_type = ICMP_ECHO;
		icmp_buf->icmp_code = 0;
		icmp_buf->icmp_id = getpid ();
		icmp_buf->icmp_seq = retry;
		icmp_buf->icmp_cksum = 0;
		icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
		
		// sending ICMP packet
		if (sendto(socketfd, icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
			//perror ("ping: error in sendto");
			close (socketfd);
			return false;
		}
#ifdef DEBUG
		sprintf (debugBuf, "Thread %02d - Sent ICMP-> ", opt->lOpts->threadNum);
#endif
	
		// receive ICMP messages
		do {
			socklen_t lsock = sizeof(dst_addr);	// size of sockaddr struct
			int pkt_len;
					
			if ((pkt_len = recvfrom(socketfd, &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock)) < 0)
			{
				// ICMP_TIMEOUT
#ifdef DEBUG
				debugOut (PING, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				retry++;
				break;
			}

			ip_buf = (struct iphdr *) pkt_buf;				// IP header
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];	// ICMP header
					
			// ICMP_ECHOREPLY from destination
			if (icmp_buf->icmp_type == ICMP_ECHOREPLY && src_addr.sin_addr.s_addr == addr.s_addr)
			{
				// Estimate hop distance from destination using default TTL values
				if (ip_buf->ttl > 200) opt->lOpts->ttl = 256 - ip_buf->ttl;			// Default TTL 255
				else if (ip_buf->ttl > 128) opt->lOpts->ttl = 201 - ip_buf->ttl;	// Default TTL 200
				else if (ip_buf->ttl > 64) opt->lOpts->ttl = 129 - ip_buf->ttl;		// Default TTL 128
				else if (ip_buf->ttl > 60) opt->lOpts->ttl = 65 - ip_buf->ttl;		// Default TTL 64
				else if (ip_buf->ttl > 32) opt->lOpts->ttl = 61 - ip_buf->ttl;		// Default TTL 60
				else if (ip_buf->ttl > 30) opt->lOpts->ttl = 33 - ip_buf->ttl;		// Default TTL 32
				else opt->lOpts->ttl = 31 - ip_buf->ttl;							// Default TTL 30
#ifdef DEBUG
				debugOut (PING, "%sReceived ICMP_ECHOREPLY from %s (%d  bytes) => TTL ~ %d\n", 
						debugBuf, inet_ntoa (src_addr.sin_addr), pkt_len, opt->lOpts->ttl);
#endif
				if (opt->lOpts->ttl > opt->gOpts->max_ttl) opt->lOpts->ttl = opt->gOpts->max_ttl;
				done = true;
			}
		} while (!done);
	}
	close (socketfd);
	
	if (done) return true;
	else return false;
}

/*! 
  \fn SnmpNode *testSnmp (struct in_addr addr, Options *opt)
  \brief This function tests if addr has SNMP enabled using each SNMP community in the list 
		
  \param addr Destination address
  \param opt Structure containing options values
  \return pointer to SnmpNode struct if success, NULL pointer if not
*/
SnmpNode *
testSnmp (struct in_addr addr, Options *opt)
{
	struct snmp_session session;	// SNMP session handler
	struct snmp_session *sptr;		// SNMP session handler pointer
	SnmpOpt options;				// SNMP options structure
	int forwarding;					// IP Forwarding value (1 -> ON, 2 -> OFF)
	ListEntry *community;			// SNMP community list element
	int socketfd;					// Socket file descriptor for incoming ICMP packets

 	options.dest = addr;	// Set SNMP destination option
	
	// Session setup
	snmp_sess_init (&session);							// Initializes a "session" that defines who we're going to talk to
	session.peername = strdup (inet_ntoa (addr));		// Set agent IP address
	session.version = SNMP_VERSION_1;					// Set authentication parameters for talking to the server
	session.retries = opt->gOpts->retriesSnmp;			// Set retries number
	session.timeout = opt->gOpts->timeoutSnmp * 1000;	// Set first timeout value for exponential backoff
	
    // Open the SNMP session
    if (!(options.session = snmp_sess_open (&session))) {
	        snmp_perror ("ack");
	        return NULL;
    }
	
	sptr = snmp_sess_session (options.session);		// Get snmp session pointer
	
	// Socket creation for ICMP incoming packets
	if ((socketfd = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {
		perror ("snmpclient: error in icmp socket creation");
		return NULL;
	}
	
	//	Test each comunity defined in the community list on the target address
	for (community = opt->gOpts->communitySNMP.head; community; community = community->next) {
		// Set community option
	    sptr->community = (unsigned char *) strdup (community->element);	// Set SNMP community name used for authentication
		sptr->community_len = strlen ((char *) community->element);			// Set SNMP community name length
	
#ifdef DEBUG
		debugOut (SNMPCLIENT, "Thread %02d - Testing community \"%s\" on %s\n", opt->lOpts->threadNum,
					community->element, session.peername);
#endif
		// Send the request for IP-MIB::ipForwarding
		options.oid = opt->gOpts->oids->ipForwarding;
		options.type = ASN_INTEGER;
		if (snmpGet (options, &forwarding))
		{	// We have a valid reply
			SnmpNode *info = (SnmpNode *) calloc (1, sizeof(SnmpNode));	// Snmp node pointer
			List vars;													// List to store queries results
			ListEntry *i;												// List entry pointer
			int result, k;

			// Store adderss, type and community into SnmpNode struct
			info->addr = addr;
			info->type = (forwarding == 1) ? ROUTER : HOST;
			info->SNMPCommunity = (u_char *) strdup ((char *) community->element);

#ifdef DEBUG
			debugOut (SNMPCLIENT, "Thread %02d - Found %s using community %s\n", opt->lOpts->threadNum, 
						info->type ? "Router" : "Host", info->SNMPCommunity);
#endif
			// Retrieve interfaces addresses (IP-MIB::ipAdEntAddr)
			sptr->timeout = 1000000;
			sptr->retries = 5;
			options.oid = opt->gOpts->oids->ipAdEntAddr;
			options.type = ASN_IPADDRESS;

			result = snmpGetNext (options, &vars);
#ifdef DEBUG
			debugOut (SNMPCLIENT, "Thread %02d - Interfaces address list: (%d)\n", opt->lOpts->threadNum, result);
#endif
			// Store interfaces into info structure
			info->skipIndex = -1;
			listInit (&info->interfaces);
			for (i = vars.head, k=0; i; i = i->next, k++) {
				struct in_addr *ipAddr = i->element;	// Current ip value

				// If interface is not 0.0.0.0
				if (ipAddr->s_addr != INADDR_ANY) {
					Interface *ifTmp = calloc (1, sizeof(Interface));	// Allocate dynamic space for the interface
					ifTmp->ip = *ipAddr;								// Set interface IP address
					listPush (&info->interfaces, ifTmp);				// Add interface to the list
#ifdef DEBUG
					debugOut (SNMPCLIENT, "Thread %02d - %s\n", opt->lOpts->threadNum, inet_ntoa(*ipAddr));
#endif
				}
				// Set 0.0.0.0 interface index
				else info->skipIndex = k;
			}
			listReset (&vars, true);
			
			// Close session and icmp socket
			snmp_sess_close (options.session);
			close (socketfd);
			return info;
		}

		// Receive ICMP messages to test if port 161 is closed
		do {
			struct sockaddr_in src_addr;			// Source address for incoming packets
			socklen_t lsock = sizeof(src_addr);		// Size of sockaddr struct
			struct timeval tv;						// Timeout value
			struct icmp *icmp_buf;					// ICMP header struct pointer
			struct iphdr *ip_buf;					// IP header struct pointer
			char pkt_buf[MAX_PACKET];				// Packet buffer
			int pkt_len;							// Packet length

			// ICMP socket timeout configuration
			tv.tv_sec = 0;		// seconds
			tv.tv_usec = 1000;	// micro-seconds
			setsockopt (socketfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));

			if ((pkt_len = recvfrom(socketfd, &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock)) < 0)
			{
				// ICMP_TIMEOUT
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread %02d - Received ICMP_TIMEOUT\n", opt->lOpts->threadNum);
#endif
				break;
			}

			ip_buf = (struct iphdr *) &pkt_buf[IP_SIZE + 8];	// IP header appended to ICMP packet
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		// ICMP header
					
			// ICMP_DEST_UNREACH reply to Packet directed to current destination IP
			if (icmp_buf->icmp_type == ICMP_DEST_UNREACH && ip_buf->daddr == addr.s_addr)
			{
				if (ip_buf->ttl > 0)
					opt->lOpts->ttl = opt->gOpts->default_ttl - ip_buf->ttl + 1;	// Calculate dest distance in hops
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread %02d - Received ICMP_DEST_UNREACH from %s (%d  bytes)\n",
						opt->lOpts->threadNum, inet_ntoa (src_addr.sin_addr), pkt_len);
				debugOut (SNMPCLIENT, "Thread %02d - SNMP inactive on %s => TTL = %d\n",
					opt->lOpts->threadNum, session.peername, opt->lOpts->ttl);
#endif
				// Close session and icmp socket
				snmp_sess_close (options.session);
				close (socketfd);
				return NULL;
			}
		} while (true);
	}

	// Close session and icmp socket
	snmp_sess_close (options.session);
	close (socketfd);
	free (session.peername);
	return NULL;
}

/*! 
  \fn NetNode *snmpclient (SnmpNode *node, GlobalOptions *gOpts, u_int16_t *nodeCount)

  \brief This function executes some SNMP queries to obtain needed information about node
		
  \param node Pointer to structure containing node's address, type and community
  \param gOpts Pointer to structure containing options values
  \param nodeCount Pointer to global counter used to assign unique node names
  \return a pointer to a new NetNode structure containing obtained information
*/
NetNode *
snmpclient (SnmpNode *node, GlobalOptions *gOpts, u_int16_t *nodeCount)
{
	struct snmp_session session;					// SNMP session handler
	SnmpOpt options;								// SNMP options structure
	List vars;										// List to store queries results
	List ifs;										// List to store interfaces indexes
	struct in_addr ip;								// SnmpGet returned IP address
	unsigned int value;								// SnmpGet returned INT value
	int result;										// SnmpGet and snmpGetNext return value
	int skipIndex = -1;								// Index of the 0.0.0.0 interface if present
	ListEntry *current;								// List entry pointer
	Interface *ifTmp;								// Temporary interface pointer
	ListEntry *i, *j;								// List iterators
	struct hostent *host;							// Hostname structure pointer
	int k;
	NetNode *info = calloc (1, sizeof(NetNode));	// New node memory location pointer

 	options.dest = node->addr;	// Set SNMP destination option
	
	// Session setup
	snmp_sess_init (&session);								// Initializes a "session" that defines who we're going to talk to
	session.peername = strdup (inet_ntoa (node->addr));		// Set agent IP address
	session.version = SNMP_VERSION_1;						// Set authentication parameters for talking to the server
	session.retries = 5;									// Set retries number
	session.timeout = 1000000;								// Set first timeout value for exponential backoff

	// Set community option
	session.community = node->SNMPCommunity;						// Set SNMP community name used for authentication
	session.community_len = strlen ((char *) session.community);	// Set SNMP community name length

    // Open the SNMP session
    if (!(options.session = snmp_sess_open (&session))) {
        snmp_perror ("ack");
        return NULL;
    }
	
#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - SNMP agent: %s\n", inet_ntoa (node->addr));
	debugOut (SNMPCLIENT, "Thread Manager - Node type: %s\n", node->type ? "ROUTER" : "HOST");
#endif
	
	// Store node type, community and interface list into info structure
	info->type = node->type;
	info->SNMPCommunity = node->SNMPCommunity;
	info->interfaces = node->interfaces;
	skipIndex = node->skipIndex;
	
	// Execute dns query if dns resolution is enabled
	if (gOpts->dns) host = gethostbyaddr ((char *) &node->addr.s_addr, sizeof(node->addr.s_addr), AF_INET);
	else host = NULL;
	
	if (host) {
		info->name = calloc (strlen(host->h_name)+1, sizeof(char));
		strncpy (info->name, host->h_name, strlen(host->h_name));
	}
	// Default node naming
	else {
		info->name = calloc (7, sizeof(char));
		sprintf (info->name, "Dev%d", *nodeCount);
		*nodeCount += 1;
	}
	printf ("."); fflush (stdout);	// CONSOLE OUTPUT

	// Retrieve default gateway (RFC1213-MIB::ipRouteDest.0.0.0.0)
	options.oid = gOpts->oids->defaultGw;
	options.type = ASN_IPADDRESS;
	result = snmpGet (options, &ip);

	// Store default gateway into info structure
	if (result > 0) info->defaultGw = ip;
#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - Default Gateway (%d): %s\n", result, inet_ntoa(info->defaultGw));
#endif

	printf ("."); fflush (stdout);	// CONSOLE OUTPUT
	
	// Retrieve interfaces index (IP-MIB::ipAdEntIfIndex)
	options.oid = gOpts->oids->ipAdEntIfIndex;
	options.type = ASN_INTEGER;

	result = snmpGetNext (options, &ifs);

	// Retrieve interfaces speed (IF-MIB::ifSpeed)
#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - Interfaces speed list: (%d)\n", ifs.size);
#endif
	options.type = ASN_GAUGE;
	options.oid = (char *) malloc (MAX_OID_LEN);
	current = info->interfaces.head;
	for (i = ifs.head, k=0; i; i = i->next, k++) {
		unsigned int *intValue = i->element;	// Current int value

		// If interface is not 0.0.0.0
		if (k != skipIndex) {
			sprintf(options.oid, "%s.%d", gOpts->oids->ifSpeed, *intValue);
			result = snmpGet (options, &value);

#ifdef DEBUG
			debugOut (SNMPCLIENT, "Thread Manager - %u (%d)\n", value, *intValue);
#endif
			// Store speeds into info structure
			ifTmp = current->element;
			ifTmp->speed = value;
			current = current->next;
		}
	}
	free (options.oid);
	
	printf ("."); fflush (stdout);	// CONSOLE OUTPUT

	// Retrieve interfaces netmasks (IP-MIB::ipAdEntNetMask)
	options.oid = gOpts->oids->ipAdEntNetMask;
	options.type = ASN_IPADDRESS;

	result = snmpGetNext (options, &vars);

#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - Interfaces netmask list: (%d)\n", result);
#endif
	// Store netmasks into info structure
	for (i = vars.head, k=0, current = info->interfaces.head; i; i = i->next, k++) {
		struct in_addr *ipAddr = i->element;	// Current ip value

		if (k != skipIndex) {
			ifTmp = current->element;
			ifTmp->mask = *ipAddr;
#ifdef DEBUG
			debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(ifTmp->mask));
#endif
			current = current->next;
		}
	}
	listReset (&vars, true);
	
	printf ("."); fflush (stdout);	// CONSOLE OUTPUT

	// Retrieve interfaces ARP tables (IP-MIB::ipAdEntNetMask)
	if (gOpts->arp) {
#ifdef DEBUG
		debugOut (SNMPCLIENT, "Thread Manager - Interfaces ARP tables: (%d)\n", ifs.size);
#endif
		options.type = ASN_IPADDRESS;
		options.oid = (char *) malloc (MAX_OID_LEN);
		current = info->interfaces.head;
		for (i = ifs.head, k=0; i; i = i->next, k++) {
			unsigned int *intValue = i->element;	// Current int value

			// If interface is not 0.0.0.0
			if (k != skipIndex) {
				ArpTableRow *rowTmp;	// ARP table row pointer

				sprintf(options.oid, "%s.%d", gOpts->oids->ipNetToMediaNetAddress, *intValue);
				result = snmpGetNext (options, &vars);
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread Manager - Interface #%d (%u)\n", *intValue, result);
#endif
				// Store IPs into info structure
				ifTmp = current->element;
				listInit (&ifTmp->arpTable);

				// Store rows into ARP table
				for (j = vars.head; j; j = j->next) {
					struct in_addr *ipAddr = j->element;	// Current ip value

					rowTmp = (ArpTableRow *) calloc (1, sizeof(ArpTableRow));	// Allocates dynamic space for the row
					rowTmp->ip = *ipAddr;										// Sets row IP address
					listPush (&ifTmp->arpTable, rowTmp);						// Inserts row in the table
#ifdef DEBUG
					debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(*ipAddr));
#endif
				}
				listReset(&vars, true);
				current = current->next;
			}
		}
		free (options.oid);
	}
	
	printf ("."); fflush (stdout);	// CONSOLE OUTPUT

	// Retrieve route destinations (RFC1213-MIB::ipRouteDest)
	options.oid = gOpts->oids->ipRouteDest;
	options.type = ASN_IPADDRESS;
	result = snmpGetNext (options, &vars);
#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - Route destinations: (%d)\n", result);
#endif

	// RFC1213-MIB present
	if (result > 0) {
		bool *direct = (bool *) calloc (result, sizeof(bool));	// Is each subnet in list directly connected?
		Subnet *subnetTmp;										// Subnet pointer
		int m, n;

		listInit (&info->nonDirectSubnets);		// Setup non-direct subnet list
		skipIndex = -1;							// Reset the skip index

		// Store subnets address into info structure
		for (i = vars.head, m=0, k=0; i; i = i->next, k++) {
			bool found = false;						// Have I found an interface belonging to this sunbnet?
			struct in_addr *ipAddr = i->element;	// Current ip value

			// If subnet is not 0.0.0.0
			if (ipAddr->s_addr != INADDR_ANY) {
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(*ipAddr));
#endif
				// Compares each subnet with interfaces retrieved before
				for (current = info->interfaces.head, n=0; current && !found; current = current->next, n++) {
					ifTmp = current->element;
					// If the interface belongs to the current subnet
					if ((ifTmp->ip.s_addr & ifTmp->mask.s_addr) == ipAddr->s_addr) {
						direct[k] = true;
						found = true;
					}
				}
				// The subnet is non-direct
				if (!found) {
					direct[k] = false;
					subnetTmp = (Subnet *) malloc (sizeof(Subnet));		// Allocate dynamic space for the subnet
					subnetTmp->netId = *ipAddr;
					subnetTmp->type = EXACT;
					listPush(&info->nonDirectSubnets, subnetTmp);		// Add subnet to the list
				}
			}
			else skipIndex = k;
		}
		listReset(&vars, true);

		printf ("."); fflush (stdout);	// CONSOLE OUTPUT
		
		// Retrieve subnets netmask (RFC1213-MIB::ipRouteMask)
		options.oid = gOpts->oids->ipRouteMask;
		options.type = ASN_IPADDRESS;
		result = snmpGetNext (options, &vars);
#ifdef DEBUG
		debugOut (SNMPCLIENT, "Thread Manager - Route destinations netmasks: (%d)\n", result);
#endif

		// Store subnets netmasks into info structure
		current = info->nonDirectSubnets.head;
		for (i = vars.head, k=0; i; i = i->next, k++) {
			struct in_addr *ipAddr = i->element;	// Current ip value

			if (k != skipIndex) {
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(*ipAddr));
#endif
				// The subnet is non-direct -> Store information in non-direct list
				if (!direct[k] && current) {
					subnetTmp = current->element;
					subnetTmp->netMask = shortMask(*ipAddr);
					current = current->next;
				}
			}
		}
		listReset (&vars, true);

		printf ("."); fflush (stdout);	// CONSOLE OUTPUT
		
		// Retrieve subnets next-hops (RFC1213-MIB::ipRouteNextHop)
		options.oid = gOpts->oids->ipRouteNextHop;
		options.type = ASN_IPADDRESS;
		result = snmpGetNext (options, &vars);
#ifdef DEBUG
		debugOut (SNMPCLIENT, "Thread Manager - Route destinations next-hops: (%d)\n", result);
#endif
		listInit (&info->nextHops);		// Setup next hops list

		// Store subnets next-hops into info structure
		current = info->nonDirectSubnets.head;
		for (i = vars.head, k=0, m=0; i; i = i->next, k++) {
			struct in_addr *ipAddr = i->element;	// Current ip value

			if (k != skipIndex) {
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(*ipAddr));
#endif
				// The subnet is non-direct -> Store information in non-direct list
				if (!direct[k]) {
					if (current) {
						subnetTmp = current->element;
						subnetTmp->nextHop = *ipAddr;
						if (ipAddr->s_addr != INADDR_ANY && !listSearch(&info->nextHops, ipAddr, (void *) ipCmp)) {
							listPush (&info->nextHops, &subnetTmp->nextHop);
						}
						current = current->next;
					}
				}
			}
		}
		listReset (&vars, true);
		listReset (&ifs, true);
	}

	// Close session
	snmp_sess_close (options.session);
	free (session.peername);

	return info;
}

/*! 
  \fn struct in_addr icmpMask (struct in_addr addr, Options *opt);
  \brief This Function sends an ICMP_MASK_REQUEST to addr and returns the mask obtained or 0.0.0.0.

  \param addr Destination address
  \param opt Structure containing options values
  \return Returns the resulting netmask or 0.0.0.0
*/
struct in_addr 
icmpMask (struct in_addr addr, Options *opt)
{
	int socketfd;						// socket file descriptor
	char pkt_buf[MAX_PACKET];			// packet buffer
	struct sockaddr_in dst_addr;		// destination address
	struct sockaddr_in src_addr;		// source address for incoming packets
	struct icmp *icmp_buf;				// ICMP header struct pointer
	struct timeval tv;					// timeout value
	u_int8_t retry = 0;					// retries counter
	struct in_addr mask = {INADDR_ANY};	// netmask acquired
	bool done = false;

#ifdef DEBUG
	char debugBuf[50];
	debugOut (MASK, "Thread %02d - Icmp Mask destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif
	
	// destination address configuration
	dst_addr.sin_family = AF_INET;
	dst_addr.sin_addr.s_addr = addr.s_addr;
	
	// socket creation for ICMP
	if ((socketfd = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {
		perror ("icmpMask: error in socket creation");
		return mask;
	}
	
	// ICMP socket timeout configuration
	tv.tv_sec = opt->gOpts->timeout / 1000;				// seconds
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	// micro-seconds
	setsockopt (socketfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));
	
	while (retry <= opt->gOpts->retries && !done) {
		// ICMP packet construction 
		icmp_buf = (struct icmp *) pkt_buf;
		icmp_buf->icmp_type = ICMP_ADDRESS;
		icmp_buf->icmp_code = 0;
		icmp_buf->icmp_id = getpid ();
		icmp_buf->icmp_seq = 0;
		icmp_buf->icmp_cksum = 0;
		icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
		
		// sending ICMP packet
		if (sendto(socketfd, icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
			perror ("icmpMask: error in sendto");
			close (socketfd);
			return mask;
		}
#ifdef DEBUG
		sprintf (debugBuf, "Thread %02d - Sent ICMP-> ", opt->lOpts->threadNum);
#endif
	
		// receive ICMP messages
		do {
			socklen_t lsock = sizeof(dst_addr);	// size of sockaddr struct
			int pkt_len;
					
			if ((pkt_len = recvfrom(socketfd, &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock)) < 0)
			{
				// ICMP_TIMEOUT
#ifdef DEBUG
				debugOut (MASK, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				retry++;
				break;
			}
			
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		// ICMP header
					
			// ICMP_ECHOREPLY from destination
			if (icmp_buf->icmp_type == ICMP_ADDRESSREPLY && src_addr.sin_addr.s_addr == addr.s_addr)
			{
				mask.s_addr = icmp_buf->icmp_mask;
#ifdef DEBUG
				debugOut (MASK, "%sReceived ICMP_ADDRESSREPLY (%s)", debugBuf, inet_ntoa(mask));
				debugOut (MASK, " from %s (%d  bytes)\n", inet_ntoa (src_addr.sin_addr), pkt_len);
#endif
				done = true;
			}
		} while (!done);
	}
	close (socketfd);
	
	return mask;
}

/*! 
  \fn void *scanner (void *arg)
  \brief This function implements the generic scanner thread that acquires information on the network

  \param arg Pointer to thread parameters
*/
void *
scanner (void *arg)
{
	struct ThreadParam *params = (struct ThreadParam *) arg;	// Pointer to parameters struct
	LocalOptions lOpt;											// Local thread options
	Options opt = {params->gOpts, &lOpt};						// Generic options
	Path *btPath = (Path *) malloc (sizeof(Path));				// Path returned by backtrace
	Path *rrPath = (Path *) malloc (sizeof(Path));				// Path returned by pingRR
	ListEntry *current;											// Generic list element pointer

	pthread_mutex_lock (&mutex_params);
	lOpt.threadNum = params->threadNum++;			// Acquire thread number for debugging purpose
	lOpt.params = params;
	pthread_mutex_unlock (&mutex_params);

#ifdef DEBUG
	debugOut (SCANNER, "Thread %02d - Ready!\n", lOpt.threadNum);
#endif

	// --------------- Scan phase ----------------- //
 	while (true) {
		struct in_addr addr;	// Current ip address
		IpRange *range;			// Current range
		bool visited = false;	// Has current addess been yet visited using SNMP?
		
		pthread_mutex_lock (&mutex_options);
		// Get address from ranges
		if (!params->gOpts->rangesIP.empty) {
			// Read first address
			range = params->gOpts->rangesIP.head->element;
			addr = range->startAddr;
		
			if (--range->numAddr == 0) listPop (&params->gOpts->rangesIP);
			else range->startAddr.s_addr = htonl (ntohl (range->startAddr.s_addr) + 1);
			pthread_mutex_unlock (&mutex_options);
		}
		else {
			pthread_mutex_unlock (&mutex_options);
			break;		// End scan phase
		}

		// Test if address has been visited before
		for (current = params->visited->head; current; current = current->next) {
			struct in_addr *addrTmp = current->element;		// Current ip address
			
			if (addr.s_addr == addrTmp->s_addr) 
			{	// Address was visited before
				visited = true;
#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - Interface %s already visited\n", lOpt.threadNum, inet_ntoa (addr));
#endif
				break;
			}	
		}
		if (visited) continue;

#ifdef DEBUG
		debugOut (SCANNER, "Thread %02d - Scanning %s\n", lOpt.threadNum, inet_ntoa(addr));
#endif

		// Send PING to current ip address
		if (ping (addr, &opt)) 
		{	// Node is active
			SnmpNode *info;		// Snmpnode pointer
#ifdef DEBUG
			debugOut (SCANNER, "Thread %02d - Node %s active\n", lOpt.threadNum, inet_ntoa(addr));
#endif
			// Test SNMP support
			if ((info = testSnmp (addr, &opt))) 
			{	// SNMP is enabled
				bool already_visited = false;
				
				pthread_mutex_lock (&mutex_params);
				// For each interface
				for (current = info->interfaces.head; current; current = current->next) {
					Interface *ifTmp = current->element;		// Current interface pointer
					
					// Skip local and any interfaces
					if (ifTmp->ip.s_addr == INADDR_ANY || *((u_int8_t *)&ifTmp->ip.s_addr) == 127) continue;
					
					// Add interface to visited list if not yet added from another thread
					if (!listSearch (params->visited, &ifTmp->ip, (void *) ipCmp)) 
						listPush (params->visited, &ifTmp->ip);
					else {
						already_visited = true;
						break;
					}
				}
				
				// Add SnmpNode to snmp list
				if (!already_visited) listPush (params->snmpList, info);
				pthread_mutex_unlock (&mutex_params);
				
				// CONSOLE OUTPUT
				if (params->gOpts->verbose) printf ("Thread %02d - SNMP enabled on %s\n", lOpt.threadNum, inet_ntoa(addr));
				else printf ("*");
				fflush (stdout);
#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - SNMP enabled on %s\n", lOpt.threadNum, inet_ntoa(addr));
#endif
			}
			else 
			{	// SNMP is not enabled => Active mode
				TraceState btResult;	// Backtrace return status
				int prrResult;			// PingRR return status
				bool mask = false;		// icmpMask successful result
				IcmpRow *row; 			// Temporary row pointer
				int i;					// Iteration variable

				// If not already present, allocate current destination IcmpTable row and add it to table
				if (!(row = listSearch (params->icmpTab, &addr, (void *) icmpRowCmp))) {
					row = (IcmpRow *) calloc (1, sizeof(IcmpRow));
					row->ipAddr = addr;
					row->dest = addr;
					pthread_mutex_lock (&mutex_icmpTab);
					listPush (params->icmpTab, row);
					pthread_mutex_unlock (&mutex_icmpTab);
				}

				// Get destination netmask
				row->netMask = icmpMask(addr, &opt);
				if (row->netMask.s_addr) mask = true;
#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - Mask %s\n", lOpt.threadNum, inet_ntoa(row->netMask));
#endif

				// Execute backtrace
				btResult = backtrace (addr, &opt, params->icmpTab, btPath);
#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - BackTrace to %s - Result %d - Hops %d - Offset %d\n",
					lOpt.threadNum, inet_ntoa(addr), btResult, btPath->length, btPath->offset);
#endif
				// Complete IcmpTab informations from backtrace data
				if (btResult >= 0) {
					// Add prec e next hops to new icmpTable elements
					pthread_mutex_lock (&mutex_icmpTab);
					for(i=btPath->length-1; i>=btPath->offset; i--) {
						if (btPath->array[i].s_addr != INADDR_ANY) {
							if (i > btPath->offset) btPath->newRows[i]->precHop = btPath->newRows[i-1];
							if (i != btPath->length - 1) btPath->newRows[i]->nextHop = btPath->newRows[i+1];
						}
					}
					// If was found an early alias fill in its precHop pointer
					if (row->alias.s_addr != INADDR_ANY)
						btPath->aliasRow->precHop = row->precHop;

					pthread_mutex_unlock (&mutex_icmpTab);
				}

				// Execute ping record route
				prrResult = pingrr (addr, &opt, rrPath);

#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - PingRR to %s - Result %d - Hops %d\n",
					lOpt.threadNum, inet_ntoa(addr), prrResult, rrPath->length);
#endif

				// Complete IcmpTab informations from PingRR data
				if (prrResult > 0) {
					// Test if each address in the path is present in icmpTab
					for(i=rrPath->length-1; i>=0; i--) {
						IcmpRow *rowTmp;

						// If processing destination row
						if (i == rrPath->length-1) {
							// Set destination row as current row
							rowTmp = row;
							
							// Set RR early detected alias when destination address is different
							if (prrResult == 2) row->aliasRR = rrPath->array[rrPath->length-1];

							// Set RR early detected alias when there are 2 different hops in the same router
							else if (rrPath->length < NROUTES-1 && rrPath->array[i+1].s_addr != addr.s_addr &&
								rrPath->array[i].s_addr != rrPath->array[i+1].s_addr)
								row->aliasRR = rrPath->array[rrPath->length];
						}
						else rowTmp = listSearch (params->icmpTab, &rrPath->array[i], (void *) icmpRowCmp);
						
						// Control if current hop was discovered before
						if (rowTmp) {
							pthread_mutex_lock (&mutex_icmpTab);
							// Refresh accuracy value if necessary
							if (rowTmp->accuracy == TRACEROUTE) {
								rowTmp->accuracy = BOTH;
							}
							rrPath->newRows[i] = rowTmp;	// Save row memory address
							if (i < rrPath->length-1) rowTmp->router = true;
							if (!rowTmp->hop) rowTmp->hop = i + 1;
							pthread_mutex_unlock (&mutex_icmpTab);
						}

						// If not found insert hop in IcmpTab
						else if (rrPath->array[i].s_addr != INADDR_ANY) {
							// Allocate row dynamic space
							rowTmp = (IcmpRow *) calloc (1, sizeof(IcmpRow));
			
							// Insert new row data
							rowTmp->ipAddr = rrPath->array[i];
							rowTmp->dest = addr;
							rowTmp->hop = i + 1;
							rowTmp->accuracy = RECORDROUTE;
							
							if (i < rrPath->length-1) rowTmp->router = true;

							rrPath->newRows[i] = rowTmp;	// Save row memory address
			
							// Add row to IcmpTab
							pthread_mutex_lock (&mutex_icmpTab);
							listPush (params->icmpTab, rowTmp);
							pthread_mutex_unlock (&mutex_icmpTab);
						}
					}

					// Add prec e next hops RR to new icmpTable elements
					pthread_mutex_lock (&mutex_icmpTab);
					for(i=rrPath->length-1; i>=0; i--) {
						if (rrPath->array[i].s_addr != INADDR_ANY) {
							if (i > 0) rrPath->newRows[i]->precHopRR = rrPath->newRows[i-1];
							if (i != rrPath->length - 1) 
								rrPath->newRows[i]->nextHopRR = rrPath->newRows[i+1];
						}
					}
					pthread_mutex_unlock (&mutex_icmpTab);
				}

				// Free temporary memory used
				free(btPath->array);
				free(btPath->newRows);
				free(rrPath->array);
				free(rrPath->newRows);

				// CONSOLE OUTPUT
				if (params->gOpts->verbose) {
					printf ("Thread %02d - ICMP info acquired (", lOpt.threadNum);
					if (btResult) printf("BT");
					if (prrResult) printf(" PRR");
					if (mask) printf(" MASK");
					printf(") on %s\n", inet_ntoa(addr));
				}
				else printf ("+");
				fflush (stdout);
			}
		}
		// CONSOLE OUTPUT
		else if (!params->gOpts->verbose) { printf ("."); fflush (stdout); }
#ifdef DEBUG
		debugOut (SCANNER, "Thread %02d - Done %s\n", lOpt.threadNum, inet_ntoa(addr));
#endif
	}

	pthread_mutex_lock (&mutex_sync);
	// CONSOLE OUTPUT
	if (params->gOpts->verbose) printf ("Thread %02d - Waiting for DNS resolution (%d)\n", lOpt.threadNum, params->sync);
	else printf ("#");
	fflush (stdout);
	
	// Decrement sync counter to synchronize with thread manager
	if (--params->sync == 0) sem_post (params->scanSem);
	pthread_mutex_unlock (&mutex_sync);

	// Wait thread manager signal to start
	sem_wait (params->scannerSemA);
	sem_post (params->scannerSemA);
	
	// --------------- DNS phase ----------------- //
	if (params->gOpts->dns) {
		// IcmpTab rows DNS resolving
		if (!params->icmpTab->empty) {
			while (true) {
				IcmpRow *row;			// Current row pointer
				struct hostent *host;	// Host struct pointer
		
				pthread_mutex_lock (&mutex_params);
				if (params->currRow) {
					// Get current row
					row = params->currRow->element;
					params->currRow = params->currRow->next;
					pthread_mutex_unlock (&mutex_params);
				}
				else {
					pthread_mutex_unlock (&mutex_params);
					break;	// end dns phase
				}
	
				// Execute dns query
				host = gethostbyaddr ((char *) &row->ipAddr.s_addr, sizeof(row->ipAddr.s_addr), AF_INET);
				if (host) 
				{	// We have an hostname
					row->ipDNS = calloc (strlen(host->h_name)+1, sizeof(char));
					strncpy (row->ipDNS, host->h_name, strlen(host->h_name));
				
					// CONSOLE OUTPUT
					if (params->gOpts->verbose)
						printf ("Thread %02d - DNS => %s = %s\n", lOpt.threadNum, inet_ntoa(row->ipAddr), row->ipDNS);
					else printf ("@");
					fflush (stdout);
				}
			}
		}
	}	
	
	pthread_mutex_lock (&mutex_sync);
	// CONSOLE OUTPUT
	if (params->gOpts->verbose)
		printf ("Thread %02d - Waiting for Alias resolution phase 1 (%d)\n", lOpt.threadNum, params->sync);
	else { printf ("#"); fflush (stdout); }
		
	// Decrement sync counter to synchronize with thread manager
	if (--params->sync == 0) sem_post (params->scanSem);
	pthread_mutex_unlock (&mutex_sync);

	// Wait thread manager signal to start
	sem_wait (params->scannerSemB);
	sem_post (params->scannerSemB);

	// --------------- Alias resolution phase 1 ----------------- //
	if (params->icmpTab->size >= 2) {
		while (true) {
			IcmpRow *row1;					// Current first row pointer
			AliasState allyResult = NONE;	// Alias result state

			pthread_mutex_lock (&mutex_params);
			if (params->currRow->next) {
				// Get current first row
				row1 = params->currRow->element;
				current = params->currRow->next;
				params->currRow = params->currRow->next;
				pthread_mutex_unlock (&mutex_params);
			}
			else {
				pthread_mutex_unlock (&mutex_params);
				break;		// End alias phase 1
			}

			// Execute Aliasing
			if (row1->router) {
				// CONSOLE OUTPUT
				if (params->gOpts->verbose)
					printf ("Thread %02d - Aliasing %s (phase 1)\n", lOpt.threadNum, inet_ntoa(row1->ipAddr));
				else printf ("§");
				fflush (stdout);

				for (; current; current = current->next) {
					IcmpRow *row2 = current->element;	// Current second row pointer
					
					if (row2->router) {
						if (row1->assNode == NULL || row2->assNode == NULL) 
						{	// Rows are both not associated to any router
							RowCouple couple = {row1, row2};	// Current row couple
							AliasState result;					// Alias result state
							bool alias;							// Are first and second rows alias?

							// Test ally prevention rules
							result = allyPrevention (&lOpt, row1, row2);

							// Execute ally algorithm 			##BOOKMARK##
							if (allyResult != TIMEOUT1) allyResult = NONE;
							if (result == NONE && allyResult != TIMEOUT1) {
								allyResult = ally (&opt, row1->ipAddr, row2->ipAddr);
#ifdef DEBUG
								debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
								debugOutNoTime (ALIAS, " %s) are %s alias (Ally%s)\n", inet_ntoa(row2->ipAddr),
												allyResult == ALIASES ? "" : "not", allyResult > 1 ? "" : " sure");
#endif
							}
#ifdef DEBUG
							if (allyResult == TIMEOUT1) {
								debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
								debugOutNoTime (ALIAS, " %s) are not alias (Ally Timeout1)\n", inet_ntoa(row2->ipAddr));
							}
#endif
														
							if (result == ALIASES || allyResult == ALIASES) alias = true;
							else alias = false;

							// Add interfaces to topology routers
							if (alias) {
								pthread_mutex_lock (&mutex_topology);
								alias2Routers (params, &couple);
								pthread_mutex_unlock (&mutex_topology);
							}
						}
#ifdef DEBUG
						else {
							debugOut (COUPLES, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
							debugOutNoTime (COUPLES, " %s) skipped (both associated)\n", inet_ntoa(row2->ipAddr));
						}
#endif
					}
#ifdef DEBUG
					else {
						debugOut (COUPLES, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
						debugOutNoTime (COUPLES, " %s) skipped (non router)\n", inet_ntoa(row2->ipAddr));
					}
#endif
				}
			}
		}
	}
	
	pthread_mutex_lock (&mutex_sync);
	// CONSOLE OUTPUT
	if (params->gOpts->verbose)
		printf ("Thread %02d - Waiting for Alias resolution phase 2 (%d)\n", lOpt.threadNum, params->sync);
	else printf ("#");
	fflush(stdout);

	// Decrement sync counter to synchronize with thread manager
	if (--params->sync == 0) sem_post (params->scanSem);
	pthread_mutex_unlock (&mutex_sync);

	// Wait thread manager signal to start
	sem_wait (params->scannerSemA);
	sem_post (params->scannerSemA);
	
	// --------------- Alias resolution phase 2 ----------------- //
	if (params->icmpTab->size >= 2) {
		while (true) {
			IcmpRow *row1;					// Current first row pointer
			AliasState allyResult = NONE;	// Alias result state

			pthread_mutex_lock (&mutex_params);
			if (params->currRow) {
				// Get current first row
				row1 = params->currRow->element;
				params->currRow = params->currRow->next;
				pthread_mutex_unlock (&mutex_params);
			}
			else {
				pthread_mutex_unlock (&mutex_params);
				break;		// End alias resolution phase 2
			}
			
			// Execute aliasing
			if (!row1->assNode) {
				// CONSOLE OUTPUT
				if (params->gOpts->verbose)
					printf ("Thread %02d - Aliasing %s (phase 2)\n", lOpt.threadNum, inet_ntoa(row1->ipAddr));
				else printf ("§");
				fflush(stdout);

				// Pick up first interface of each (non SNMP) router
				for (current = params->topology->routers.head; current; current = current->next) 
				{	// For each discovered router
					NetNode *node = current->element;					// Current router pointer
					Interface *ifTmp = node->interfaces.head->element;	// First node interface pointer
					IcmpRow *row2;										// Current second row pointer

					if (node->type == ROUTER && !node->SNMPCommunity) {
						RowCouple couple = {row1, row2};	// Current row couple
						AliasState result;					// Alias result state
						bool alias;							// Are first and second rows alias?
							
						row2 = listSearch (params->icmpTab, &ifTmp->ip, (void *) icmpRowCmp);

						// Skip dummy alias couple
						if (row1 == row2) continue;

						// Test ally prevention rules
						result = allyPrevention (&lOpt, row1, row2);

						// Execute ally algorithm
						if (allyResult != TIMEOUT1) allyResult = NONE;
						if (result == NONE && allyResult != TIMEOUT1) {
							allyResult = ally (&opt, row1->ipAddr, row2->ipAddr);
#ifdef DEBUG
							debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
							debugOutNoTime (ALIAS, " %s) are %s alias (Ally%s)\n", inet_ntoa(row2->ipAddr),
											allyResult == ALIASES ? "" : "not", allyResult > 1 ? "" : " sure");
#endif
						}
#ifdef DEBUG
						if (allyResult == TIMEOUT1) {
							debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
							debugOutNoTime (ALIAS, " %s) are not alias (Ally Timeout1)\n", inet_ntoa(row2->ipAddr));
						}
#endif
						
						if (result == ALIASES || allyResult == ALIASES) alias = true;
						else alias = false;
						
						// Add interfaces to topology routers
						if (alias) {
							pthread_mutex_lock (&mutex_topology);
							couple.second = row2;
							alias2Routers (params, &couple);
							pthread_mutex_unlock (&mutex_topology);
						}
					}
#ifdef DEBUG
					else {
						debugOut (COUPLES, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
						debugOutNoTime (COUPLES, " %s) skipped (not router or Snmp)\n", node->name);
					}
#endif
				}
			}
		}
	}

	// CONSOLE OUTPUT
	if (params->gOpts->verbose)
		printf ("Thread %02d - Terminating execution\n", lOpt.threadNum);
	else printf ("X");
	fflush(stdout);

#ifdef DEBUG
	debugOut (SCANNER, "Thread %02d - Terminating execution\n", lOpt.threadNum);
#endif
	free(btPath);
	free(rrPath);
	return NULL;
}

/*! 
  \fn int scan (ThreadParam *params)
  \brief This Function manages threads during the analysis of the network and executes some non threaded operations.

  \param params Parameters nedeed by scanner threads
  \return Return an exit status code
*/
int
scan (ThreadParam *params)
{
	pthread_t *threadIds; 	// Thread Ids array
	ListEntry *current;		// Generic list entry pointer
	int j;

	// Allocate dynamic memory
	threadIds = (pthread_t *) calloc (params->gOpts->threads, sizeof(pthread_t));
	params->gOpts->oids = (OidVars *) malloc (sizeof(OidVars));
	params->visited = (List *) malloc (sizeof(List));
	params->snmpList = (List *) malloc (sizeof(List));
	params->scanSem = (sem_t *) malloc (sizeof(sem_t));
	params->scannerSemA = (sem_t *) malloc (sizeof(sem_t));
	params->scannerSemB = (sem_t *) malloc (sizeof(sem_t));
	
	snmpSetup (params->gOpts->oids);				// Initialize the SNMP library
	params->gOpts->default_ttl = getDefaultTTL();	// Get default TTL value
	listInit (params->visited);						// Initialize visited list
	listInit (params->snmpList);					// Initialize snmp list
	listInit (params->icmpTab);						// Initialize icmpTab list
	listInit (&params->topology->routers);			// Initialize topology nodes list
	listInit (&params->topology->links);			// Initialize topology links list
	listInit (&params->topology->subnets);			// Initialize topology subnets list

	// Initialize Semaphores
	sem_init (params->scanSem, 0, 0);
	sem_init(params->scannerSemA, 0, 0);
	sem_init(params->scannerSemB, 0, 0);
	
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting Scanner threads (%d)\n", params->gOpts->threads);
#endif
	// Generate Scanner threads
	params->threadNum = 0;					// Reset thread counter
	params->nodeCount = 0;					// Reset node counter
	params->sync = params->gOpts->threads;	// Set Synchronization counter
	for(j=0; j<params->gOpts->threads; j++)
		pthread_create (&threadIds[j], NULL, scanner, params);

	// CONSOLE OUTPUT
	printf ("Thread Manager - Starting Scan process\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting scan process\n");
#endif
	
	// Wait on scanSem while Scan finish
	while (params->sync > 0) sem_wait (params->scanSem);

	// CONSOLE OUTPUT
	if (!params->gOpts->verbose) printf ("\n");
	printf ("Thread Manager - Starting SNMP queries on SNMP enabled nodes\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting SNMP queries on SNMP enabled nodes\n");
#endif
	
	// Start exploration of SNMP enabled nodes
	for (current = params->snmpList->head; current; current = current->next) {
		SnmpNode *node = current->element;
		NetNode *info;
		ListEntry *curr;
		
		// CONSOLE OUTPUT
		printf ("Thread Manager - SNMP Agent %s: ", inet_ntoa (node->addr));
		fflush (stdout);
		
		// Get information from node
		info = snmpclient (node, params->gOpts, &params->nodeCount);
		
		// Store node information into topology if is a router
		if (info->type == ROUTER) listPush (&params->topology->routers, info);
		
		// For each interface
		for (curr = info->interfaces.head; curr; curr = curr->next) {
			Interface *ifTmp = curr->element;		// Current interface pointer
			
			// Skip local and any interfaces
			if (ifTmp->ip.s_addr == INADDR_ANY || *((u_int8_t *)&ifTmp->ip.s_addr) == 127) continue;
			
			// Add a row in IcmpTab pointing to that node
			if (info->type == HOST) {
				IcmpRow *row = calloc (1, sizeof(IcmpRow));

				// Setup new row values
				row->ipAddr = ifTmp->ip;
				row->netMask = ifTmp->mask;
				row->assNode = info;
				row->router = false;
				row->hop = 0;

				// Add row to icmpTab
				listPush (params->icmpTab, row);
			}
		}

		// CONSOLE OUTPUT
		printf ("done!\n");
	}
	listReset (params->snmpList, true);
	
	// CONSOLE OUTPUT
	printf ("Thread Manager - Starting DNS resolution\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting DNS resolution\n");
#endif
		
	// Start DNS resolution and wait
	params->sync = params->gOpts->threads;	// Set Synchronization counter
	params->currRow = params->icmpTab->head;
	params->currNode = params->topology->routers.head;
	sem_post (params->scannerSemA);
	while (params->sync > 0) sem_wait (params->scanSem);

	// CONSOLE OUTPUT
	if (!params->gOpts->verbose) printf ("\n");
	printf ("Thread Manager - IcmpTable rows association with SNMP nodes\n");
	printf ("Thread Manager - IcmpTable rows correction using SNMP information\n");
	printf ("Thread Manager - Early detected alias nodes creation\n");
	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	// For each IcmpTable row
		IcmpRow *row = current->element;	// Current row pointer
		
		// Associate row with SNMP found routers
		row->assNode = listSearch (&params->topology->routers, &row->ipAddr, (void *) nodeCmp);

		// Correct row using SNMP information
		if (row->assNode || listSearch (&params->topology->routers, &row->ipAddr, (void *) nodeNextHopCmp))
			row->router = true;
		
		// Create early detected alias router
		if (row->alias.s_addr != INADDR_ANY) {
			RowCouple couple = {row, NULL};
			
			couple.second = listSearch (params->icmpTab, &row->alias, (void *) icmpRowCmp);
			
#ifdef DEBUG
			debugOut (ALIAS, "Thread Manager - Couple (%s,", inet_ntoa(row->ipAddr));
			debugOutNoTime (ALIAS, " %s) alias (EarlyDetectedAlias)\n", inet_ntoa(couple.second->ipAddr));
#endif
			alias2Routers (params, &couple);
		}
		
		// Test if RR early detected are alias router
		if (row->aliasRR.s_addr != INADDR_ANY) {
			RowCouple couple = {row, NULL};		// Current row couple
			
			couple.second = listSearch (params->icmpTab, &row->aliasRR, (void *) icmpRowCmp);
								
			// If hop count for row and its aliasRR is equal
			if (couple.second && couple.second->hop == row->hop) {
#ifdef DEBUG
				debugOut (ALIAS, "Thread Manager - Couple (%s,", inet_ntoa(row->ipAddr));
				debugOutNoTime (ALIAS, " %s) alias (RREarlyDetectedAlias)\n", inet_ntoa(couple.second->ipAddr));
#endif
				alias2Routers (params, &couple);
			}
		}
	}

	// CONSOLE OUTPUT
	printf ("Thread Manager - Starting Alias resolution phase 1\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting Alias resolution phase 1\n");
#endif

	// Wait on scanSem until Alias phase 1 finish
	params->sync = params->gOpts->threads;		// Set Synchronization counter
	params->currRow = params->icmpTab->head;	// Set current row pointer
	sem_destroy (params->scannerSemA);
	sem_init (params->scannerSemA, 0, 0);
	sem_post (params->scannerSemB);
	while (params->sync > 0) sem_wait (params->scanSem);

	// CONSOLE OUTPUT
	if (!params->gOpts->verbose) printf ("\n");
	printf ("Thread Manager - Starting Alias resolution phase 2\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Waiting scan process to finish\n");
#endif

	// Wait on scanSem until Alias phase 2 finish
	params->sync = params->gOpts->threads;		// Set Synchronization counter
	params->currRow = params->icmpTab->head;	// Set current row pointer
	sem_destroy (params->scannerSemB);
	sem_init (params->scannerSemB, 0, 0);
	sem_post (params->scannerSemA);

	// CONSOLE OUTPUT
	printf ("Thread Manager - Waiting Scanner threads to terminate (%d)\n", params->gOpts->threads);
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Waiting Scanner threads to terminate (%d)\n", params->gOpts->threads);
#endif
	
	// Wait all threads for termination
	for (j=0; j<params->gOpts->threads; j++) pthread_join (threadIds[j], NULL);

	// CONSOLE OUTPUT
	if (!params->gOpts->verbose) printf ("\n");
	printf ("Thread Manager - Creating unaliased routers\n");
	
	// Create unaliased routers
	for (current = params->icmpTab->head; current; current = current->next) 
	{	// For each IcmpTable row 
		IcmpRow *row = current->element;	// Current row pointer
		
		if (row->assNode == NULL && row->router) {
			// Allocate new node and interface memory
			NetNode *newNode = (NetNode *) calloc (1, sizeof (NetNode));
			Interface *newIf = (Interface *) calloc (1, sizeof (Interface));
	
			// Set node type
			newNode->type = ROUTER;
	
			// Set node name
			if (row->ipDNS) newNode->name = row->ipDNS;
			else {
				newNode->name = calloc (7, sizeof(char));
				sprintf (newNode->name, "Dev%d", params->nodeCount++);
			}
	
			// Associate row with router
			row->assNode = newNode;
	
			// Set interfaces information
			newIf->ip = row->ipAddr;
			newIf->mask = row->netMask;
	
			// Add new interface to router
			listInit (&newNode->interfaces);
			listPush (&newNode->interfaces, newIf);
	
			// Add new node to topology
			listPush (&params->topology->routers, newNode);
#ifdef DEBUG
			debugOut (ALIAS, "Created node %s (%s)\n", newNode->name, inet_ntoa (row->ipAddr));
#endif
		}
	}

	// Destroy semaphores
	sem_destroy (params->snmpSem);
	sem_destroy (params->scanSem);
	sem_destroy (params->scannerSemA);
	sem_destroy (params->scannerSemB);

	// Free dynamic allocated memory
	free (params->gOpts->oids);
	free (params->visited);
	free (params->snmpList);
	free (params->scanSem);
	free (params->scannerSemA);
	free (params->scannerSemB);
	free (threadIds);

	// CONSOLE OUTPUT
	printf ("+-+ SCAN TERMINATED +-+\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Scan process terminated\n");
#endif

	return 0;
}

/*!
  \fn int backtrace (struct in_addr addr, Options *opt, List *icmpTab, Path *hops)

  \brief This function executes a traceroute in inverse order to an addr and returns an array with the path

  \param addr Address to send a traceroute
  \param opt Structure containing options values
  \param icmpTab Table containing active method results
  \param path Pointer to a path structure
  \return Return an exit status code (see scanner.h)
*/
int
backtrace (struct in_addr addr, Options *opt, List *icmpTab, Path *hops)
{
	int socketfd[2];					// socket file descriptors: [0]->ICMP - [1]->UDP
	char pkt_buf[MAX_PACKET];			// packet buffer
	struct sockaddr_in dst_addr;		// destination address 
	struct sockaddr_in src_addr;		// source address for incoming packets
	struct icmp *icmp_buf;				// ICMP header struct pointer
	struct iphdr *ip_buf;				// IP header struct pointer
	struct timeval tv;					// timeout value
	int ttl = opt->lOpts->ttl;			// starting time to live
	u_int8_t retry = 0;					// retries counter
	TraceState state = SCANNING;		// backtrace scan process status
	bool icmp_filtered = false;			// ICMP packets filtered from some router through the path
	bool udp_filtered = false;			// UDP packets filtered from some router through the path
	u_int8_t mode = opt->gOpts->mode;	// backtrace preferred mode: ICMP = 0 - UDP = 1
	TraceOrder order = FORWARD;			// Trace proceding order
	bool done = false;					// No more informations needed
	struct in_addr alias = {INADDR_ANY};	// Alias address of destination node if found

#ifdef DEBUG
	char debugBuf[50];
	debugOut (BACKTRACE, "Thread %02d - Backtrace destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif

	// Path array and rows pointers allocation
	hops->array = (struct in_addr *) calloc (opt->gOpts->max_ttl, sizeof(struct in_addr));
	hops->newRows = (IcmpRow **) calloc (opt->gOpts->max_ttl, sizeof(IcmpRow *));
	hops->offset = 0;

	// destination address configuration
	dst_addr.sin_family = AF_INET;	
	dst_addr.sin_addr = addr;
	dst_addr.sin_port = BIG_UDP_PORT;
	
	// socket creation for ICMP
	if ((socketfd[ICMP] = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {	
		perror ("backtrace: error in socket0 creation");
		return -1;
	}

	// socket creation for UDP
	if ((socketfd[UDP] = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {	
		perror ("backtrace: error in socket1 creation");
		return -1;
	}

	// ICMP socket timeout configuration
	tv.tv_sec = opt->gOpts->timeout / 1000;			// seconds
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	// micro-seconds
	setsockopt (socketfd[ICMP], SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));
	
	do {
		bool newHopFound = false;				// Has been found a new hop address?
		u_int8_t index;							// Last added IP array index
		TraceMode turn = (retry + mode) % 2;	// Backtrace current mode
		
		// prepare ICMP packet
		if (!icmp_filtered && (turn == ICMP || (turn == UDP && udp_filtered)))
		{
			// set TTL value in IP header
			if (setsockopt (socketfd[ICMP], IPPROTO_IP, IP_TTL, (char *) &ttl, sizeof (ttl)) < 0) {
				perror ("backtrace: error in setsockopt IP_TTL");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -3;
			}
			
			// ICMP packet construction 
			icmp_buf = (struct icmp *) pkt_buf;
			icmp_buf->icmp_type = ICMP_ECHO;
			icmp_buf->icmp_code = 0;
			icmp_buf->icmp_id = opt->lOpts->threadNum;
			icmp_buf->icmp_seq = 0;
			icmp_buf->icmp_cksum = 0;
			icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
			
			// sending ICMP packet
			if (sendto(socketfd[ICMP], icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
				perror ("backtrace: error in sendto ICMP");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -4;
			}
#ifdef DEBUG
			sprintf (debugBuf, "Thread %02d - Sent ICMP (TTL %02d)-> ", opt->lOpts->threadNum, ttl);
#endif
		}
		// prepare UDP packet
		else if (!udp_filtered && (turn == UDP || (turn == ICMP && icmp_filtered)))
		{
			// set TTL value in IP header
			if (setsockopt (socketfd[UDP], IPPROTO_IP, IP_TTL, (char *) &ttl, sizeof (ttl)) < 0) {
				perror ("backtrace: error in setsockopt IP_TTL");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -3;
			}

			// set packet payload
			memset (&pkt_buf, 'X', UDP_SIZE);
			
			// sending UDP packet
			if (sendto(socketfd[UDP], pkt_buf, UDP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
				perror ("backtrace: error in sendto UDP");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -4;
			}
#ifdef DEBUG
			sprintf (debugBuf, "Thread %02d - Sent UDP  (TTL %02d)-> ", opt->lOpts->threadNum, ttl);
#endif
		}
		// All packets are filtered
		else {
			state = DEST_FILTERED;
			udp_filtered = false;
			icmp_filtered = false;

			if (order == BACKWARD) ttl--;
			else {
				ttl = opt->lOpts->ttl - 1;
				order = BACKWARD;
			}
			continue;
		}
		
		// receive ICMP messages 
		while (true)
		{
			socklen_t lsock = sizeof(dst_addr);		// size of sockaddr struct
			
			if (recvfrom(socketfd[ICMP], &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock) < 0) 
			{
				// ICMP_TIMEOUT
#ifdef DEBUG
				debugOut (BACKTRACE, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				if (retry < opt->gOpts->retries) retry++;
				else {
					// Set next TTL value according to current order and reset retries
					order ? ttl-- : ttl++;		
					retry = 0;
				}
				break;			
			}
			
			// retrieve packet information
			ip_buf = (struct iphdr *) &pkt_buf[IP_SIZE + 8];	// IP header appended to ICMP packet
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		// ICMP header 
			index = ttl - 1;									// Set current array index
			
			// ICMP_TIME_EXCEEDED reply to Packet directed to current destination IP
			if (icmp_buf->icmp_type == ICMP_TIME_EXCEEDED && ip_buf->daddr == addr.s_addr) 
			{
#ifdef DEBUG
				debugOut (BACKTRACE, "%sReceived ICMP_TIME_EXCEEDED from %s\n", debugBuf, inet_ntoa(src_addr.sin_addr));
#endif
				newHopFound = true;
				
				// switch preferred mode if necessary
				if (ip_buf->protocol == IPPROTO_UDP) mode = UDP;
				else mode = ICMP;
				
				// Set next TTL value according to current order and reset retries
				order ? ttl-- : ttl++;
				retry = 0;
				break;
			}
			
			// ICMP_ECHOREPLY from destination
			else if (icmp_buf->icmp_type == ICMP_ECHOREPLY && src_addr.sin_addr.s_addr == addr.s_addr && turn == ICMP)
			{ 
#ifdef DEBUG
				debugOut (BACKTRACE, "%sReceived ICMP_ECHOREPLY from %s\n", debugBuf, 
							inet_ntoa (src_addr.sin_addr));
#endif
				newHopFound = true;
				break;
			}

			// ICMP_DEST_UNREACH reply to Packet directed to current destination IP
			else if (icmp_buf->icmp_type == ICMP_DEST_UNREACH && ip_buf->daddr == addr.s_addr) 
			{
				// ICMP_PORT_UNREACH code
				if (icmp_buf->icmp_code == ICMP_PORT_UNREACH)
				{
#ifdef DEBUG
					debugOut (BACKTRACE, "%sReceived ICMP_PORT_UNREACH from %s\n", debugBuf, inet_ntoa (src_addr.sin_addr));
#endif
					newHopFound = true;
					break;
				}
				// ICMP_PKT_FILTERED code
				else if (icmp_buf->icmp_code == ICMP_PKT_FILTERED)
				{
#ifdef DEBUG
					debugOut (BACKTRACE, "%sReceived ICMP_PKT_FILTERED from %s (proto=%d)\n", 
							debugBuf, inet_ntoa (src_addr.sin_addr), ip_buf->protocol);
#endif
					// set as filtered involved protocol
					if (ip_buf->protocol == IPPROTO_UDP) udp_filtered = true;
					if (ip_buf->protocol == IPPROTO_ICMP) icmp_filtered = true;
					
					retry++;
					break;
				}
				// Other ICMP_DEST_UNREACH code type
				else
				{
#ifdef DEBUG
					debugOut (BACKTRACE, "%sReceived ICMP_DEST_UNREACH (code=%d) from %s\n", 
							debugBuf, icmp_buf->icmp_code, inet_ntoa (src_addr.sin_addr));
#endif
					newHopFound = true;
					state = DEST_UNREACHABLE;
					hops->length = ttl;
					if (order == BACKWARD) ttl--;
					else {
						ttl = opt->lOpts->ttl - 1;
						order = BACKWARD;
					}
					break;
				}
			}
		}
		
		// If MAX_TTL is reached switch to backward mode
		if (ttl > opt->gOpts->max_ttl) {
			state = MAX_TTL_REACHED;
			ttl = opt->lOpts->ttl - 1;
			order = BACKWARD;
		}

		// If new hop has been found
		if (newHopFound) {
			IcmpRow *row;	// Temporary row pointer

			// store current hop in the path array
			hops->array[index].s_addr = src_addr.sin_addr.s_addr;

			// the ICMP message is from destination
			if (src_addr.sin_addr.s_addr == addr.s_addr) {
				state = DEST_REACHED;
				hops->length = index + 1;
				if (order == BACKWARD) ttl--;
				else {
					if (ttl > opt->lOpts->ttl) opt->lOpts->ttl = ttl;
					ttl = opt->lOpts->ttl - 1;
					order = BACKWARD;
				}
				if (hops->offset > 0) done = true;
			}

			// ICMP_PORT_UNREACH to this thread but not from destination
			else if (icmp_buf->icmp_code == ICMP_PORT_UNREACH) {
				mode = ICMP;				// Switch mode to ICMP
				alias = src_addr.sin_addr;	// Set alias address
			}
			
			pthread_mutex_lock (&mutex_icmpTab);
			// If current hop was discovered before
			if ((row = listSearch (icmpTab, &src_addr.sin_addr, (void *) icmpRowCmp))) {
				// Only if IP is not destination IP
				if (src_addr.sin_addr.s_addr != addr.s_addr) {
					if (!row->router) row->router = true;	// Update router value
					if (order == BACKWARD) {
						hops->offset = index;	// Set starting offset in path array
					 	done = true;			// Stop trace process
					}
				}
				// If hop is destination and alias was found => set alias 
				else {
					if (alias.s_addr != INADDR_ANY) row->alias = alias;
					row->hop = index + 1;	// Set exact hop count
				}
				if (row->accuracy == RECORDROUTE) row->accuracy = BOTH;
				
				// Save alias row memory address
				if (icmp_buf->icmp_code == ICMP_PORT_UNREACH) hops->aliasRow = row;
				hops->newRows[index] = row;
			}

			// If not found insert hop in IcmpTab
			else if (src_addr.sin_addr.s_addr != INADDR_ANY) {
				// Allocate row dynamic space
				row = (IcmpRow *) calloc (1, sizeof(IcmpRow));

				// Insert new row data
				row->ipAddr = src_addr.sin_addr;
				row->dest = addr;
				row->hop = index + 1;
				row->accuracy = TRACEROUTE;
				if (hops->length == index + 1 || icmp_buf->icmp_code == ICMP_PORT_UNREACH)
					row->router = false;
				else
					row->router = true;

				// If hop is destination and alias was found => set alias 
				if (alias.s_addr != INADDR_ANY && addr.s_addr == src_addr.sin_addr.s_addr)
					row->alias = alias;

				// Save alias row memory address
				if (icmp_buf->icmp_code == ICMP_PORT_UNREACH) hops->aliasRow = row;

				hops->newRows[index] = row;	// Save row memory address

				// Add row to IcmpTab
				listPush (icmpTab, row);
			}
			pthread_mutex_unlock (&mutex_icmpTab);
		}
	} while (ttl > 0 && !done);

	close (socketfd[ICMP]);
	close (socketfd[UDP]);
	
#ifdef DEBUG
	switch (state) {
		case SCANNING: break;
		case DEST_REACHED:
			debugOut (BACKTRACE, "Thread %02d - Destination %s reached in %d hops\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
		case MAX_TTL_REACHED:
			debugOut (BACKTRACE, "Thread %02d - Destination %s not reached in %d hops (MAX_TTL_REACHED)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
		case DEST_FILTERED:
			debugOut (BACKTRACE, "Thread %02d - Destination %s not reached in %d hops (DEST_FILTERED)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
		case DEST_UNREACHABLE:
			debugOut (BACKTRACE, "Thread %02d - Destination %s not reached in %d hops (DEST_UNREACHABLE)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
	}
#endif

	return state;
}


/*!
  \fn AliasState ally (Options *opt, const struct in_addr addr1, const struct in_addr addr2)

  \brief This function implements the Ally's algorithm to test if addr1 and addr2 are aliases

  \param opt Structure containing options values
  \param addr1 First address
  \param addr2 Second address

  \return Return the finale state of the couple
*/
AliasState
ally (Options *opt, const struct in_addr addr1, const struct in_addr addr2)
{
	int socketfd[2];				// socket file descriptors: [0]->ICMP - [1]->UDP
	char pkt_buf[MAX_PACKET];		// packet buffer
	struct sockaddr_in dst_addr;	// current destination address
	struct sockaddr_in src_addr;	// source address for incoming packets
	struct iphdr *ip_head;			// IP header struct pointer
	struct iphdr *ip_buf;			// IP header struct pointer
	struct icmp *icmp_buf;			// ICMP header struct pointer
	struct timeval tv;				// timeout value
	u_int8_t retry = 0;				// retries counter
	int id[3] = {0, 0, 0};			// IP id values array
	int turn = 0;					// destination turn counter

#ifdef DEBUG
	char debugBuf[50];
	sprintf (debugBuf, "Thread %02d - Ally couple: %s", opt->lOpts->threadNum, inet_ntoa (addr1));
	debugOut (ALLY, "%s, %s \n", debugBuf, inet_ntoa (addr2));
#endif

	// socket creation for ICMP
	if ((socketfd[ICMP] = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {	
		perror ("ally: error in socket0 creation");
		return -1;
	}

	// socket creation for UDP
	if ((socketfd[UDP] = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {	
		perror ("ally: error in socket1 creation");
		return -1;
	}

	// ICMP socket timeout configuration
	tv.tv_sec = opt->gOpts->timeoutAlly / 1000;				// seconds
	tv.tv_usec = (opt->gOpts->timeoutAlly % 1000) * 1000;	// micro-seconds
	setsockopt (socketfd[ICMP], SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));

	// destination type and port configuration
	dst_addr.sin_family = AF_INET;	
	dst_addr.sin_port = BIG_UDP_PORT;

	do {
		// set destination address and packet payload
		if (turn % 2) dst_addr.sin_addr = addr2;
		else dst_addr.sin_addr = addr1;
		memset (&pkt_buf, 'X', UDP_SIZE);

		// sending UDP packet
		if (sendto(socketfd[UDP], pkt_buf, UDP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
			perror ("ally: error in sendto UDP");
			return -4;
		}
#ifdef DEBUG
		sprintf (debugBuf, "Thread %02d - Sent UDP to %s -> ", opt->lOpts->threadNum, inet_ntoa(dst_addr.sin_addr));
#endif
		// receive ICMP messages
		while (true) {
			socklen_t lsock = sizeof(dst_addr);		// size of sockaddr struct
			
			if (recvfrom(socketfd[ICMP], &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock) < 0) 
			{
				// ICMP_TIMEOUT
#ifdef DEBUG
				debugOut (ALLY, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				if (retry < opt->gOpts->retriesAlly) retry++;
				else if (turn % 2 == 0) {
					close (socketfd[UDP]);
					close (socketfd[ICMP]);
					return TIMEOUT1;
				}
				else {
					close (socketfd[UDP]);
					close (socketfd[ICMP]);
					return TIMEOUT2;
				}
				break;
			}
			
			// retrieve packet informations
			ip_buf = (struct iphdr *) &pkt_buf[IP_SIZE + 8];	// IP header appended to ICMP packet
			ip_head = (struct iphdr *) &pkt_buf;				// IP header
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		// ICMP header 

			// ICMP_PORT_UNREACH reply to Packet directed to current destination IP
			if (icmp_buf->icmp_type == ICMP_DEST_UNREACH &&
				icmp_buf->icmp_code == ICMP_PORT_UNREACH &&
				ip_buf->daddr == dst_addr.sin_addr.s_addr)
			{
#ifdef DEBUG
				debugOut (ALLY, "%sReceived ICMP_PORT_UNREACH from %s (id=%d)\n",
							debugBuf, inet_ntoa (src_addr.sin_addr), ntohs (ip_head->id));
#endif
				id[turn++] = ntohs (ip_head->id);
				retry = 0;

				// Assume: very near counters => alias 
				if (turn == 2 && id[1] > id[0] && (id[1] - id[0]) < 20)	{
					close (socketfd[UDP]);
					close (socketfd[ICMP]);
					return ALIASES;
				}			

				break;
			}
		}
	} while (turn < 3);

	close (socketfd[UDP]);
	close (socketfd[ICMP]);

	if ((id[0] < id[1]) && (id[1] < id[2]) && ((id[2] - id[0]) < 500)) return ALIASES;
	else return NOT_ALIASES;
}


/*!
  \fn void alias2Routers (ThreadParam *params, RowCouple *couple)
  \brief This function from a couple of IcmpTable rows creates or modifies topology routers

  \param params pointer to generic thread parameters
  \param couple row couple to add to topology
*/
void
alias2Routers (ThreadParam *params, RowCouple *couple)
{
	// If both rowa are associated to a node => do nothing
	if (couple->first->assNode && couple->second->assNode) return;
	
	// Associate second row to first row associated router
	if (couple->first->assNode != NULL) {
		// Allocate interface memory
		Interface *newIf = (Interface *) calloc (1, sizeof (Interface));

		// Associate row with router
		couple->second->assNode = couple->first->assNode;
		if (couple->first->router) couple->second->router = true;
		if (couple->second->router) {
			couple->first->router = true;
			couple->first->assNode->type = ROUTER;
		}

		// Set interface information
		newIf->ip = couple->second->ipAddr;
		newIf->mask = couple->second->netMask;

		// Add new interface to router
		listPush (&couple->first->assNode->interfaces, newIf);
	
		debugOut (ALIAS, "Associated %s to node %s\n", inet_ntoa (couple->second->ipAddr), couple->first->assNode->name);
	}
	// Associate first row to second row associated router
	else if (couple->second->assNode != NULL) {
		// Allocate interface memory
		Interface *newIf = (Interface *) calloc (1, sizeof (Interface));

		// Associate row with router
		couple->first->assNode = couple->second->assNode;
		if (couple->second->router) couple->first->router = true;
		if (couple->first->router) {
			couple->second->router = true;
			couple->second->assNode->type = ROUTER;
		}

		// Set interface information
		newIf->ip = couple->first->ipAddr;
		newIf->mask = couple->first->netMask;

		// Add new interface to router
		listPush (&couple->second->assNode->interfaces, newIf);
	
		debugOut (ALIAS, "Associated %s to node %s\n", inet_ntoa (couple->first->ipAddr), couple->second->assNode->name);
	}
	// Create new router with those two interfaces
	else {
		// Allocate new node and interfaces memory
		NetNode *newNode = (NetNode *) calloc (1, sizeof (NetNode));
		Interface *newIf = (Interface *) calloc (2, sizeof (Interface));

		// Set node type
		if (couple->first->router || couple->second->router) {
			couple->first->router = true;
			couple->second->router = true;
			newNode->type = ROUTER;
		}

		// Set node name
		if (couple->first->ipDNS) newNode->name = couple->first->ipDNS;
		else if (couple->second->ipDNS) newNode->name = couple->second->ipDNS;
		else {
			newNode->name = calloc (7, sizeof(char));
			sprintf (newNode->name, "Dev%d", params->nodeCount++);
		}

		// Associate rows with router
		couple->first->assNode = newNode;
		couple->second->assNode = newNode;

		// Set interfaces information
		newIf[0].ip = couple->first->ipAddr;
		newIf[0].mask = couple->first->netMask;
		newIf[1].ip = couple->second->ipAddr;
		newIf[1].mask = couple->second->netMask;

		// Add new interfaces to router
		listInit (&newNode->interfaces);
		listPush (&newNode->interfaces, &newIf[0]);
		listPush (&newNode->interfaces, &newIf[1]);

		// Add new node to topology
		listPush (&params->topology->routers, newNode);
		
		debugOut (ALIAS, "Created node %s (%s, ", newNode->name, inet_ntoa (couple->first->ipAddr));
		debugOutNoTime (ALIAS, "%s)\n", inet_ntoa (couple->second->ipAddr));
	}
}

/*!
  \fn AliasState allyPrevention (LocalOptions *lOpt, IcmpRow *row1, IcmpRow *row2)

  \brief This function tests ally prevention rules on a couple of IcmpTable rows

  \param lOpt pointer to local thread options
  \param row1 row couple to add to topology
  \param row2 true if the couple are aliases

  \return decision result state
*/
AliasState
allyPrevention (LocalOptions *lOpt, IcmpRow *row1, IcmpRow *row2)
{
	IcmpRow *rowTmp;
	ThreadParam *params = lOpt->params;
	
	// DNS rule (Same name => alias)
	if (params->gOpts->dns && row1->ipDNS != NULL &&
		row2->ipDNS != NULL && !strcmp(row1->ipDNS, row2->ipDNS)) {
#ifdef DEBUG
		debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt->threadNum, inet_ntoa(row1->ipAddr));
		debugOutNoTime (ALIAS, " %s) alias (DNS rule)\n", inet_ntoa(row2->ipAddr));
#endif
		return ALIASES;
	}

	// Hop Distance rule
	if (row1->hop != row2->hop) return NOT_ALIASES;

	// 2nd rule (Two adiacent backtrace hops can't be aliases)
	if (row1->accuracy != RECORDROUTE && row2->accuracy != RECORDROUTE) {
		if (row1->precHop == row2 || row1->nextHop == row2 ||
			row2->precHop == row1 || row2->nextHop == row1) {
#ifdef DEBUG
			debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt->threadNum, inet_ntoa(row1->ipAddr));
			debugOutNoTime (ALIAS, " %s) not alias (2nd rule)\n", inet_ntoa(row2->ipAddr));
#endif
			return NOT_ALIASES;
		}
	}
	
	// 3rd Rule (PingRR path hops can't be aliases)
	if (row1->accuracy != TRACEROUTE && row2->accuracy != TRACEROUTE) {
		bool done = false;
		
		for (rowTmp = row1->precHopRR; rowTmp; rowTmp = rowTmp->precHop)
			if (rowTmp->ipAddr.s_addr == row2->ipAddr.s_addr) { done = true; break; }

		for (rowTmp = row1->nextHopRR; rowTmp && !done; rowTmp = rowTmp->nextHop)
			if (rowTmp->ipAddr.s_addr == row2->ipAddr.s_addr) { done = true; break; }

		for (rowTmp = row2->precHopRR; rowTmp && !done; rowTmp = rowTmp->precHop)
			if (rowTmp->ipAddr.s_addr == row1->ipAddr.s_addr) { done = true; break; }

		for (rowTmp = row2->nextHopRR; rowTmp && !done; rowTmp = rowTmp->nextHop)
			if (rowTmp->ipAddr.s_addr == row1->ipAddr.s_addr) { done = true; break; }
		
		if (done) {
#ifdef DEBUG
			debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt->threadNum, inet_ntoa(row1->ipAddr));
			debugOutNoTime (ALIAS, " %s) not alias (3rd rule)\n", inet_ntoa(row2->ipAddr));
#endif
			return NOT_ALIASES;
		}
	}
	
	// 4th rule (Corresponding path hops in BackTrace and PingRR belong to same router)
	if (row1->hop == row2->hop) {
		bool done = false;
		
		if (row1->dest.s_addr == row2->dest.s_addr) done = true;
		// First is PRR and second is TR
		else if (row1->accuracy != TRACEROUTE && row2->accuracy != RECORDROUTE) {
			rowTmp = listSearch (params->icmpTab, &row1->dest, (void *) icmpRowCmp);
			if (rowTmp) {
				// Search same hop distance starting from destination
				while (rowTmp->hop != row1->hop && rowTmp->precHop) rowTmp = rowTmp->precHop;
				if (rowTmp->ipAddr.s_addr == row2->ipAddr.s_addr) done = true;
			}
		}
		// First is TR and second is PRR
		else if (row2->accuracy != TRACEROUTE && row1->accuracy != RECORDROUTE) {
			rowTmp = listSearch (params->icmpTab, &row2->dest, (void *) icmpRowCmp);
			if (rowTmp) {
				// Search same hop distance starting from destination
				while (rowTmp->hop != row2->hop && rowTmp->precHop) rowTmp = rowTmp->precHop;
				if (rowTmp->ipAddr.s_addr == row1->ipAddr.s_addr) done = true;
			}
		}
				
		if (done) {
#ifdef DEBUG
			debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt->threadNum, inet_ntoa(row1->ipAddr));
			debugOutNoTime (ALIAS, " %s) alias (4th rule)\n", inet_ntoa(row2->ipAddr));
#endif
			return ALIASES;
		}
	}

	return NONE;
}

