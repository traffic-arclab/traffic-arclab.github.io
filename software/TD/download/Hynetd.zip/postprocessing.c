/***************************************************************************
                postprocessing.c
                Network topology post processing functions implementation
 
                -------------------
    begin       : 26/05/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 
#include "postprocessing.h"

/*!
  \fn void extractLinks (ThreadParam *params)
  \brief This function creates links from SNMP and IcmpTable data

  \param params pointer to generic thread parameters
*/
void
extractLinks (ThreadParam *params)
{
	ListEntry *current;		// List entry pointer

	// Create links from SNMP information
	for (current = params->topology->routers.head; current; current = current->next) 
	{	// For each node
		NetNode *node = current->element;	// Current node pointer
		ListEntry *curr;					// List entry pointer

		if (!node->SNMPCommunity) continue;		// Skip non SNMP routers
		
		for (curr = node->interfaces.head; curr; curr = curr->next) 
		{	// For each interface
			Interface *ifTmp = curr->element;	// Current interface pointer
			struct in_addr *nextHop;			// Next hop address pointer
			
			// Skip local and any interfaces
			if (ifTmp->ip.s_addr == INADDR_ANY || *((u_int8_t *)&ifTmp->ip.s_addr) == 127) continue;

			// Test first default gateway as nexthop
			if (nextHopCmp (ifTmp, &node->defaultGw))
				nextHop = &node->defaultGw;
			else
				nextHop = listSearch (&node->nextHops, ifTmp, (void *) nextHopCmp);
			
			if (nextHop) 
			{	// NextHop found => create link and add it to topology
				NetLink *newLink = calloc (1, sizeof (NetLink));
		
				// Set basic link properties
				newLink->snmp = true;
				newLink->speed = ifTmp->speed;
				newLink->srcNode = node;
				newLink->srcIf = ifTmp;
		
				if ((newLink->dstNode = listSearch(&params->topology->routers, nextHop, (void *) nodeCmp))) 
				{	// Destination node exists => point to it
					newLink->dstIf = listSearch (&newLink->dstNode->interfaces, nextHop, (void *) ifCmp);
					newLink->dstIf->speed = ifTmp->speed;
					newLink->dstIf->mask = ifTmp->mask;
				}

				else 
				{	// Create destination node
					// Allocate new node and interface dynamic memory
					newLink->dstNode = (NetNode *) calloc (1, sizeof(NetNode));
					newLink->dstIf = (Interface *) calloc (1, sizeof(Interface));
		
					// Set destination node properties
					newLink->dstNode->type = ROUTER;
					newLink->dstNode->name = calloc (7, sizeof(char));
					sprintf (newLink->dstNode->name, "Dev%d", params->nodeCount++);
					listInit (&newLink->dstNode->nonDirectSubnets);
					listInit (&newLink->dstNode->interfaces);
					listInit (&newLink->dstNode->nextHops);

					// Set destination interface properties
					newLink->dstIf->ip = *nextHop;
					newLink->dstIf->mask = ifTmp->mask;
					newLink->dstIf->speed = ifTmp->speed;
					listPush (&newLink->dstNode->interfaces, newLink->dstIf);
		
					// Add node to topology
					listPush (&params->topology->routers, newLink->dstNode);
#ifdef DEBUG
					debugOut (ALIAS, "Created node %s (%s)\n", newLink->dstNode->name, inet_ntoa (newLink->dstIf->ip));
#endif
				}
		
				if (!listSearch (&params->topology->links, newLink, (void *) linkCmp)) 
					// Link is not yet present in topology => Add link to topology
					listPush(&params->topology->links, newLink);
				else
					// Link already added before => Erase link
					free (newLink);
			}
		}
	}
	
	// Create links from IcmpTable
	Interface *nullIf = calloc (1, sizeof(Interface));	// Null interface
	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	// For each icmpTable row
		IcmpRow *row = current->element;	// Current row pointer

		if (row->precHop || row->precHopRR) {
			NetLink *newLink = calloc (1, sizeof (NetLink));		// New link pointer
			ListEntry *curr2, *curr3;								// List entries pointers
			u_int32_t XOR;											// XOR between 2 ip addresses 
			u_int32_t minXOR = 0xFFFFFFFF;							// Minimum XOR value found
			u_int32_t mask = ntohl (0xFFFFFFFC);					// 255.255.255.252 netmask
			struct in_addr netId = { row->ipAddr.s_addr & mask };	// Link subnet id

			// If row->ip is ends with 00 or 11 bits => skip row
			if (htonl (row->ipAddr.s_addr & ~mask) == 0 ||
				htonl (row->ipAddr.s_addr & ~mask) == 3) continue;

			// This block assumes that two valid addresses, one precHop of the other, in the same 255.255.255.252 subnet
			// are both routers and generate a link
			if (!row->router) 
			{	// Current row is an host 
				if (row->precHopRR) 
				{	// Current row has precHopRR => Test if precHopRR belongs to the same 255.255.255.252 subnet
					bool found = false;
					
					// If row->ip and its prechop->ip are not in the same 255.255.255.252 subnet => skip row
					if ((row->precHopRR->ipAddr.s_addr & mask) != netId.s_addr) continue;
					
					// If prechop->ip ends with 00 or 11 bits => skip row
					if (htonl (row->precHopRR->ipAddr.s_addr & ~mask) == 0 ||
						htonl (row->precHopRR->ipAddr.s_addr & ~mask) == 3) continue;
				
					for (curr2 = params->icmpTab->head; curr2; curr2 = curr2->next) 
					{	// For each row in IcmpTab
						IcmpRow *rowTmp = curr2->element;	// Current row pointer
						
						if (row != rowTmp && rowTmp->precHopRR == row->precHopRR) 
						{	// Inspecting different rows with same precHopRR 
							LocalOptions lOpt = {0, 0, params};				// Local thread options
							Options opt = {params->gOpts, &lOpt};			// Generic options
							
							// Test if row and rowTmp are aliases
							if (row->router && rowTmp->router) {
								if (row->assNode != rowTmp->assNode) {
									found = true;
									break;
								}
							}
							else {
								// Test ally prevention rules
								AliasState result = allyPrevention (&lOpt, rowTmp, row);
	
								// Execute ally algorithm
								if (result == NONE) {
									result = ally (&opt, rowTmp->ipAddr, row->ipAddr);
#ifdef DEBUG
									debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(rowTmp->ipAddr));
									debugOutNoTime (ALIAS, " %s) are %s alias (Ally%s)\n", inet_ntoa(row->ipAddr),
											result == ALIASES ? "" : "not", result > 1 ? "" : " sure");
#endif
								}

								if (result != ALIASES) {
									found = true;
									break;
								}
								else 
								{	// Found new aliases => Create/modify routers
									RowCouple couple = {row, rowTmp};
									alias2Routers (params, &couple);
								}
							}
						}
					}
					// If found other non-alias rows with same precHop => skip row
					if (found) continue;
				}
				else continue;
				
				// Set row type to router, create node (if necessary) and add it to topology
				row->router = true;
				if (!row->assNode)
					listPush (&params->topology->routers, icmpRow2NetNode (params, row));
				else row->assNode->type = ROUTER;
			}

			// Set destination node
			newLink->dstNode = row->assNode;
			newLink->hop = row->hop - 1;
			
			if (row->precHopRR) 
			{	// We have RecordRoute information => source interface is sure
				// Set source node and interface
				newLink->srcNode = row->precHopRR->assNode;
				newLink->srcIf = listSearch (&newLink->srcNode->interfaces, &row->precHopRR->ipAddr, (void *) ifCmp);
				newLink->dstIf = nullIf;
				minXOR = 255;

				// Refine link adding destination interface
				for (curr3 = newLink->dstNode->interfaces.head; curr3; curr3 = curr3->next) 
				{	// For each destination node interface
					Interface *if2 = curr3->element;	// Current destination interface pointer

					// Skip local interfaces
					if (*((u_int8_t *)&if2->ip.s_addr) == 127) continue;

					XOR = ntohl (newLink->srcIf->ip.s_addr ^ if2->ip.s_addr);
					if (XOR <= minXOR) {
						minXOR = XOR;
						if (minXOR <= MAX_SUBNET_LINK) newLink->dstIf = if2;
					}
				}
			}
			else 
			{	// We have only traceroute information => we have no sure interfaces
				// Set source node
				newLink->srcNode = row->precHop->assNode;
				newLink->srcIf = nullIf;
				newLink->dstIf = nullIf;
				minXOR = 255;

				// Refine link adding source and destination interface
				for (curr2 = newLink->srcNode->interfaces.head; curr2; curr2 = curr2->next) 
				{	// For each source node interface
					Interface *if1 = curr2->element;	// Current source interface pointer
					
					// Skip local interfaces
					if (*((u_int8_t *)&if1->ip.s_addr) == 127) continue;
					
					for (curr3 = newLink->dstNode->interfaces.head; curr3; curr3 = curr3->next) 
					{	// For each destination node interface
						Interface *if2 = curr3->element;	// Current destination interface pointer
						
						// Skip local interfaces
						if (*((u_int8_t *)&if2->ip.s_addr) == 127) continue;
						
						XOR = ntohl (if1->ip.s_addr ^ if2->ip.s_addr);
						if (XOR < minXOR) {
							minXOR = XOR;
							if (minXOR < MAX_SUBNET_LINK) {
								newLink->srcIf = if1;
								newLink->dstIf = if2;
							}
						}
					}
				}
			}
			
			// Test if link already exists
			NetLink *link = listSearch (&params->topology->links, newLink, (void *) linkCmp);
			if (!link)
				// Link doesn't exitst => Add link to topology 
				listPush(&params->topology->links, newLink);
			else 
			{	// Link exists => Add destination interface (if not present) to link and discard new link
				if (link->dstIf->ip.s_addr == INADDR_ANY) link->dstIf = newLink->dstIf;
				free (newLink);
			}
		}
	}
}

/*!
  \fn void extractSubnets (ThreadParam *params)
  \brief This function creates subnets from IcmpTable data

  \param params pointer to generic thread parameters
*/
void
extractSubnets (ThreadParam *params)
{
	ListEntry *current;		// List entry pointer

#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from SNMP routers\n");
#endif
	
	// Extract subnets from SNMP routers
	for (current = params->topology->routers.head; current; current = current->next) 
	{	// For each discovered router
		NetNode *info = current->element;	// Current router pointer
		ListEntry *curr;					// List entry pointer
		
		for (curr = info->interfaces.head; curr; curr = curr->next) 
		{	// For each interface
			Interface *ifTmp = curr->element;							// Current interface pointer
			Subnet *net;												// Interface subnet pointer
			NetLink *link;												// Link pointer
			u_int32_t netId = ifTmp->ip.s_addr & ifTmp->mask.s_addr;	// Network number

			// Skip local and any interfaces
			if (netId == INADDR_ANY || *((u_int8_t *)&netId) == 127) continue;

			if (!(net = listSearch (&params->topology->subnets, &ifTmp->ip, (void *) ipSubnet))) 
			{	// Subnet doesn't exists
				// Allocate subnet dynamic memory
				net = (Subnet *) calloc (1, sizeof (Subnet));
				net->nodes = (List *) calloc (1, sizeof (List));

				// Set subnet properties
				net->netId.s_addr = netId;
				net->netMask = shortMask (ifTmp->mask);
				net->type = EXACT;

				// Add node to subnet
				listInit (net->nodes);
				listPush (net->nodes, info);
#ifdef DEBUG
				debugOut (SUBNET, "Assigning %s ", inet_ntoa (ifTmp->ip));
				debugOutNoTime (SUBNET, "to %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
				// If interface belongs to a link add also its nextHop to subnet
				link = listSearch (&params->topology->links, &ifTmp->ip, (void *) ipLinkCmp);
				if (link) {
					// Associate nextHop row to subnet if exists
					IcmpRow *row = listSearch (params->icmpTab, &link->dstIf->ip, (void *) icmpRowCmp);
					if (row) row->assSubnet = net;
					
					listPush (net->nodes, link->dstNode);
#ifdef DEBUG
					debugOut (SUBNET, "Assigning %s ", link->dstNode->name);
					debugOutNoTime (SUBNET, "to %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
				}
				
				// Add subnet to topology
				listPush (&params->topology->subnets, net);
#ifdef DEBUG
				debugOut (SUBNET, "Created %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
			}
			else 
			{	// Subnet already exists
				// Add node to subnet only if subnet doesn't include it yet
				if (!listSearch (net->nodes, info, (void *) nodeAddrCmp))
					listPush (net->nodes, info);

				// Correct netmask if necessary
				if (shortMask(ifTmp->mask) < net->netMask) ifTmp->mask = longMask (net->netMask);
			}
		}
	}

#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from links\n");
#endif

	// Extract subnets from links (non SNMP)
	for (current = params->topology->links.head; current; current = current->next) 
	{	// For each discovered link
		NetLink *link = current->element;		// Current link pointer
		struct in_addr netId;					// Subnet id
		struct in_addr mask;					// Subnet netmask
		struct in_addr tmpMask;					// Temporary netmask used for correction
		u_int32_t a = link->srcIf->ip.s_addr;	// Source interface ip value
		u_int32_t b = link->dstIf->ip.s_addr;	// Destination interface ip value
		int i;

		// Skip raw links
		if (a == 0 || b == 0 || link->snmp) continue;

		inet_aton ("255.255.255.252", &tmpMask);

		// Get netmask from source interface
		if (link->srcIf->mask.s_addr) mask.s_addr = link->srcIf->mask.s_addr;
		// Get netmask from destination interface
		else if (link->dstIf->mask.s_addr) mask.s_addr = link->dstIf->mask.s_addr;
		// Calculate mask using Keshav euristic
		else {
			mask.s_addr = ~((a & b) ^ (a | b));
		
			// Correct netmask
			for (i=0; i<25; i++) {
				if (htonl(mask.s_addr) >= htonl(tmpMask.s_addr)) {
					mask.s_addr = tmpMask.s_addr;
					break;
				}
				tmpMask.s_addr = ntohl( htonl (tmpMask.s_addr) << 1);
			}
		}

		// Assign netmask to interfaces
		link->srcIf->mask = mask;
		link->dstIf->mask = mask;

		// Calculate subnet id
		netId.s_addr = a & mask.s_addr;

		// If subnet doesn't exists yet
		if (!listSearch (&params->topology->subnets, &netId, (void *) subnetCmp)) {
			Subnet *net = calloc (1, sizeof (Subnet));	// Allocate subnet dynamic memory
			net->nodes = calloc (1, sizeof (List));		// Allocate subnet nodes list dynamic memory

			// Set subnet properties
			net->netId = netId;
			net->netMask = shortMask (mask);
			net->type = EURISTIC;
			net->hop = link->hop;
			
			// Add link nodes to subnet
			listInit (net->nodes);

			// Add subnet to topology
			listPush (&params->topology->subnets, net);

#ifdef DEBUG
			debugOut (SUBNET, "Created %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
		}
	}

	// Test if each row, not associated to any subnet, belongs to a discovered subnet
	icmpTabSubnetCmp (params, true);

#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from IcmpTable (only precHopRR)\n");
#endif

	// Create subnets from IcmpTable (only precHopRR)
	for (current = params->icmpTab->head; current; current = current->next) 
	{	// For each IcmpTable row
		IcmpRow *row = current->element;	// Current row pointer
		
		// Process only rows not associated to any subnet
		if (!row->assSubnet && row->precHopRR) {
			// Create subnet from current row
			icmpRow2Subnet (params, current, PREC_HOP_RR);
			// Assign rows to subnet created
			icmpTabSubnetCmp (params, false);
		}
	}

#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from IcmpTable (no precHop)\n");
#endif

	// Create subnets from IcmpTable (no precHop)
	for (current = params->icmpTab->head; current; current = current->next) 
	{	// For each IcmpTable row
		IcmpRow *row = current->element;	// Current row pointer
		
		// Process only rows not associated to any subnet
		if (!row->assSubnet && !row->precHop) {
			// Create subnet from current row
			icmpRow2Subnet (params, current, NO_PREC_HOP);
			// Assign rows to subnet created
			icmpTabSubnetCmp (params, false);
			break;
		}
	}
	
#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from IcmpTable (only precHop)\n");
#endif
	
	// Create subnets from IcmpTable (only precHop)
	for (current = params->icmpTab->head; current; current = current->next) 
	{	// For each IcmpTable row
		IcmpRow *row = current->element;	// Current row pointer
		
		// Process only rows not associated to any subnet
		if (!row->assSubnet && row->precHop) {
			// Create subnet from current row
			icmpRow2Subnet (params, current, PREC_HOP);
			// Assign rows to subnet created
			icmpTabSubnetCmp (params, false);
		}
	}

}

/*!
  \fn void icmpRow2Subnet (ThreadParam *params, ListEntry *current, SubExtPhase phase)

  \brief This function from a row extracts a subnet comparing precHops

  \param params pointer to generic thread parameters
  \param current pointer to current IcmpTable row
  \param phase subnet extraction phase
*/
void
icmpRow2Subnet (ThreadParam *params, ListEntry *current, SubExtPhase phase)
{
	IcmpRow *row = current->element;			// Starting row pointer
	List tmpList;								// Subnet rows list
	ListEntry *curr, *curr2;					// List entry pointers
	IcmpRow *rowTmp;							// Temporary row pointer
	struct in_addr bestMask = { INADDR_ANY };	// Best netmask found for this subnet
	bool netmask = false;						// True if at least one row has a valid netmask
	Subnet *net = calloc (1, sizeof (Subnet));	// New subnet pointer
	net->nodes = calloc (1, sizeof (List));		// Allocate subnet nodes list dynamic memory

#ifdef DEBUG
	debugOut (SUBNET, "Processing %s:\n", inet_ntoa (row->ipAddr));
#endif

	// Initialize lists
	listInit (net->nodes);
	listInit (&tmpList);

	// Add current row to tmpList
	listPush (&tmpList, row);
	if (row->netMask.s_addr != INADDR_ANY) netmask = true;

	// Find rows with same precHopRR
	for (curr = current->next; curr; curr = curr->next) 
	{	// For each IcmpTable row starting from current
		rowTmp = curr->element;		// Current row pointer
		bool condition;				// Can current row belong to current subnet?
		
		// Skip visited rows
		if (rowTmp->assSubnet) continue;

		switch (phase) {
			case PREC_HOP_RR:
				condition = (row->precHopRR == rowTmp->precHopRR);
			break;
			case PREC_HOP:
				condition = false;
			break;
			case NO_PREC_HOP:
				condition = (rowTmp->precHop == NULL && row->hop == 1 && rowTmp->hop == 1);
			break;
		}
		
		if (condition) {
			bool found = false;		// Found an alias in current subnet
			
			// Control if tmpList contains aliases of current row
			if (rowTmp->assNode) {
				for (curr2 = rowTmp->assNode->interfaces.head; curr2 && !found; curr2 = curr2->next) 
				{	// For each current row associated node interface
					Interface *ifTmp = curr2->element;	// Current interface pointer

					found = (bool) listSearch (&tmpList, &ifTmp->ip, (void *) icmpRowCmp);
				}
			}

			if (!found) {
#ifdef DEBUG
				debugOut (SUBNET, "%s\n", inet_ntoa (rowTmp->ipAddr));
#endif
				if (rowTmp->netMask.s_addr != INADDR_ANY) netmask = true;
				listPush (&tmpList, rowTmp);
			}
		}
	}

	// If there is at least one netmask
	if (netmask) {
		// Find biggest mask
		for (curr = tmpList.head; curr; curr = curr->next) 
		{	// For each row in current subnet
			rowTmp = curr->element;
			if (htonl (rowTmp->netMask.s_addr) > htonl (bestMask.s_addr))
				bestMask = rowTmp->netMask;
		}
	}

	// Execute keshav euristic
	else bestMask = keshav (&tmpList);
	
	// Set subnet properties
	net->netId.s_addr = row->ipAddr.s_addr & bestMask.s_addr;
	net->netMask = shortMask (bestMask);
	net->type = EURISTIC;
	net->hop = row->hop;
	defaultGateway (row, net);
	
	
	if (!listSearch (&params->topology->subnets, net, (void *) subnetInclude)) 
	{	// Current subnet doesn't conflict with others
		// Assign best mask to each row
		for (curr = tmpList.head; curr; curr = curr->next) {
			rowTmp = curr->element;
			rowTmp->assSubnet = net;
			rowTmp->netMask = bestMask;
		}
	
		// Create nodes and add them to subnet
		for (curr = tmpList.head; curr; curr = curr->next) {
			rowTmp = curr->element;
			if (!rowTmp->assNode) icmpRow2NetNode (params, rowTmp);
			else {
				Interface *ifTmp = listSearch (&rowTmp->assNode->interfaces, &rowTmp->ipAddr, (void *) ifCmp);
				ifTmp->mask = bestMask;
			}
			listPush (net->nodes, rowTmp->assNode);
		}
	
		// Add subnet to topology
		listPush (&params->topology->subnets, net);
	
#ifdef DEBUG
		debugOut (SUBNET, "Created %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
	}
	else 
	{	// Current subnet conflicts with others
#ifdef DEBUG
		debugOut (SUBNET, "Aborted %s/%d subnet (Conflict)\n", inet_ntoa (net->netId), net->netMask);
#endif
		// Discard current subnet
		free (net);
	}
	
	// Reset subnet nodes list
	listReset (&tmpList, false);
}


/*!
  \fn void icmpTabSubnetCmp (ThreadParam *params, bool allSubnets)

  \brief This function scans IcmpTab for rows not yet visited during subnet creation and tests if each one
  \brief belongs to an existing subnet.

  \param params pointer to generic thread parameters
  \param allSubnets if false consider only the last subnet of the list
*/
void
icmpTabSubnetCmp (ThreadParam *params, bool allSubnets)
{
	ListEntry *current;		// List entry pointer

	// Compare IcmpTable with subnets acquired
	for (current = params->icmpTab->head; current; current = current->next) 
	{	// For each IcmpTable row
		IcmpRow *row = current->element;	// Current row pointer
		Subnet *net = 0x0;					// Subnet pointer
		Interface *ifTmp;					// Temporary interface pointer

		if (allSubnets)  
			// Test if row->ip belongs to an existing subnet
			net = listSearch (&params->topology->subnets, row, (void *) rowSubnet);
		else {
			// Test if row->ip belongs to last created subnet
			if (rowSubnet (row, (Subnet *) params->topology->subnets.last->element))
				net = (Subnet *) params->topology->subnets.last->element;
		}
		
		if (net) 
		{	// Found a subnet for current row
			row->netMask = longMask (net->netMask);
			row->assSubnet = net;

#ifdef DEBUG
			debugOut (SUBNET, "Assigning %s ", inet_ntoa (row->ipAddr));
			debugOutNoTime (SUBNET, "to %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif

			if (!row->assNode) 
				// Row is not associated to any node => create it
				icmpRow2NetNode (params, row);
			else {
				// Set netmask of corresponding interface
				ifTmp = listSearch (&row->assNode->interfaces, &row->ipAddr, (void *) ifCmp);
				ifTmp->mask = row->netMask;
			}
			
			// Add node to subnet if not yet present
			if (!listSearch (net->nodes, &row->ipAddr, (void *) nodeCmp))
				listPush (net->nodes, row->assNode);

			// Find subnet Default Gateway if not present
			if (!net->defaultGw.s_addr) defaultGateway (row, net);
		}
	}
}

/*!
  \fn void defaultGateway (IcmpRow *row, Subnet *net)

  \brief This function tries to assing a default gateway to a subnet

  \param row IcmpTable row pointer
  \param net Subnet pointer
*/
void
defaultGateway (IcmpRow *row, Subnet *net)
{
	u_int32_t XOR; 					// IP addresses XOR value
	u_int32_t minXOR = 0xFFFFFFFF;	// IP addresses minimum XOR value
	IcmpRow *precRow = 0x0;			// PrecHop row pointer
	ListEntry *curr;				// List entry pointer

	// Set PrecHop pointer (precHopRR has the precedence)
	if (row->precHopRR) precRow = row->precHopRR;
	else if (row->precHop) precRow = row->precHop;

	if (precRow && precRow->assNode) 
	{	// We have a precHop associated to a node
		for (curr = precRow->assNode->interfaces.head; curr; curr = curr->next) 
		{	// For each row associated node interface
			Interface *ifTmp = curr->element;	// Current interface pointer

			XOR = ntohl (net->netId.s_addr ^ ifTmp->ip.s_addr);
			if (XOR < minXOR) {
				minXOR = XOR;
				// If current interface ip address belongs to subnet, set as default gateway
				if (ipSubnet(&ifTmp->ip, net)) net->defaultGw = ifTmp->ip;
			}
		}
	}
}

/*!
  \fn NetNode *icmpRow2NetNode (ThreadParam *params, IcmpRow *row)

  \brief This function creates a node from an IcmpTable row and associate them

  \param row IcmpTable row pointer

  \return pointer to new node
*/
NetNode *
icmpRow2NetNode (ThreadParam *params, IcmpRow *row)
{
	// Allocate node dynamic memory
	Interface *ifTmp = calloc (1, sizeof(Interface));
	row->assNode = calloc (1, sizeof (NetNode));

	// Set node properties
	if (row->ipDNS) row->assNode->name = row->ipDNS;
	else {
		row->assNode->name = calloc (7, sizeof(char));
		sprintf (row->assNode->name, "Dev%d", params->nodeCount++);
	}
	row->assNode->type = (NodeType) row->router;
	listInit (&row->assNode->interfaces);

	// Set interface properties
	ifTmp->ip = row->ipAddr;
	ifTmp->mask = row->netMask;
	listPush (&row->assNode->interfaces, ifTmp);

	return row->assNode;
}

/*!
  \fn struct in_addr keshav (List *rows)

  \brief This function executes Keshav euristic to obtain a netmask from a list of ip addresses

  \param row IcmpTable row pointer
  \return pointer to new node
*/
struct in_addr
keshav (List *rows)
{
	struct in_addr cumulativeAnds = { 0xFFFFFFFF };	// Cumulative ANDs value
	struct in_addr cumulativeOrs = { 0 };			// Cumulative ORs value
	struct in_addr netMask;							// Netmask address
	struct in_addr tmpMask;							// Temporary netmask value
	u_int32_t netId, bcast;							// Subnet id and broadcast values
	ListEntry *curr;								// List entry pointer
	int i;

	// Calculate cumulative Ands and Ors
	for (curr = rows->head; curr; curr = curr->next) 
	{	// For each row in list
		IcmpRow *rowTmp = curr->element;	// Current row pointer
		cumulativeAnds.s_addr = cumulativeAnds.s_addr & rowTmp->ipAddr.s_addr;
		cumulativeOrs.s_addr = cumulativeOrs.s_addr | rowTmp->ipAddr.s_addr;
	}

	// Execute NOT of XOR of cumulative Ands and Ors
	netMask.s_addr = ~(cumulativeAnds.s_addr ^ cumulativeOrs.s_addr);

	inet_aton ("255.255.255.252", &tmpMask);

	// Correct netmask
	for (i=0; i<25; i++) {
		if (htonl(netMask.s_addr) >= htonl(tmpMask.s_addr)) {
			netMask.s_addr = tmpMask.s_addr;
			break;
		}
		tmpMask.s_addr = ntohl( htonl (tmpMask.s_addr) << 1);
	}

	// Test if one of addresses in list is equal to netId or broadcast address
	netId = ((IcmpRow*)rows->head->element)->ipAddr.s_addr & netMask.s_addr;
	bcast = netId | (~netMask.s_addr);
	for (curr = rows->head; curr; curr = curr->next) 
	{	// For each row in list
		IcmpRow *rowTmp = curr->element;	// Current row pointer
		
		if (rowTmp->ipAddr.s_addr == netId || rowTmp->ipAddr.s_addr == bcast) 
		{	// Shift netmask of 1 bit to include also this address
			netMask.s_addr = ntohl( htonl (tmpMask.s_addr) << 1);
			break;
		}
	}
	
	return netMask;
}

