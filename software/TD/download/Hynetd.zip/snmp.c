/***************************************************************************
                snmp.c
                SNMP query functions implementation

                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "snmp.h"

/*!
  \fn snmpSetup (OidVars *oids);

  \brief This function initializes SNMP library and names of an OID variables set.

  \param oids is a structure containing a set of OID names to be filled up.
*/
void snmpSetup (OidVars *oids)
{
	init_snmp ("snmpapp");	// Initialize the SNMP library
	
	// Initialize OIDs strings
	oids->sysDescr = strdup ("1.3.6.1.2.1.1.1.0");
	oids->ipForwarding = strdup ("1.3.6.1.2.1.4.1.0");
	oids->ipAdEntAddr = strdup ("1.3.6.1.2.1.4.20.1.1");
	oids->ipAdEntIfIndex = strdup ("1.3.6.1.2.1.4.20.1.2");
	oids->ipAdEntNetMask = strdup ("1.3.6.1.2.1.4.20.1.3");
	oids->ifSpeed = strdup ("1.3.6.1.2.1.2.2.1.5");
	oids->defaultGw = strdup ("1.3.6.1.2.1.4.21.1.7.0.0.0.0");
	oids->ipNetToMediaNetAddress = strdup ("1.3.6.1.2.1.4.22.1.3");
	oids->ipNetToMediaPhysAddress = strdup ("1.3.6.1.2.1.4.22.1.2");
	oids->ipRouteDest = strdup ("1.3.6.1.2.1.4.21.1.1");
	oids->ipRouteMask = strdup ("1.3.6.1.2.1.4.21.1.11");
	oids->ipRouteType = strdup ("1.3.6.1.2.1.4.21.1.8");
	oids->ipRouteNextHop = strdup ("1.3.6.1.2.1.4.21.1.7");
}

/*!
  \fn int snmpGet (SnmpOpt opt, void *value)

  \brief This function extracts with SNMP a Gauge32 type data from an OID.

  This function extracts from dest, using an SNMP Get message, the value
  corresponding to the type and the OID specified in opt.

  \param opt is a structure containing SNMP options.
  \param value points to the value extracted.
  \return 1 if ok, 0 on error.
*/
int snmpGet (SnmpOpt opt, void *value)
{
	struct snmp_pdu *pdu;				// Outgoing PDU pointer
	struct snmp_pdu *response;			// Incoming PDU pointer
	struct variable_list *vars;			// Variable list pointer
	oid root[MAX_OID_LEN];				// OID name
	size_t rootlen = MAX_OID_LEN;		// OID length
	int status = 0;						// Snmp send return status
	int count = 0;						// Variable counter
	unsigned int *intValue = value;		// Extracted variable casted as int
	struct in_addr *ipValue = value;	// Extracted variable casted as in_addr

	// Prepares the PDU
	pdu = snmp_pdu_create (SNMP_MSG_GET);
	read_objid (opt.oid, root, &rootlen);
	snmp_add_null_var (pdu, root, rootlen);

	status = snmp_sess_synch_response (opt.session, pdu, &response);	// Sends the Request out.

	// Process the response received
	// SUCCESS: Print the result variables
	if (status == STAT_SUCCESS && response->errstat == SNMP_ERR_NOERROR) {
		for (vars = response->variables; vars; vars = vars->next_variable) {
			switch (opt.type){
				case ASN_GAUGE:
					// Estracts integer from response
					if (vars->type == ASN_GAUGE) {
						*intValue = *vars->val.integer;
						count = 1;
					}
					else printf ("value #%d is NOT a gauge! Ack!\n", count);
				break;
				case ASN_INTEGER:
					// Estracts integer from response
					if (vars->type == ASN_INTEGER) {
						*intValue = *vars->val.integer;
						count = 1;
					}
					else printf ("value #%d is NOT an integer! Ack!\n", count);
				break;
				case ASN_IPADDRESS:
					// Estracts IP address from response
					if (vars->type == ASN_IPADDRESS) {
						char address[16];
						u_char *ipAddr = vars->val.string;

						sprintf (address, "%d.%d.%d.%d", ipAddr[0], ipAddr[1],	ipAddr[2], ipAddr[3]);
						inet_aton (address, ipValue);
						count = 1;
					}
					else printf ("value #%d is NOT an IP address! Ack!\n", count);
				break;
			}
		}
	}
	// FAILURE
	else count = 0;

	// Frees PDU
	if (response) snmp_free_pdu (response);

	return count;
}

/*!
  \fn int snmpGetNext (SnmpOpt opt, List *list)
  \brief Extracts with SNMP an array of values from an OID.

  This function extracts from dest, using an SNMP Get-Next message, an array of values corresponding to
  the type and the OID specified in opt and returns the array's elements number.

  \param opt is a structure containing SNMP options.
  \param array points to the array estracted
  \return array's elements number or -1 on error
*/
int snmpGetNext (SnmpOpt opt, List *list)
{
	struct snmp_pdu *pdu;				// Outgoing PDU pointer
	struct snmp_pdu *response;          // Incoming PDU pointer
	struct variable_list *vars;         // Variable list pointer
	oid name[MAX_OID_LEN];              // OID current name
	size_t name_length = MAX_OID_LEN;   // OID current length
	oid root[MAX_OID_LEN];              // OID name
	size_t rootlen = MAX_OID_LEN;       // OID length
	int status = 0;						// Snmp send return status
	bool running = true;				// Loop exit condition
	int count = 0;						// Variable counter

	listInit (list);	// Initialize list

	// Sets OIDs values
	read_objid (opt.oid, name, &name_length);
	read_objid (opt.oid, root, &rootlen);

	while (running) {
		// Prepares the PDU
		pdu = snmp_pdu_create (SNMP_MSG_GETNEXT);
		snmp_add_null_var (pdu, name, name_length);

		status = snmp_sess_synch_response (opt.session, pdu, &response); // Sends the Request out

		// Process the response received
		// SUCCESS: Extract resulting variables
		if (status == STAT_SUCCESS) {
			if (response->errstat == SNMP_ERR_NOERROR) {
				// Check resulting variables
				for (vars = response->variables; vars; vars = vars->next_variable) {
					// Not part of this subtree
					if ((vars->name_length < rootlen) || (memcmp (root, vars->name, rootlen * sizeof (oid)) != 0)) {
						running = false;
						continue;
					}
					// Not an exception value
					if (vars->type != SNMP_ENDOFMIBVIEW && vars->type != SNMP_NOSUCHOBJECT &&
						vars->type != SNMP_NOSUCHINSTANCE) {
						switch (opt.type){
							case ASN_GAUGE:
								// Estracts integer from response
								if (vars->type == ASN_GAUGE) {
									unsigned int *tmp = (unsigned int *) malloc (sizeof (unsigned int));
									*tmp = *vars->val.integer;
									listPush (list, tmp);
									count++;
								}
								else printf ("value #%d is NOT a gauge! Ack!\n", count);
							break;
							case ASN_INTEGER:
								// Estracts integer from response
								if (vars->type == ASN_INTEGER) {
									unsigned int *tmp = (unsigned int *) malloc (sizeof (unsigned int));
									*tmp = *vars->val.integer;
									listPush (list, tmp);
									count++;
								}
								else printf ("value #%d is NOT an integer! Ack!\n", count);
							break;
							case ASN_IPADDRESS:
								// Estracts IP address from response
								if (vars->type == ASN_IPADDRESS) {
									struct in_addr *tmp = (struct in_addr *) malloc (sizeof (struct in_addr));
									char address[16];
									u_char *ipAddr = vars->val.string;

									sprintf (address, "%d.%d.%d.%d", ipAddr[0], ipAddr[1],	ipAddr[2], ipAddr[3]);
									inet_aton (address, tmp);
									listPush (list, tmp);
									count++;
								}
								else printf ("value #%d is NOT an IP address! Ack!\n", count);
							break;
						}
						// Saves in name the last OID received
						memmove ((char *) name, (char *) vars->name, vars->name_length * sizeof (oid));
						name_length = vars->name_length;
					}
					// An exception value, so stop
					else {
						running = false;
						continue;
					}
				}
			}
			// Error in response, print it
			else {
				running = false;
				fprintf (stderr, "Error in packet.\nReason: %s\n", snmp_errstring (response->errstat));
				if (response->errstat == SNMP_ERR_NOSUCHNAME) {
					fprintf (stderr, "The request for this object identifier failed: ");
					if (vars)
						fprint_objid (stderr, vars->name, vars->name_length);
					fprintf (stderr, "\n");
				}
			}
		}
		// TIMEOUT
		else if (status == STAT_TIMEOUT) {
			struct snmp_session *sptr = snmp_sess_session (opt.session);	// Get snmp session pointer
			fprintf (stderr, "Timeout: No Response from %s\n", sptr->peername);
			running = false;
			count = -1;
		}
		// FAILURE: print what went wrong!
		else {
			snmp_perror ("snmpwalk");
			running = false;
			count = -1;
		}

		// Frees PDU
		if (response) snmp_free_pdu (response);
	}

	return count;
}

