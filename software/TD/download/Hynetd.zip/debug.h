/***************************************************************************
                debug.h 
                Debug logging functions definition
 
                -------------------
    begin       : 28/03/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/********************* Included Libraries **********************/

#include "types.h"
#include <stdio.h>

#ifndef _DEBUG_H
#define _DEBUG_H

/******************** Constants Declaration ********************/

#define LOG_FILE_NUM 11

// LogFile Identifiers
typedef enum {
	PING,		// Log file id for ping() debug output
	MASK,		// Log file id for icmpMask() debug output
	BACKTRACE,	// Log file id for backtrace() debug output
	PINGRR,		// Log file id for pingrr() debug output
	ALLY,		// Log file id for ally() debug output
	SNMPCLIENT,	// Log file id for snmpclient() debug output
	SCANNER,	// Log file id for scanner() debug output
	SCAN,		// Log file id for scan() debug output
	ALIAS,		// Log file id for alias2Routers() debug output
	COUPLES,	// Log file id for alias resolution couples debug output
	SUBNET		// Log file id for extractSubnets() debug output
} LogFile;

/******************** Functions Declaration ********************/

/*!
  \fn void debugOut (LogFile id, const char *message, ...);

  \brief This function sends debug output to id log file
  
  \param LogFile log file identifier
  \param message debug message
*/
void debugOut (LogFile id, const char *message, ...);

/*!
  \fn void debugOutNoTime (LogFile id, const char *message, ...);

  \brief This function sends debug output to id log file without timestamp

  \param LogFile log file identifier
  \param message debug message
*/
void debugOutNoTime (LogFile id, const char *message, ...);

/*!
  \fn int debugInit (LogFile id);

  \brief This function opens debug output files

  \return number of log files opened  
*/
int debugInit (LogFile id);

/*!
  \fn int debugReset (void);

  \brief This function closes debug output files

  \return number of log files closed  
*/
int debugReset (void);

#endif
