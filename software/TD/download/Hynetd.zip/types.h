/***************************************************************************
                types.h 
                Common types definition

                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _TYPES_H
#define _TYPES_H

#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdio.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <net/ethernet.h>
#include <string.h>
#include <stdlib.h>
#include "list.h"

/******************** Data Types Definition ********************/

#ifndef _BOOL_
#define _BOOL_
typedef enum {false, true} bool;	/*!< Boolean type */
#endif

// Interface
typedef struct Interface {
	struct in_addr ip;		/*!< IP address */
	struct in_addr mask;	/*!< Netmask */
	unsigned int speed;		/*!< Interface speed in bps */
	List arpTable;			/*!< Arp Table */
} Interface;

// ARP Table row
typedef struct ArpTableRow {
	struct in_addr ip;		/*!< IP address */
	//struct ether_addr mac;	/*!< MAC address */
} ArpTableRow;

typedef enum {HOST, ROUTER} NodeType;	// Node type

// Network node
typedef struct NetNode {
	char *name;					/*!< Node name */
	u_char *SNMPCommunity;		/*!< Community string (if present) */
	NodeType type;				/*!< Type of node (Host/Router) */
	struct in_addr defaultGw;	/*!< Default gateway */
	List nonDirectSubnets;		/*!< List of routes to Subnets non directly connected */
	List interfaces;			/*!< Interface list */
	List nextHops;				/*!< NextHops list */
} NetNode;

// Network link
typedef struct NetLink {
	bool snmp;				/*!< Link obtained from SNMP */
	unsigned int speed;		/*!< Link speed in bps */
	u_int8_t hop;			/*!< Hop distance from HyNeTD host */
	NetNode *srcNode;		/*!< Pointer to source node */
	NetNode *dstNode;		/*!< Pointer to destination node */
	Interface *srcIf;		/*!< Pointer to source interface */
	Interface *dstIf;		/*!< Pointer to destination interface */
} NetLink;

typedef enum {EXACT, EURISTIC} Reliability;	// Obtained info reliability 

// Subnet
typedef struct Subnet {
	struct in_addr netId;		/*!< Subnet ID */
	u_int8_t netMask;			/*!< Synthetic netmask notation */
	union {
		struct in_addr defaultGw;	/*!< Default gateway */
		struct in_addr nextHop;		/*!< Next hop towards this subnet */
	};
	Reliability type;			/*!< Reliability of informations about the subnet (Exact/Euristic) */
	u_int8_t hop;				/*!< Hop distance from HyNeTD host */
	List *nodes;				/*!< List of nodes discovered in this subnet */
} Subnet;

// Topology
typedef struct Topology {
	List routers;	/*!< List of found nodes */
	List links;		/*!< List of found links */
	List subnets;	/*!< List of found subnets */
} Topology;

typedef enum {TRACEROUTE, RECORDROUTE, BOTH} Accuracy;	// Data Accuracy

// Icmp row element
typedef struct IcmpRow {
	struct in_addr ipAddr;		/*!< Address IP */
	struct in_addr netMask;		/*!< NetMask value */
	struct IcmpRow *precHop;	/*!< Preceding Hop by TraceRoute */
	struct IcmpRow *nextHop;	/*!< Next Hop by TraceRoute */
	struct IcmpRow *precHopRR;	/*!< Preceding Hop by Ping with Record Route */
	struct IcmpRow *nextHopRR;	/*!< Next Hop by Ping with Record Route */
	char *ipDNS;				/*!< Domain Name */
	u_int8_t hop;				/*!< Number of hops from source */
	Accuracy accuracy;			/*!< Method based data accuracy */
	Reliability accuNetMask;	/*!< NetMask Accuracy. EURISTIC if got by Keshav's Heuristics, EXACT otherwise */
	bool router;				/*!< Does ipAddr belong to a router? */
	struct in_addr alias;		/*!< Early detected alias address */
	struct in_addr aliasRR;		/*!< Early detected alias address using pingRR */
	struct in_addr dest;		/*!< Destination IP address used when the row is added */
	NetNode *assNode;			/*!< Pointer to row associated node */
	Subnet *assSubnet;			/*!< Pointer to row associated subnet */
} IcmpRow;

/******************** Functions Declaration ********************/

/*!
  \fn u_int8_t shortMask (const struct in_addr mask)

  \brief Converts a netmask address in synthetic format.

  \param mask the netmask to convert
  \return short netmask value
*/
u_int8_t shortMask (const struct in_addr mask);

/*!
  \fn struct in_addr longMask (const u_int8_t sMask)

  \brief Converts a synthetic netmask in normal 32 bit format

  \param sMask the netmask to convert
  \return netmask value
*/
struct in_addr longMask (const u_int8_t sMask);

/*!
  \fn bool icmpRowCmp (struct in_addr *ip, IcmpRow *row)

  \brief Compares row ipAddr attribute with ip

  \param ip ip address pointer
  \param row IcmpTable row pointer
  \return true if equal, false otherwise
*/
bool icmpRowCmp (struct in_addr *ip, IcmpRow *row);

/*!
  \fn bool nextHopCmp (Interface *interface, struct in_addr *nextHop)

  \brief Evaluate if nextHop and interface belong to the same subnet

  \param interface interface pointer
  \param nextHop next hop ip address pointer
  \return true/false
*/
bool
nextHopCmp (Interface *interface, struct in_addr *nextHop);

/*!
  \fn bool nodeNextHopCmp (struct in_addr *ip, NetNode *node)

  \brief Compares node next hop addresses with ip

  \param ip ip address pointer
  \param node net node pointer
  \return true if at least one is equal, false otherwise
*/
bool
nodeNextHopCmp (struct in_addr *ip, NetNode *node);

/*!
  \fn bool nodeCmp (struct in_addr *ip, NetNode *node)

  \brief Compares node interfaces addresses with ip

  \param ip ip address pointer
  \param node net node pointer
  \return true if at least one is equal, false otherwise
*/
bool nodeCmp (struct in_addr *ip, NetNode *node);

/*!
  \fn bool subnetCmp (struct in_addr *netId, Subnet *subnet)

  \brief Compares subnet->netId with netId

  \param netId subnet id pointer
  \param subnet subnet pointer
  \return true if equal, false otherwise
*/
bool subnetCmp (struct in_addr *netId, Subnet *subnet);

/*!
  \fn bool ifCmp (struct in_addr *ip, Interface *itf)

  \brief Compares interface address with ip

  \param ip ip address pointer
  \param itf interface pointer
  \return true if equal, false otherwise
*/
bool ifCmp (struct in_addr *ip, Interface *itf);

/*!
  \fn bool ipCmp (struct in_addr *ip1, struct in_addr *ip2)

  \brief Compares ip1 and ip2 addresses

  \param ip1 first ip address pointer
  \param ip2 second ip address pointer
  \return true if equal, false otherwise
*/
bool ipCmp (struct in_addr *ip1, struct in_addr *ip2);

/*!
  \fn bool linkCmp (NetLink *link1, NetLink *link2)

  \brief Compares two links

  \param link1 first link pointer
  \param link2 second link pointer
  \return true if equal, false otherwise
*/
bool linkCmp (NetLink *link1, NetLink *link2);

/*!
  \fn bool ipLinkCmp (struct in_addr *ip, NetLink *link)

  \brief Tests if ip belongs to link

  \param ip ip address pointer
  \param link link pointer
  \return true/false
*/
bool ipLinkCmp (struct in_addr *ip, NetLink *link);


/*!
  \fn bool ipSubnet (struct in_addr *ip, Subnet *subnet)

  \brief Test if ip belongs to subnet

  \param ip ip address pointer
  \param subnet subnet pointer
  \return true/false
*/
bool ipSubnet (struct in_addr *ip, Subnet *subnet);

/*!
  \fn bool rowSubnet (IcmpRow *row, Subnet *subnet)

  \brief Test if row->ipAddr belongs to subnet, where subnet is bigger than row->assSubnet

  \param row IcmpTable row pointer
  \param subnet subnet pointer
  \return true/false
*/
bool rowSubnet (IcmpRow *row, Subnet *subnet);

/*!
  \fn bool nodeAddrCmp (NetNode *node1, NetNode *node2)

  \brief Compares node1 and node2 memory address

  \param node1 first net node pointer
  \param node2 second net node pointer
  \return true if equal, false otherwise
*/
bool nodeAddrCmp (NetNode *node1, NetNode *node2);

/*!
  \fn bool subnetInclude (Subnet *net, Subnet *subnet)

  \brief Test if net includes subnet

  \param net first subnet pointer
  \param subnet second subnet pointer
  \return true/false
*/
bool subnetInclude (Subnet *net, Subnet *subnet);

#endif
