/***************************************************************************
                scanner.h 
                Network discovery functions definitions
 
                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _SCANNER_H
#define _SCANNER_H

/************************ Included Libraries ********************************/

#include "types.h"
#include "list.h"
#include "snmp.h"
#include "debug.h"
#include "output.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/types.h>
#include <netdb.h>
#include <errno.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <semaphore.h>

/******************** Constants Declaration ********************/

#define IP_SIZE 20			/* IP header dimension in byte */
#define ICMP_SIZE 16		/* ICMP packet dimension in byte */
#define UDP_SIZE 8			/* UDP header dimension in byte */
#define MAX_PACKET 100		/* MAX packet size */
#define IP_SIZE_RR 60		/* Record route option dimension */
#define BIG_UDP_PORT 61234	/* UDP port for traceroute */
#define NROUTES 9			/* Max hop number for RR ping */

/******************** Data Types Definition ********************/

typedef enum {ICMP, UDP} TraceMode;				// Traceroute modes
typedef enum {FORWARD, BACKWARD} TraceOrder;	// Backtrace order

// Traceroute and Backtrace scan states
typedef enum {
	SCANNING, 			// Scan in progress
	DEST_REACHED, 		// Destination reached
	MAX_TTL_REACHED, 	// Maximum TTL value reached before destination
	DEST_FILTERED, 		// All Packets filtered from source to dest
	DEST_UNREACHABLE	// Destination can not be reached
} TraceState;

// IP Range
typedef struct IpRange {
	struct in_addr startAddr;	/*!< First IP address of the range */
	u_int16_t numAddr;			/*!< Number of addresses in the range */
} IpRange;

// Snmp enabled node
typedef struct SnmpNode {
	struct in_addr addr;		/*!< Detected interface address */
	u_char *SNMPCommunity;		/*!< Community string */
	NodeType type;				/*!< Type of node (Host/Router) */
	List interfaces;			/*!< Interfaces list */
	int skipIndex;				/*!< Index of INADDR_ANY interface, if present */
} SnmpNode;

// Global Options
typedef struct GlobalOptions {
	u_int8_t retries;		/*!< Number of retries if no answer received (Generic) */
	u_int8_t retriesSnmp;	/*!< Number of retries if no answer received (SnmpTest) */
	u_int8_t retriesAlly;	/*!< Number of retries if no answer received (Ally) */
	u_int8_t max_ttl;		/*!< Maximum value of TTL to use in traceroute*/
	u_int8_t default_ttl;	/*!< Default TTL used for outgoing packets */
	u_int16_t timeout;		/*!< Timeout for recvfrom in msec (Generic) */
	u_int16_t timeoutSnmp;	/*!< Timeout for recvfrom in msec (SnmpTest) */
	u_int16_t timeoutAlly;	/*!< Timeout for recvfrom in msec (Ally) */
	TraceMode mode;			/*!< Traceroute preferred mode */
	u_int16_t threads;		/*!< Maximum number of concurrent threads */
	bool dns;				/*!< DNS query enabled */
	bool arp;				/*!< ARP table retrieving enabled */
	bool verbose;			/*!< Verbose mode enabled */
	OidVars *oids;			/*!< Pointer to OID vars structure */
	List communitySNMP;		/*!< Snmp community strings list */
	List rangesIP;			/*!< Ip ranges list */
} GlobalOptions;

// Thread parameters
typedef struct ThreadParam {
	Topology *topology;		/*!< Pointer to final topology struct */
	List *visited;			/*!< Pointer to SNMP visited addresses list */
	List *snmpList;			/*!< Pointer to SNMP detected nodes list */
	List *icmpTab;			/*!< Pointer to table containing active method results */
	GlobalOptions *gOpts;	/*!< Pointer to Scan options */
	sem_t *scanSem;			/*!< Pointer to Scanner Semaphore */
	sem_t *snmpSem;			/*!< Pointer to SNMP Semaphore */
	sem_t *scannerSemA;		/*!< Pointer to Scanner thread Semaphore A */
	sem_t *scannerSemB;		/*!< Pointer to Scanner thread Semaphore B */
	u_int8_t threadNum;		/*!< Thread number for debugging purpose */
	ListEntry *currRow;		/*!< Shared IcmpTab iterator */
	ListEntry *currNode;	/*!< Shared Nodes iterator */
	u_int8_t sync;			/*!< Threads synchronization counter */
	u_int16_t nodeCount;	/*!< Nodes counter for unique node naming*/
} ThreadParam;

// Local Options
typedef struct LocalOptions {
	u_int8_t threadNum;		/*!< Thread number for debugging purpose */
	u_int8_t ttl;			/*!< Initial value of TTL to use in backtrace */
	ThreadParam *params;	/*!< Pointer to thread parameters struct */
} LocalOptions;

// Options
typedef struct Options {
	GlobalOptions *gOpts;	/*!< Global options */
	LocalOptions *lOpts;	/*!< Local options */
} Options;

// Path collected informations
typedef struct Path {		
	u_int8_t length;		/*!< Length of Addresses/Interfaces list */
	u_int8_t offset;		/*!< First address in array offset */
	struct in_addr *array;	/*!< IP Address list */
	IcmpRow **newRows;		/*!< New IcmpTab list element pointer vector */
	IcmpRow *aliasRow;		/*!< Early alias list element pointer vector */
} Path;

// IcmpTab Row couple
typedef struct RowCouple {
	IcmpRow *first;		/*!< First IcmpTable row */
	IcmpRow *second;	/*!< Second IcmpTable row */
} RowCouple;

typedef enum {NOT_ALIASES, ALIASES, NONE, TIMEOUT1, TIMEOUT2} AliasState;	// Alias decision

/******************** Functions Declaration ********************/

/*!
  \fn unsigned short cksum (unsigned short *addr, int len)
  \brief Calculate the check sum of an IP header.

  The checksum is calculated by considering the entire IPheader as a sequence
  of 16-bit words, adding them up using ones complement arithmetic, and taking
  the ones complement of the result.

  \param addr is the value to calculate the checksum.
  \param len is the lenght of the value.
  \return Return the checksum value.
*/
unsigned short cksum (unsigned short *addr, int len);

/*!
  \fn u_int8_t getDefaultTTL (void)

  \brief Reads the default TTL value used for outgoing packets from /proc/sys/net/ipv4/ip_default_ttl.

  \return Returns the default TTL value used for outgoing packets.
*/
u_int8_t getDefaultTTL (void);

/*!
  \fn int traceroute (struct in_addr addr, Options *opt, Path *path)
  \brief This function executes traceroute algorithm to destination addr and returns an array with the path discovered
	 
  \param addr Address to send a traceroute
  \param opt Structure containing options values
  \param path Pointer to a path structure
  \return Return an exit status code (see scanner.h)
*/
int traceroute (struct in_addr, Options *, Path *);

/*! 
  \fn int pingrr (struct in_addr addr, Options *opt, Path *path)
  \brief This Function sends a Ping with Record Route Option
		
  \param addr Destination address
  \param opt Structure containing options values
  \param path Pointer to a path structure
  \return Return an exit status code (0 on error, 1 on ok, 2 on alias)
*/
int pingrr (struct in_addr addr, Options *opt, Path *);

/*! 
  \fn bool ping (struct in_addr addr, Options *opt)
  \brief This Function sends a Ping to discover active nodes
		
  \param addr Destination address
  \param opt Structure containing options values
  \return Return if the node is active
*/
bool ping (struct in_addr addr, Options *opt);

/*! 
  \fn SnmpNode *testSnmp (struct in_addr addr, Options *opt)
  \brief This function tests if addr has SNMP enabled using each SNMP community in the list 
		
  \param addr Destination address
  \param opt Structure containing options values
  \return pointer to SnmpNode struct if success, NULL pointer if not
*/
SnmpNode *testSnmp (struct in_addr addr, Options *opt);

/*! 
  \fn NetNode *snmpclient (SnmpNode *node, GlobalOptions *gOpts, u_int16_t *nodeCount)

  \brief This function executes some SNMP queries to obtain needed information about node
		
  \param node Pointer to structure containing node's address, type and community
  \param gOpts Pointer to structure containing options values
  \param nodeCount Pointer to global counter used to assign unique node names
  \return a pointer to a new NetNode structure containing obtained information
*/
NetNode *snmpclient (SnmpNode *node, GlobalOptions *gOpts, u_int16_t *nodeCount);

/*! 
  \fn void *scanner (void *arg)
  \brief This function implements the generic scanner thread that acquires information on the network

  \param arg Pointer to thread parameters
*/
void *scanner (void *arg);

/*!
  \fn int scan (ThreadParam *params)
  \brief This Function manages threads during the analysis of the network and executes some non threaded operations.

  \param params Parameters nedeed by scanner threads
  \return Return an exit status code
*/
int scan (ThreadParam *params);

/*! 
  \fn struct in_addr icmpMask (struct in_addr addr, Options *opt);
  \brief This Function sends an ICMP_MASK_REQUEST to addr and returns the mask obtained or 0.0.0.0.

  \param addr Destination address
  \param opt Structure containing options values
  \return Returns a pointer the resulting netmask or 0.0.0.0
*/
struct in_addr icmpMask (struct in_addr addr, Options *opt);

/*!
  \fn int backtrace (struct in_addr addr, Options *opt, List *icmpTab, Path *hops)
  \brief This function executes a traceroute in inverse order to an addr and returns an array with the path
	 
  \param addr Address to send a traceroute
  \param opt Structure containing options values
  \param icmpTab Table containing active method results
  \param path Pointer to a path structure
  \return Return an exit status code (see scanner.h)
*/
int backtrace (struct in_addr addr, Options *opt, List *icmpTab, Path *hops);

/*!
  \fn ally (Options *opt, const struct in_addr addr1, const struct in_addr addr2)
  \brief This function implements the Ally algorithm to test if addr1 and addr2 are aliases

  \param opt Structure containing options values
  \param addr1 First address
  \param addr2 Second address
  \return Return the finale state of the couple
*/
AliasState ally (Options *opt, const struct in_addr addr1, const struct in_addr addr2);

/*!
  \fn void alias2Routers (ThreadParam *params, RowCouple *couple)
  \brief This function form a couple of IcmpTable rows creates or modifies topology routers

  \param params pointer to generic thread parameters
  \param couple row couple to add to topology
*/
void alias2Routers (ThreadParam *params, RowCouple *couple);

/*!
  \fn AliasState allyPrevention (LocalOptions *lOpt, IcmpRow *row1, IcmpRow *row2)
  \brief This function tests ally prevention rules on a couple of IcmpTable rows

  \param lOpts pointer to local thread options
  \param row1 row couple to add to topology
  \param row2 true if the couple are aliases
  \return the decision state
*/
AliasState allyPrevention (LocalOptions *lOpt, IcmpRow *row1, IcmpRow *row2);

#endif
