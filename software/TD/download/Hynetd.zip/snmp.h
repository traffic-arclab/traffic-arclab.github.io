/***************************************************************************
                snmp.h 
                SNMP data and query functions definitions

                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _SNMP_H
#define _SNMP_H

/************************ Included Libraries ********************************/

#include "types.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>

/******************** Data Types Definition ********************/

// SNMP options
typedef struct SnmpOpt {
	struct in_addr dest;	/*!< SNMP Agent IP address */
	char *oid; 				/*!< Subtree OID number */
	unsigned char type;		/*!< Value type */
	void *session;			/*!< SNMP opaque session pointer */
} SnmpOpt;

// OID vars structure
typedef struct OidVars {
	char *sysDescr;					// 1.3.6.1.2.1.1.1.0
	char *ipForwarding;
	char *ipAdEntAddr;
	char *ipAdEntIfIndex;
	char *ipAdEntNetMask;
	char *ifSpeed;
	char *defaultGw;
	char *ipNetToMediaNetAddress;	// 1.3.6.1.2.1.4.22.1.3
	char *ipNetToMediaPhysAddress;	// 1.3.6.1.2.1.4.22.1.2
	char *ipRouteDest;
	char *ipRouteMask;
	char *ipRouteType;
	char *ipRouteNextHop;
} OidVars;

/******************** Functions Declaration ********************/

/*!
  \fn snmpSetup (OidVars *oids)

  \brief This function initializes names of an OID variables set.

  \param oids structure containing a set of OID names to be filled up
*/
void snmpSetup (OidVars *oids);

/*!
  \fn int snmpGet (SnmpOpt opt, void *value)

  \brief This function extracts a value from an OID.

  This function extracts from dest, using an SNMP Get message, the value corresponding to the type and the OID specified in opt.

  \param opt is a structure containing SNMP options.
  \param value points to the value extracted.
  \return 1 if ok, 0 on error.
*/
int snmpGet (SnmpOpt opt, void *value);

/*!
  \fn int snmpGetNext (SnmpOpt opt, List *list)
  \brief Extracts with SNMP an array of values from an OID.

  This function extracts from dest, using an SNMP Get-Next message, an array of values corresponding to
  the type and the OID specified in opt and returns the array's elements number.

  \param opt is a structure containing SNMP options.
  \param array points to the array estracted
  \return array's elements number or -1 on error
*/
int snmpGetNext (SnmpOpt opt, List *list);

#endif
