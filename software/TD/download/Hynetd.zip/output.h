/***************************************************************************
                output.h
                File/Console output functions definition
 
                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _OUTPUT_H
#define _OUTPUT_H

#include "types.h"

/******************** Functions Declaration ********************/

/*!
  \fn void fprintIcmpTab (FILE *fp, List *icmpTab, bool full)

  \brief Prints IcmpTable into file pointed by fp

  \param fp output file pointer
  \param icmpTab IcmpTable pointer
  \param full print all table columns?
*/
void fprintIcmpTab (FILE *fp, List *icmpTab, bool full);

/*!
  \fn void fprintRouters (FILE *fp, Topology *topology)

  \brief Prints Routers into file pointed by fp

  \param fp output file pointer
  \param topology topology pointer
*/
void fprintRouters (FILE *fp, Topology *topology);

/*!
  \fn void fprintLinks (FILE *fp, Topology *topology)

  \brief Prints Links into file pointed by fp

  \param fp output file pointer
  \param topology topology pointer
*/
void fprintLinks (FILE *fp, Topology *topology);

/*!
  \fn void fprintSubnets (FILE *fp, Topology *topology)

  \brief Prints Subnets into file pointed by fp

  \param fp output file pointer
  \param topology topology pointer
*/
void fprintSubnets (FILE *fp, Topology *topology);

/*!
  \fn void fprintCell (FILE *fp, char *string, u_int8_t numtabs)

  \brief Prints a table cell, using fixed width size as numtabs tabs, into file pointed by fp

  \param fp output file pointer
  \param string string to print in current cell
  \param numtabs cell width as tabs number
*/
void fprintCell (FILE *fp, char *string, u_int8_t numtabs);

/*!
  \fn void xmlLinks (FILE *fp, Topology *topology)

  \brief Prints Links into file pointed by fp using XML standard

  \param fp output file pointer
  \param topology topology pointer
*/
void xmlLinks (FILE *fp, Topology *topology);

/*!
  \fn void xmlSubnets (FILE *fp, Topology *topology)

  \brief Prints Subnets into file pointed by fp using XML standard

  \param fp output file pointer
  \param topology topology pointer
*/
void xmlSubnets (FILE *fp, Topology *topology);

/*!
  \fn void xmlRouters (FILE *fp, Topology *topology)

  \brief Prints Routers into file pointed by fp using XML standard

  \param fp output file pointer
  \param topology topology pointer
*/
void xmlRouters (FILE *fp, Topology *topology);

/*!
  \fn void xmlTopology (FILE *fp, Topology *topology)

  \brief Prints Topology into file pointed by fp using XML standard

  \param fp output file pointer
  \param topology topology pointer
*/
void xmlTopology (FILE *fp, Topology *topology);

/*!
  \fn void dump (void *buffer, int len, int mode)

  \brief Prints generic buffer Dump in formatted Hex, formatted Decimal or dotted decimal Format

  \param buffer Buffer to print
  \param len Lenght of the buffer
  \param mode Byte representation (0 = Hex, 1 = Dec, 2 = Char, 3 = Dotted Decimal)
*/
void dump (void *buffer, int len, int mode);

#endif
