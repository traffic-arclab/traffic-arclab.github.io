/***************************************************************************
                types.c 
                Common types comparison and conversion implementation
 
                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli 
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "types.h"

/******************** Functions implementation ********************/

/*!
  \fn u_int8_t shortMask (const struct in_addr mask)

  \brief Converts a netmask address in synthetic format.

  \param mask the netmask to convert.
  \return Return the short netmask value.
*/
u_int8_t
shortMask (const struct in_addr mask)
{
	int i, rest = 0;
	u_int8_t *byte = (u_int8_t *) &mask;
	u_int32_t tmp;

	// Controls BIG or LITTLE ENDIAN
	if (*byte == 0xFF) tmp = ntohl(mask.s_addr);
	else tmp = mask.s_addr;

	// Count ones number from most significant bit
	for (i=0; i<32 && rest == 0; i++) {
		tmp = (tmp >> 1);
		rest = tmp % 2;
	}

	return 32 - i;
}

/*!
  \fn struct in_addr longMask (const u_int8_t sMask)

  \brief Converts a synthetic netmask in normal 32 bit form

  \param sMask the netmask to convert.
  \return Return the netmask
*/
struct in_addr
longMask (const u_int8_t sMask)
{
	u_int32_t tmp = 0xFFFFFFFF;
	struct in_addr mask;
		
	mask.s_addr = htonl (tmp << (32 - sMask));
	return mask;
}

/*!
  \fn bool icmpRowCmp (struct in_addr *ip, IcmpRow *row)

  \brief Compares row ipAddr attribute with ip

  \param ip ip address pointer
  \param row IcmpTable row pointer
  \return true if equal, false otherwise
*/
bool
icmpRowCmp (struct in_addr *ip, IcmpRow *row)
{
	if (row->ipAddr.s_addr == ip->s_addr) return true;
	else return false;
}

/*!
  \fn bool subnetCmp (struct in_addr *netId, Subnet *subnet)

  \brief Compares subnet->netId with netId

  \param netId subnet id pointer
  \param subnet subnet pointer
  \return true if equal, false otherwise
*/
bool
subnetCmp (struct in_addr *netId, Subnet *subnet)
{
	if (subnet->netId.s_addr == netId->s_addr) return true;
	else return false;
}

/*!
  \fn bool ipSubnet (struct in_addr *ip, Subnet *subnet)

  \brief Test if ip belongs to subnet

  \param ip ip address pointer
  \param subnet subnet pointer
  \return true/false
*/
bool
ipSubnet (struct in_addr *ip, Subnet *subnet)
{
	struct in_addr mask = longMask (subnet->netMask);

	if (subnet->netId.s_addr == (ip->s_addr & mask.s_addr)) return true;
	else return false;
}

/*!
  \fn bool subnetInclude (Subnet *net, Subnet *subnet)

  \brief Test if net includes subnet

  \param net first subnet pointer
  \param subnet second subnet pointer
  \return true/false
*/
bool
subnetInclude (Subnet *net, Subnet *subnet)
{
	if (net->netMask <= subnet->netMask && ipSubnet (&subnet->netId, net)) return true;
	else return false;
}

/*!
  \fn bool rowSubnet (IcmpRow *row, Subnet *subnet)

  \brief Test if row->ipAddr belongs to subnet, where subnet is bigger than row->assSubnet

  \param row IcmpTable row pointer
  \param subnet subnet pointer
  \return true/false
*/
bool
rowSubnet (IcmpRow *row, Subnet *subnet)
{
	struct in_addr mask = longMask (subnet->netMask);

	if (row->assSubnet && subnet->netMask <= row->assSubnet->netMask) return false;
	if (subnet->netId.s_addr == (row->ipAddr.s_addr & mask.s_addr)) return true;
	else return false;
}

/*!
  \fn bool nextHopCmp (Interface *interface, struct in_addr *nextHop)

  \brief Evaluate if nextHop and interface belong to the same subnet

  \param interface interface pointer
  \param nextHop next hop ip address pointer
  \return true/false
*/
bool
nextHopCmp (Interface *interface, struct in_addr *nextHop)
{
	u_int32_t netId = interface->ip.s_addr & interface->mask.s_addr;
	u_int32_t nextHopNet = nextHop->s_addr & interface->mask.s_addr;

	if (netId == nextHopNet && interface->ip.s_addr != nextHop->s_addr) return true;
	else return false;
}

/*!
  \fn bool nodeNextHopCmp (struct in_addr *ip, NetNode *node)

  \brief Compares node next hop addresses with ip

  \param ip ip address pointer
  \param node net node pointer
  \return true if at least one is equal, false otherwise
*/
bool
nodeNextHopCmp (struct in_addr *ip, NetNode *node)
{
	ListEntry *current;

	for (current = node->nextHops.head; current; current = current->next) {
		struct in_addr *nextHop = current->element;

		if (nextHop->s_addr == ip->s_addr) return true;
	}

	return false;
}

/*!
  \fn bool nodeAddrCmp (NetNode *node1, NetNode *node2)

  \brief Compares node1 and node2 memory address

  \param node1 first net node pointer
  \param node2 second net node pointer
  \return true if equal, false otherwise
*/
bool
nodeAddrCmp (NetNode *node1, NetNode *node2)
{
	if (node1 == node2) return true;
	else return false;
}

/*!
  \fn bool nodeCmp (struct in_addr *ip, NetNode *node)

  \brief Compares node interfaces addresses with ip

  \param ip ip address pointer
  \param node net node pointer
  \return true if at least one is equal, false otherwise
*/
bool
nodeCmp (struct in_addr *ip, NetNode *node)
{
	ListEntry *current;
	Interface *ifTmp;

	for (current = node->interfaces.head; current; current = current->next) {
		ifTmp = current->element;

		if (ifTmp->ip.s_addr == ip->s_addr) return true;
	}

	return false;
}

/*!
  \fn bool ifCmp (struct in_addr *ip, Interface *itf)

  \brief Compares interface address with ip

  \param ip ip address pointer
  \param itf interface pointer
  \return true if equal, false otherwise
*/
bool
ifCmp (struct in_addr *ip, Interface *itf)
{
	if (ip->s_addr == itf->ip.s_addr) return true;
	else return false;
}

/*!
  \fn bool ipCmp (struct in_addr *ip1, struct in_addr *ip2)

  \brief Compares ip1 and ip2 addresses

  \param ip1 first ip address pointer
  \param ip2 second ip address pointer
  \return true if equal, false otherwise
*/
bool
ipCmp (struct in_addr *ip1, struct in_addr *ip2)
{
	if (ip1->s_addr == ip2->s_addr) return true;
	else return false;
}

/*!
  \fn bool linkCmp (NetLink *link1, NetLink *link2)

  \brief Compares two links

  \param link1 first link pointer
  \param link2 second link pointer
  \return true if equal, false otherwise
*/
bool
linkCmp (NetLink *link1, NetLink *link2)
{
	if ((link1->srcNode == link2->srcNode &&
		link1->dstNode == link2->dstNode &&
		link1->srcIf->ip.s_addr == link2->srcIf->ip.s_addr) ||
		(link1->srcNode == link2->dstNode &&
		link1->dstNode == link2->srcNode &&
		link1->srcIf->ip.s_addr == link2->dstIf->ip.s_addr)) return true;
	else return false;
}

/*!
  \fn bool ipLinkCmp (struct in_addr *ip, NetLink *link)

  \brief Tests if ip belongs to link

  \param ip ip address pointer
  \param link link pointer
  \return true/false
*/
bool ipLinkCmp (struct in_addr *ip, NetLink *link)
{
	if (link->snmp && ip->s_addr == link->srcIf->ip.s_addr) return true;
	else return false;
}

