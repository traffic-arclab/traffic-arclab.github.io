/***************************************************************************
                hynetd.c
                Application main file
 
                -------------------
    begin       : 26/01/2006
    copyright   : (C) 2006 by Universita' Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <sys/stat.h>
#include <unistd.h>
#include "scanner.h"
#include "postprocessing.h"
#include "output.h"

/******************** Functions implementation ********************/

/*!
  \fn void printHelp ()

  \brief This function visualizes options help screen
*/
void
printHelp ()
{
	printf ("\n SYNOPSIS \n\n"
			" HyNeTD [-h] | [--help] |\n"
			"        [-v] [-d] [-a] [-r[G|S|A] <retries_number>] [-T[G|S|A] <timeout>] [-L <max_ttl>] [-I]\n"
			"        [-c <community_name> [[community_name] ... ]] -t <max_number_of_threads>\n"
			"        <base_address> <address_space_size> [[<base_address> <address_space_size>] ... ]\n");
	
	printf	("\n DESCRIPTION \n\n"
			" Hybrid Network Topology Discovery Tool \n");
	
	printf (" \n OPTIONS \n\n"
			" base_address\t\tthe first address of an ip address range\n"
			" address_space_size\tip address range dimension\n\n");
	
	printf ("\t\t-t\tmax number of threads to generate \n"
			"\t\t-d\tenable DNS inverse name lookup (default = disabled)\n"
			"\t\t-c\tcommunity_name's list to be used in SNMP client requests (default = public)\n"
			"\t\t-a\tenable ARP table extraction (default = disabled)\n"
			"\t\t-r[G|S|A]\tnumber of retries in packet sendings (Generic/SnmpTest/Ally) (defaults = 1/1/1)\n"
			"\t\t-T[G|S|A]\ttimeout value used during scan process in ms (Generic/SnmpTest/Ally) (defaults = 500/500/1000 ms) \n"
			"\t\t-L\tmax value of ttl to use during backtrace process (default = 20)\n"
			"\t\t-I\tset predefinite backtrace mode ICMP (default mode UDP)\n"
			"\t\t-v\tenable verbose mode\n"
			"\t -h --help\tprint this help \n\n");
}

/*!
  \fn int parser (int argc, char **argv, GlobalOptions *options)

  \brief This function parses command-line options

  \param argc arguments count
  \param argv arguments pointers vector
  \param options pointer to global options structure

  \return 0 if ok, -1 on error
*/
int
parser (int argc, char **argv, GlobalOptions *options)
{
	bool threads = false;
	bool haveRange = false;
	
	listInit (&options->rangesIP);
	listInit (&options->communitySNMP);
	
	if (argc > 1) {
		while (argc > 0) {
			if (argv[0][0] == '-') {
				switch (argv[0][1]) {
					case 'd':
						options->dns = true;
						argc--;	argv++;
					break;
					// SNMP community list
					case 'c':		
						argc--;	argv++;
						printf("SNMP community list:\n");
						while((argv[0][0] != '-') && (argc > 0)) {
							listPush (&options->communitySNMP, argv[0]);
							printf("\t%s\n", argv[0]);
							argc--;	argv++;
						}
						printf ("\n");
					break;
					case 'a':
						options->arp = true;
						argc--;	argv++;
					break;
					case 'v':
						options->verbose = true;
						argc--;	argv++;
					break;
					case 'r':
						switch (argv[0][2]) {
							default: 
							case 'G': options->retries = atoi(argv[1]); break;
							case 'S': options->retriesSnmp = atoi(argv[1]); break;
							case 'A': options->retriesAlly = atoi(argv[1]); break;
						}
						argc-=2; argv+=2;
					break;
					case 'T':
						switch (argv[0][2]) {
							default: 
							case 'G': options->timeout = atoi(argv[1]); break;
							case 'S': options->timeoutSnmp = atoi(argv[1]); break;
							case 'A': options->timeoutAlly = atoi(argv[1]); break;
						}
						argc-=2; argv+=2;
					break;
					case 'L':
						argc--;	argv++;
						options->max_ttl = atoi(argv[0]);
						argc--;	argv++;
					break;
					case 'I':
						argc--;	argv++;
						options->mode = ICMP;
					break;
					case 't':
						argc--;	argv++;
						options->threads = atoi(argv[0]);
						threads = true;
						argc--;	argv++;
					break;
					case 'h':
						printHelp();
						exit (0);
					break;
					case '-':
						if (strcmp(argv[0],"--help") == 0) {
							printHelp();
							exit (0);
						}
					break;
					default: return -1;
				}
			}
			
			// Get IP ranges
			else if (threads) {
				if (argc % 2 != 0) {
					printf ("No address space size specified for last range!\n");
					return -1;
				}
				
				printf("Ranges to scan:\n");
				while (argc > 0 && argv[0][0] != '-') {
					IpRange *range = (IpRange *) malloc (sizeof(IpRange));

					inet_aton (argv[0], &range->startAddr);
					range->numAddr = atoi(argv[1]);
					listPush (&options->rangesIP, range);

					printf("\t%s (%d)\n", argv[0], range->numAddr);
					haveRange = true;
					argc -= 2;	argv += 2;
				}
				printf ("\n");fflush (stdout);
			}
			
			// Skip argument
			else {
				argc--;
				argv++;
			}
		}
		
		if (options->communitySNMP.empty) {
			listPush (&options->communitySNMP, strdup ("public"));
			printf("SNMP community list:\n\tpublic\n\n");
		}

		if (!threads) {
			printf ("Max number of threads not specified!!\n");
			return -1;
		}
		
		if (!haveRange) {
			printf ("No range specified!\n");
			return -1;
		}
		
		printf ("Selected Options:\n\tThreads: %d\n\tRetries (G/S/A) = %d / %d / %d\n\tTimeout (G/S/A) = %d / %d / %d ms\n\tmax TTL = %d\n"
				"\tBacktrace preferred mode = %s\n\tDNS aliasing = %s\n\tARP tables retrieving = %s\n\t"
				"Verbose mode = %s\n\n",
				options->threads, options->retries, options->retriesSnmp, options->retriesAlly, 
				options->timeout, options->timeoutSnmp, options->timeoutAlly, options->max_ttl, 
				options->mode ? "UDP" : "ICMP", options->dns ? "ENABLED" : "DISABLED", 
				options->arp ? "ENABLED" : "DISABLED", options->verbose ? "ENABLED" : "DISABLED");
		printf("--------------------------------------------------------------------------\n");
		
		return 0;
	}
	else return -1;
}

/*!
  \fn int main(int argn, char **argv)

  \brief Entry point of HyNeTD tool

  \param argn arguments number
  \param argv arguments pointers vector
*/
int
main(int argn, char **argv)
{
	struct ThreadParam params;	/*!< Structure used to share informations among threads */
	Topology topology;			/*!< Final topology structure */
	List icmpTab;				/*!< Table containing active method results */
	GlobalOptions gOpts;		/*!< Structure containing all options passed by command-line */

	// Output files pointers
	FILE *icmptabFp, *linksFp, *subnetsFp, *routersFp, *xmlFp;

	// CONSOLE OUTPUT
	printf("--------------------------------------------------------------------------\n");
	printf("            HyNeTD v0.2 - (Hybrid Network Topology Discovery)\n\n");
	printf(" copyright: (C) 2006 by Università Degli Studi di Napoli Federico II\n");
	printf(" email    : pescape@unina.it\n");
	printf("--------------------------------------------------------------------------\n");
	printf("\n");

	if (getuid ()) {
		printf ("Root permissions are needed to execute this tool!\n");
		exit (0);
	}

	// Set default options
	gOpts.retries = 1;
	gOpts.retriesSnmp = 1;
	gOpts.retriesAlly = 1;
	gOpts.timeout = 500;
	gOpts.timeoutSnmp = 500;
	gOpts.timeoutAlly = 1000;
	gOpts.max_ttl = 20;
	gOpts.mode = UDP;
	gOpts.dns = false;
	gOpts.arp = false;
	gOpts.verbose = false;

	// Parse options
	if (parser (argn, argv, &gOpts)) {
		printf ("Error parsing options!\n");
		printHelp();
		exit(0);
	}

	// If verbose mode is disabled print symbols meanings
	if (!gOpts.verbose) {
		printf ("Threads output symbols meanings:\n"
				"\t. = Ping timeout\t+ = ICMP info acquired\t* = SNMP enabled\n"
				"\t@ = DNS name acquired\t§ = Aliasing\t\tX = Terminated\n"
				"\t# = Waiting for next step\n"
				"--------------------------------------------------------------------------\n");
	}

	// If logs directory doesn't exists create it
	struct stat sb;
	if (stat("./logs", &sb)) mkdir("./logs", S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH);

	// Open output files
	xmlFp = fopen ("topology.xml","w");
	icmptabFp = fopen ("logs/icmptab.log","w");
	linksFp = fopen ("logs/links.log","w");
	subnetsFp = fopen ("logs/subnets.log","w");
	routersFp = fopen ("logs/routers.log","w");
	
	// Setup parameters
	params.topology = &topology;
	params.icmpTab = &icmpTab;
	params.gOpts = &gOpts;

	// Start Scan process
	scan (&params);

	// CONSOLE AND LOG OUTPUT
	if (gOpts.verbose) fprintIcmpTab (stdout, &icmpTab, false);
	fprintIcmpTab (icmptabFp, &icmpTab, false);

	// Start links extraction
	extractLinks(&params);

	// CONSOLE AND LOG OUTPUT
	fprintLinks (stdout, &topology);
	fprintLinks (linksFp, &topology);
	fprintIcmpTab (icmptabFp, &icmpTab, false);

	// Start subnets extraction
	extractSubnets (&params);

	// CONSOLE AND LOG OUTPUT
	fprintSubnets (stdout, &topology);
	fprintSubnets (subnetsFp, &topology);
	fprintRouters (stdout, &topology);
	fprintRouters (routersFp, &topology);
	fprintIcmpTab (icmptabFp, &icmpTab, false);

	// XML Output
	xmlTopology (xmlFp, &topology);

	// Close output files
	fclose (xmlFp);
	fclose (icmptabFp);
	fclose (routersFp);
	fclose (subnetsFp);
	fclose (linksFp);

#ifdef DEBUG
	debugReset ();
#endif
	return 0;
}

