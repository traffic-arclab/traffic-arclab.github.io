/***************************************************************************
                debug.c 
                Debug logging functions implementation

                -------------------
    begin       : 28/03/2006
    copyright   : (C) 2006 by Università Degli Studi di Napoli
                              Federico II
    email       : pescape@unina.it
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "debug.h"

#include <stdarg.h>
#include <sys/time.h>
#include <time.h>


/******************** Global Variables ********************/

FILE *logFiles[LOG_FILE_NUM];	// Log files pointers vector
bool debugActive[LOG_FILE_NUM];	// Debug state

/******************** Functions implementation ********************/

/*!
  \fn int debugInit (LogFile id);

  \brief This function opens debug output files

  \return numbero of log files opened  
*/
int debugInit (LogFile id)
{
	if (debugActive[id]) return 1;	// Prevent logfiles been opened twice

	switch (id) {
		case PING:			logFiles[id] = fopen ("./logs/ping.log", "w"); break;
		case MASK:			logFiles[id] = fopen ("./logs/mask.log", "w"); break;
		case BACKTRACE: 	logFiles[id] = fopen ("./logs/bt.log", "w"); break;
		case PINGRR: 		logFiles[id] = fopen ("./logs/prr.log", "w"); break;
		case ALLY:			logFiles[id] = fopen ("./logs/ally.log", "w"); break;
		case SNMPCLIENT:	logFiles[id] = fopen ("./logs/snmpc.log", "w"); break;
		case SCANNER:		logFiles[id] = fopen ("./logs/scanner.log", "w"); break;
		case SCAN:			logFiles[id] = fopen ("./logs/scan.log", "w"); break;
		case ALIAS:			logFiles[id] = fopen ("./logs/alias.log", "w"); break;
		case COUPLES:		logFiles[id] = fopen ("./logs/couples.log", "w"); break;
		case SUBNET:		logFiles[id] = fopen ("./logs/subnet.log", "w"); break;
	}
	if (!logFiles[id]) {
		printf ("Unable to create log file %d!\n", id);
		return 2;
	}
	debugActive[id] = true;

	return 0;
}

/*!
  \fn void debugOut (LogFile id, const char *message, ...);

  \brief This function sends debug output to id log file

  \param LogFile log file identifier
  \param message debug message
*/
void debugOut (LogFile id, const char *message, ...)
{
	va_list ap;
	struct timeval t;
	struct tm *now;

	gettimeofday(&t, NULL);
	now = gmtime(&t.tv_sec);

	if (!debugActive[id]) debugInit (id);

	va_start (ap, message);
	fprintf (logFiles[id], "%02d:%02d:%02d.%06d ", 
			(int) now->tm_hour, 
			(int) now->tm_min, 
			(int) now->tm_sec, 
			(int) t.tv_usec);
	vfprintf (logFiles[id], message, ap);
	va_end (ap);
	fflush(logFiles[id]);
}

/*!
  \fn void debugOutNoTime (LogFile id, const char *message, ...);

  \brief This function sends debug output to id log file without timestamp

  \param LogFile log file identifier
  \param message debug message
*/
void debugOutNoTime (LogFile id, const char *message, ...)
{
	va_list ap;

	if (!debugActive[id]) debugInit (id);

	va_start (ap, message);
	vfprintf (logFiles[id], message, ap);
	va_end (ap);
	fflush(logFiles[id]);
}

/*!
  \fn int debugReset (void);

  \brief This function closes all opened debug output files

  \return number of log files closed  
*/
int debugReset (void)
{
	int i;
	
	for (i=0; i<LOG_FILE_NUM; i++) {
		if (debugActive[i]) {
			fclose(logFiles[i]);
			debugActive[i] = false;
		}
	}
	return i;
}
