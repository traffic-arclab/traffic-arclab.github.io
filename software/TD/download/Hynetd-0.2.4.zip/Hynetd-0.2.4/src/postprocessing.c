/*
 *	Component of the Hynetd v0.2.4 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */

 
#include "postprocessing.h"


void
extractLinks (ThreadParam *params)
{
	
	extSnmpLinks (params);
	
	
	if (params->gOpts->heurLinks) extIcmpLinksE (params);
	else extIcmpLinks (params);
}


void extSnmpLinks (ThreadParam *params)
{
	ListEntry *current;		

	
	for (current = params->topology->routers.head; current; current = current->next) 
	{	
		NetNode *node = current->element;	
		ListEntry *curr;					

		if (!node->SNMPCommunity) continue;		
		
		for (curr = node->interfaces.head; curr; curr = curr->next) 
		{	
			Interface *ifTmp = curr->element;	
			struct in_addr *nextHop;			
			
			
			if (ifTmp->ip.s_addr == INADDR_ANY || *((u_int8_t *)&ifTmp->ip.s_addr) == 127) continue;

			
			if (nextHopCmp (ifTmp, &node->defaultGw))
				nextHop = &node->defaultGw;
			else
				nextHop = listSearch (&node->nextHops, ifTmp, (void *) nextHopCmp);
			
			if (nextHop) 
			{	
				NetLink *newLink = calloc (1, sizeof (NetLink));
		
				
				newLink->snmp = true;
				newLink->speed = ifTmp->speed;
				newLink->srcNode = node;
				newLink->srcIf = ifTmp;
		
				if ((newLink->dstNode = listSearch(&params->topology->routers, nextHop, (void *) nodeCmp))) 
				{	
					newLink->dstIf = listSearch (&newLink->dstNode->interfaces, nextHop, (void *) ifCmp);
					newLink->dstIf->speed = ifTmp->speed;
					newLink->dstIf->mask = ifTmp->mask;
				}

				else 
				{	
					
					newLink->dstNode = (NetNode *) calloc (1, sizeof(NetNode));
					newLink->dstIf = (Interface *) calloc (1, sizeof(Interface));
		
					
					newLink->dstNode->type = ROUTER;
					newLink->dstNode->name = calloc (7, sizeof(char));
					sprintf (newLink->dstNode->name, "Dev%d", params->nodeCount++);
					listInit (&newLink->dstNode->nonDirectSubnets);
					listInit (&newLink->dstNode->interfaces);
					listInit (&newLink->dstNode->nextHops);

					
					newLink->dstIf->ip = *nextHop;
					newLink->dstIf->mask = ifTmp->mask;
					newLink->dstIf->speed = ifTmp->speed;
					listPush (&newLink->dstNode->interfaces, newLink->dstIf);
		
					
					listPush (&params->topology->routers, newLink->dstNode);
#ifdef DEBUG
					debugOut (ALIAS, "Created node %s (%s)\n", newLink->dstNode->name, inet_ntoa (newLink->dstIf->ip));
#endif
				}
		
				if (!listSearch (&params->topology->links, newLink, (void *) linkCmp)) 
					
					listPush(&params->topology->links, newLink);
				else
					
					free (newLink);
			}
		}
	}
}


void extIcmpLinks (ThreadParam *params)
{
	ListEntry *current;		

	
	Interface *nullIf = calloc (1, sizeof(Interface));	
	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	
		IcmpRow *row = current->element;	

		if (row->precHop || row->precHopRR) {
			ListEntry *curr2, *curr3;								
			u_int32_t XOR;											
			u_int32_t minXOR = 0xFFFFFFFF;							
			u_int32_t mask = ntohl (0xFFFFFFFC);					
			struct in_addr netId = { row->ipAddr.s_addr & mask };	

			
			if (htonl (row->ipAddr.s_addr & ~mask) == 0 ||
				htonl (row->ipAddr.s_addr & ~mask) == 3) continue;

			
			
			if (!row->router) 
			{	
				if (row->precHopRR) 
				{	
					bool found = false;
					
					
					if ((row->precHopRR->ipAddr.s_addr & mask) != netId.s_addr) continue;
					
					
					if (htonl (row->precHopRR->ipAddr.s_addr & ~mask) == 0 ||
						htonl (row->precHopRR->ipAddr.s_addr & ~mask) == 3) continue;
				
					for (curr2 = params->icmpTab->head; curr2; curr2 = curr2->next) 
					{	
						IcmpRow *rowTmp = curr2->element;	
						
						if (row != rowTmp && rowTmp->precHopRR == row->precHopRR) 
						{	
							LocalOptions lOpt = {0, 0, params};				
							Options opt = {params->gOpts, &lOpt};			
							
							
							if (row->router && rowTmp->router) {
								if (row->assNode != rowTmp->assNode) {
									found = true;
									break;
								}
							}
							else {
								
								AliasState result = allyPrevention (&lOpt, rowTmp, row);
	
								
								if (result == NONE) {
									result = ally (&opt, rowTmp->ipAddr, row->ipAddr);
#ifdef DEBUG
									debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(rowTmp->ipAddr));
									debugOutNoTime (ALIAS, " %s) are %s alias (Ally%s)\n", inet_ntoa(row->ipAddr),
											result == ALIASES ? "" : "not", result > 1 ? "" : " sure");
#endif
								}

								if (result != ALIASES) {
									found = true;
									break;
								}
								else 
								{	
									RowCouple couple = {row, rowTmp};
									alias2Routers (params, &couple);
								}
							}
						}
					}
					
					if (found) continue;
				}
				else continue;
				
				
				row->router = true;
				if (!row->assNode)
					listPush (&params->topology->routers, icmpRow2NetNode (params, row));
				else row->assNode->type = ROUTER;
			}

			
			NetLink *newLink = calloc (1, sizeof (NetLink));		
			newLink->dstNode = row->assNode;
			newLink->hop = row->hop - 1;
			
			if (row->precHopRR) 
			{	
				
				newLink->srcNode = row->precHopRR->assNode;
				newLink->srcIf = listSearch (&newLink->srcNode->interfaces, &row->precHopRR->ipAddr, (void *) ifCmp);
				newLink->dstIf = nullIf;
				minXOR = 255;

				
				for (curr3 = newLink->dstNode->interfaces.head; curr3; curr3 = curr3->next) 
				{	
					Interface *if2 = curr3->element;	

					
					if (*((u_int8_t *)&if2->ip.s_addr) == 127) continue;

					XOR = ntohl (newLink->srcIf->ip.s_addr ^ if2->ip.s_addr);
					if (XOR <= minXOR) {
						minXOR = XOR;
						if (minXOR <= MAX_SUBNET_LINK) newLink->dstIf = if2;
					}
				}
			}
			else 
			{	
				
				newLink->srcNode = row->precHop->assNode;
				newLink->srcIf = nullIf;
				newLink->dstIf = nullIf;
				minXOR = 255;

				
				for (curr2 = newLink->srcNode->interfaces.head; curr2; curr2 = curr2->next) 
				{	
					Interface *if1 = curr2->element;	
					
					
					if (*((u_int8_t *)&if1->ip.s_addr) == 127) continue;
					
					for (curr3 = newLink->dstNode->interfaces.head; curr3; curr3 = curr3->next) 
					{	
						Interface *if2 = curr3->element;	
						
						
						if (*((u_int8_t *)&if2->ip.s_addr) == 127) continue;
						
						XOR = ntohl (if1->ip.s_addr ^ if2->ip.s_addr);
						if (XOR < minXOR) {
							minXOR = XOR;
							if (minXOR < MAX_SUBNET_LINK) {
								newLink->srcIf = if1;
								newLink->dstIf = if2;
							}
						}
					}
				}
			}
			
			
			NetLink *link = listSearch (&params->topology->links, newLink, (void *) linkCmp);
			if (!link)
				
				listPush(&params->topology->links, newLink);
			else 
			{	
				if (link->dstIf->ip.s_addr == INADDR_ANY) link->dstIf = newLink->dstIf;
				free (newLink);
			}
		}
	}
}


void extIcmpLinksE (ThreadParam *params)
{
	ListEntry *curr1, *curr2;		

	for (curr1 = params->icmpTab->head; curr1; curr1 = curr1->next) 
	{	
		IcmpRow *row1 = curr1->element;							
		u_int32_t mask = ntohl (0xFFFFFFFC);					
		struct in_addr netId = { row1->ipAddr.s_addr & mask };	
		struct in_addr tmpIp = { netId.s_addr | ~mask };		
		
		
		if (htonl (row1->ipAddr.s_addr & ~mask) == 0 ||
			htonl (row1->ipAddr.s_addr & ~mask) == 3) continue;

		
		if (listSearch (&params->topology->links, &row1->ipAddr, (void *) ip2LinkCmp)) continue;
		
		for (curr2 = curr1->next; curr2; curr2 = curr2->next) 
		{	
			IcmpRow *row2 = curr2->element;	

			
			if (!(row1->hop - row2->hop == 1 || row2->hop - row1->hop == 1)) continue;
			
			
			if ((row2->ipAddr.s_addr & mask) != netId.s_addr) continue;
			
			
			if (htonl (row2->ipAddr.s_addr & ~mask) == 0 ||
				htonl (row2->ipAddr.s_addr & ~mask) == 3) continue;

			
			if (listSearch (&params->topology->links, &row2->ipAddr, (void *) ip2LinkCmp)) continue;

			
			if (listSearch (params->icmpTab, &netId, (void *) icmpRowCmp)) continue;

			if (listSearch (params->icmpTab, &tmpIp, (void *) icmpRowCmp)) continue;
				
			tmpIp.s_addr = htonl (ntohl (tmpIp.s_addr) + 1);	

			if (listSearch (params->icmpTab, &tmpIp, (void *) icmpRowCmp)) continue;

			tmpIp.s_addr = htonl (ntohl (netId.s_addr) - 1);	

			if (listSearch (params->icmpTab, &tmpIp, (void *) icmpRowCmp)) continue;
			
			
			NetLink *newLink = calloc (1, sizeof (NetLink));		

			if (!row1->assNode) icmpRow2NetNode (params, row1);
			newLink->srcNode = row1->assNode;
			newLink->srcIf = listSearch (&newLink->srcNode->interfaces, &row1->ipAddr, (void *) ifCmp);

			if (!row2->assNode) icmpRow2NetNode (params, row2);
			newLink->dstNode = row2->assNode;
			newLink->dstIf = listSearch (&newLink->dstNode->interfaces, &row2->ipAddr, (void *) ifCmp);
			newLink->hop = row1->hop > row2->hop ? row2->hop : row1->hop;

			
			listPush(&params->topology->links, newLink);
			break;
		}
	}
}



void
extractSubnets (ThreadParam *params)
{
	ListEntry *current;		

#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from SNMP routers\n");
#endif
	
	
	for (current = params->topology->routers.head; current; current = current->next) 
	{	
		NetNode *info = current->element;	
		ListEntry *curr;					
		
		for (curr = info->interfaces.head; curr; curr = curr->next) 
		{	
			Interface *ifTmp = curr->element;							
			Subnet *net;												
			NetLink *link;												
			u_int32_t netId = ifTmp->ip.s_addr & ifTmp->mask.s_addr;	

			
			if (netId == INADDR_ANY || *((u_int8_t *)&netId) == 127) continue;

			if (!(net = listSearch (&params->topology->subnets, &ifTmp->ip, (void *) ipSubnet))) 
			{	
				
				net = (Subnet *) calloc (1, sizeof (Subnet));
				net->nodes = (List *) calloc (1, sizeof (List));

				
				net->netId.s_addr = netId;
				net->netMask = shortMask (ifTmp->mask);
				net->type = EXACT;

				
				listInit (net->nodes);
				listPush (net->nodes, info);
#ifdef DEBUG
				debugOut (SUBNET, "Assigning %s ", inet_ntoa (ifTmp->ip));
				debugOutNoTime (SUBNET, "to %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
				
				link = listSearch (&params->topology->links, &ifTmp->ip, (void *) ipLinkCmp);
				if (link) {
					
					IcmpRow *row = listSearch (params->icmpTab, &link->dstIf->ip, (void *) icmpRowCmp);
					if (row) row->assSubnet = net;
					
					listPush (net->nodes, link->dstNode);
#ifdef DEBUG
					debugOut (SUBNET, "Assigning %s ", link->dstNode->name);
					debugOutNoTime (SUBNET, "to %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
				}
				
				
				listPush (&params->topology->subnets, net);
#ifdef DEBUG
				debugOut (SUBNET, "Created %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
			}
			else 
			{	
				
				if (!listSearch (net->nodes, info, (void *) nodeAddrCmp))
					listPush (net->nodes, info);

				
				if (shortMask(ifTmp->mask) < net->netMask) ifTmp->mask = longMask (net->netMask);
			}
		}
	}

#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from links\n");
#endif

	
	for (current = params->topology->links.head; current; current = current->next) 
	{	
		NetLink *link = current->element;		
		struct in_addr netId;					
		struct in_addr mask;					
		struct in_addr tmpMask;					
		u_int32_t a = link->srcIf->ip.s_addr;	
		u_int32_t b = link->dstIf->ip.s_addr;	
		int i;

		
		if (a == 0 || b == 0 || link->snmp) continue;

		inet_aton ("255.255.255.252", &tmpMask);

		
		if (link->srcIf->mask.s_addr) mask.s_addr = link->srcIf->mask.s_addr;
		
		else if (link->dstIf->mask.s_addr) mask.s_addr = link->dstIf->mask.s_addr;
		
		else {
			mask.s_addr = ~((a & b) ^ (a | b));
		
			
			for (i=0; i<25; i++) {
				if (htonl(mask.s_addr) >= htonl(tmpMask.s_addr)) {
					mask.s_addr = tmpMask.s_addr;
					break;
				}
				tmpMask.s_addr = ntohl( htonl (tmpMask.s_addr) << 1);
			}
		}

		
		link->srcIf->mask = mask;
		link->dstIf->mask = mask;

		
		netId.s_addr = a & mask.s_addr;

		
		if (!listSearch (&params->topology->subnets, &netId, (void *) subnetCmp)) {
			Subnet *net = calloc (1, sizeof (Subnet));	
			net->nodes = calloc (1, sizeof (List));		

			
			net->netId = netId;
			net->netMask = shortMask (mask);
			net->type = EURISTIC;
			net->hop = link->hop;
			
			
			listInit (net->nodes);

			
			listPush (&params->topology->subnets, net);

#ifdef DEBUG
			debugOut (SUBNET, "Created %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
		}
	}

	
	icmpTabSubnetCmp (params, true);

#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from IcmpTable (only precHopRR)\n");
#endif

	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	
		IcmpRow *row = current->element;	
		
		
		if (!row->assSubnet && row->precHopRR) {
			
			icmpRow2Subnet (params, current, PREC_HOP_RR);
			
			icmpTabSubnetCmp (params, false);
		}
	}

#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from IcmpTable (no precHop)\n");
#endif

	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	
		IcmpRow *row = current->element;	
		
		
		if (!row->assSubnet && !row->precHop) {
			
			icmpRow2Subnet (params, current, NO_PREC_HOP);
			
			icmpTabSubnetCmp (params, false);
			break;
		}
	}
	
#ifdef DEBUG
	debugOut (SUBNET, "Extracting subnets from IcmpTable (only precHop)\n");
#endif
	
	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	
		IcmpRow *row = current->element;	
		
		
		if (!row->assSubnet && row->precHop) {
			
			icmpRow2Subnet (params, current, PREC_HOP);
			
			icmpTabSubnetCmp (params, false);
		}
	}

}


void
icmpRow2Subnet (ThreadParam *params, ListEntry *current, SubExtPhase phase)
{
	IcmpRow *row = current->element;			
	List tmpList;								
	ListEntry *curr, *curr2;					
	IcmpRow *rowTmp;							
	struct in_addr bestMask = { INADDR_ANY };	
	bool netmask = false;						
	Subnet *net = calloc (1, sizeof (Subnet));	
	net->nodes = calloc (1, sizeof (List));		

#ifdef DEBUG
	debugOut (SUBNET, "Processing %s:\n", inet_ntoa (row->ipAddr));
#endif

	
	listInit (net->nodes);
	listInit (&tmpList);

	
	listPush (&tmpList, row);
	if (row->netMask.s_addr != INADDR_ANY) netmask = true;

	
	for (curr = current->next; curr; curr = curr->next) 
	{	
		rowTmp = curr->element;		
		bool condition;				
		
		
		if (rowTmp->assSubnet) continue;

		switch (phase) {
			case PREC_HOP_RR:
				condition = (row->precHopRR == rowTmp->precHopRR);
			break;
			case PREC_HOP:
				condition = false;
			break;
			case NO_PREC_HOP:
				condition = (rowTmp->precHop == NULL && row->hop == 1 && rowTmp->hop == 1);
			break;
		}
		
		if (condition) {
			bool found = false;		
			
			
			if (rowTmp->assNode) {
				for (curr2 = rowTmp->assNode->interfaces.head; curr2 && !found; curr2 = curr2->next) 
				{	
					Interface *ifTmp = curr2->element;	

					found = (bool) listSearch (&tmpList, &ifTmp->ip, (void *) icmpRowCmp);
				}
			}

			if (!found) {
#ifdef DEBUG
				debugOut (SUBNET, "%s\n", inet_ntoa (rowTmp->ipAddr));
#endif
				if (rowTmp->netMask.s_addr != INADDR_ANY) netmask = true;
				listPush (&tmpList, rowTmp);
			}
		}
	}

	
	if (netmask) {
		
		for (curr = tmpList.head; curr; curr = curr->next) 
		{	
			rowTmp = curr->element;
			if (htonl (rowTmp->netMask.s_addr) > htonl (bestMask.s_addr))
				bestMask = rowTmp->netMask;
		}
	}

	
	else bestMask = keshav (&tmpList);
	
	
	net->netId.s_addr = row->ipAddr.s_addr & bestMask.s_addr;
	net->netMask = shortMask (bestMask);
	net->type = EURISTIC;
	net->hop = row->hop;
	defaultGateway (row, net);
	
	
	if (!listSearch (&params->topology->subnets, net, (void *) subnetInclude)) 
	{	
		
		for (curr = tmpList.head; curr; curr = curr->next) {
			rowTmp = curr->element;
			rowTmp->assSubnet = net;
			rowTmp->netMask = bestMask;
		}
	
		
		for (curr = tmpList.head; curr; curr = curr->next) {
			rowTmp = curr->element;
			if (!rowTmp->assNode) icmpRow2NetNode (params, rowTmp);
			else {
				Interface *ifTmp = listSearch (&rowTmp->assNode->interfaces, &rowTmp->ipAddr, (void *) ifCmp);
				ifTmp->mask = bestMask;
			}
			listPush (net->nodes, rowTmp->assNode);
		}
	
		
		listPush (&params->topology->subnets, net);
	
#ifdef DEBUG
		debugOut (SUBNET, "Created %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif
	}
	else 
	{	
#ifdef DEBUG
		debugOut (SUBNET, "Aborted %s/%d subnet (Conflict)\n", inet_ntoa (net->netId), net->netMask);
#endif
		
		free (net);
	}
	
	
	listReset (&tmpList, false);
}



void
icmpTabSubnetCmp (ThreadParam *params, bool allSubnets)
{
	ListEntry *current;		

	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	
		IcmpRow *row = current->element;	
		Subnet *net = 0x0;					
		Interface *ifTmp;					

		if (allSubnets)  
			
			net = listSearch (&params->topology->subnets, row, (void *) rowSubnet);
		else {
			
			if (rowSubnet (row, (Subnet *) params->topology->subnets.last->element))
				net = (Subnet *) params->topology->subnets.last->element;
		}
		
		if (net) 
		{	
			row->netMask = longMask (net->netMask);
			row->assSubnet = net;

#ifdef DEBUG
			debugOut (SUBNET, "Assigning %s ", inet_ntoa (row->ipAddr));
			debugOutNoTime (SUBNET, "to %s/%d subnet\n", inet_ntoa (net->netId), net->netMask);
#endif

			if (!row->assNode) 
				
				icmpRow2NetNode (params, row);
			else {
				
				ifTmp = listSearch (&row->assNode->interfaces, &row->ipAddr, (void *) ifCmp);
				ifTmp->mask = row->netMask;
			}
			
			
			if (!listSearch (net->nodes, &row->ipAddr, (void *) nodeCmp))
				listPush (net->nodes, row->assNode);

			
			if (!net->defaultGw.s_addr) defaultGateway (row, net);
		}
	}
}


void
defaultGateway (IcmpRow *row, Subnet *net)
{
	u_int32_t XOR; 					
	u_int32_t minXOR = 0xFFFFFFFF;	
	IcmpRow *precRow = 0x0;			
	ListEntry *curr;				

	
	if (row->precHopRR) precRow = row->precHopRR;
	else if (row->precHop) precRow = row->precHop;

	if (precRow && precRow->assNode) 
	{	
		for (curr = precRow->assNode->interfaces.head; curr; curr = curr->next) 
		{	
			Interface *ifTmp = curr->element;	

			XOR = ntohl (net->netId.s_addr ^ ifTmp->ip.s_addr);
			if (XOR < minXOR) {
				minXOR = XOR;
				
				if (ipSubnet(&ifTmp->ip, net)) net->defaultGw = ifTmp->ip;
			}
		}
	}
}


NetNode *
icmpRow2NetNode (ThreadParam *params, IcmpRow *row)
{
	
	Interface *ifTmp = calloc (1, sizeof(Interface));
	row->assNode = calloc (1, sizeof (NetNode));

	
	if (row->ipDNS) row->assNode->name = row->ipDNS;
	else {
		row->assNode->name = calloc (7, sizeof(char));
		sprintf (row->assNode->name, "Dev%d", params->nodeCount++);
	}
	row->assNode->type = (NodeType) row->router;
	listInit (&row->assNode->interfaces);

	
	ifTmp->ip = row->ipAddr;
	ifTmp->mask = row->netMask;
	listPush (&row->assNode->interfaces, ifTmp);

	return row->assNode;
}


struct in_addr
keshav (List *rows)
{
	struct in_addr cumulativeAnds = { 0xFFFFFFFF };	
	struct in_addr cumulativeOrs = { 0 };			
	struct in_addr netMask;							
	struct in_addr tmpMask;							
	u_int32_t netId, bcast;							
	ListEntry *curr;								
	int i;

	
	for (curr = rows->head; curr; curr = curr->next) 
	{	
		IcmpRow *rowTmp = curr->element;	
		cumulativeAnds.s_addr = cumulativeAnds.s_addr & rowTmp->ipAddr.s_addr;
		cumulativeOrs.s_addr = cumulativeOrs.s_addr | rowTmp->ipAddr.s_addr;
	}

	
	netMask.s_addr = ~(cumulativeAnds.s_addr ^ cumulativeOrs.s_addr);

	inet_aton ("255.255.255.252", &tmpMask);

	
	for (i=0; i<25; i++) {
		if (htonl(netMask.s_addr) >= htonl(tmpMask.s_addr)) {
			netMask.s_addr = tmpMask.s_addr;
			break;
		}
		tmpMask.s_addr = ntohl( htonl (tmpMask.s_addr) << 1);
	}

	
	netId = ((IcmpRow*)rows->head->element)->ipAddr.s_addr & netMask.s_addr;
	bcast = netId | (~netMask.s_addr);
	for (curr = rows->head; curr; curr = curr->next) 
	{	
		IcmpRow *rowTmp = curr->element;	
		
		if (rowTmp->ipAddr.s_addr == netId || rowTmp->ipAddr.s_addr == bcast) 
		{	
			netMask.s_addr = ntohl( htonl (tmpMask.s_addr) << 1);
			break;
		}
	}
	
	return netMask;
}

