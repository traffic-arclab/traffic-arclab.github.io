/*
 *	Component of the Hynetd v0.2.4 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */


#ifndef _SCANNER_H
#define _SCANNER_H



#include "types.h"
#include "list.h"
#include "snmp.h"
#include "debug.h"
#include "output.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/types.h>
#include <netdb.h>
#include <errno.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <semaphore.h>



#define IP_SIZE 20			
#define ICMP_SIZE 16		
#define UDP_SIZE 8			
#define MAX_PACKET 100		
#define IP_SIZE_RR 60		
#define BIG_UDP_PORT 61234	
#define NROUTES 9			



typedef enum {ICMP, UDP} TraceMode;				
typedef enum {FORWARD, BACKWARD} TraceOrder;	


typedef enum {
	SCANNING, 			
	DEST_REACHED, 		
	MAX_TTL_REACHED, 	
	DEST_FILTERED, 		
	DEST_UNREACHABLE	
} TraceState;


typedef struct IpRange {
	struct in_addr startAddr;	
	u_int16_t numAddr;			
} IpRange;


typedef struct SnmpNode {
	struct in_addr addr;		
	u_char *SNMPCommunity;		
	NodeType type;				
	List interfaces;			
	int skipIndex;				
} SnmpNode;


typedef struct GlobalOptions {
	u_int8_t retries;		
	u_int8_t retriesSnmp;	
	u_int8_t retriesAlly;	
	u_int8_t max_ttl;		
	u_int8_t default_ttl;	
	u_int16_t timeout;		
	u_int16_t timeoutSnmp;	
	u_int16_t timeoutAlly;	
	TraceMode mode;			
	u_int16_t threads;		
	bool dns;				
	bool arp;				
	bool pingOnly;			
	bool verbose;			
	bool heurLinks;			
	OidVars *oids;			
	List communitySNMP;		
	List rangesIP;			
} GlobalOptions;


typedef struct ThreadParam {
	Topology *topology;		
	List *visited;			
	List *snmpList;			
	List *icmpTab;			
	GlobalOptions *gOpts;	
	sem_t *scanSem;			
	sem_t *snmpSem;			
	sem_t *scannerSemA;		
	sem_t *scannerSemB;		
	u_int8_t threadNum;		
	ListEntry *currRow;		
	ListEntry *currNode;	
	u_int8_t sync;			
	u_int16_t nodeCount;	
} ThreadParam;


typedef struct LocalOptions {
	u_int8_t threadNum;		
	u_int8_t ttl;			
	ThreadParam *params;	
} LocalOptions;


typedef struct Options {
	GlobalOptions *gOpts;	
	LocalOptions *lOpts;	
} Options;


typedef struct Path {		
	u_int8_t length;		
	u_int8_t offset;		
	struct in_addr *array;	
	IcmpRow **newRows;		
	IcmpRow *aliasRow;		
} Path;


typedef struct RowCouple {
	IcmpRow *first;		
	IcmpRow *second;	
} RowCouple;

typedef enum {NOT_ALIASES, ALIASES, NONE, TIMEOUT1, TIMEOUT2} AliasState;	




unsigned short cksum (unsigned short *addr, int len);


u_int8_t getDefaultTTL (void);


int traceroute (struct in_addr, Options *, Path *);


int pingrr (struct in_addr addr, Options *opt, Path *);


bool ping (struct in_addr addr, Options *opt);


SnmpNode *testSnmp (struct in_addr addr, Options *opt);


NetNode *snmpclient (SnmpNode *node, GlobalOptions *gOpts, u_int16_t *nodeCount);


void *scanner (void *arg);


int scan (ThreadParam *params);


struct in_addr icmpMask (struct in_addr addr, Options *opt);


int backtrace (struct in_addr addr, Options *opt, List *icmpTab, Path *hops);


AliasState ally (Options *opt, const struct in_addr addr1, const struct in_addr addr2);


void alias2Routers (ThreadParam *params, RowCouple *couple);


AliasState allyPrevention (LocalOptions *lOpt, IcmpRow *row1, IcmpRow *row2);

#endif
