/*
 *	Component of the Hynetd v0.2.4 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */


#ifndef _OUTPUT_H
#define _OUTPUT_H

#include "types.h"




void fprintIcmpTab (FILE *fp, List *icmpTab, bool full);


void fprintSummary (FILE *fp, List *icmpTab);


void fprintRouters (FILE *fp, Topology *topology);


void fprintLinks (FILE *fp, Topology *topology);


void fprintSubnets (FILE *fp, Topology *topology);


void fprintCell (FILE *fp, char *string, u_int8_t numtabs);


void xmlLinks (FILE *fp, Topology *topology);


void xmlSubnets (FILE *fp, Topology *topology);


void xmlRouters (FILE *fp, Topology *topology);


void xmlTopology (FILE *fp, Topology *topology);


void dump (void *buffer, int len, int mode);

#endif
