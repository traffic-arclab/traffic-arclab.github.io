/*
 *	Component of the Hynetd v0.2.4 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */


#include "debug.h"

#include <stdarg.h>
#include <sys/time.h>
#include <time.h>




FILE *logFiles[LOG_FILE_NUM];	
bool debugActive[LOG_FILE_NUM];	




int debugInit (LogFile id)
{
	if (debugActive[id]) return 1;	

	switch (id) {
		case PING:			logFiles[id] = fopen ("./logs/ping.log", "w"); break;
		case MASK:			logFiles[id] = fopen ("./logs/mask.log", "w"); break;
		case BACKTRACE: 	logFiles[id] = fopen ("./logs/bt.log", "w"); break;
		case PINGRR: 		logFiles[id] = fopen ("./logs/prr.log", "w"); break;
		case ALLY:			logFiles[id] = fopen ("./logs/ally.log", "w"); break;
		case SNMPCLIENT:	logFiles[id] = fopen ("./logs/snmpc.log", "w"); break;
		case SCANNER:		logFiles[id] = fopen ("./logs/scanner.log", "w"); break;
		case SCAN:			logFiles[id] = fopen ("./logs/scan.log", "w"); break;
		case ALIAS:			logFiles[id] = fopen ("./logs/alias.log", "w"); break;
		case COUPLES:		logFiles[id] = fopen ("./logs/couples.log", "w"); break;
		case SUBNET:		logFiles[id] = fopen ("./logs/subnet.log", "w"); break;
	}
	if (!logFiles[id]) {
		printf ("Unable to create log file %d!\n", id);
		return 2;
	}
	debugActive[id] = true;

	return 0;
}


void debugOut (LogFile id, const char *message, ...)
{
	va_list ap;
	struct timeval t;
	struct tm *now;

	gettimeofday(&t, NULL);
	now = gmtime(&t.tv_sec);

	if (!debugActive[id]) debugInit (id);

	va_start (ap, message);
	fprintf (logFiles[id], "%02d:%02d:%02d.%06d ", 
			(int) now->tm_hour, 
			(int) now->tm_min, 
			(int) now->tm_sec, 
			(int) t.tv_usec);
	vfprintf (logFiles[id], message, ap);
	va_end (ap);
	fflush(logFiles[id]);
}


void debugOutNoTime (LogFile id, const char *message, ...)
{
	va_list ap;

	if (!debugActive[id]) debugInit (id);

	va_start (ap, message);
	vfprintf (logFiles[id], message, ap);
	va_end (ap);
	fflush(logFiles[id]);
}


int debugReset (void)
{
	int i;
	
	for (i=0; i<LOG_FILE_NUM; i++) {
		if (debugActive[i]) {
			fclose(logFiles[i]);
			debugActive[i] = false;
		}
	}
	return i;
}
