/*
 *	Component of the Hynetd v0.2.4 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */


#include <sys/stat.h>
#include <unistd.h>
#include "scanner.h"
#include "postprocessing.h"
#include "output.h"





void
printHelp ()
{
	printf ("\n SYNOPSIS \n\n"
			" HyNeTD [-h] | [--help] | [-P] |\n"
			"        [-v] [-d] [-a] [-r[G|S|A] <retries_number>] [-T[G|S|A] <timeout>] [-L <max_ttl>] [-I]\n"
			"        [-l] [-c <community_name> [[community_name] ... ]] -t <max_number_of_threads>\n"
			"        <base_address> <address_space_size> [[<base_address> <address_space_size>] ... ]\n");
	
	printf	("\n DESCRIPTION \n\n"
			" Hybrid Network Topology Discovery Tool \n");
	
	printf (" \n OPTIONS \n\n"
			" base_address\t\tthe first address of an ip address range\n"
			" address_space_size\tip address range dimension\n\n");
	
	printf ("\t\t-t\tmax number of threads to generate \n"
			"\t\t-d\tenable DNS inverse name lookup (default = disabled)\n"
			"\t\t-c\tcommunity_name's list to be used in SNMP client requests\n"
			"\t\t\t(default = public)\n"
			"\t\t-a\tenable ARP table extraction (default = disabled)\n"
			"\t\t-r[G|S|A]\n"
			"\t\t\tnumber of retries in packet sendings (Generic/SnmpTest/Ally)\n"
			"\t\t\t(defaults = 1/1/1)\n"
			"\t\t-T[G|S|A]\n"
			"\t\t\ttimeout value used during scan process in ms (Generic/SnmpTest/Ally)\n"
			"\t\t\t(defaults = 500/500/1000 ms) \n"
			"\t\t-L\tmax value of ttl to use during backtrace process (default = 20)\n"
			"\t\t-I\tset predefinite backtrace mode ICMP (default mode UDP)\n"
			"\t\t-v\tenable verbose mode\n"
			"\t\t-P\tenable ping-only mode\n"
			"\t\t-l\tenable serial links heuristic method\n"
			"\t -h --help\tprint this help \n\n");
}


int
parser (int argc, char **argv, GlobalOptions *options)
{
	bool threads = false;
	bool haveRange = false;
	
	listInit (&options->rangesIP);
	listInit (&options->communitySNMP);
	
	if (argc > 1) {
		while (argc > 0) {
			if (argv[0][0] == '-') {
				switch (argv[0][1]) {
					case 'd':
						options->dns = true;
						argc--;	argv++;
					break;
					
					case 'c':		
						argc--;	argv++;
						printf("SNMP community list:\n");
						while((argv[0][0] != '-') && (argc > 0)) {
							listPush (&options->communitySNMP, argv[0]);
							printf("\t%s\n", argv[0]);
							argc--;	argv++;
						}
						printf ("\n");
					break;
					case 'a':
						options->arp = true;
						argc--;	argv++;
					break;
					case 'P':
						options->pingOnly = true;
						argc--;	argv++;
					break;
					case 'v':
						options->verbose = true;
						argc--;	argv++;
					break;
					case 'l':
						options->heurLinks = true;
						argc--;	argv++;
					break;
					case 'r':
						switch (argv[0][2]) {
							default: 
							case 'G': options->retries = atoi(argv[1]); break;
							case 'S': options->retriesSnmp = atoi(argv[1]); break;
							case 'A': options->retriesAlly = atoi(argv[1]); break;
						}
						argc-=2; argv+=2;
					break;
					case 'T':
						switch (argv[0][2]) {
							default: 
							case 'G': options->timeout = atoi(argv[1]); break;
							case 'S': options->timeoutSnmp = atoi(argv[1]); break;
							case 'A': options->timeoutAlly = atoi(argv[1]); break;
						}
						argc-=2; argv+=2;
					break;
					case 'L':
						argc--;	argv++;
						options->max_ttl = atoi(argv[0]);
						argc--;	argv++;
					break;
					case 'I':
						argc--;	argv++;
						options->mode = ICMP;
					break;
					case 't':
						argc--;	argv++;
						options->threads = atoi(argv[0]);
						threads = true;
						argc--;	argv++;
					break;
					case 'h':
						printHelp();
						exit (0);
					break;
					case '-':
						if (strcmp(argv[0],"--help") == 0) {
							printHelp();
							exit (0);
						}
					break;
					default: return -1;
				}
			}
			
			
			else if (threads) {
				if (argc % 2 != 0) {
					printf ("No address space size specified for last range!\n");
					return -1;
				}
				
				printf("Ranges to scan:\n");
				while (argc > 0 && argv[0][0] != '-') {
					IpRange *range = (IpRange *) malloc (sizeof(IpRange));

					inet_aton (argv[0], &range->startAddr);
					range->numAddr = atoi(argv[1]);
					listPush (&options->rangesIP, range);

					printf("\t%s (%d)\n", argv[0], range->numAddr);
					haveRange = true;
					argc -= 2;	argv += 2;
				}
				printf ("\n");fflush (stdout);
			}
			
			
			else {
				argc--;
				argv++;
			}
		}
		
		if (options->communitySNMP.empty) {
			listPush (&options->communitySNMP, strdup ("public"));
			printf("SNMP community list:\n\tpublic\n\n");
		}

		if (!threads) {
			printf ("Max number of threads not specified!!\n");
			return -1;
		}
		
		if (!haveRange) {
			printf ("No range specified!\n");
			return -1;
		}
		
		printf ("Selected Options:\n\tThreads: %d\n\tRetries (G/S/A) = %d / %d / %d\n"
				"\tTimeout (G/S/A) = %d / %d / %d ms\n\tmax TTL = %d\n"
				"\tBacktrace preferred mode = %s\n\tDNS aliasing = %s\n\tARP tables retrieving = %s\n"
				"\tSerial links heuristic = %s\n\tVerbose mode = %s\n\tPing-only mode = %s\n\n",
				options->threads, options->retries, options->retriesSnmp, options->retriesAlly, 
				options->timeout, options->timeoutSnmp, options->timeoutAlly, options->max_ttl, 
				options->mode ? "UDP" : "ICMP", options->dns ? "ENABLED" : "DISABLED", 
				options->arp ? "ENABLED" : "DISABLED", options->heurLinks ? "ENABLED" : "DISABLED",
				options->verbose ? "ENABLED" : "DISABLED", options->pingOnly ? "ENABLED" : "DISABLED");
		printf("--------------------------------------------------------------------------\n");
		
		return 0;
	}
	else return -1;
}


int
main(int argn, char **argv)
{
	struct ThreadParam params;	
	Topology topology;			
	List icmpTab;				
	GlobalOptions gOpts;		

	
	FILE *icmptabFp, *linksFp, *subnetsFp, *routersFp, *xmlFp;

	
	printf("--------------------------------------------------------------------------\n");
	printf("            HyNeTD v%s - (Hybrid Network Topology Discovery)\n\n", VERSION);
	printf(" copyright: (C) 2004-2007 by Università Degli Studi di Napoli Federico II\n");
	printf(" email    : td@comics.unina.it\n");
	printf("--------------------------------------------------------------------------\n");
	printf("\n");

	if (getuid ()) {
		printf ("Root permissions are needed to execute this tool!\n");
		exit (0);
	}

	
	gOpts.retries = 1;
	gOpts.retriesSnmp = 1;
	gOpts.retriesAlly = 1;
	gOpts.timeout = 500;
	gOpts.timeoutSnmp = 500;
	gOpts.timeoutAlly = 1000;
	gOpts.max_ttl = 20;
	gOpts.mode = UDP;
	gOpts.dns = false;
	gOpts.arp = false;
	gOpts.pingOnly = false;
	gOpts.verbose = false;
	gOpts.heurLinks = false;

	
	if (parser (argn, argv, &gOpts)) {
		printf ("Error parsing options!\n");
		printHelp();
		exit(0);
	}

	
	if (!gOpts.verbose) {
		printf ("Threads output symbols meanings:\n"
				"\t. = Ping timeout\t+ = ICMP info acquired\t* = SNMP enabled\n"
				"\t@ = DNS name acquired\t$ = Aliasing\t\tX = Terminated\n"
				"\t# = Waiting for next step\n"
				"--------------------------------------------------------------------------\n");
	}

	
	struct stat sb;
	if (stat("./logs", &sb)) mkdir("./logs", S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH);

	
	xmlFp = fopen ("topology.xml","w");
	icmptabFp = fopen ("logs/icmptab.log","w");
	linksFp = fopen ("logs/links.log","w");
	subnetsFp = fopen ("logs/subnets.log","w");
	routersFp = fopen ("logs/routers.log","w");
	
	
	params.topology = &topology;
	params.icmpTab = &icmpTab;
	params.gOpts = &gOpts;

	
	scan (&params);

	
	if (gOpts.verbose) fprintIcmpTab (stdout, &icmpTab, false);
	fprintIcmpTab (icmptabFp, &icmpTab, false);

	
	if (!gOpts.pingOnly) {
		
		extractLinks(&params);
	
		
		fprintLinks (stdout, &topology);
		fprintLinks (linksFp, &topology);
		fprintIcmpTab (icmptabFp, &icmpTab, false);
	
		
		extractSubnets (&params);
	
		
		fprintSubnets (stdout, &topology);
		fprintSubnets (subnetsFp, &topology);
		fprintRouters (stdout, &topology);
		fprintRouters (routersFp, &topology);
		fprintIcmpTab (icmptabFp, &icmpTab, false);
	
		
		xmlTopology (xmlFp, &topology);
	}
	
	else {
		FILE *summaryFp = fopen ("summary.txt","w");

		printf ("\n%d active addresses were detected!\n", icmpTab.size);
		fprintSummary (summaryFp, &icmpTab);
		fclose (summaryFp);
		printf ("A list of all those addresses has been written to \"summary.txt\" file.\n");
	}

	
	fclose (xmlFp);
	fclose (icmptabFp);
	fclose (routersFp);
	fclose (subnetsFp);
	fclose (linksFp);

#ifdef DEBUG
	debugReset ();
#endif
	return 0;
}

