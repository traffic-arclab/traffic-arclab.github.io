/*
 *	Component of the Hynetd v0.2.5 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2008 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *    
 *    For professional services please write to tdpro@comics.unina.it.
 */


#ifndef _POSTPROCESSING_H
#define _POSTPROCESSING_H



#include "scanner.h"



#define MAX_SUBNET_LINK 4	



typedef enum {PREC_HOP_RR, PREC_HOP, NO_PREC_HOP} SubExtPhase; 



void extractLinks (ThreadParam *params);


void extSnmpLinks (ThreadParam *params);


void extIcmpLinks (ThreadParam *params);


void extIcmpLinksE (ThreadParam *params);



void extractSubnets (ThreadParam *params);


NetNode *icmpRow2NetNode (ThreadParam *params, IcmpRow *row);


struct in_addr keshav (List *rows);


void icmpTabSubnetCmp (ThreadParam *params, bool allSubnets);


void icmpRow2Subnet (ThreadParam *params, ListEntry *current, SubExtPhase phase);


void defaultGateway (IcmpRow *row, Subnet *net);


void cleanRouters (ThreadParam *params);

#endif
