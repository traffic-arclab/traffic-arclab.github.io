/*
 *	Component of the Hynetd v0.2.5 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2008 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *    
 *    For professional services please write to tdpro@comics.unina.it.
 */




#include "types.h"
#include <stdio.h>

#ifndef _DEBUG_H
#define _DEBUG_H



#define LOG_FILE_NUM 12


typedef enum {
	PING,		
	MASK,		
	BACKTRACE,	
	PINGRR,		
	ALLY,		
	SNMPCLIENT,	
	SCANNER,	
	SCAN,		
	ALIAS,		
	COUPLES,	
	SUBNET,		
	SNMP		
} LogFile;

 



void debugOut (LogFile id, const char *message, ...);


void debugOutNoTime (LogFile id, const char *message, ...);


int debugInit (LogFile id);


int debugReset (void);

#endif
