/*
 *	Component of the Hynetd v0.2.5 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2008 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *    
 *    For professional services please write to tdpro@comics.unina.it.
 */


#ifndef _OUTPUT_H
#define _OUTPUT_H

#include "types.h"




void fprintIcmpTab (FILE *fp, List *icmpTab, bool full);


void fprintSummary (FILE *fp, List *icmpTab);


void fprintRouters (FILE *fp, Topology *topology);


void fprintRoutersStat (FILE *fp, Topology *topology);


void fprintLinks (FILE *fp, Topology *topology);


void fprintLinksStat (FILE *fp, Topology *topology);


void fprintSubnets (FILE *fp, Topology *topology);


void fprintSubnetsStat (FILE *fp, Topology *topology);


void fprintCell (FILE *fp, char *string, u_int8_t numtabs);


void xmlLinks (FILE *fp, Topology *topology);


void xmlSubnets (FILE *fp, Topology *topology);


void xmlRouters (FILE *fp, Topology *topology);


void xmlTopology (FILE *fp, Topology *topology);


void dump (void *buffer, int len, int mode);

#endif
