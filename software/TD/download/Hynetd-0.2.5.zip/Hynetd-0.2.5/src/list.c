/*
 *	Component of the Hynetd v0.2.5 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2008 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *    
 *    For professional services please write to tdpro@comics.unina.it.
 */


#include "list.h"
#include <string.h>
#include <stdio.h>




void listInit(List *list)
{
    list->size = 0;
    list->empty = true;
    list->head = NULL;
    list->last = NULL;
}


void listReset(List *list, bool full)
{
    ListEntry *tmp;

    while (list->head != NULL) {
	tmp = list->head;
	list->head = tmp->next;
	if (full)
	    free(tmp->element);
	free(tmp);
    }

    list->size = 0;
    list->empty = true;
    list->last = NULL;
}


void listPush(List *list, void *element)
{
    ListEntry *tmp = (ListEntry *) malloc(sizeof(ListEntry));

    
    tmp->next = NULL;
    tmp->prev = NULL;
    tmp->element = element;

    if (list->empty) { 
	list->empty = false;
	list->head = tmp;
    } else { 
	list->last->next = tmp;
	tmp->prev = list->last; 
    }

    list->last = tmp;
    list->size++;
}


void * listPop(List *list)
{
    if (!list->empty) {
	ListEntry *tmp = list->head;
	void *element;

	list->head = tmp->next;
	if (list->head) list->head->prev = NULL;
	list->size--;
	if (list->size == 0) {
	    list->empty = true;
	    list->last = NULL;
	}
	element = tmp->element;

	free(tmp);
	return element;
    } else
	return NULL;
}


void * listGet(List *list, int i)
{
    if (i < list->size) {
	int j;
	ListEntry *tmp = list->head;

	
	for (j=0; j<i; j++)
	    tmp = tmp->next;

	return tmp->element;
    } else
	return NULL;
}


void * listSearch(List *list, const void *element, bool(*compare)(const void *, const void *))
{
    ListEntry *current;

    for (current = list->head; current; current = current->next)
	if (compare(element, current->element))
	    return current->element;

    return NULL;
}


void listRemoveEntry(List *list, ListEntry *entry, bool full)
{
    if (entry->next)
	entry->next->prev = entry->prev;
    else
	list->last = entry->prev;
    if (entry->prev)
	entry->prev->next = entry->next;
    else
	list->head = entry->next;
    if (full)
	free(entry->element);
    if (--list->size == 0)
	list->empty = true;
    free(entry);
}
