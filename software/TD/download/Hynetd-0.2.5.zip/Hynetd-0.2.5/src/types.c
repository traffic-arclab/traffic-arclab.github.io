/*
 *	Component of the Hynetd v0.2.5 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2008 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *    
 *    For professional services please write to tdpro@comics.unina.it.
 */

#include "types.h"




u_int8_t shortMask(const struct in_addr mask)
{
    int i, rest = 0;
    u_int8_t *byte = (u_int8_t *) &mask;
    u_int32_t tmp;

    
    if (*byte == 0xFF)
	tmp = ntohl(mask.s_addr);
    else
	tmp = mask.s_addr;

    
    for (i=0; i<32 && rest == 0; i++) {
	tmp = (tmp >> 1);
	rest = tmp % 2;
    }

    return 32 - i;
}


struct in_addr longMask(const u_int8_t sMask)
{
    u_int32_t tmp = 0xFFFFFFFF;
    struct in_addr mask;

    mask.s_addr = htonl(tmp << (32 - sMask));
    return mask;
}


bool icmpRowCmp(struct in_addr *ip, IcmpRow *row)
{
    if (row->ipAddr.s_addr == ip->s_addr)
	return true;
    else
	return false;
}


bool subnetCmp(struct in_addr *netId, Subnet *subnet)
{
    if (subnet->netId.s_addr == netId->s_addr)
	return true;
    else
	return false;
}


bool ipSubnet(struct in_addr *ip, Subnet *subnet)
{
    struct in_addr mask = longMask(subnet->netMask);

    if (subnet->netId.s_addr == (ip->s_addr & mask.s_addr))
	return true;
    else
	return false;
}


bool subnetInclude(Subnet *net, Subnet *subnet)
{
    if (net->netMask <= subnet->netMask && ipSubnet(&subnet->netId, net))
	return true;
    else
	return false;
}


bool rowSubnet(IcmpRow *row, Subnet *subnet)
{
    struct in_addr mask = longMask(subnet->netMask);

    if (row->assSubnet && subnet->netMask <= row->assSubnet->netMask)
	return false;
    if (subnet->netId.s_addr == (row->ipAddr.s_addr & mask.s_addr))
	return true;
    else
	return false;
}


bool nextHopCmp(Interface *interface, struct in_addr *nextHop)
{
    if (shortMask(interface->mask) >= 30) {
	u_int32_t netId = interface->ip.s_addr & interface->mask.s_addr;
	u_int32_t nextHopNet = nextHop->s_addr & interface->mask.s_addr;

	if (netId == nextHopNet && interface->ip.s_addr != nextHop->s_addr)
	    return true;
	else
	    return false;
    }
    else return false;
}


bool nodeNextHopCmp(struct in_addr *ip, NetNode *node)
{
    ListEntry *current;

    for (current = node->nextHops.head; current; current = current->next) {
	struct in_addr *nextHop = current->element;

	if (nextHop->s_addr == ip->s_addr)
	    return true;
    }

    return false;
}


bool nodeAddrCmp(NetNode *node1, NetNode *node2)
{
    if (node1 == node2)
	return true;
    else
	return false;
}


bool nodeCmp(struct in_addr *ip, NetNode *node)
{
    ListEntry *current;
    Interface *ifTmp;

    for (current = node->interfaces.head; current; current = current->next) {
	ifTmp = current->element;

	if (ifTmp->ip.s_addr == ip->s_addr)
	    return true;
    }

    return false;
}


bool ifCmp(struct in_addr *ip, Interface *itf)
{
    if (ip->s_addr == itf->ip.s_addr)
	return true;
    else
	return false;
}


bool ipCmp(struct in_addr *ip1, struct in_addr *ip2)
{
    if (ip1->s_addr == ip2->s_addr)
	return true;
    else
	return false;
}


bool linkCmp(NetLink *link1, NetLink *link2)
{
    if ((link1->srcNode == link2->srcNode && link1->dstNode == link2->dstNode && link1->srcIf->ip.s_addr
	    == link2->srcIf->ip.s_addr) || (link1->srcNode == link2->dstNode && link1->dstNode == link2->srcNode
	    && link1->srcIf->ip.s_addr == link2->dstIf->ip.s_addr))
	return true;
    else
	return false;
}


bool ipLinkCmp(struct in_addr *ip, NetLink *link)
{
    if (link->snmp && ip->s_addr == link->srcIf->ip.s_addr)
	return true;
    else
	return false;
}


bool ip2LinkCmp(struct in_addr *ip, NetLink *link)
{
    if (ip->s_addr == link->srcIf->ip.s_addr || ip->s_addr == link->dstIf->ip.s_addr)
	return true;
    else
	return false;
}
