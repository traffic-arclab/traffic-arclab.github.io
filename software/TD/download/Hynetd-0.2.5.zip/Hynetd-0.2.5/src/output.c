/*
 *	Component of the Hynetd v0.2.5 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2008 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *    
 *    For professional services please write to tdpro@comics.unina.it.
 */


#include "output.h"




void fprintIcmpTab(FILE *fp, List *icmpTab, bool full)
{
    IcmpRow *row;
    ListEntry *curr;

    fprintf(fp, "----------\n"
            	"ICMP TABLE:\n"
            	"----------\n");

    if (full)
	fprintf(fp, "IP:\t\tNetMask:\tPrecHop:\tNextHop:\tPrecHopRR:\tNextHopRR:"
	            "\tHop #:\tRouter:\tAccu:\tAlias:\t\tDest:\t\tAssNode\tDNS:\n");
    else
	fprintf(fp, "IP:\t\tNetMask:\tPrecHop:\tPrecHopRR:\tHop #:\tRouter:\tAccu:\tAlias:\t\tAliasRR:\tDNS:\n");

    fprintf(fp, "--------------------------------------------------------------------"
            	"---------------------------------------------------------------------------\n");

    for (curr = icmpTab->head; curr; curr = curr->next) {
	row = (IcmpRow *) curr->element;

	fprintCell(fp, inet_ntoa(row->ipAddr), 2);
	fprintCell(fp, inet_ntoa(row->netMask), 2);
	fprintCell(fp, row->precHop ? inet_ntoa(row->precHop->ipAddr) : "0.0.0.0", 2);
	if (full)
	    fprintCell(fp, row->nextHop ? inet_ntoa(row->nextHop->ipAddr) : "0.0.0.0", 2);
	fprintCell(fp, row->precHopRR ? inet_ntoa(row->precHopRR->ipAddr) : "0.0.0.0", 2);
	if (full)
	    fprintCell(fp, row->nextHopRR ? inet_ntoa(row->nextHopRR->ipAddr) : "0.0.0.0", 2);

	fprintf(fp, "%d\t", (int) row->hop);
	fprintf(fp, "%s\t", row->router ? "TRUE" : "FALSE");
	fprintf(fp, "%s\t", (int) row->accuracy ? ((row->accuracy == 1) ? "RR" : "BOTH") : "TR");

	fprintCell(fp, inet_ntoa(row->alias), 2);
	fprintCell(fp, inet_ntoa(row->aliasRR), 2);
	if (full)
	    fprintCell(fp, inet_ntoa(row->dest), 2);

	
	fprintf(fp, "%s\n", row->ipDNS);
    }
}


void fprintSummary(FILE *fp, List *icmpTab)
{
    IcmpRow *row;
    ListEntry *curr;

    for (curr = icmpTab->head; curr; curr = curr->next) {
	row = (IcmpRow *) curr->element;

	fprintf(fp, "%s\n", inet_ntoa(row->ipAddr));
    }
}


void fprintLinks(FILE *fp, Topology *topology)
{
    ListEntry *curr;
    char tmpStr[24];
    int j;

    fprintf(fp, "------\n"
            	"Links:\n"
            	"--------------------------------------------------------------------------------------------------------------\n");

    fprintf(fp, "Link #:\tSrc Node:\t\tSrc If:\t\tDst Node:\t\tDst If:\t\tSpeed:\t\tSNMP:\n");

    for (curr = topology->links.head, j=1; curr; curr = curr->next, j++) {
	NetLink *link = curr->element;

	fprintf(fp, "%d\t", j);
	fprintCell(fp, link->srcNode->name, 3);
	fprintCell(fp, inet_ntoa(link->srcIf->ip), 2);
	fprintCell(fp, link->dstNode->name, 3);
	fprintCell(fp, inet_ntoa(link->dstIf->ip), 2);
	sprintf(tmpStr, "%u", link->speed);
	fprintCell(fp, tmpStr, 2);
	fprintf(fp, "%s\n", link->snmp ? "TRUE" : "FALSE");
    }
    fprintf(fp,
	    "--------------------------------------------------------------------------------------------------------------\n");
}


void fprintLinksStat(FILE *fp, Topology *topology)
{
    ListEntry *curr;
    int numLinks = 0, snmpLinks=0, icmpLinks=0;
    unsigned int maxSpeed=0, minSpeed=1000000000, avgSpeed=0;

    fprintf(fp, "----------------\n"
            	"Link Statistics:\n"
            	"---------------------------------\n");

    for (curr = topology->links.head; curr; curr = curr->next) {
	NetLink *link = curr->element;

	numLinks++;
	if (link->snmp) {
	    snmpLinks++;
	    if (link->speed > maxSpeed)
		maxSpeed = link->speed;
	    if (link->speed < minSpeed)
		minSpeed = link->speed;
	    avgSpeed += link->speed;
	} else
	    icmpLinks++;
    }

    if (snmpLinks == 0)
	minSpeed = 0;
    else
	avgSpeed = avgSpeed/snmpLinks;

    fprintf(fp, "Links: %d\n", numLinks);
    fprintf(fp, "Discovered using SNMP: %d\n", snmpLinks);
    fprintf(fp, "Discovered using ICMP: %d\n", icmpLinks);
    fprintf(fp, "Max Link Speed: %u\n", maxSpeed);
    fprintf(fp, "Min Link Speed: %u\n", minSpeed);
    fprintf(fp, "Avg Link Speed: %u\n", avgSpeed);

    fprintf(fp, "---------------------------------\n");
}



void fprintSubnets(FILE *fp, Topology *topology)
{
    ListEntry *curr, *curr2, *curr3;
    NetNode *info;
    Subnet *subnet;
    Interface *ifTmp;
    int i, j;
    char tmpStr[30];

    fprintf(fp, "--------\n"
            	"Subnets:\n"
            	"------------------------------------------------------------------------------------------\n");

    for (curr = topology->subnets.head, j=1; curr; curr = curr->next, j++) {
	subnet = curr->element;

	fprintf(fp, "Net #%d: %s/%d\t", j, inet_ntoa(subnet->netId), subnet->netMask);
	fprintf(fp, "Default GW: %s\t", inet_ntoa(subnet->defaultGw));
	fprintf(fp, "Reliability: %s\n", subnet->type ? "HEURISTIC" : "EXACT");

	if (subnet->nodes) {
	    fprintf(fp, "\tType:\tCommunity:\tIP Address:\tSpeed (bps):\tNode Name:\n");
	    for (curr2 = subnet->nodes->head; curr2; curr2 = curr2->next) {
		info = curr2->element;

		for (curr3 = info->interfaces.head, i=1; curr3; curr3 = curr3->next, i++) {
		    ifTmp = curr3->element;
		    if (ipSubnet(&ifTmp->ip, subnet)) {
			fprintf(fp, "\t%s\t", info->type ? "ROUTER" : "HOST");
			fprintCell(fp, (char *)info->SNMPCommunity, 2);
			fprintCell(fp, inet_ntoa(ifTmp->ip), 2);
			sprintf(tmpStr, "%u", ifTmp->speed);
			fprintCell(fp, tmpStr, 2);
			fprintf(fp, "%s\n", info->name);
		    }
		}
	    }
	}
	fprintf(fp, "------------------------------------------------------------------------------------------\n");
    }
}


void fprintSubnetsStat(FILE *fp, Topology *topology)
{
    ListEntry *curr, *curr2, *curr3;
    NetNode *info;
    Subnet *subnet;
    Interface *ifTmp;
    int i;
    float j;
    unsigned int numSubs=0, snmpSubs=0, icmpSubs=0;
    unsigned int maxSubDim=0, minSubDim=32, avgSubDim=0;
    float maxSubDensity=0, minSubDensity=100, avgSubDensity=0;

    fprintf(fp, "------------------\n"
            	"Subnet Statistics:\n"
            	"---------------------------------\n");

    for (curr = topology->subnets.head; curr; curr = curr->next) {
	subnet = curr->element;

	numSubs++;
	if (subnet->type == EXACT)
	    snmpSubs++;
	else
	    icmpSubs++;

	if (subnet->netMask > maxSubDim)
	    maxSubDim = subnet->netMask;
	if (subnet->netMask < minSubDim)
	    minSubDim = subnet->netMask;
	avgSubDim += subnet->netMask;

	if (subnet->nodes) {
	    for (curr2 = subnet->nodes->head, i=0; curr2; curr2 = curr2->next) {
		info = curr2->element;

		for (curr3 = info->interfaces.head; curr3; curr3 = curr3->next) {
		    ifTmp = curr3->element;
		    if (ipSubnet(&ifTmp->ip, subnet)) {
			i++;
		    }
		}
	    }
	    j = (1 << (32 - subnet->netMask)) - 2;
	    j = (float)i/(float)j * 100;
	    if (j > 100)
		j=100;
	    if (j > maxSubDensity)
		maxSubDensity = j;
	    if (j < minSubDensity)
		minSubDensity = j;
	    avgSubDensity += j;
	}

    }

    if (numSubs > 0) {
	avgSubDim = avgSubDim/numSubs;
	avgSubDensity = avgSubDensity/numSubs;
    }

    fprintf(fp, "Subnets: %d\n", numSubs);
    fprintf(fp, "Discovered using SNMP: %d\n", snmpSubs);
    fprintf(fp, "Discovered using ICMP: %d\n", icmpSubs);
    fprintf(fp, "Max Subnet width: /%u\n", maxSubDim);
    fprintf(fp, "Min Subnet width: /%u\n", minSubDim);
    fprintf(fp, "Avg Subnet width: /%u\n", avgSubDim);
    fprintf(fp, "Max Subnet Density: %2.2f%%\n", maxSubDensity);
    fprintf(fp, "Min Subnet Density: %2.2f%%\n", minSubDensity);
    fprintf(fp, "Avg Subnet Density: %2.2f%%\n", avgSubDensity);

    fprintf(fp, "---------------------------------\n");
}


void fprintRouters(FILE *fp, Topology *topology)
{
    ListEntry *curr, *curr2, *curr3;
    int i;

    fprintf(fp, "--------\n"
            	"Routers:\n"
            	"------------------------------------------------------------------------------------------\n");

    for (curr = topology->routers.head; curr; curr = curr->next) {
	NetNode *info = curr->element;

	fprintf(fp, "%s Name: %s\t", info->type ? "ROUTER" : "HOST", info->name);
	fprintf(fp, "SNMP Community: %s\t", info->SNMPCommunity);
	fprintf(fp, "Default gateway: %s\n", inet_ntoa(info->defaultGw));
	fprintf(fp, "\tIf#:\tIP:\t\tNetmask:\tSpeed (bps)\n");

	for (curr2 = info->interfaces.head, i=1; curr2; curr2 = curr2->next, i++) {
	    Interface *ifTmp = curr2->element;

	    fprintf(fp, "\t%d\t", i);
	    fprintCell(fp, inet_ntoa(ifTmp->ip), 2);
	    fprintCell(fp, inet_ntoa(ifTmp->mask), 2);
	    fprintf(fp, "%u\n", ifTmp->speed);

	    
	    if (ifTmp->arpTable.head) {
		fprintf(fp, "ARP entries: ");
		for (curr3 = ifTmp->arpTable.head; curr3; curr3 = curr3->next) {
		    ArpTableRow *tableRow = curr3->element;
		    fprintf(fp, "%s ", inet_ntoa(tableRow->ip));
		}
		fprintf(fp, "\n");
	    }
	}

	
	if (info->nextHops.head) {
	    fprintf(fp, "NextHops: \t");
	    for (curr2 = info->nextHops.head; curr2; curr2 = curr2->next) {
		struct in_addr *hop = curr2->element;
		fprintf(fp, "%s ", inet_ntoa(*hop));
	    }
	    fprintf(fp, "\n");
	}
	fprintf(fp, "------------------------------------------------------------------------------------------\n");
    }
}


void fprintRoutersStat(FILE *fp, Topology *topology)
{
    ListEntry *curr, *curr2;
    int i;
    unsigned int numRouters=0, snmpRouters=0, icmpRouters=0;
    unsigned int maxIfsPerRouter=0, minIfsPerRouter=255, avgIfsPerRouter=0;

    fprintf(fp, "------------------\n"
            	"Router Statistics:\n"
            	"---------------------------------\n");

    for (curr = topology->routers.head; curr; curr = curr->next) {
	NetNode *info = curr->element;

	numRouters++;
	if (info->SNMPCommunity)
	    snmpRouters++;
	else
	    icmpRouters++;

	for (curr2 = info->interfaces.head, i=0; curr2; curr2 = curr2->next) {
	    i++;
	}
	if (i > maxIfsPerRouter)
	    maxIfsPerRouter = i;
	if (i < minIfsPerRouter)
	    minIfsPerRouter = i;
	avgIfsPerRouter += i;
    }
    if (numRouters > 0)
	avgIfsPerRouter = avgIfsPerRouter/numRouters;

    fprintf(fp, "Routers: %d\n", numRouters);
    fprintf(fp, "Discovered using SNMP: %d\n", snmpRouters);
    fprintf(fp, "Discovered using ICMP: %d\n", icmpRouters);
    fprintf(fp, "Max # of interfaces per router: %u\n", maxIfsPerRouter);
    fprintf(fp, "Min # of interfaces per router: %u\n", minIfsPerRouter);
    fprintf(fp, "Avg # of interfaces per router: %u\n", avgIfsPerRouter);
    fprintf(fp, "---------------------------------\n");
}



void fprintCell(FILE *fp, char *string, u_int8_t numtabs)
{
    int space;
    int i;
    char *cell;

    if (string != NULL) {
	cell = strdup(string);
	space = numtabs - strlen(cell) / 8;
	
	if (space <= 0) {
	    cell [(numtabs * 8) - 1] = '\0';
	    space = 1;
	}
	fprintf(fp, "%s", cell);
	free(cell);
    } else
	space = numtabs;

    for (i=0; i < space; i++)
	fprintf(fp, "\t");
    fflush(fp);
}


void xmlLinks(FILE *fp, Topology *topology)
{
    ListEntry *curr;
    int j;

    fprintf(fp, "  <Links>\n");

    for (curr = topology->links.head, j=1; curr; curr = curr->next, j++) {
	NetLink *link = curr->element;

	fprintf(fp, "    <Link id='%d' snmp='%s' srcnode='%s' dstnode='%s' srcif='%s' ", j, link->snmp ? "TRUE"
	                                                                                               : "FALSE",
	        link->srcNode->name, link->dstNode->name, inet_ntoa(link->srcIf->ip));
	fprintf(fp, "dstif='%s' bandwidth='%u'></Link>\n", inet_ntoa(link->dstIf->ip), link->speed);
    }

    fprintf(fp, "  </Links>\n");
}


void xmlSubnets(FILE *fp, Topology *topology)
{
    ListEntry *curr, *curr2, *curr3;
    NetNode *info;
    Subnet *subnet;
    Interface *ifTmp;
    int j;

    fprintf(fp, "  <Subnets>\n");

    for (curr = topology->subnets.head, j=1; curr; curr = curr->next, j++) {
	subnet = curr->element;

	fprintf(fp, "    <Subnet id='%d' netid='%s' netmask='%d' ", j, inet_ntoa(subnet->netId), subnet->netMask);
	fprintf(fp, "defaultgw='%s' reliability='%s'>\n", inet_ntoa(subnet->defaultGw), subnet->type ? "HEURISTIC"
	                                                                                             : "EXACT");

	if (subnet->nodes) {
	    for (curr2 = subnet->nodes->head; curr2; curr2 = curr2->next) {
		info = curr2->element;

		fprintf(fp, "      <Node name='%s' type='%s' community='%s'>\n", info->name, info->type ? "ROUTER"
		                                                                                        : "HOST",
		        info->SNMPCommunity ? (char *) info->SNMPCommunity : "");

		for (curr3 = info->interfaces.head; curr3; curr3 = curr3->next) {
		    ifTmp = curr3->element;

		    if (ipSubnet(&ifTmp->ip, subnet)) {
			fprintf(fp, "        <Interface ip='%s' speed='%u'></Interface>\n", inet_ntoa(ifTmp->ip),
			        ifTmp->speed);
		    }
		}

		fprintf(fp, "      </Node>\n");
	    }
	}
	fprintf(fp, "    </Subnet>\n");
    }

    fprintf(fp, "  </Subnets>\n");
}


void xmlRouters(FILE *fp, Topology *topology)
{
    ListEntry *curr, *curr2, *curr3;
    int i;

    fprintf(fp, "  <Routers>\n");

    for (curr = topology->routers.head; curr; curr = curr->next) {
	NetNode *info = curr->element;

	fprintf(fp, "    <Node name='%s' type='%s' community='%s' defaultgw='%s'>\n", info->name, info->type ? "ROUTER"
	                                                                                                     : "HOST",
	        info->SNMPCommunity ? (char *) info->SNMPCommunity : "", inet_ntoa(info->defaultGw));

	for (curr2 = info->interfaces.head, i=1; curr2; curr2 = curr2->next, i++) {
	    Interface *ifTmp = curr2->element;

	    fprintf(fp, "      <Interface ip='%s' speed='%u' ", inet_ntoa(ifTmp->ip), ifTmp->speed);
	    fprintf(fp, "mask='%s'></Interface>\n", inet_ntoa(ifTmp->mask));

	    
	    if (ifTmp->arpTable.head) {
		fprintf(fp, "     <ArpTable>\n");

		for (curr3 = ifTmp->arpTable.head; curr3; curr3 = curr3->next) {
		    ArpTableRow *tableRow = curr3->element;

		    fprintf(fp, "        <Address>%s</Address>\n", inet_ntoa(tableRow->ip));
		}

		fprintf(fp, "      </ArpTable>\n");
	    }
	}

	
	if (info->nextHops.head) {
	    fprintf(fp, "      <NextHops>\n");

	    for (curr2 = info->nextHops.head; curr2; curr2 = curr2->next) {
		struct in_addr *hop = curr2->element;

		fprintf(fp, "        <Address>%s</Address>\n", inet_ntoa(*hop));
	    }

	    fprintf(fp, "      </NextHops>\n");
	}

	fprintf(fp, "    </Node>\n");
    }

    fprintf(fp, "  </Routers>\n");
}


void xmlTopology(FILE *fp, Topology *topology)
{
    fprintf(fp, "<?xml version='1.0' encoding='UTF-8'?>\n");

    fprintf(fp, "<Topology>\n");
    xmlRouters(fp, topology);
    xmlLinks(fp, topology);
    xmlSubnets(fp, topology);
    fprintf(fp, "</Topology>\n");
}


void dump(void *buffer, int len, int mode)
{
    char *ptr = (char *) buffer;
    int i;

    if (mode < 3) {
	printf("Dump: ");
	for (i=0; i<len; i++) {
	    if (i % 8 == 0)
		printf(" ");
	    if (i % 16 == 0)
		printf("\n");
	    switch (mode) {
		case 0:
		    printf("%02X ", (unsigned char) ptr[i]);
		break;
		case 1:
		    printf("%03d ", (unsigned char) ptr[i]);
		break;
		case 2:
		    printf("%c ", (unsigned char) ptr[i]);
		break;
	    }
	}
    } else
	for (i=0; i<len; i++)
	    printf("%d.", (unsigned char) ptr[i]);
    printf("\n");
}
