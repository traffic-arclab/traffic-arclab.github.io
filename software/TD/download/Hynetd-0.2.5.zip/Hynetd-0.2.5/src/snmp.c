/*
 *	Component of the Hynetd v0.2.5 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2008 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *    
 *    For professional services please write to tdpro@comics.unina.it.
 */


#include "snmp.h"
#include "output.h"

#define OID_STRING_LEN 50


void snmpSetup(OidVars *oids)
{
    init_snmp("snmpapp"); 

    
    oids->sysDescr = strdup("1.3.6.1.2.1.1.1.0");
    oids->ipForwarding = strdup("1.3.6.1.2.1.4.1.0");
    oids->ipAdEntAddr = strdup("1.3.6.1.2.1.4.20.1.1");
    oids->ipAdEntIfIndex = strdup("1.3.6.1.2.1.4.20.1.2");
    oids->ipAdEntNetMask = strdup("1.3.6.1.2.1.4.20.1.3");
    oids->ifSpeed = strdup("1.3.6.1.2.1.2.2.1.5");
    oids->defaultGw = strdup("1.3.6.1.2.1.4.21.1.7.0.0.0.0");
    oids->ipNetToMediaNetAddress = strdup("1.3.6.1.2.1.4.22.1.3");
    oids->ipNetToMediaPhysAddress = strdup("1.3.6.1.2.1.4.22.1.2");
    oids->ipRouteDest = strdup("1.3.6.1.2.1.4.21.1.1");
    oids->ipRouteMask = strdup("1.3.6.1.2.1.4.21.1.11");
    oids->ipRouteType = strdup("1.3.6.1.2.1.4.21.1.8");
    oids->ipRouteNextHop = strdup("1.3.6.1.2.1.4.21.1.7");
}


int snmpGet(SnmpOpt opt, void *value)
{
    struct snmp_pdu *pdu; 		
    struct snmp_pdu *response; 		
    struct variable_list *vars; 	
    oid root[MAX_OID_LEN]; 		
    size_t rootlen = MAX_OID_LEN; 	
    int status = 0; 			
    int count = 0; 			
    unsigned int *intValue = value; 	
    struct in_addr *ipValue = value; 	

    
    pdu = snmp_pdu_create(SNMP_MSG_GET);
    read_objid(opt.oid, root, &rootlen);
    snmp_add_null_var(pdu, root, rootlen);

    status = snmp_sess_synch_response(opt.session, pdu, &response); 

    
    
    if (status == STAT_SUCCESS && response->errstat == SNMP_ERR_NOERROR) {
	for (vars = response->variables; vars; vars = vars->next_variable) {
	    switch (opt.type) {
		case ASN_GAUGE:
		    
		    if (vars->type == ASN_GAUGE) {
			*intValue = *vars->val.integer;
			count = 1;
#ifdef DEBUG
			debugOut(SNMP,"Thread Manager: (%d) OID - %s -> %u\n", count, opt.oid, *intValue);
#endif
		    } else
			printf("value #%d is NOT a gauge! Ack!\n", count);
		break;
		case ASN_INTEGER:
		    
		    if (vars->type == ASN_INTEGER) {
			*intValue = *vars->val.integer;
			count = 1;
#ifdef DEBUG
			debugOut(SNMP,"Thread Manager: (%d) OID - %s -> %d\n", count, opt.oid, *intValue);
#endif
		    } else
			printf("value #%d is NOT an integer! Ack!\n", count);
		break;
		case ASN_IPADDRESS:
		    
		    if (vars->type == ASN_IPADDRESS) {
			char address[16];
			u_char *ipAddr = vars->val.string;

			sprintf(address, "%d.%d.%d.%d", ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
			inet_aton(address, ipValue);
			count = 1;
#ifdef DEBUG
			debugOut(SNMP,"Thread Manager: (%d) OID - %s -> %s\n", count, opt.oid, address);
#endif
		    } else
			printf("value #%d is NOT an IP address! Ack!\n", count);
		break;
	    }
	}
    }
    
    else
	count = 0;

    
    if (response)
	snmp_free_pdu(response);

    return count;
}


int snmpGetNext(SnmpOpt opt, List *list)
{
    struct snmp_pdu *pdu; 
    struct snmp_pdu *response; 
    struct variable_list *vars= NULL; 
    oid name[MAX_OID_LEN]; 
    size_t name_length = MAX_OID_LEN; 
    oid root[MAX_OID_LEN]; 
    size_t rootlen = MAX_OID_LEN; 
    int status = 0; 
    bool running = true; 
    int count = 0; 
    char oidString[OID_STRING_LEN+1]; 

    listInit(list); 

    
    read_objid(opt.oid, name, &name_length);
    read_objid(opt.oid, root, &rootlen);

    while (running) {
	
	pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
	snmp_add_null_var(pdu, name, name_length);

	status = snmp_sess_synch_response(opt.session, pdu, &response); 

	
	
	if (status == STAT_SUCCESS) {
	    if (response->errstat == SNMP_ERR_NOERROR) {
		
		for (vars = response->variables; vars; vars = vars->next_variable) {

		    
		    if ((vars->name_length < rootlen) || (memcmp(root, vars->name, rootlen * sizeof(oid)) != 0)) {
			running = false;
			continue;
		    }

		    
		    snprint_objid(oidString, OID_STRING_LEN, vars->name, name_length);
		    if (!strstr(oidString, "0.0.0.0") && !strstr(oidString, "127.0.0.")) {
			if (vars->type != SNMP_ENDOFMIBVIEW && vars->type != SNMP_NOSUCHOBJECT && vars->type
			        != SNMP_NOSUCHINSTANCE) {
			    switch (opt.type) {
				case ASN_GAUGE:
				    
				    if (vars->type == ASN_GAUGE) {
					unsigned int *tmp = (unsigned int *) malloc(sizeof(unsigned int));
					*tmp = *vars->val.integer;
					listPush(list, tmp);
					count++;
#ifdef DEBUG
					debugOut(SNMP,"Thread Manager: (%d) OID - %s -> %u\n", count, oidString, *tmp);
#endif
				    } else
					printf("value #%d is NOT a gauge! Ack!\n", count);
				break;
				case ASN_INTEGER:
				    
				    if (vars->type == ASN_INTEGER) {
					unsigned int *tmp = (unsigned int *) malloc(sizeof(unsigned int));
					*tmp = *vars->val.integer;
					listPush(list, tmp);
					count++;
#ifdef DEBUG
					debugOut(SNMP,"Thread Manager: (%d) OID - %s -> %d\n", count, oidString, *tmp);
#endif
				    } else
					printf("value #%d is NOT an integer! Ack!\n", count);
				break;
				case ASN_IPADDRESS:
				    
				    if (vars->type == ASN_IPADDRESS) {
					struct in_addr *tmp = (struct in_addr *) malloc(sizeof(struct in_addr));
					char address[16];
					u_char *ipAddr = vars->val.string;

					sprintf(address, "%d.%d.%d.%d", ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
					inet_aton(address, tmp);
					if (!strstr(address, "0.0.0.0") && !strstr(address, "127.0.0.")) {
					    listPush(list, tmp);
					    count++;
#ifdef DEBUG
					    debugOut(SNMP,"Thread Manager: (%d) OID - %s -> %s\n", count, oidString, address);
#endif
					}
				    } else
					printf("value #%d is NOT an IP address! Ack!\n", count);
				break;
			    }
			}
			
			else {
			    running = false;
			    continue;
			}
		    }

		    
		    memmove((char *) name, (char *) vars->name, vars->name_length * sizeof(oid));
		    name_length = vars->name_length;
		}
	    }
	    
	    else {
		running = false;
		fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring (response->errstat));
		if (response->errstat == SNMP_ERR_NOSUCHNAME) {
		    fprintf(stderr, "The request for this object identifier failed: ");
		    if (vars)
			fprint_objid(stderr, vars->name, vars->name_length);
		    fprintf(stderr, "\n");
		}
	    }
	}
	
	else if (status == STAT_TIMEOUT) {
	    struct snmp_session *sptr = snmp_sess_session(opt.session); 
	    fprintf(stderr, "Timeout: No Response from %s\n", sptr->peername);
	    running = false;
	    count = -1;
	}
	
	else {
	    snmp_perror("snmpwalk");
	    running = false;
	    count = -1;
	}

	
	if (response)
	    snmp_free_pdu(response);
    }

    return count;
}


int snmpGetNextE(SnmpOpt opt, List *list)
{
    struct snmp_pdu *pdu; 		
    struct snmp_pdu *response; 		
    struct variable_list *vars= NULL; 	
    oid name[MAX_OID_LEN]; 		
    size_t name_length = MAX_OID_LEN; 	
    oid root[MAX_OID_LEN]; 		
    size_t rootlen = MAX_OID_LEN; 	
    int status = 0; 			
    bool running = true; 		
    int count = 0; 			
    char oidString[OID_STRING_LEN+1]; 	

    listInit(list); 

    
    read_objid(opt.oid, name, &name_length);
    read_objid(opt.oid, root, &rootlen);

    while (running) {
	
	pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
	snmp_add_null_var(pdu, name, name_length);

	status = snmp_sess_synch_response(opt.session, pdu, &response); 

	
	
	if (status == STAT_SUCCESS) {
	    if (response->errstat == SNMP_ERR_NOERROR) {
		
		for (vars = response->variables; vars; vars = vars->next_variable) {

		    
		    memmove((char *) name, (char *) vars->name, vars->name_length * sizeof(oid));
		    name_length = vars->name_length;

		    
		    if ((vars->name_length < rootlen) || (memcmp(root, vars->name, rootlen * sizeof(oid)) != 0)) {
			running = false;
			continue;
		    }

		    
		    snprint_objid(oidString, OID_STRING_LEN, vars->name, vars->name_length);
		    if (!strstr(oidString, "0.0.0.0") && !strstr(oidString, "127.0.0.")) {
			if (vars->type != SNMP_ENDOFMIBVIEW && vars->type != SNMP_NOSUCHOBJECT && vars->type
			        != SNMP_NOSUCHINSTANCE) {
			    SnmpResponse *tmp = (SnmpResponse *) calloc(1, sizeof(SnmpResponse));

			    
			    inet_aton(index(oidString, '.') + 1, &tmp->key);

			    switch (opt.type) {
				case ASN_GAUGE:
				    
				    if (vars->type == ASN_GAUGE) {
					tmp->intValue = *vars->val.integer;
					listPush(list, tmp);
					count++;
#ifdef DEBUG
					debugOut(SNMP,"Thread Manager: (%d) OID - %s (%s)-> %u\n", count, oidString, inet_ntoa(tmp->key), tmp->intValue);
#endif
				    } else
					printf("value #%d is NOT a gauge! Ack!\n", count);
				break;
				case ASN_INTEGER:
				    
				    if (vars->type == ASN_INTEGER) {
					tmp->intValue = *vars->val.integer;
					listPush(list, tmp);
					count++;
#ifdef DEBUG
					debugOut(SNMP,"Thread Manager: (%d) OID - %s (%s)-> %d\n", count, oidString, inet_ntoa(tmp->key), tmp->intValue);
#endif
				    } else
					printf("value #%d is NOT an integer! Ack!\n", count);
				break;
				case ASN_IPADDRESS:
				    
				    if (vars->type == ASN_IPADDRESS) {
					char address[16];
					u_char *ipAddr = vars->val.string;

					sprintf(address, "%d.%d.%d.%d", ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
					inet_aton(address, &tmp->ipValue);
					listPush(list, tmp);
					count++;
#ifdef DEBUG
					debugOut(SNMP,"Thread Manager: (%d) OID - %s (%s)-> %s\n", count, oidString, inet_ntoa(tmp->key), address);
#endif
				    } else
					printf("value #%d is NOT an IP address! Ack!\n", count);
				break;
			    }
			}
			
			else {
			    running = false;
			    continue;
			}
		    }
		}
	    }
	    
	    else {
		running = false;
		fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring (response->errstat));
		if (response->errstat == SNMP_ERR_NOSUCHNAME) {
		    fprintf(stderr, "The request for this object identifier failed: ");
		    if (vars)
			fprint_objid(stderr, vars->name, vars->name_length);
		    fprintf(stderr, "\n");
		}
	    }
	}
	
	else if (status == STAT_TIMEOUT) {
	    struct snmp_session *sptr = snmp_sess_session(opt.session); 
	    fprintf(stderr, "Timeout: No Response from %s\n", sptr->peername);
	    running = false;
	    count = -1;
	}
	
	else {
	    snmp_perror("snmpwalk");
	    running = false;
	    count = -1;
	}

	
	if (response)
	    snmp_free_pdu(response);
    }

    return count;
}
