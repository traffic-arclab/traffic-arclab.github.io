/*
 *	Component of the Hynetd v0.2.5 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2008 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *    
 *    For professional services please write to tdpro@comics.unina.it.
 */


#ifndef _SNMP_H
#define _SNMP_H



#include "types.h"
#include "debug.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>




typedef struct SnmpOpt {
	struct in_addr dest;	
	char *oid; 				
	unsigned char type;		
	void *session;			
} SnmpOpt;


typedef struct OidVars {
	char *sysDescr;					
	char *ipForwarding;
	char *ipAdEntAddr;
	char *ipAdEntIfIndex;
	char *ipAdEntNetMask;
	char *ifSpeed;
	char *defaultGw;
	char *ipNetToMediaNetAddress;	
	char *ipNetToMediaPhysAddress;	
	char *ipRouteDest;
	char *ipRouteMask;
	char *ipRouteType;
	char *ipRouteNextHop;
} OidVars;


typedef struct SnmpResponse {
	struct in_addr key;
	union {
		struct in_addr ipValue;
		unsigned int intValue;
	};
} SnmpResponse;




void snmpSetup (OidVars *oids);


int snmpGet (SnmpOpt opt, void *value);


int snmpGetNext (SnmpOpt opt, List *list);


int snmpGetNextE (SnmpOpt opt, List *list);

#endif
