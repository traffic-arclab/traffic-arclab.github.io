/*
 *	Component of the Hynetd v0.2.3 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */



#ifndef _LIST_H
#define _LIST_H

#include <stdlib.h>


#ifndef _BOOL_
#define _BOOL_
typedef enum {false, true} bool;	
#endif


typedef struct ListEntry {
   void *element;          
   struct ListEntry *next; 
} ListEntry;


typedef struct List {
   u_int16_t size;		
   bool empty;			
   ListEntry *head;		
   ListEntry *last;		
} List;
 



void listInit (List *list);


void listReset (List *list, bool full);


void listPush (List *list, void *element);


void *listPop (List *list);


void *listGet (List *list, int i);


void *listSearch (List *list, const void *element, bool(*compare)(const void *, const void *));

#endif
