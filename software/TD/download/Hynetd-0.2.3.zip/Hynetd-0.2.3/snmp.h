/*
 *	Component of the Hynetd v0.2.3 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */



#ifndef _SNMP_H
#define _SNMP_H



#include "types.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>




typedef struct SnmpOpt {
	struct in_addr dest;	
	char *oid; 				
	unsigned char type;		
	void *session;			
} SnmpOpt;


typedef struct OidVars {
	char *sysDescr;					
	char *ipForwarding;
	char *ipAdEntAddr;
	char *ipAdEntIfIndex;
	char *ipAdEntNetMask;
	char *ifSpeed;
	char *defaultGw;
	char *ipNetToMediaNetAddress;	
	char *ipNetToMediaPhysAddress;	
	char *ipRouteDest;
	char *ipRouteMask;
	char *ipRouteType;
	char *ipRouteNextHop;
} OidVars;




void snmpSetup (OidVars *oids);


int snmpGet (SnmpOpt opt, void *value);


int snmpGetNext (SnmpOpt opt, List *list);

#endif
