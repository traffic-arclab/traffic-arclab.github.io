/*
 *	Component of the Hynetd v0.2.3 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */



#ifndef _POSTPROCESSING_H
#define _POSTPROCESSING_H



#include "scanner.h"



#define MAX_SUBNET_LINK 4	



typedef enum {PREC_HOP_RR, PREC_HOP, NO_PREC_HOP} SubExtPhase;	



void extractLinks (ThreadParam *params);


void extractSubnets (ThreadParam *params);


NetNode *icmpRow2NetNode (ThreadParam *params, IcmpRow *row);


struct in_addr keshav (List *rows);


void icmpTabSubnetCmp (ThreadParam *params, bool allSubnets);


void icmpRow2Subnet (ThreadParam *params, ListEntry *current, SubExtPhase phase);


void defaultGateway (IcmpRow *row, Subnet *net);

#endif
