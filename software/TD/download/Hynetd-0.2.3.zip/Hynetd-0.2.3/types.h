/*
 *	Component of the Hynetd v0.2.3 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */



#ifndef _TYPES_H
#define _TYPES_H

#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdio.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <net/ethernet.h>
#include <string.h>
#include <stdlib.h>
#include "list.h"



#ifndef _BOOL_
#define _BOOL_
typedef enum {false, true} bool;	
#endif


typedef struct Interface {
	struct in_addr ip;		
	struct in_addr mask;	
	unsigned int speed;		
	List arpTable;			
} Interface;


typedef struct ArpTableRow {
	struct in_addr ip;		
	
} ArpTableRow;

typedef enum {HOST, ROUTER} NodeType;	


typedef struct NetNode {
	char *name;					
	u_char *SNMPCommunity;		
	NodeType type;				
	struct in_addr defaultGw;	
	List nonDirectSubnets;		
	List interfaces;			
	List nextHops;				
} NetNode;


typedef struct NetLink {
	bool snmp;				
	unsigned int speed;		
	u_int8_t hop;			
	NetNode *srcNode;		
	NetNode *dstNode;		
	Interface *srcIf;		
	Interface *dstIf;		
} NetLink;

typedef enum {EXACT, EURISTIC} Reliability;	


typedef struct Subnet {
	struct in_addr netId;		
	u_int8_t netMask;			
	union {
		struct in_addr defaultGw;	
		struct in_addr nextHop;		
	};
	Reliability type;			
	u_int8_t hop;				
	List *nodes;				
} Subnet;


typedef struct Topology {
	List routers;	
	List links;		
	List subnets;	
} Topology;

typedef enum {TRACEROUTE, RECORDROUTE, BOTH} Accuracy;	


typedef struct IcmpRow {
	struct in_addr ipAddr;		
	struct in_addr netMask;		
	struct IcmpRow *precHop;	
	struct IcmpRow *nextHop;	
	struct IcmpRow *precHopRR;	
	struct IcmpRow *nextHopRR;	
	char *ipDNS;				
	u_int8_t hop;				
	Accuracy accuracy;			
	Reliability accuNetMask;	
	bool router;				
	struct in_addr alias;		
	struct in_addr aliasRR;		
	struct in_addr dest;		
	NetNode *assNode;			
	Subnet *assSubnet;			
} IcmpRow;




u_int8_t shortMask (const struct in_addr mask);


struct in_addr longMask (const u_int8_t sMask);


bool icmpRowCmp (struct in_addr *ip, IcmpRow *row);


bool
nextHopCmp (Interface *interface, struct in_addr *nextHop);


bool
nodeNextHopCmp (struct in_addr *ip, NetNode *node);


bool nodeCmp (struct in_addr *ip, NetNode *node);


bool subnetCmp (struct in_addr *netId, Subnet *subnet);


bool ifCmp (struct in_addr *ip, Interface *itf);


bool ipCmp (struct in_addr *ip1, struct in_addr *ip2);


bool linkCmp (NetLink *link1, NetLink *link2);


bool ipLinkCmp (struct in_addr *ip, NetLink *link);



bool ipSubnet (struct in_addr *ip, Subnet *subnet);


bool rowSubnet (IcmpRow *row, Subnet *subnet);


bool nodeAddrCmp (NetNode *node1, NetNode *node2);


bool subnetInclude (Subnet *net, Subnet *subnet);

#endif
