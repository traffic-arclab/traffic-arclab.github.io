/*
 *	Component of the Hynetd v0.2.3 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */


 
#include "scanner.h"




pthread_mutex_t mutex_options = PTHREAD_MUTEX_INITIALIZER;	
pthread_mutex_t mutex_params = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_icmpTab = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_topology = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_sync = PTHREAD_MUTEX_INITIALIZER;





unsigned short
cksum (unsigned short *addr, int len)
{
	int nleft = len;
	int sum = 0;
	unsigned short *w = addr;
	unsigned short answer = 0;
	
	while (nleft > 1) {
		sum = sum + *w++;
		nleft = nleft - 2;
	}
	
	if (nleft == 1) {
		*(unsigned char *) (&answer) = *(unsigned char *) w;
		sum = sum + answer;
	}
	sum = (sum >> 16) + (sum & 0xffff);
	sum = sum + (sum >> 16);
	answer = ~sum;
	return answer;
}


u_int8_t
getDefaultTTL (void)
{
	FILE *fp;
	int ttl;

	fp = fopen ("/proc/sys/net/ipv4/ip_default_ttl", "r");
	fscanf (fp, "%d", &ttl);
	fclose (fp);

	return ttl;
}


int
traceroute (struct in_addr addr, Options *opt, Path *hops)
{
	int socketfd[2];					
	char pkt_buf[MAX_PACKET];			
	struct sockaddr_in dst_addr;		
	struct sockaddr_in src_addr;		
	struct icmp *icmp_buf;				
	struct iphdr *ip_buf;				
	struct timeval tv;					
	int ttl = 1;						
	u_int8_t retry = 0;					
	TraceState state = SCANNING;		
	bool icmp_filtered = false;			
	bool udp_filtered = false;			
	u_int8_t mode = opt->gOpts->mode;	

	
	hops->array = (struct in_addr *) calloc (opt->gOpts->max_ttl, sizeof(struct in_addr));

#ifdef DEBUG
	char debugBuf[50];
	printf ("Thread %02d - Traceroute destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif

	
	dst_addr.sin_family = AF_INET;	
	dst_addr.sin_addr = addr;
	dst_addr.sin_port = BIG_UDP_PORT;
	
	
	if ((socketfd[ICMP] = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {	
		perror ("traceroute: error in socket0 creation");
		return -1;
	}

	
	if ((socketfd[UDP] = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {	
		perror ("traceroute: error in socket1 creation");
		return -1;
	}

	
	tv.tv_sec = opt->gOpts->timeout / 1000;			
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	
	setsockopt (socketfd[ICMP], SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));
	
	do {
		TraceMode turn = (retry + mode) % 2;
		
		
		if (!icmp_filtered && (turn == ICMP || (turn == UDP && udp_filtered)))
		{
			
			if (setsockopt (socketfd[ICMP], IPPROTO_IP, IP_TTL, (char *) &ttl, sizeof (ttl)) < 0) {
				perror ("traceroute: error in setsockopt IP_TTL");
				return -3;
			}
			
			
			icmp_buf = (struct icmp *) pkt_buf;
			icmp_buf->icmp_type = ICMP_ECHO;
			icmp_buf->icmp_code = 0;
			icmp_buf->icmp_id = getpid ();
			icmp_buf->icmp_seq = 0;
			icmp_buf->icmp_cksum = 0;
			icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
			
			
			if (sendto(socketfd[ICMP], icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
				perror ("traceroute: error in sendto");
				return -4;
			}
#ifdef DEBUG
			sprintf (debugBuf, "Thread %02d - Sent ICMP (TTL %02d)-> ", opt->lOpts->threadNum, ttl);
#endif
		}
		
		else if (!udp_filtered && (turn == UDP || (turn == ICMP && icmp_filtered)))
		{
			
			if (setsockopt (socketfd[UDP], IPPROTO_IP, IP_TTL, (char *) &ttl, sizeof (ttl)) < 0) {
				perror ("traceroute: error in setsockopt IP_TTL");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -3;
			}

			
			memset (&pkt_buf, 'X', UDP_SIZE);
			
			
			if (sendto(socketfd[UDP], pkt_buf, UDP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
				perror ("traceroute: error in sendto");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -4;
			}
#ifdef DEBUG
			sprintf (debugBuf, "Thread %02d - Sent UDP  (TTL %02d)-> ", opt->lOpts->threadNum, ttl);
#endif
		}
		
		else state = DEST_FILTERED;
		
		
		while (!state) 
		{
			socklen_t lsock = sizeof(dst_addr);	
			
			if (recvfrom(socketfd[ICMP], &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock) < 0) 
			{
				
#ifdef DEBUG
				printf ("%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				if (retry < opt->gOpts->retries) retry++;
				else {
					
					hops->array[ttl-1].s_addr = (u_int32_t) 0;
					ttl++;
					retry = 0;
				}
				break;			
			}
			
			
			ip_buf = (struct iphdr *) &pkt_buf[IP_SIZE + 8];	
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		
			
			
			if (icmp_buf->icmp_type == ICMP_TIME_EXCEEDED && ip_buf->daddr == addr.s_addr) 
			{
#ifdef DEBUG
				printf ("%sReceived ICMP_TIME_EXCEEDED from %s\n", debugBuf, inet_ntoa(src_addr.sin_addr));
#endif
				
				hops->array[ttl-1].s_addr = src_addr.sin_addr.s_addr;
				hops->length = ttl;
				
				
				if(src_addr.sin_addr.s_addr == addr.s_addr) {
					state = DEST_REACHED;
					break;
				}
				
				
				if (ip_buf->protocol == IPPROTO_UDP) mode = UDP;
				else mode = ICMP;
				
				ttl++;
				retry = 0;		
				break;
			}
			
			
			else if (icmp_buf->icmp_type == ICMP_ECHOREPLY && src_addr.sin_addr.s_addr == addr.s_addr) 
			{ 
#ifdef DEBUG
				printf ("%sReceived ICMP_ECHOREPLY from %s\n", debugBuf, inet_ntoa (src_addr.sin_addr));
#endif
				hops->array[ttl-1].s_addr = src_addr.sin_addr.s_addr;
				hops->length = ttl;
				state = DEST_REACHED;
				break;	      
			}

			
			else if (icmp_buf->icmp_type == ICMP_DEST_UNREACH && ip_buf->daddr == addr.s_addr) 
			{
				
				if (icmp_buf->icmp_code == ICMP_PORT_UNREACH)
				{
#ifdef DEBUG
					printf ("%sReceived ICMP_PORT_UNREACH from %s\n", debugBuf, inet_ntoa (src_addr.sin_addr));
#endif
					hops->array[ttl-1].s_addr = src_addr.sin_addr.s_addr;
					hops->length = ttl;
					state = DEST_REACHED;
					break;	      

				}
				
				else if (icmp_buf->icmp_code == ICMP_PKT_FILTERED)
				{
#ifdef DEBUG
					printf ("%sReceived ICMP_PKT_FILTERED from %s (proto=%d)\n", 
							debugBuf, inet_ntoa (src_addr.sin_addr), ip_buf->protocol);
#endif
					
					if (ip_buf->protocol == IPPROTO_UDP) udp_filtered = true;
					if (ip_buf->protocol == IPPROTO_ICMP) icmp_filtered = true;
					
					retry++;
					break;
				}
				
				else
				{
#ifdef DEBUG
					printf ("%sReceived ICMP_DEST_UNREACH (code=%d) from %s\n", 
							debugBuf, icmp_buf->icmp_code, inet_ntoa (src_addr.sin_addr));
#endif
					hops->array[ttl-1].s_addr = src_addr.sin_addr.s_addr;
					hops->length = ttl;
					state = DEST_UNREACHABLE;
				}
			}
		}
		if (ttl > opt->gOpts->max_ttl) state = MAX_TTL_REACHED;
	} while (!state);

	close (socketfd[ICMP]);
	close (socketfd[UDP]);
	
#ifdef DEBUG
	switch (state) {
		case SCANNING: break;
		case DEST_REACHED:
			printf ("Thread %02d - Destination %s reached in %d hops\n",
					opt->lOpts->threadNum, inet_ntoa (addr), ttl);
		break;
		case MAX_TTL_REACHED:
			printf ("Thread %02d - Destination %s not reached in %d hops (MAX_TTL_REACHED)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), ttl);
		break;
		case DEST_FILTERED:
			printf ("Thread %02d - Destination %s not reached in %d hops (DEST_FILTERED)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
		case DEST_UNREACHABLE:
			printf ("Thread %02d - Destination %s not reached in %d hops (DEST_UNREACHABLE)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
	}
#endif

	return state;
}


int
pingrr (struct in_addr addr, Options *opt, Path *hops)
{
	int socketfd;					
	char pkt_buf[MAX_PACKET];		
	struct sockaddr_in dst_addr;	
	struct sockaddr_in src_addr;	
	struct icmp *icmp_buf;			
	struct timeval tv;				
	u_int8_t retry = 0;				
	char rspace[3 + 4*NROUTES + 1]; 
	bool done = false;
	bool alias = false;

	
	hops->array = (struct in_addr *) calloc (NROUTES, sizeof(struct in_addr));
	hops->newRows = (IcmpRow **) calloc (NROUTES, sizeof(IcmpRow *));
	hops->length = 0;

#ifdef DEBUG
	char debugBuf[50];
	debugOut (PINGRR, "Thread %02d - PingRR destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif
	
	
	dst_addr.sin_family = AF_INET;
	dst_addr.sin_addr.s_addr = addr.s_addr;
	
	
	if ((socketfd = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {	
		perror ("traceroute: error in socket creation");
		return -1;
	}
	
	
	tv.tv_sec = opt->gOpts->timeout / 1000;				
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	
	setsockopt (socketfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));
	
	
	memset (rspace, 0, sizeof (rspace));
	rspace[IPOPT_OPTVAL] = IPOPT_RR;
	rspace[IPOPT_OLEN] = sizeof (rspace) - 1;
	rspace[IPOPT_OFFSET] = IPOPT_MINOFF;
	if (setsockopt (socketfd, IPPROTO_IP, IP_OPTIONS, rspace, sizeof (rspace)) < 0) {
		perror ("pingrr: error while setting record route option");
		close (socketfd);
		return -1;
	}
	
	while (retry <= opt->gOpts->retries && !done) {
		
		icmp_buf = (struct icmp *) pkt_buf;
		icmp_buf->icmp_type = ICMP_ECHO;
		icmp_buf->icmp_code = 0;
		icmp_buf->icmp_id = getpid ();
		icmp_buf->icmp_seq = 0;
		icmp_buf->icmp_cksum = 0;
		icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
		
		
		if (sendto(socketfd, icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
			perror ("pingrr: error in sendto");
			close (socketfd);
			return -2;
		}
#ifdef DEBUG
		sprintf (debugBuf, "Thread %02d - Sent ICMP-> ", opt->lOpts->threadNum);
#endif
	
		
		do {
			socklen_t lsock = sizeof(dst_addr);	
			int pkt_len;
			
			if ((pkt_len = recvfrom(socketfd, &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock)) < 0) 
			{
				
#ifdef DEBUG
				debugOut (PINGRR, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				retry++;
				break;
			}
			
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE_RR];		
			
			
			if (icmp_buf->icmp_type == ICMP_ECHOREPLY && src_addr.sin_addr.s_addr == addr.s_addr) 
			{ 
				u_int32_t *l;		
				u_int32_t *myaddr;	
				int i;
#ifdef DEBUG
				debugOut (PINGRR, "%sReceived ICMP_ECHOREPLY from %s (%d  bytes)\n",
							debugBuf, inet_ntoa (src_addr.sin_addr), pkt_len);
#endif
				l = (void *) (&pkt_buf) + IP_SIZE + 3;
				myaddr = (void *) (&pkt_buf) + IP_SIZE - 4;

				if (*myaddr == *l) l++;
				else return 0;
				
				
				for (i = 0; i < NROUTES-1; i++) {
					
					if (*l == 0) {
						hops->length = i+1;
						if (i == 0) return 0;
						break;
					}
					
					else if (i > 0 && hops->array[i-1].s_addr == *l) {
						hops->length = i+1;
						alias = true;
#ifdef DEBUG
						debugOut (PINGRR, "Thread %02d - TWICE\n", opt->lOpts->threadNum);
#endif
						break;
					}
					
					else if (addr.s_addr == *l || i == opt->lOpts->ttl - 1) {
						hops->array[i].s_addr = *l;
						hops->length = i+1;
#ifdef DEBUG
						debugOut (PINGRR, "Thread %02d - Hop #%d: %s\n", opt->lOpts->threadNum, i+1, inet_ntoa (hops->array[i]));
#endif
						if (addr.s_addr != *l) alias = true;
						break;
					}
					else {
						hops->array[i].s_addr = *l;
						hops->length = i+1;
#ifdef DEBUG
						debugOut (PINGRR, "Thread %02d - Hop #%d: %s\n", opt->lOpts->threadNum, i+1, inet_ntoa (hops->array[i]));
#endif
						
						if ((*(l-1) & ntohl (0xFFFFFFFC)) == (*(l+1) & ntohl (0xFFFFFFFC))) {
							if (addr.s_addr != *l) alias = true;
							break;
						}
					}
					
					l++;
				}
				
				
				if (i < NROUTES-2 && *(l+1) != *myaddr) {
					hops->array[i+1].s_addr = *(l+1);
#ifdef DEBUG
					debugOut (PINGRR, "Thread %02d - NextHopRR: %s\n", opt->lOpts->threadNum, inet_ntoa (hops->array[i+1]));
#endif
				}
				
				done = true;
			}
		} while (!done);	 
	}
	close (socketfd);
	
	if (done) {
		if (alias) return 2;
		else return 1;
	}	
	else return 0;
}


bool
ping (struct in_addr addr, Options *opt)
{
	int socketfd;					
	char pkt_buf[MAX_PACKET];		
	struct sockaddr_in dst_addr;	
	struct sockaddr_in src_addr;	
	struct iphdr *ip_buf;			
	struct icmp *icmp_buf;			
	struct timeval tv;				
	u_int8_t retry = 0;				
	bool done = false;
	
#ifdef DEBUG
	char debugBuf[50];
	debugOut (PING, "Thread %02d - Ping destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif
	
	
	dst_addr.sin_family = AF_INET;
	dst_addr.sin_addr.s_addr = addr.s_addr;
	
	
	if ((socketfd = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {
		perror ("ping: error in socket creation");
		return false;
	}

	
	tv.tv_sec = opt->gOpts->timeout / 1000;				
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	
	setsockopt (socketfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));

	while (retry <= opt->gOpts->retries && !done) {
		
		icmp_buf = (struct icmp *) pkt_buf;
		icmp_buf->icmp_type = ICMP_ECHO;
		icmp_buf->icmp_code = 0;
		icmp_buf->icmp_id = getpid ();
		icmp_buf->icmp_seq = retry;
		icmp_buf->icmp_cksum = 0;
		icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
		
		
		if (sendto(socketfd, icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
			
			close (socketfd);
			return false;
		}
#ifdef DEBUG
		sprintf (debugBuf, "Thread %02d - Sent ICMP-> ", opt->lOpts->threadNum);
#endif
	
		
		do {
			socklen_t lsock = sizeof(dst_addr);	
			int pkt_len;
					
			if ((pkt_len = recvfrom(socketfd, &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock)) < 0)
			{
				
#ifdef DEBUG
				debugOut (PING, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				retry++;
				break;
			}

			ip_buf = (struct iphdr *) pkt_buf;				
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];	
					
			
			if (icmp_buf->icmp_type == ICMP_ECHOREPLY && src_addr.sin_addr.s_addr == addr.s_addr)
			{
				
				if (ip_buf->ttl > 200) opt->lOpts->ttl = 256 - ip_buf->ttl;			
				else if (ip_buf->ttl > 128) opt->lOpts->ttl = 201 - ip_buf->ttl;	
				else if (ip_buf->ttl > 64) opt->lOpts->ttl = 129 - ip_buf->ttl;		
				else if (ip_buf->ttl > 60) opt->lOpts->ttl = 65 - ip_buf->ttl;		
				else if (ip_buf->ttl > 32) opt->lOpts->ttl = 61 - ip_buf->ttl;		
				else if (ip_buf->ttl > 30) opt->lOpts->ttl = 33 - ip_buf->ttl;		
				else opt->lOpts->ttl = 31 - ip_buf->ttl;							
#ifdef DEBUG
				debugOut (PING, "%sReceived ICMP_ECHOREPLY from %s (%d  bytes) => TTL ~ %d\n", 
						debugBuf, inet_ntoa (src_addr.sin_addr), pkt_len, opt->lOpts->ttl);
#endif
				if (opt->lOpts->ttl > opt->gOpts->max_ttl) opt->lOpts->ttl = opt->gOpts->max_ttl;
				done = true;
			}
		} while (!done);
	}
	close (socketfd);
	
	if (done) return true;
	else return false;
}


SnmpNode *
testSnmp (struct in_addr addr, Options *opt)
{
	struct snmp_session session;	
	struct snmp_session *sptr;		
	SnmpOpt options;				
	int forwarding;					
	ListEntry *community;			
	int socketfd;					

 	options.dest = addr;	
	
	
	snmp_sess_init (&session);							
	session.peername = strdup (inet_ntoa (addr));		
	session.version = SNMP_VERSION_1;					
	session.retries = opt->gOpts->retriesSnmp;			
	session.timeout = opt->gOpts->timeoutSnmp * 1000;	
	
    
    if (!(options.session = snmp_sess_open (&session))) {
	        snmp_perror ("ack");
	        return NULL;
    }
	
	sptr = snmp_sess_session (options.session);		
	
	
	if ((socketfd = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {
		perror ("snmpclient: error in icmp socket creation");
		return NULL;
	}
	
	
	for (community = opt->gOpts->communitySNMP.head; community; community = community->next) {
		
	    sptr->community = (unsigned char *) strdup (community->element);	
		sptr->community_len = strlen ((char *) community->element);			
	
#ifdef DEBUG
		debugOut (SNMPCLIENT, "Thread %02d - Testing community \"%s\" on %s\n", opt->lOpts->threadNum,
					community->element, session.peername);
#endif
		
		options.oid = opt->gOpts->oids->ipForwarding;
		options.type = ASN_INTEGER;
		if (snmpGet (options, &forwarding))
		{	
			SnmpNode *info = (SnmpNode *) calloc (1, sizeof(SnmpNode));	
			List vars;													
			ListEntry *i;												
			int result, k;

			
			info->addr = addr;
			info->type = (forwarding == 1) ? ROUTER : HOST;
			info->SNMPCommunity = (u_char *) strdup ((char *) community->element);

#ifdef DEBUG
			debugOut (SNMPCLIENT, "Thread %02d - Found %s using community %s\n", opt->lOpts->threadNum, 
						info->type ? "Router" : "Host", info->SNMPCommunity);
#endif
			
			sptr->timeout = 1000000;
			sptr->retries = 5;
			options.oid = opt->gOpts->oids->ipAdEntAddr;
			options.type = ASN_IPADDRESS;

			result = snmpGetNext (options, &vars);
#ifdef DEBUG
			debugOut (SNMPCLIENT, "Thread %02d - Interfaces address list: (%d)\n", opt->lOpts->threadNum, result);
#endif
			
			info->skipIndex = -1;
			listInit (&info->interfaces);
			for (i = vars.head, k=0; i; i = i->next, k++) {
				struct in_addr *ipAddr = i->element;	

				
				if (ipAddr->s_addr != INADDR_ANY) {
					Interface *ifTmp = calloc (1, sizeof(Interface));	
					ifTmp->ip = *ipAddr;								
					listPush (&info->interfaces, ifTmp);				
#ifdef DEBUG
					debugOut (SNMPCLIENT, "Thread %02d - %s\n", opt->lOpts->threadNum, inet_ntoa(*ipAddr));
#endif
				}
				
				else info->skipIndex = k;
			}
			listReset (&vars, true);
			
			
			snmp_sess_close (options.session);
			close (socketfd);
			return info;
		}

		
		do {
			struct sockaddr_in src_addr;			
			socklen_t lsock = sizeof(src_addr);		
			struct timeval tv;						
			struct icmp *icmp_buf;					
			struct iphdr *ip_buf;					
			char pkt_buf[MAX_PACKET];				
			int pkt_len;							

			
			tv.tv_sec = 0;		
			tv.tv_usec = 1000;	
			setsockopt (socketfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));

			if ((pkt_len = recvfrom(socketfd, &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock)) < 0)
			{
				
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread %02d - Received ICMP_TIMEOUT\n", opt->lOpts->threadNum);
#endif
				break;
			}

			ip_buf = (struct iphdr *) &pkt_buf[IP_SIZE + 8];	
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		
					
			
			if (icmp_buf->icmp_type == ICMP_DEST_UNREACH && ip_buf->daddr == addr.s_addr)
			{
				if (ip_buf->ttl > 0)
					opt->lOpts->ttl = opt->gOpts->default_ttl - ip_buf->ttl + 1;	
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread %02d - Received ICMP_DEST_UNREACH from %s (%d  bytes)\n",
						opt->lOpts->threadNum, inet_ntoa (src_addr.sin_addr), pkt_len);
				debugOut (SNMPCLIENT, "Thread %02d - SNMP inactive on %s => TTL = %d\n",
					opt->lOpts->threadNum, session.peername, opt->lOpts->ttl);
#endif
				
				snmp_sess_close (options.session);
				close (socketfd);
				return NULL;
			}
		} while (true);
	}

	
	snmp_sess_close (options.session);
	close (socketfd);
	free (session.peername);
	return NULL;
}


NetNode *
snmpclient (SnmpNode *node, GlobalOptions *gOpts, u_int16_t *nodeCount)
{
	struct snmp_session session;					
	SnmpOpt options;								
	List vars;										
	List ifs;										
	struct in_addr ip;								
	unsigned int value;								
	int result;										
	int skipIndex = -1;								
	ListEntry *current;								
	Interface *ifTmp;								
	ListEntry *i, *j;								
	struct hostent *host;							
	int k;
	NetNode *info = calloc (1, sizeof(NetNode));	

 	options.dest = node->addr;	
	
	
	snmp_sess_init (&session);								
	session.peername = strdup (inet_ntoa (node->addr));		
	session.version = SNMP_VERSION_1;						
	session.retries = 5;									
	session.timeout = 1000000;								

	
	session.community = node->SNMPCommunity;						
	session.community_len = strlen ((char *) session.community);	

    
    if (!(options.session = snmp_sess_open (&session))) {
        snmp_perror ("ack");
        return NULL;
    }
	
#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - SNMP agent: %s\n", inet_ntoa (node->addr));
	debugOut (SNMPCLIENT, "Thread Manager - Node type: %s\n", node->type ? "ROUTER" : "HOST");
#endif
	
	
	info->type = node->type;
	info->SNMPCommunity = node->SNMPCommunity;
	info->interfaces = node->interfaces;
	skipIndex = node->skipIndex;
	
	
	if (gOpts->dns) host = gethostbyaddr ((char *) &node->addr.s_addr, sizeof(node->addr.s_addr), AF_INET);
	else host = NULL;
	
	if (host) {
		info->name = calloc (strlen(host->h_name)+1, sizeof(char));
		strncpy (info->name, host->h_name, strlen(host->h_name));
	}
	
	else {
		info->name = calloc (7, sizeof(char));
		sprintf (info->name, "Dev%d", *nodeCount);
		*nodeCount += 1;
	}
	printf ("."); fflush (stdout);	

	
	options.oid = gOpts->oids->defaultGw;
	options.type = ASN_IPADDRESS;
	result = snmpGet (options, &ip);

	
	if (result > 0) info->defaultGw = ip;
#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - Default Gateway (%d): %s\n", result, inet_ntoa(info->defaultGw));
#endif

	printf ("."); fflush (stdout);	
	
	
	options.oid = gOpts->oids->ipAdEntIfIndex;
	options.type = ASN_INTEGER;

	result = snmpGetNext (options, &ifs);

	
#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - Interfaces speed list: (%d)\n", ifs.size);
#endif
	options.type = ASN_GAUGE;
	options.oid = (char *) malloc (MAX_OID_LEN);
	current = info->interfaces.head;
	for (i = ifs.head, k=0; i; i = i->next, k++) {
		unsigned int *intValue = i->element;	

		
		if (k != skipIndex) {
			sprintf(options.oid, "%s.%d", gOpts->oids->ifSpeed, *intValue);
			result = snmpGet (options, &value);

#ifdef DEBUG
			debugOut (SNMPCLIENT, "Thread Manager - %u (%d)\n", value, *intValue);
#endif
			
			ifTmp = current->element;
			ifTmp->speed = value;
			current = current->next;
		}
	}
	free (options.oid);
	
	printf ("."); fflush (stdout);	

	
	options.oid = gOpts->oids->ipAdEntNetMask;
	options.type = ASN_IPADDRESS;

	result = snmpGetNext (options, &vars);

#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - Interfaces netmask list: (%d)\n", result);
#endif
	
	for (i = vars.head, k=0, current = info->interfaces.head; i; i = i->next, k++) {
		struct in_addr *ipAddr = i->element;	

		if (k != skipIndex) {
			ifTmp = current->element;
			ifTmp->mask = *ipAddr;
#ifdef DEBUG
			debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(ifTmp->mask));
#endif
			current = current->next;
		}
	}
	listReset (&vars, true);
	
	printf ("."); fflush (stdout);	

	
	if (gOpts->arp) {
#ifdef DEBUG
		debugOut (SNMPCLIENT, "Thread Manager - Interfaces ARP tables: (%d)\n", ifs.size);
#endif
		options.type = ASN_IPADDRESS;
		options.oid = (char *) malloc (MAX_OID_LEN);
		current = info->interfaces.head;
		for (i = ifs.head, k=0; i; i = i->next, k++) {
			unsigned int *intValue = i->element;	

			
			if (k != skipIndex) {
				ArpTableRow *rowTmp;	

				sprintf(options.oid, "%s.%d", gOpts->oids->ipNetToMediaNetAddress, *intValue);
				result = snmpGetNext (options, &vars);
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread Manager - Interface #%d (%u)\n", *intValue, result);
#endif
				
				ifTmp = current->element;
				listInit (&ifTmp->arpTable);

				
				for (j = vars.head; j; j = j->next) {
					struct in_addr *ipAddr = j->element;	

					rowTmp = (ArpTableRow *) calloc (1, sizeof(ArpTableRow));	
					rowTmp->ip = *ipAddr;										
					listPush (&ifTmp->arpTable, rowTmp);						
#ifdef DEBUG
					debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(*ipAddr));
#endif
				}
				listReset(&vars, true);
				current = current->next;
			}
		}
		free (options.oid);
	}
	
	printf ("."); fflush (stdout);	

	
	options.oid = gOpts->oids->ipRouteDest;
	options.type = ASN_IPADDRESS;
	result = snmpGetNext (options, &vars);
#ifdef DEBUG
	debugOut (SNMPCLIENT, "Thread Manager - Route destinations: (%d)\n", result);
#endif

	
	if (result > 0) {
		bool *direct = (bool *) calloc (result, sizeof(bool));	
		Subnet *subnetTmp;										
		int m, n;

		listInit (&info->nonDirectSubnets);		
		skipIndex = -1;							

		
		for (i = vars.head, m=0, k=0; i; i = i->next, k++) {
			bool found = false;						
			struct in_addr *ipAddr = i->element;	

			
			if (ipAddr->s_addr != INADDR_ANY) {
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(*ipAddr));
#endif
				
				for (current = info->interfaces.head, n=0; current && !found; current = current->next, n++) {
					ifTmp = current->element;
					
					if ((ifTmp->ip.s_addr & ifTmp->mask.s_addr) == ipAddr->s_addr) {
						direct[k] = true;
						found = true;
					}
				}
				
				if (!found) {
					direct[k] = false;
					subnetTmp = (Subnet *) malloc (sizeof(Subnet));		
					subnetTmp->netId = *ipAddr;
					subnetTmp->type = EXACT;
					listPush(&info->nonDirectSubnets, subnetTmp);		
				}
			}
			else skipIndex = k;
		}
		listReset(&vars, true);

		printf ("."); fflush (stdout);	
		
		
		options.oid = gOpts->oids->ipRouteMask;
		options.type = ASN_IPADDRESS;
		result = snmpGetNext (options, &vars);
#ifdef DEBUG
		debugOut (SNMPCLIENT, "Thread Manager - Route destinations netmasks: (%d)\n", result);
#endif

		
		current = info->nonDirectSubnets.head;
		for (i = vars.head, k=0; i; i = i->next, k++) {
			struct in_addr *ipAddr = i->element;	

			if (k != skipIndex) {
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(*ipAddr));
#endif
				
				if (!direct[k] && current) {
					subnetTmp = current->element;
					subnetTmp->netMask = shortMask(*ipAddr);
					current = current->next;
				}
			}
		}
		listReset (&vars, true);

		printf ("."); fflush (stdout);	
		
		
		options.oid = gOpts->oids->ipRouteNextHop;
		options.type = ASN_IPADDRESS;
		result = snmpGetNext (options, &vars);
#ifdef DEBUG
		debugOut (SNMPCLIENT, "Thread Manager - Route destinations next-hops: (%d)\n", result);
#endif
		listInit (&info->nextHops);		

		
		current = info->nonDirectSubnets.head;
		for (i = vars.head, k=0, m=0; i; i = i->next, k++) {
			struct in_addr *ipAddr = i->element;	

			if (k != skipIndex) {
#ifdef DEBUG
				debugOut (SNMPCLIENT, "Thread Manager - %s\n", inet_ntoa(*ipAddr));
#endif
				
				if (!direct[k]) {
					if (current) {
						subnetTmp = current->element;
						subnetTmp->nextHop = *ipAddr;
						if (ipAddr->s_addr != INADDR_ANY && !listSearch(&info->nextHops, ipAddr, (void *) ipCmp)) {
							listPush (&info->nextHops, &subnetTmp->nextHop);
						}
						current = current->next;
					}
				}
			}
		}
		listReset (&vars, true);
		listReset (&ifs, true);
	}

	
	snmp_sess_close (options.session);
	free (session.peername);

	return info;
}


struct in_addr 
icmpMask (struct in_addr addr, Options *opt)
{
	int socketfd;						
	char pkt_buf[MAX_PACKET];			
	struct sockaddr_in dst_addr;		
	struct sockaddr_in src_addr;		
	struct icmp *icmp_buf;				
	struct timeval tv;					
	u_int8_t retry = 0;					
	struct in_addr mask = {INADDR_ANY};	
	bool done = false;

#ifdef DEBUG
	char debugBuf[50];
	debugOut (MASK, "Thread %02d - Icmp Mask destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif
	
	
	dst_addr.sin_family = AF_INET;
	dst_addr.sin_addr.s_addr = addr.s_addr;
	
	
	if ((socketfd = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {
		perror ("icmpMask: error in socket creation");
		return mask;
	}
	
	
	tv.tv_sec = opt->gOpts->timeout / 1000;				
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	
	setsockopt (socketfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));
	
	while (retry <= opt->gOpts->retries && !done) {
		
		icmp_buf = (struct icmp *) pkt_buf;
		icmp_buf->icmp_type = ICMP_ADDRESS;
		icmp_buf->icmp_code = 0;
		icmp_buf->icmp_id = getpid ();
		icmp_buf->icmp_seq = 0;
		icmp_buf->icmp_cksum = 0;
		icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
		
		
		if (sendto(socketfd, icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
			perror ("icmpMask: error in sendto");
			close (socketfd);
			return mask;
		}
#ifdef DEBUG
		sprintf (debugBuf, "Thread %02d - Sent ICMP-> ", opt->lOpts->threadNum);
#endif
	
		
		do {
			socklen_t lsock = sizeof(dst_addr);	
			int pkt_len;
					
			if ((pkt_len = recvfrom(socketfd, &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock)) < 0)
			{
				
#ifdef DEBUG
				debugOut (MASK, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				retry++;
				break;
			}
			
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		
					
			
			if (icmp_buf->icmp_type == ICMP_ADDRESSREPLY && src_addr.sin_addr.s_addr == addr.s_addr)
			{
				mask.s_addr = icmp_buf->icmp_mask;
#ifdef DEBUG
				debugOut (MASK, "%sReceived ICMP_ADDRESSREPLY (%s)", debugBuf, inet_ntoa(mask));
				debugOut (MASK, " from %s (%d  bytes)\n", inet_ntoa (src_addr.sin_addr), pkt_len);
#endif
				done = true;
			}
		} while (!done);
	}
	close (socketfd);
	
	return mask;
}


void *
scanner (void *arg)
{
	struct ThreadParam *params = (struct ThreadParam *) arg;	
	LocalOptions lOpt;											
	Options opt = {params->gOpts, &lOpt};						
	Path *btPath = (Path *) malloc (sizeof(Path));				
	Path *rrPath = (Path *) malloc (sizeof(Path));				
	ListEntry *current;											

	pthread_mutex_lock (&mutex_params);
	lOpt.threadNum = params->threadNum++;			
	lOpt.params = params;
	pthread_mutex_unlock (&mutex_params);

#ifdef DEBUG
	debugOut (SCANNER, "Thread %02d - Ready!\n", lOpt.threadNum);
#endif

	
 	while (true) {
		struct in_addr addr;	
		IpRange *range;			
		bool visited = false;	
		
		pthread_mutex_lock (&mutex_options);
		
		if (!params->gOpts->rangesIP.empty) {
			
			range = params->gOpts->rangesIP.head->element;
			addr = range->startAddr;
		
			if (--range->numAddr == 0) listPop (&params->gOpts->rangesIP);
			else range->startAddr.s_addr = htonl (ntohl (range->startAddr.s_addr) + 1);
			pthread_mutex_unlock (&mutex_options);
		}
		else {
			pthread_mutex_unlock (&mutex_options);
			break;		
		}

		
		for (current = params->visited->head; current; current = current->next) {
			struct in_addr *addrTmp = current->element;		
			
			if (addr.s_addr == addrTmp->s_addr) 
			{	
				visited = true;
#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - Interface %s already visited\n", lOpt.threadNum, inet_ntoa (addr));
#endif
				break;
			}	
		}
		if (visited) continue;

#ifdef DEBUG
		debugOut (SCANNER, "Thread %02d - Scanning %s\n", lOpt.threadNum, inet_ntoa(addr));
#endif

		
		if (ping (addr, &opt)) 
		{	
			SnmpNode *info;		
#ifdef DEBUG
			debugOut (SCANNER, "Thread %02d - Node %s active\n", lOpt.threadNum, inet_ntoa(addr));
#endif
			
			if ((info = testSnmp (addr, &opt))) 
			{	
				bool already_visited = false;
				
				pthread_mutex_lock (&mutex_params);
				
				for (current = info->interfaces.head; current; current = current->next) {
					Interface *ifTmp = current->element;		
					
					
					if (ifTmp->ip.s_addr == INADDR_ANY || *((u_int8_t *)&ifTmp->ip.s_addr) == 127) continue;
					
					
					if (!listSearch (params->visited, &ifTmp->ip, (void *) ipCmp)) 
						listPush (params->visited, &ifTmp->ip);
					else {
						already_visited = true;
						break;
					}
				}
				
				
				if (!already_visited) listPush (params->snmpList, info);
				pthread_mutex_unlock (&mutex_params);
				
				
				if (params->gOpts->verbose) printf ("Thread %02d - SNMP enabled on %s\n", lOpt.threadNum, inet_ntoa(addr));
				else printf ("*");
				fflush (stdout);
#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - SNMP enabled on %s\n", lOpt.threadNum, inet_ntoa(addr));
#endif
			}
			else 
			{	
				TraceState btResult;	
				int prrResult;			
				bool mask = false;		
				IcmpRow *row; 			
				int i;					

				
				if (!(row = listSearch (params->icmpTab, &addr, (void *) icmpRowCmp))) {
					row = (IcmpRow *) calloc (1, sizeof(IcmpRow));
					row->ipAddr = addr;
					row->dest = addr;
					pthread_mutex_lock (&mutex_icmpTab);
					listPush (params->icmpTab, row);
					pthread_mutex_unlock (&mutex_icmpTab);
				}

				
				row->netMask = icmpMask(addr, &opt);
				if (row->netMask.s_addr) mask = true;
#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - Mask %s\n", lOpt.threadNum, inet_ntoa(row->netMask));
#endif

				
				btResult = backtrace (addr, &opt, params->icmpTab, btPath);
#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - BackTrace to %s - Result %d - Hops %d - Offset %d\n",
					lOpt.threadNum, inet_ntoa(addr), btResult, btPath->length, btPath->offset);
#endif
				
				if (btResult >= 0) {
					
					pthread_mutex_lock (&mutex_icmpTab);
					for(i=btPath->length-1; i>=btPath->offset; i--) {
						if (btPath->array[i].s_addr != INADDR_ANY) {
							if (i > btPath->offset) btPath->newRows[i]->precHop = btPath->newRows[i-1];
							if (i != btPath->length - 1) btPath->newRows[i]->nextHop = btPath->newRows[i+1];
						}
					}
					
					if (row->alias.s_addr != INADDR_ANY)
						btPath->aliasRow->precHop = row->precHop;

					pthread_mutex_unlock (&mutex_icmpTab);
				}

				
				prrResult = pingrr (addr, &opt, rrPath);

#ifdef DEBUG
				debugOut (SCANNER, "Thread %02d - PingRR to %s - Result %d - Hops %d\n",
					lOpt.threadNum, inet_ntoa(addr), prrResult, rrPath->length);
#endif

				
				if (prrResult > 0) {
					
					for(i=rrPath->length-1; i>=0; i--) {
						IcmpRow *rowTmp;

						
						if (i == rrPath->length-1) {
							
							rowTmp = row;
							
							
							if (prrResult == 2) row->aliasRR = rrPath->array[rrPath->length-1];

							
							else if (rrPath->length < NROUTES-1 && rrPath->array[i+1].s_addr != addr.s_addr &&
								rrPath->array[i].s_addr != rrPath->array[i+1].s_addr)
								row->aliasRR = rrPath->array[rrPath->length];
						}
						else rowTmp = listSearch (params->icmpTab, &rrPath->array[i], (void *) icmpRowCmp);
						
						
						if (rowTmp) {
							pthread_mutex_lock (&mutex_icmpTab);
							
							if (rowTmp->accuracy == TRACEROUTE) {
								rowTmp->accuracy = BOTH;
							}
							rrPath->newRows[i] = rowTmp;	
							if (i < rrPath->length-1) rowTmp->router = true;
							if (!rowTmp->hop) rowTmp->hop = i + 1;
							pthread_mutex_unlock (&mutex_icmpTab);
						}

						
						else if (rrPath->array[i].s_addr != INADDR_ANY) {
							
							rowTmp = (IcmpRow *) calloc (1, sizeof(IcmpRow));
			
							
							rowTmp->ipAddr = rrPath->array[i];
							rowTmp->dest = addr;
							rowTmp->hop = i + 1;
							rowTmp->accuracy = RECORDROUTE;
							
							if (i < rrPath->length-1) rowTmp->router = true;

							rrPath->newRows[i] = rowTmp;	
			
							
							pthread_mutex_lock (&mutex_icmpTab);
							listPush (params->icmpTab, rowTmp);
							pthread_mutex_unlock (&mutex_icmpTab);
						}
					}

					
					pthread_mutex_lock (&mutex_icmpTab);
					for(i=rrPath->length-1; i>=0; i--) {
						if (rrPath->array[i].s_addr != INADDR_ANY) {
							if (i > 0) rrPath->newRows[i]->precHopRR = rrPath->newRows[i-1];
							if (i != rrPath->length - 1) 
								rrPath->newRows[i]->nextHopRR = rrPath->newRows[i+1];
						}
					}
					pthread_mutex_unlock (&mutex_icmpTab);
				}

				
				free(btPath->array);
				free(btPath->newRows);
				free(rrPath->array);
				free(rrPath->newRows);

				
				if (params->gOpts->verbose) {
					printf ("Thread %02d - ICMP info acquired (", lOpt.threadNum);
					if (btResult) printf("BT");
					if (prrResult) printf(" PRR");
					if (mask) printf(" MASK");
					printf(") on %s\n", inet_ntoa(addr));
				}
				else printf ("+");
				fflush (stdout);
			}
		}
		
		else if (!params->gOpts->verbose) { printf ("."); fflush (stdout); }
#ifdef DEBUG
		debugOut (SCANNER, "Thread %02d - Done %s\n", lOpt.threadNum, inet_ntoa(addr));
#endif
	}

	pthread_mutex_lock (&mutex_sync);
	
	if (params->gOpts->verbose) printf ("Thread %02d - Waiting for DNS resolution (%d)\n", lOpt.threadNum, params->sync);
	else printf ("#");
	fflush (stdout);
	
	
	if (--params->sync == 0) sem_post (params->scanSem);
	pthread_mutex_unlock (&mutex_sync);

	
	sem_wait (params->scannerSemA);
	sem_post (params->scannerSemA);
	
	
	if (params->gOpts->dns) {
		
		if (!params->icmpTab->empty) {
			while (true) {
				IcmpRow *row;			
				struct hostent *host;	
		
				pthread_mutex_lock (&mutex_params);
				if (params->currRow) {
					
					row = params->currRow->element;
					params->currRow = params->currRow->next;
					pthread_mutex_unlock (&mutex_params);
				}
				else {
					pthread_mutex_unlock (&mutex_params);
					break;	
				}
	
				
				host = gethostbyaddr ((char *) &row->ipAddr.s_addr, sizeof(row->ipAddr.s_addr), AF_INET);
				if (host) 
				{	
					row->ipDNS = calloc (strlen(host->h_name)+1, sizeof(char));
					strncpy (row->ipDNS, host->h_name, strlen(host->h_name));
				
					
					if (params->gOpts->verbose)
						printf ("Thread %02d - DNS => %s = %s\n", lOpt.threadNum, inet_ntoa(row->ipAddr), row->ipDNS);
					else printf ("@");
					fflush (stdout);
				}
			}
		}
	}	
	
	pthread_mutex_lock (&mutex_sync);
	
	if (params->gOpts->verbose)
		printf ("Thread %02d - Waiting for Alias resolution phase 1 (%d)\n", lOpt.threadNum, params->sync);
	else { printf ("#"); fflush (stdout); }
		
	
	if (--params->sync == 0) sem_post (params->scanSem);
	pthread_mutex_unlock (&mutex_sync);

	
	sem_wait (params->scannerSemB);
	sem_post (params->scannerSemB);

	
	if (params->icmpTab->size >= 2) {
		while (true) {
			IcmpRow *row1;					
			AliasState allyResult = NONE;	

			pthread_mutex_lock (&mutex_params);
			if (params->currRow->next) {
				
				row1 = params->currRow->element;
				current = params->currRow->next;
				params->currRow = params->currRow->next;
				pthread_mutex_unlock (&mutex_params);
			}
			else {
				pthread_mutex_unlock (&mutex_params);
				break;		
			}

			
			if (row1->router) {
				
				if (params->gOpts->verbose)
					printf ("Thread %02d - Aliasing %s (phase 1)\n", lOpt.threadNum, inet_ntoa(row1->ipAddr));
				else printf ("§");
				fflush (stdout);

				for (; current; current = current->next) {
					IcmpRow *row2 = current->element;	
					
					if (row2->router) {
						if (row1->assNode == NULL || row2->assNode == NULL) 
						{	
							RowCouple couple = {row1, row2};	
							AliasState result;					
							bool alias;							

							
							result = allyPrevention (&lOpt, row1, row2);

							
							if (allyResult != TIMEOUT1) allyResult = NONE;
							if (result == NONE && allyResult != TIMEOUT1) {
								allyResult = ally (&opt, row1->ipAddr, row2->ipAddr);
#ifdef DEBUG
								debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
								debugOutNoTime (ALIAS, " %s) are %s alias (Ally%s)\n", inet_ntoa(row2->ipAddr),
												allyResult == ALIASES ? "" : "not", allyResult > 1 ? "" : " sure");
#endif
							}
#ifdef DEBUG
							if (allyResult == TIMEOUT1) {
								debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
								debugOutNoTime (ALIAS, " %s) are not alias (Ally Timeout1)\n", inet_ntoa(row2->ipAddr));
							}
#endif
														
							if (result == ALIASES || allyResult == ALIASES) alias = true;
							else alias = false;

							
							if (alias) {
								pthread_mutex_lock (&mutex_topology);
								alias2Routers (params, &couple);
								pthread_mutex_unlock (&mutex_topology);
							}
						}
#ifdef DEBUG
						else {
							debugOut (COUPLES, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
							debugOutNoTime (COUPLES, " %s) skipped (both associated)\n", inet_ntoa(row2->ipAddr));
						}
#endif
					}
#ifdef DEBUG
					else {
						debugOut (COUPLES, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
						debugOutNoTime (COUPLES, " %s) skipped (non router)\n", inet_ntoa(row2->ipAddr));
					}
#endif
				}
			}
		}
	}
	
	pthread_mutex_lock (&mutex_sync);
	
	if (params->gOpts->verbose)
		printf ("Thread %02d - Waiting for Alias resolution phase 2 (%d)\n", lOpt.threadNum, params->sync);
	else printf ("#");
	fflush(stdout);

	
	if (--params->sync == 0) sem_post (params->scanSem);
	pthread_mutex_unlock (&mutex_sync);

	
	sem_wait (params->scannerSemA);
	sem_post (params->scannerSemA);
	
	
	if (params->icmpTab->size >= 2) {
		while (true) {
			IcmpRow *row1;					
			AliasState allyResult = NONE;	

			pthread_mutex_lock (&mutex_params);
			if (params->currRow) {
				
				row1 = params->currRow->element;
				params->currRow = params->currRow->next;
				pthread_mutex_unlock (&mutex_params);
			}
			else {
				pthread_mutex_unlock (&mutex_params);
				break;		
			}
			
			
			if (!row1->assNode) {
				
				if (params->gOpts->verbose)
					printf ("Thread %02d - Aliasing %s (phase 2)\n", lOpt.threadNum, inet_ntoa(row1->ipAddr));
				else printf ("§");
				fflush(stdout);

				
				for (current = params->topology->routers.head; current; current = current->next) 
				{	
					NetNode *node = current->element;					
					Interface *ifTmp = node->interfaces.head->element;	
					IcmpRow *row2;										

					if (node->type == ROUTER && !node->SNMPCommunity) {
						RowCouple couple = {row1, row2};	
						AliasState result;					
						bool alias;							
							
						row2 = listSearch (params->icmpTab, &ifTmp->ip, (void *) icmpRowCmp);

						
						if (row1 == row2) continue;

						
						result = allyPrevention (&lOpt, row1, row2);

						
						if (allyResult != TIMEOUT1) allyResult = NONE;
						if (result == NONE && allyResult != TIMEOUT1) {
							allyResult = ally (&opt, row1->ipAddr, row2->ipAddr);
#ifdef DEBUG
							debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
							debugOutNoTime (ALIAS, " %s) are %s alias (Ally%s)\n", inet_ntoa(row2->ipAddr),
											allyResult == ALIASES ? "" : "not", allyResult > 1 ? "" : " sure");
#endif
						}
#ifdef DEBUG
						if (allyResult == TIMEOUT1) {
							debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
							debugOutNoTime (ALIAS, " %s) are not alias (Ally Timeout1)\n", inet_ntoa(row2->ipAddr));
						}
#endif
						
						if (result == ALIASES || allyResult == ALIASES) alias = true;
						else alias = false;
						
						
						if (alias) {
							pthread_mutex_lock (&mutex_topology);
							couple.second = row2;
							alias2Routers (params, &couple);
							pthread_mutex_unlock (&mutex_topology);
						}
					}
#ifdef DEBUG
					else {
						debugOut (COUPLES, "Thread %02d - Couple (%s,", lOpt.threadNum, inet_ntoa(row1->ipAddr));
						debugOutNoTime (COUPLES, " %s) skipped (not router or Snmp)\n", node->name);
					}
#endif
				}
			}
		}
	}

	
	if (params->gOpts->verbose)
		printf ("Thread %02d - Terminating execution\n", lOpt.threadNum);
	else printf ("X");
	fflush(stdout);

#ifdef DEBUG
	debugOut (SCANNER, "Thread %02d - Terminating execution\n", lOpt.threadNum);
#endif
	free(btPath);
	free(rrPath);
	return NULL;
}


int
scan (ThreadParam *params)
{
	pthread_t *threadIds; 	
	ListEntry *current;		
	int j;

	
	threadIds = (pthread_t *) calloc (params->gOpts->threads, sizeof(pthread_t));
	params->gOpts->oids = (OidVars *) malloc (sizeof(OidVars));
	params->visited = (List *) malloc (sizeof(List));
	params->snmpList = (List *) malloc (sizeof(List));
	params->scanSem = (sem_t *) malloc (sizeof(sem_t));
	params->scannerSemA = (sem_t *) malloc (sizeof(sem_t));
	params->scannerSemB = (sem_t *) malloc (sizeof(sem_t));
	
	snmpSetup (params->gOpts->oids);				
	params->gOpts->default_ttl = getDefaultTTL();	
	listInit (params->visited);						
	listInit (params->snmpList);					
	listInit (params->icmpTab);						
	listInit (&params->topology->routers);			
	listInit (&params->topology->links);			
	listInit (&params->topology->subnets);			

	
	sem_init (params->scanSem, 0, 0);
	sem_init(params->scannerSemA, 0, 0);
	sem_init(params->scannerSemB, 0, 0);
	
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting Scanner threads (%d)\n", params->gOpts->threads);
#endif
	
	params->threadNum = 0;					
	params->nodeCount = 0;					
	params->sync = params->gOpts->threads;	
	for(j=0; j<params->gOpts->threads; j++)
		pthread_create (&threadIds[j], NULL, scanner, params);

	
	printf ("Thread Manager - Starting Scan process\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting scan process\n");
#endif
	
	
	while (params->sync > 0) sem_wait (params->scanSem);

	
	if (!params->gOpts->verbose) printf ("\n");
	printf ("Thread Manager - Starting SNMP queries on SNMP enabled nodes\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting SNMP queries on SNMP enabled nodes\n");
#endif
	
	
	for (current = params->snmpList->head; current; current = current->next) {
		SnmpNode *node = current->element;
		NetNode *info;
		ListEntry *curr;
		
		
		printf ("Thread Manager - SNMP Agent %s: ", inet_ntoa (node->addr));
		fflush (stdout);
		
		
		info = snmpclient (node, params->gOpts, &params->nodeCount);
		
		
		if (info->type == ROUTER) listPush (&params->topology->routers, info);
		
		
		for (curr = info->interfaces.head; curr; curr = curr->next) {
			Interface *ifTmp = curr->element;		
			
			
			if (ifTmp->ip.s_addr == INADDR_ANY || *((u_int8_t *)&ifTmp->ip.s_addr) == 127) continue;
			
			
			if (info->type == HOST) {
				IcmpRow *row = calloc (1, sizeof(IcmpRow));

				
				row->ipAddr = ifTmp->ip;
				row->netMask = ifTmp->mask;
				row->assNode = info;
				row->router = false;
				row->hop = 0;

				
				listPush (params->icmpTab, row);
			}
		}

		
		printf ("done!\n");
	}
	listReset (params->snmpList, true);
	
	
	printf ("Thread Manager - Starting DNS resolution\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting DNS resolution\n");
#endif
		
	
	params->sync = params->gOpts->threads;	
	params->currRow = params->icmpTab->head;
	params->currNode = params->topology->routers.head;
	sem_post (params->scannerSemA);
	while (params->sync > 0) sem_wait (params->scanSem);

	
	if (!params->gOpts->verbose) printf ("\n");
	printf ("Thread Manager - IcmpTable rows association with SNMP nodes\n");
	printf ("Thread Manager - IcmpTable rows correction using SNMP information\n");
	printf ("Thread Manager - Early detected alias nodes creation\n");
	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	
		IcmpRow *row = current->element;	
		
		
		row->assNode = listSearch (&params->topology->routers, &row->ipAddr, (void *) nodeCmp);

		
		if (row->assNode || listSearch (&params->topology->routers, &row->ipAddr, (void *) nodeNextHopCmp))
			row->router = true;
		
		
		if (row->alias.s_addr != INADDR_ANY) {
			RowCouple couple = {row, NULL};
			
			couple.second = listSearch (params->icmpTab, &row->alias, (void *) icmpRowCmp);
			
#ifdef DEBUG
			debugOut (ALIAS, "Thread Manager - Couple (%s,", inet_ntoa(row->ipAddr));
			debugOutNoTime (ALIAS, " %s) alias (EarlyDetectedAlias)\n", inet_ntoa(couple.second->ipAddr));
#endif
			alias2Routers (params, &couple);
		}
		
		
		if (row->aliasRR.s_addr != INADDR_ANY) {
			RowCouple couple = {row, NULL};		
			
			couple.second = listSearch (params->icmpTab, &row->aliasRR, (void *) icmpRowCmp);
								
			
			if (couple.second && couple.second->hop == row->hop) {
#ifdef DEBUG
				debugOut (ALIAS, "Thread Manager - Couple (%s,", inet_ntoa(row->ipAddr));
				debugOutNoTime (ALIAS, " %s) alias (RREarlyDetectedAlias)\n", inet_ntoa(couple.second->ipAddr));
#endif
				alias2Routers (params, &couple);
			}
		}
	}

	
	printf ("Thread Manager - Starting Alias resolution phase 1\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Starting Alias resolution phase 1\n");
#endif

	
	params->sync = params->gOpts->threads;		
	params->currRow = params->icmpTab->head;	
	sem_destroy (params->scannerSemA);
	sem_init (params->scannerSemA, 0, 0);
	sem_post (params->scannerSemB);
	while (params->sync > 0) sem_wait (params->scanSem);

	
	if (!params->gOpts->verbose) printf ("\n");
	printf ("Thread Manager - Starting Alias resolution phase 2\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Waiting scan process to finish\n");
#endif

	
	params->sync = params->gOpts->threads;		
	params->currRow = params->icmpTab->head;	
	sem_destroy (params->scannerSemB);
	sem_init (params->scannerSemB, 0, 0);
	sem_post (params->scannerSemA);

	
	printf ("Thread Manager - Waiting Scanner threads to terminate (%d)\n", params->gOpts->threads);
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Waiting Scanner threads to terminate (%d)\n", params->gOpts->threads);
#endif
	
	
	for (j=0; j<params->gOpts->threads; j++) pthread_join (threadIds[j], NULL);

	
	if (!params->gOpts->verbose) printf ("\n");
	printf ("Thread Manager - Creating unaliased routers\n");
	
	
	for (current = params->icmpTab->head; current; current = current->next) 
	{	
		IcmpRow *row = current->element;	
		
		if (row->assNode == NULL && row->router) {
			
			NetNode *newNode = (NetNode *) calloc (1, sizeof (NetNode));
			Interface *newIf = (Interface *) calloc (1, sizeof (Interface));
	
			
			newNode->type = ROUTER;
	
			
			if (row->ipDNS) newNode->name = row->ipDNS;
			else {
				newNode->name = calloc (7, sizeof(char));
				sprintf (newNode->name, "Dev%d", params->nodeCount++);
			}
	
			
			row->assNode = newNode;
	
			
			newIf->ip = row->ipAddr;
			newIf->mask = row->netMask;
	
			
			listInit (&newNode->interfaces);
			listPush (&newNode->interfaces, newIf);
	
			
			listPush (&params->topology->routers, newNode);
#ifdef DEBUG
			debugOut (ALIAS, "Created node %s (%s)\n", newNode->name, inet_ntoa (row->ipAddr));
#endif
		}
	}

	
	sem_destroy (params->snmpSem);
	sem_destroy (params->scanSem);
	sem_destroy (params->scannerSemA);
	sem_destroy (params->scannerSemB);

	
	free (params->gOpts->oids);
	free (params->visited);
	free (params->snmpList);
	free (params->scanSem);
	free (params->scannerSemA);
	free (params->scannerSemB);
	free (threadIds);

	
	printf ("+-+ SCAN TERMINATED +-+\n");
#ifdef DEBUG
	debugOut (SCAN, "Thread Manager - Scan process terminated\n");
#endif

	return 0;
}


int
backtrace (struct in_addr addr, Options *opt, List *icmpTab, Path *hops)
{
	int socketfd[2];					
	char pkt_buf[MAX_PACKET];			
	struct sockaddr_in dst_addr;		
	struct sockaddr_in src_addr;		
	struct icmp *icmp_buf;				
	struct iphdr *ip_buf;				
	struct timeval tv;					
	int ttl = opt->lOpts->ttl;			
	u_int8_t retry = 0;					
	TraceState state = SCANNING;		
	bool icmp_filtered = false;			
	bool udp_filtered = false;			
	u_int8_t mode = opt->gOpts->mode;	
	TraceOrder order = FORWARD;			
	bool done = false;					
	struct in_addr alias = {INADDR_ANY};	

#ifdef DEBUG
	char debugBuf[50];
	debugOut (BACKTRACE, "Thread %02d - Backtrace destination: %s \n", opt->lOpts->threadNum, inet_ntoa (addr));
#endif

	
	hops->array = (struct in_addr *) calloc (opt->gOpts->max_ttl, sizeof(struct in_addr));
	hops->newRows = (IcmpRow **) calloc (opt->gOpts->max_ttl, sizeof(IcmpRow *));
	hops->offset = 0;

	
	dst_addr.sin_family = AF_INET;	
	dst_addr.sin_addr = addr;
	dst_addr.sin_port = BIG_UDP_PORT;
	
	
	if ((socketfd[ICMP] = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {	
		perror ("backtrace: error in socket0 creation");
		return -1;
	}

	
	if ((socketfd[UDP] = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {	
		perror ("backtrace: error in socket1 creation");
		return -1;
	}

	
	tv.tv_sec = opt->gOpts->timeout / 1000;			
	tv.tv_usec = (opt->gOpts->timeout % 1000) * 1000;	
	setsockopt (socketfd[ICMP], SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));
	
	do {
		bool newHopFound = false;				
		u_int8_t index;							
		TraceMode turn = (retry + mode) % 2;	
		
		
		if (!icmp_filtered && (turn == ICMP || (turn == UDP && udp_filtered)))
		{
			
			if (setsockopt (socketfd[ICMP], IPPROTO_IP, IP_TTL, (char *) &ttl, sizeof (ttl)) < 0) {
				perror ("backtrace: error in setsockopt IP_TTL");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -3;
			}
			
			
			icmp_buf = (struct icmp *) pkt_buf;
			icmp_buf->icmp_type = ICMP_ECHO;
			icmp_buf->icmp_code = 0;
			icmp_buf->icmp_id = opt->lOpts->threadNum;
			icmp_buf->icmp_seq = 0;
			icmp_buf->icmp_cksum = 0;
			icmp_buf->icmp_cksum = cksum ((unsigned short *) icmp_buf, ICMP_SIZE);
			
			
			if (sendto(socketfd[ICMP], icmp_buf, ICMP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
				perror ("backtrace: error in sendto ICMP");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -4;
			}
#ifdef DEBUG
			sprintf (debugBuf, "Thread %02d - Sent ICMP (TTL %02d)-> ", opt->lOpts->threadNum, ttl);
#endif
		}
		
		else if (!udp_filtered && (turn == UDP || (turn == ICMP && icmp_filtered)))
		{
			
			if (setsockopt (socketfd[UDP], IPPROTO_IP, IP_TTL, (char *) &ttl, sizeof (ttl)) < 0) {
				perror ("backtrace: error in setsockopt IP_TTL");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -3;
			}

			
			memset (&pkt_buf, 'X', UDP_SIZE);
			
			
			if (sendto(socketfd[UDP], pkt_buf, UDP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
				perror ("backtrace: error in sendto UDP");
				close (socketfd[ICMP]);
				close (socketfd[UDP]);
				return -4;
			}
#ifdef DEBUG
			sprintf (debugBuf, "Thread %02d - Sent UDP  (TTL %02d)-> ", opt->lOpts->threadNum, ttl);
#endif
		}
		
		else {
			state = DEST_FILTERED;
			udp_filtered = false;
			icmp_filtered = false;

			if (order == BACKWARD) ttl--;
			else {
				ttl = opt->lOpts->ttl - 1;
				order = BACKWARD;
			}
			continue;
		}
		
		
		while (true)
		{
			socklen_t lsock = sizeof(dst_addr);		
			
			if (recvfrom(socketfd[ICMP], &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock) < 0) 
			{
				
#ifdef DEBUG
				debugOut (BACKTRACE, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				if (retry < opt->gOpts->retries) retry++;
				else {
					
					order ? ttl-- : ttl++;		
					retry = 0;
				}
				break;			
			}
			
			
			ip_buf = (struct iphdr *) &pkt_buf[IP_SIZE + 8];	
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		
			index = ttl - 1;									
			
			
			if (icmp_buf->icmp_type == ICMP_TIME_EXCEEDED && ip_buf->daddr == addr.s_addr) 
			{
#ifdef DEBUG
				debugOut (BACKTRACE, "%sReceived ICMP_TIME_EXCEEDED from %s\n", debugBuf, inet_ntoa(src_addr.sin_addr));
#endif
				newHopFound = true;
				
				
				if (ip_buf->protocol == IPPROTO_UDP) mode = UDP;
				else mode = ICMP;
				
				
				order ? ttl-- : ttl++;
				retry = 0;
				break;
			}
			
			
			else if (icmp_buf->icmp_type == ICMP_ECHOREPLY && src_addr.sin_addr.s_addr == addr.s_addr && turn == ICMP)
			{ 
#ifdef DEBUG
				debugOut (BACKTRACE, "%sReceived ICMP_ECHOREPLY from %s\n", debugBuf, 
							inet_ntoa (src_addr.sin_addr));
#endif
				newHopFound = true;
				break;
			}

			
			else if (icmp_buf->icmp_type == ICMP_DEST_UNREACH && ip_buf->daddr == addr.s_addr) 
			{
				
				if (icmp_buf->icmp_code == ICMP_PORT_UNREACH)
				{
#ifdef DEBUG
					debugOut (BACKTRACE, "%sReceived ICMP_PORT_UNREACH from %s\n", debugBuf, inet_ntoa (src_addr.sin_addr));
#endif
					newHopFound = true;
					break;
				}
				
				else if (icmp_buf->icmp_code == ICMP_PKT_FILTERED)
				{
#ifdef DEBUG
					debugOut (BACKTRACE, "%sReceived ICMP_PKT_FILTERED from %s (proto=%d)\n", 
							debugBuf, inet_ntoa (src_addr.sin_addr), ip_buf->protocol);
#endif
					
					if (ip_buf->protocol == IPPROTO_UDP) udp_filtered = true;
					if (ip_buf->protocol == IPPROTO_ICMP) icmp_filtered = true;
					
					retry++;
					break;
				}
				
				else
				{
#ifdef DEBUG
					debugOut (BACKTRACE, "%sReceived ICMP_DEST_UNREACH (code=%d) from %s\n", 
							debugBuf, icmp_buf->icmp_code, inet_ntoa (src_addr.sin_addr));
#endif
					newHopFound = true;
					state = DEST_UNREACHABLE;
					hops->length = ttl;
					if (order == BACKWARD) ttl--;
					else {
						ttl = opt->lOpts->ttl - 1;
						order = BACKWARD;
					}
					break;
				}
			}
		}
		
		
		if (ttl > opt->gOpts->max_ttl) {
			state = MAX_TTL_REACHED;
			ttl = opt->lOpts->ttl - 1;
			order = BACKWARD;
		}

		
		if (newHopFound) {
			IcmpRow *row;	

			
			hops->array[index].s_addr = src_addr.sin_addr.s_addr;

			
			if (src_addr.sin_addr.s_addr == addr.s_addr) {
				state = DEST_REACHED;
				hops->length = index + 1;
				if (order == BACKWARD) ttl--;
				else {
					if (ttl > opt->lOpts->ttl) opt->lOpts->ttl = ttl;
					ttl = opt->lOpts->ttl - 1;
					order = BACKWARD;
				}
				if (hops->offset > 0) done = true;
			}

			
			else if (icmp_buf->icmp_code == ICMP_PORT_UNREACH) {
				mode = ICMP;				
				alias = src_addr.sin_addr;	
			}
			
			pthread_mutex_lock (&mutex_icmpTab);
			
			if ((row = listSearch (icmpTab, &src_addr.sin_addr, (void *) icmpRowCmp))) {
				
				if (src_addr.sin_addr.s_addr != addr.s_addr) {
					if (!row->router) row->router = true;	
					if (order == BACKWARD) {
						hops->offset = index;	
					 	done = true;			
					}
				}
				
				else {
					if (alias.s_addr != INADDR_ANY) row->alias = alias;
					row->hop = index + 1;	
				}
				if (row->accuracy == RECORDROUTE) row->accuracy = BOTH;
				
				
				if (icmp_buf->icmp_code == ICMP_PORT_UNREACH) hops->aliasRow = row;
				hops->newRows[index] = row;
			}

			
			else if (src_addr.sin_addr.s_addr != INADDR_ANY) {
				
				row = (IcmpRow *) calloc (1, sizeof(IcmpRow));

				
				row->ipAddr = src_addr.sin_addr;
				row->dest = addr;
				row->hop = index + 1;
				row->accuracy = TRACEROUTE;
				if (hops->length == index + 1 || icmp_buf->icmp_code == ICMP_PORT_UNREACH)
					row->router = false;
				else
					row->router = true;

				
				if (alias.s_addr != INADDR_ANY && addr.s_addr == src_addr.sin_addr.s_addr)
					row->alias = alias;

				
				if (icmp_buf->icmp_code == ICMP_PORT_UNREACH) hops->aliasRow = row;

				hops->newRows[index] = row;	

				
				listPush (icmpTab, row);
			}
			pthread_mutex_unlock (&mutex_icmpTab);
		}
	} while (ttl > 0 && !done);

	close (socketfd[ICMP]);
	close (socketfd[UDP]);
	
#ifdef DEBUG
	switch (state) {
		case SCANNING: break;
		case DEST_REACHED:
			debugOut (BACKTRACE, "Thread %02d - Destination %s reached in %d hops\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
		case MAX_TTL_REACHED:
			debugOut (BACKTRACE, "Thread %02d - Destination %s not reached in %d hops (MAX_TTL_REACHED)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
		case DEST_FILTERED:
			debugOut (BACKTRACE, "Thread %02d - Destination %s not reached in %d hops (DEST_FILTERED)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
		case DEST_UNREACHABLE:
			debugOut (BACKTRACE, "Thread %02d - Destination %s not reached in %d hops (DEST_UNREACHABLE)\n",
					opt->lOpts->threadNum, inet_ntoa (addr), hops->length);
		break;
	}
#endif

	return state;
}



AliasState
ally (Options *opt, const struct in_addr addr1, const struct in_addr addr2)
{
	int socketfd[2];				
	char pkt_buf[MAX_PACKET];		
	struct sockaddr_in dst_addr;	
	struct sockaddr_in src_addr;	
	struct iphdr *ip_head;			
	struct iphdr *ip_buf;			
	struct icmp *icmp_buf;			
	struct timeval tv;				
	u_int8_t retry = 0;				
	int id[3] = {0, 0, 0};			
	int turn = 0;					

#ifdef DEBUG
	char debugBuf[50];
	sprintf (debugBuf, "Thread %02d - Ally couple: %s", opt->lOpts->threadNum, inet_ntoa (addr1));
	debugOut (ALLY, "%s, %s \n", debugBuf, inet_ntoa (addr2));
#endif

	
	if ((socketfd[ICMP] = socket (AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1) {	
		perror ("ally: error in socket0 creation");
		return -1;
	}

	
	if ((socketfd[UDP] = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {	
		perror ("ally: error in socket1 creation");
		return -1;
	}

	
	tv.tv_sec = opt->gOpts->timeoutAlly / 1000;				
	tv.tv_usec = (opt->gOpts->timeoutAlly % 1000) * 1000;	
	setsockopt (socketfd[ICMP], SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof (tv));

	
	dst_addr.sin_family = AF_INET;	
	dst_addr.sin_port = BIG_UDP_PORT;

	do {
		
		if (turn % 2) dst_addr.sin_addr = addr2;
		else dst_addr.sin_addr = addr1;
		memset (&pkt_buf, 'X', UDP_SIZE);

		
		if (sendto(socketfd[UDP], pkt_buf, UDP_SIZE, 0, (struct sockaddr *) &dst_addr, sizeof(dst_addr)) < 0) {
			perror ("ally: error in sendto UDP");
			return -4;
		}
#ifdef DEBUG
		sprintf (debugBuf, "Thread %02d - Sent UDP to %s -> ", opt->lOpts->threadNum, inet_ntoa(dst_addr.sin_addr));
#endif
		
		while (true) {
			socklen_t lsock = sizeof(dst_addr);		
			
			if (recvfrom(socketfd[ICMP], &pkt_buf, MAX_PACKET, 0, (struct sockaddr *) &src_addr, &lsock) < 0) 
			{
				
#ifdef DEBUG
				debugOut (ALLY, "%sReceived ICMP_TIMEOUT - Try #%d\n", debugBuf, retry+1);
#endif
				if (retry < opt->gOpts->retriesAlly) retry++;
				else if (turn % 2 == 0) {
					close (socketfd[UDP]);
					close (socketfd[ICMP]);
					return TIMEOUT1;
				}
				else {
					close (socketfd[UDP]);
					close (socketfd[ICMP]);
					return TIMEOUT2;
				}
				break;
			}
			
			
			ip_buf = (struct iphdr *) &pkt_buf[IP_SIZE + 8];	
			ip_head = (struct iphdr *) &pkt_buf;				
			icmp_buf = (struct icmp *) &pkt_buf[IP_SIZE];		

			
			if (icmp_buf->icmp_type == ICMP_DEST_UNREACH &&
				icmp_buf->icmp_code == ICMP_PORT_UNREACH &&
				ip_buf->daddr == dst_addr.sin_addr.s_addr)
			{
#ifdef DEBUG
				debugOut (ALLY, "%sReceived ICMP_PORT_UNREACH from %s (id=%d)\n",
							debugBuf, inet_ntoa (src_addr.sin_addr), ntohs (ip_head->id));
#endif
				id[turn++] = ntohs (ip_head->id);
				retry = 0;

				
				if (turn == 2 && id[1] > id[0] && (id[1] - id[0]) < 20)	{
					close (socketfd[UDP]);
					close (socketfd[ICMP]);
					return ALIASES;
				}			

				break;
			}
		}
	} while (turn < 3);

	close (socketfd[UDP]);
	close (socketfd[ICMP]);

	if ((id[0] < id[1]) && (id[1] < id[2]) && ((id[2] - id[0]) < 500)) return ALIASES;
	else return NOT_ALIASES;
}



void
alias2Routers (ThreadParam *params, RowCouple *couple)
{
	
	if (couple->first->assNode && couple->second->assNode) return;
	
	
	if (couple->first->assNode != NULL) {
		
		Interface *newIf = (Interface *) calloc (1, sizeof (Interface));

		
		couple->second->assNode = couple->first->assNode;
		if (couple->first->router) couple->second->router = true;
		if (couple->second->router) {
			couple->first->router = true;
			couple->first->assNode->type = ROUTER;
		}

		
		newIf->ip = couple->second->ipAddr;
		newIf->mask = couple->second->netMask;

		
		listPush (&couple->first->assNode->interfaces, newIf);
	
		debugOut (ALIAS, "Associated %s to node %s\n", inet_ntoa (couple->second->ipAddr), couple->first->assNode->name);
	}
	
	else if (couple->second->assNode != NULL) {
		
		Interface *newIf = (Interface *) calloc (1, sizeof (Interface));

		
		couple->first->assNode = couple->second->assNode;
		if (couple->second->router) couple->first->router = true;
		if (couple->first->router) {
			couple->second->router = true;
			couple->second->assNode->type = ROUTER;
		}

		
		newIf->ip = couple->first->ipAddr;
		newIf->mask = couple->first->netMask;

		
		listPush (&couple->second->assNode->interfaces, newIf);
	
		debugOut (ALIAS, "Associated %s to node %s\n", inet_ntoa (couple->first->ipAddr), couple->second->assNode->name);
	}
	
	else {
		
		NetNode *newNode = (NetNode *) calloc (1, sizeof (NetNode));
		Interface *newIf = (Interface *) calloc (2, sizeof (Interface));

		
		if (couple->first->router || couple->second->router) {
			couple->first->router = true;
			couple->second->router = true;
			newNode->type = ROUTER;
		}

		
		if (couple->first->ipDNS) newNode->name = couple->first->ipDNS;
		else if (couple->second->ipDNS) newNode->name = couple->second->ipDNS;
		else {
			newNode->name = calloc (7, sizeof(char));
			sprintf (newNode->name, "Dev%d", params->nodeCount++);
		}

		
		couple->first->assNode = newNode;
		couple->second->assNode = newNode;

		
		newIf[0].ip = couple->first->ipAddr;
		newIf[0].mask = couple->first->netMask;
		newIf[1].ip = couple->second->ipAddr;
		newIf[1].mask = couple->second->netMask;

		
		listInit (&newNode->interfaces);
		listPush (&newNode->interfaces, &newIf[0]);
		listPush (&newNode->interfaces, &newIf[1]);

		
		listPush (&params->topology->routers, newNode);
		
		debugOut (ALIAS, "Created node %s (%s, ", newNode->name, inet_ntoa (couple->first->ipAddr));
		debugOutNoTime (ALIAS, "%s)\n", inet_ntoa (couple->second->ipAddr));
	}
}


AliasState
allyPrevention (LocalOptions *lOpt, IcmpRow *row1, IcmpRow *row2)
{
	IcmpRow *rowTmp;
	ThreadParam *params = lOpt->params;
	
	
	if (params->gOpts->dns && row1->ipDNS != NULL &&
		row2->ipDNS != NULL && !strcmp(row1->ipDNS, row2->ipDNS)) {
#ifdef DEBUG
		debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt->threadNum, inet_ntoa(row1->ipAddr));
		debugOutNoTime (ALIAS, " %s) alias (DNS rule)\n", inet_ntoa(row2->ipAddr));
#endif
		return ALIASES;
	}

	
	if (row1->hop != row2->hop) return NOT_ALIASES;

	
	if (row1->accuracy != RECORDROUTE && row2->accuracy != RECORDROUTE) {
		if (row1->precHop == row2 || row1->nextHop == row2 ||
			row2->precHop == row1 || row2->nextHop == row1) {
#ifdef DEBUG
			debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt->threadNum, inet_ntoa(row1->ipAddr));
			debugOutNoTime (ALIAS, " %s) not alias (2nd rule)\n", inet_ntoa(row2->ipAddr));
#endif
			return NOT_ALIASES;
		}
	}
	
	
	if (row1->accuracy != TRACEROUTE && row2->accuracy != TRACEROUTE) {
		bool done = false;
		
		for (rowTmp = row1->precHopRR; rowTmp; rowTmp = rowTmp->precHop)
			if (rowTmp->ipAddr.s_addr == row2->ipAddr.s_addr) { done = true; break; }

		for (rowTmp = row1->nextHopRR; rowTmp && !done; rowTmp = rowTmp->nextHop)
			if (rowTmp->ipAddr.s_addr == row2->ipAddr.s_addr) { done = true; break; }

		for (rowTmp = row2->precHopRR; rowTmp && !done; rowTmp = rowTmp->precHop)
			if (rowTmp->ipAddr.s_addr == row1->ipAddr.s_addr) { done = true; break; }

		for (rowTmp = row2->nextHopRR; rowTmp && !done; rowTmp = rowTmp->nextHop)
			if (rowTmp->ipAddr.s_addr == row1->ipAddr.s_addr) { done = true; break; }
		
		if (done) {
#ifdef DEBUG
			debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt->threadNum, inet_ntoa(row1->ipAddr));
			debugOutNoTime (ALIAS, " %s) not alias (3rd rule)\n", inet_ntoa(row2->ipAddr));
#endif
			return NOT_ALIASES;
		}
	}
	
	
	if (row1->hop == row2->hop) {
		bool done = false;
		
		if (row1->dest.s_addr == row2->dest.s_addr) done = true;
		
		else if (row1->accuracy != TRACEROUTE && row2->accuracy != RECORDROUTE) {
			rowTmp = listSearch (params->icmpTab, &row1->dest, (void *) icmpRowCmp);
			if (rowTmp) {
				
				while (rowTmp->hop != row1->hop && rowTmp->precHop) rowTmp = rowTmp->precHop;
				if (rowTmp->ipAddr.s_addr == row2->ipAddr.s_addr) done = true;
			}
		}
		
		else if (row2->accuracy != TRACEROUTE && row1->accuracy != RECORDROUTE) {
			rowTmp = listSearch (params->icmpTab, &row2->dest, (void *) icmpRowCmp);
			if (rowTmp) {
				
				while (rowTmp->hop != row2->hop && rowTmp->precHop) rowTmp = rowTmp->precHop;
				if (rowTmp->ipAddr.s_addr == row1->ipAddr.s_addr) done = true;
			}
		}
				
		if (done) {
#ifdef DEBUG
			debugOut (ALIAS, "Thread %02d - Couple (%s,", lOpt->threadNum, inet_ntoa(row1->ipAddr));
			debugOutNoTime (ALIAS, " %s) alias (4th rule)\n", inet_ntoa(row2->ipAddr));
#endif
			return ALIASES;
		}
	}

	return NONE;
}

