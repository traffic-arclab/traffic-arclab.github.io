/*
 *	Component of the Hynetd v0.2.3 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */



#include "list.h"
#include <string.h>
#include <stdio.h>




void
listInit (List *list)
{
	list->size = 0;
	list->empty = true;
	list->head = NULL;
	list->last = NULL;
}


void listReset (List *list, bool full)
{
	ListEntry *tmp;
	
	while (list->head != NULL) {
		tmp = list->head;
		list->head = tmp->next;
		if (full) free(tmp->element);
		free(tmp);
	}

	list->size = 0;
	list->empty = true;
	list->last = NULL;
}


void
listPush (List *list, void *element)
{
	ListEntry *tmp = (ListEntry *) malloc (sizeof(ListEntry));

	
	tmp->next = NULL;
	tmp->element = element;

	if (list->empty) 
	{	
		list->empty = false;
		list->head = tmp;
	}
	else
	{	
		list->last->next = tmp;
	}

	list->last = tmp;
	list->size++;
}


void *
listPop (List *list)
{
	if (!list->empty) {
		ListEntry *tmp = list->head;
		void *element;

		list->head = tmp->next;
		list->size--;
		if (list->size == 0) {
			list->empty = true;
			list->last = NULL;
		}
		element = tmp->element;	

		free(tmp);
		return element;
	}
	else return NULL;
}


void *
listGet (List *list, int i)
{
	if (i < list->size) {
		int j;
		ListEntry *tmp = list->head;
		
		
		for (j=0; j<i ; j++) tmp = tmp->next;
		
		return tmp->element;
	}
	else return NULL;
}


void *
listSearch (List *list, const void *element, bool(*compare)(const void *, const void *))
{
	ListEntry *current;

	for (current = list->head; current; current = current->next)
		if (compare (element, current->element)) return current->element;

	return NULL;
}
