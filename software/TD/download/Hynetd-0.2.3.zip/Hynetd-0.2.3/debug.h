/*
 *	Component of the Hynetd v0.2.3 platform (http://www.grid.unina.it/software/TD)
 *
 *    Copyright    : (C) 2004-2007 by Alessio Botta , Walter de Donato , Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and CommunicationS)
 *                                      Group, Dipartimento di Informatica e Sistemistica of the 
 *                                      University of Napoli "Federico II".
 *
 *    email:       : a.botta@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *    This program is open-source and completely free for Universities, Schools,
 *    Research Institutes, and Individuals; it is also free for Companies that 
 *    use HyNeTD for their internal research; you can redistribute it and/or modify 
 *    it under the terms of the HYNETD NON-COMMERCIAL LICENSE as reported in the 
 *    LICENSE file of this ditribution; either version 1 of the License, or
 *    (at your option) any later version.
 *    
 *    For commercial use please write to tdpro@comics.unina.it.
 */





#include "types.h"
#include <stdio.h>

#ifndef _DEBUG_H
#define _DEBUG_H



#define LOG_FILE_NUM 11


typedef enum {
	PING,		
	MASK,		
	BACKTRACE,	
	PINGRR,		
	ALLY,		
	SNMPCLIENT,	
	SCANNER,	
	SCAN,		
	ALIAS,		
	COUPLES,	
	SUBNET		
} LogFile;

 



void debugOut (LogFile id, const char *message, ...);


void debugOutNoTime (LogFile id, const char *message, ...);


int debugInit (LogFile id);


int debugReset (void);

#endif
