/*
 *	Component of the D-ITG v2.6.1b platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright    : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                      Walter de Donato, Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and 
 *                                      CommunicationS) Group, Dipartimento di Informatica
 *                                      e Sistemistica of the University of Napoli "Federico II".
 *      email        : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                     walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is open-source and completely free for Universities, Schools,
 *      Research Institutes, and Individuals; it is also free for Companies that 
 *      use D-ITG for their internal research; you can redistribute it and/or modify
 *      it under the terms of the D-ITG NON-COMMERCIAL LICENSE as reported in the 
 *      LICENSE file of this ditribution; either version 1 of the License, or
 *      (at your option) any later version.
 *
 *      For commercial use please refer to D-ITG Professional.
 */





#define MSG_FT_OK 1
#define MSG_FT_ERR1 2
#define MSG_FT_ERR2 3





struct paramThread {
	BYTE l7Proto;				    
	struct addrinfo destHost;		
	int flowId;				        
	info *addressInfos;			    
	int count;				        
	int socket;				        
	int socketClose;		    	
	BYTE meter;				        
	char *fileLog;
	int logSock;				        
    struct addrinfo *logHost;
    char serial[DIM_NAME_SERIAL_INTERFACE];
#ifdef LINUX_OS
	int rPipe[2];
#endif
#ifdef WIN32
	HANDLE rPipe[3];
#endif
	int preambleSize; 
	int payloadLogType; 
};


struct memChannel {		
	int flowId;				
	BYTE l4Proto;			
};


struct manageLogFile{
	ofstream out;				 
	int num;
	char logFile[DIM_LOG_FILE]; 
};



extern const char DEFAULT_LOG_FILE[];


extern int flagTerm;


extern struct addrinfo *logHost;


extern int logCheck;


extern int logRemote;


extern BYTE l4ProtoLog;	


extern ofstream out;


extern int sockSignaling;


extern char logFile[DIM_LOG_FILE];

#ifdef WIN32

extern HANDLE mutexLog;

extern HANDLE mutexLogRem;

extern int userId;
#endif

#ifdef LINUX_OS

extern pthread_mutex_t mutexLog;

extern pthread_mutex_t mutexLogRem;

extern uid_t userId;
#endif




void *signalManager(void *param);


void printHelpAndExit();



void terminate(int sign);


void reportErrorAndExit(char *function, char *program, char *msg);


int sendAck(int signaling, BYTE typeMessage);


int sendAckFlow(int signaling,BYTE typeMessage,int flowId);



void recvInit();



void parserRecv(int argc , char *argv[]);






#ifdef WIN32
int typeParser(BYTE type, int &numFlow, int newSockSignaling , memChannel flowIdNum[],
		  paramThread paraThread[], pthread_t hThr[], HANDLE rPipe[], char *fileLog, int logSock, int logSockSignaling,
          struct addrinfo *logHost);
#endif

#ifdef LINUX_OS
int typeParser(BYTE type, int &numFlow, int newSockSignaling , memChannel flowIdNum[],
		  paramThread paraThread[], pthread_t hThr[], int rPipe[], char *fileLog, int logSock, int logSockSignaling,
          struct addrinfo *logHost);
#endif


#ifdef WIN32
void pipeParser(int newSockSignaling,int &numFlow, HANDLE rPipe[], memChannel flowIdNum[],
		   paramThread paraThread[], pthread_t hThr[]);
#endif

#ifdef LINUX_OS
void pipeParser(int newSockSignaling,int &numFlow, int rPipe[], memChannel flowIdNum[],
		   paramThread paraThread[], pthread_t hThr[]);
#endif



void createRemoteLogFile(struct addrinfo &logHost, char logFile[DIM_LOG_FILE], BYTE protocolLog, int & logSockSignaling, int & logSock);



void createSignalingLogChannel(struct addrinfo logHost, char logFile[DIM_LOG_FILE], BYTE protocolLog, int & logSockSignaling);


void recvFlowLog(int newSockSignaling, struct addrinfo & logHost, BYTE &protocolLog, char logFile[]);



inline void flushBuffer(ofstream *, struct info *infos , int count);
void recvNameLog(char nameFile[DIM_LOG_FILE],int newSockSignaling);
void copia(const struct addrinfo* src, struct addrinfo & dst);

