/*
 *	Component of the D-ITG v2.6.1b platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright    : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                      Walter de Donato, Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and 
 *                                      CommunicationS) Group, Dipartimento di Informatica
 *                                      e Sistemistica of the University of Napoli "Federico II".
 *      email        : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                     walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is open-source and completely free for Universities, Schools,
 *      Research Institutes, and Individuals; it is also free for Companies that 
 *      use D-ITG for their internal research; you can redistribute it and/or modify
 *      it under the terms of the D-ITG NON-COMMERCIAL LICENSE as reported in the 
 *      LICENSE file of this ditribution; either version 1 of the License, or
 *      (at your option) any later version.
 *
 *      For commercial use please refer to D-ITG Professional.
 */


#define PIPE_BUFSIZE 1000
#define PIPE_TIMEOUT 100000
extern char nameProgram[];

struct pipeMsg {
	int flowId;
	int code;
};

#ifdef WIN32
extern HANDLE mutex_numPipes;
extern int numPipes;
#endif

#ifdef LINUX_OS
int createNewPipe(int fd[2]);
int sendPipeMsg(int fd[2], pipeMsg *msg);
int recvPipeMsg(int fd[2], pipeMsg *msg);
int closePipe(int fd[2]);
#endif
#ifdef WIN32
int createNewPipe(HANDLE pipe[3]);
int sendPipeMsg(HANDLE pipe[3], pipeMsg *msg);
int recvPipeMsg(HANDLE pipe[3], pipeMsg *msg);
int closePipe(HANDLE fd[3]);
#endif

