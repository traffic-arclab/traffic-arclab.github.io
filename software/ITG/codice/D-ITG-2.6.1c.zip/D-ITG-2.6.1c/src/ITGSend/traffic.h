/*
 *	Component of the D-ITG v2.6.1c platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright    : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                      Walter de Donato, Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and 
 *                                      CommunicationS) Group, Dipartimento di Informatica
 *                                      e Sistemistica of the University of Napoli "Federico II".
 *      email        : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                     walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is open-source and completely free for Universities, Schools,
 *      Research Institutes, and Individuals; it is also free for Companies that 
 *      use D-ITG for their internal research; you can redistribute it and/or modify
 *      it under the terms of the D-ITG NON-COMMERCIAL LICENSE as reported in the 
 *      LICENSE file of this ditribution; either version 1 of the License, or
 *      (at your option) any later version.
 *
 *      For commercial use please refer to D-ITG Professional.
 */




typedef enum TDistro { pdConstant, pdUniform, pdExponential, pdPareto, pdCauchy,
	
	pdNormal, pdPoisson, pdGamma, pdTelnet, pdAoM, pdDiscrete, pdExtreme_Largest, pdQuake, pdStudent, pdCSa,pdCSi };

extern const char *DistroStrings[];
extern const unsigned int DefaultPktPerSec;
extern const unsigned int DefaultPktSize;
extern const unsigned long DefaultDuration;
extern const unsigned long DefaultDelay;

extern Constant *ConstantRV;
extern Uniform *UniformRV;
extern Exponential *ExponentialRV;
extern Pareto *ParetoRV;
extern Cauchy *CauchyRV;
extern Normal *NormalRV;
extern Poisson *PoissonRV;
extern Gamma *GammaRV;

extern Extreme_Largest *Extreme_LargestRV;
extern Student *StudentRV;



void telnetParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);
void voIPParser(int h, char *argv[], int &argc, unsigned int flowId, SumRandom ** pIntArriv,
    SumRandom ** pPktSize, TDistro & IntArrivDistro, TDistro & PktSizeDistro);
void dnsParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);

void CSParsera(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);
void QuakeParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro, TDistro & PktSizeDistro);
void CSParseri(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);


