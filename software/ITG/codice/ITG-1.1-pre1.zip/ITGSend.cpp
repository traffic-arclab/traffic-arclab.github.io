#include <errno.h>
#include <netdb.h>
#include "ITG.h"
#include "newran.h"   // to include after iostream.h
#include <sys/wait.h>
#include <math.h>
#include <netinet/tcp.h> // for NO_DELAY TCP option
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <sys/shm.h>

//#define DEBUG_PARSER
//#define DEBUG_INTARRIV
//#define DEBUG_PKTSIZE
//#define DEBUG_PACKET

//Type enum declarations
typedef enum TDistro {pdConstant,pdUniform,pdExponential,pdPareto,pdCauchy,pdNormal,pdPoisson,pdGamma,pdTelnet};
typedef enum TAppProto {apNone,apTelnet,apVoIP,apDNS};

//Const declarations
const char* DistroStrings[] = {"Constant","Uniform","Exponential","Pareto","Cauchy","Normal","Poisson","Gamma","Telnet"};
const char* AppProto[] = {"", "Telnet", "VoIP", "DNS", " "};    // the last element must be " "
const char DefaultLogFile[] = "/tmp/ITGSend.log";
const char DefaultDestIP[] = "127.0.0.1";
const unsigned int DefaultDSByte = 0;
const unsigned int DefaultPktPerSec = 100;
const unsigned int DefaultPktSize = 1000;
const unsigned long DefaultDuration = 10000;
const unsigned long DefaultDelay = 0;
const unsigned int MinPayloadSize = 2 * ( sizeof(unsigned int) + sizeof(long int) );
char DefaultProto[]="UDP";
char DefaultProtoTx_Log[]="UDP"; //default proto TX-Log remoto
const int DimDefault=10;


//Global variables
unsigned char payload[MaxPayloadSize];
unsigned char rpayload[MaxPayloadSize];
int logfile,sock;

SumRandom IntArriv;
SumRandom PktSize;
TDistro IntArrivDistro;
TDistro PktSizeDistro;


// Random Variables
Constant ConstantRV(1);
Uniform UniformRV;
Exponential ExponentialRV;
Pareto ParetoRV;
Cauchy CauchyRV;        //new
Normal NormalRV;        //new
Poisson PoissonRV;      //new
Gamma GammaRV;          //new

//Structures declarations
struct TTicker {
   Real count;
   struct timeval lastTime;
};

struct InfoScambiate{
     struct sockaddr_in MyAddress;
     char protocolName[30];
     char AppProtocolName[30];
     bool stop;
     int FlowIdStop;
};

struct Signaling {
        int bufferdimensione;
	int PortoLog;
	char protocol[30];
};


// Prototypes
void Parser(char *argv[],int argc);
void telnet_parser();
void DNS_parser();
void VoIP_parser(char *argv[],int &argc, unsigned int FlowID,char*memptr);
void CreaCanaleSignaling(int &signaling,struct sockaddr_in DestHost);
int findProto(char *s);
void PrintHelpAndExit();
void ReportErrorAndExit(char *function, char *msg, char *pname, int fid,char *memptr);
void UpdateTicker(struct TTicker *Ticker);
void Terminate(int sig);



void send_packowdm(int &,unsigned int &DSByte,unsigned long &Duration,uid_t,
 int icmptype,TAppProto,int logvar,int FlowId,char *LogFile,struct timeval timeout,
 struct sockaddr_in DestHost,int &logout,struct sockaddr_in LogHost,char *ProtoTx_Log,char*upProtocol,
 int Dim,char *ProtocolName,int priority,int &signaling);

void send_packrttm(int &,unsigned int &DSByte,unsigned long &Duration,uid_t,pid_t,
 char LogFile[100],struct timeval timeout,struct sockaddr_in DestHost,int &logout,
 struct sockaddr_in LogHost,char *ProtoTx_Log,char *upProtocol,int Dim,int NumFlows,
 char protocolName[100],int priority,int &signaling);


//Start Main

int main(int argc, char* argv[]) {
  int priority=0;	         // Priority
  unsigned int FlowId = 1;       // Identificativo del flusso

  int Dim=DimDefault;		 // Array dimension
  unsigned int DSByte = DefaultDSByte;
  unsigned long Duration = DefaultDuration;
  unsigned long Delay = DefaultDelay;

  char protocolName[100];            // Nome del protocollo (TCP/UDP)
  strcpy(protocolName,DefaultProto); //default UDP
  char *Namemsr=DefaultMsr;          //default owdm
  char *ProtoTx_Log= DefaultProtoTx_Log; //default proto TX-Log remoto
  char *upProtocol="none";           //
  char LogFile[100];
  strcpy(LogFile,DefaultLogFile);    //default /tmp/ITGSend.log
  int signaling;
  InfoScambiate Info_Scambiate;
  int icmptype=8;
  int ScriptMode = 0;
  int logvar = 0;
  int logout = 0;
  double seed = 0.0;
  uid_t user_id = getuid();          //var user_id is the id of the user who calls the process
  pid_t pid=1;
  int NumFlows = FlowId;
  TAppProto AppProtocol;
  AppProtocol = apNone;
  struct timeval timeout;
  struct sockaddr_in DestHost;
  struct sockaddr_in locale;
  struct hostent *host;
  int id_shm,val;
  char *memptr;


// Set the default IP dest addr
  DestHost.sin_family=AF_INET;
  inet_aton(DefaultDestIP, &DestHost.sin_addr);
  DestHost.sin_port=htons(DefaultPort);

// Set the default IP log addr
  struct sockaddr_in LogHost;
  LogHost.sin_family=AF_INET;
  inet_aton(DefaultDestIP, &LogHost.sin_addr);
  LogHost.sin_port=htons(DefaultLogPort);

// Set the default inter-arrival time (msecs)
  IntArrivDistro = pdConstant;
  IntArriv.SetExpr(1000.0 / DefaultPktPerSec * ConstantRV);

// Set the default packet size (bytes)
  PktSizeDistro = pdConstant;
  PktSize.SetExpr(DefaultPktSize * ConstantRV);

// Fill the buffer used as packets payload with random numbers
  UniformRV.Set(0.5);
  for (int i=0; i<MaxPayloadSize; i++)
   payload[i] = (unsigned char) (255 * UniformRV.Next());

// Store the program name and inc argv
  strcpy(programName, argv[0]);
  argv++;
  argc--;


// Controlla se la modalità è script!
  if ( argc>0 && argv[0][0] != '-' && !findProto(argv[0]) ) {
    // script mode
    FILE *batch;
    char line[200];
    char temp[200];
    const int BMaxArg = 100;

    ScriptMode = 1;

    if ((batch = fopen(argv[0], "r")) == NULL) {
      cerr << "Cannot open '" << argv[0] << "' for reading" << endl;
      exit(1);
    }
    if (argc>1) {
      strcpy(LogFile, argv[1]);
         if ((logfile = open(LogFile,O_CREAT | O_TRUNC | O_WRONLY, 0666))== -1)
        cerr << "** WARNING **  Cannot create '" << LogFile << "' for writing" << endl;
      else {
            logvar=1; //voglio creare il file di log!
           }
    }
    else // log di default se la metrica è rttm
           if (strcmp(Namemsr,"rttm")==0){
             strcpy(LogFile,DefaultLogFile);
             if ((logfile = open(LogFile,O_CREAT | O_TRUNC | O_WRONLY, 0666))== -1)
               cerr << "** WARNING **  Cannot create '" << LogFile << "' for writing" << endl;
             else
              logvar = 1;
           }

  // Read the first line
  if (fgets(line, sizeof(line)-1, batch) == NULL) {
      cerr << "'" << argv[0] << "' is empty" << endl;
      exit(1);
  }
  else { //ricerca dell'indirizzo del receiver
    char *token;
    strcpy(temp,line);
    token=strtok(temp,"  ");
    while (strcmp(token,"-a")!=0){
     token=strtok(NULL, " ");
    }
    token=strtok(NULL, " ");
    if (!(host=gethostbyname(token)))
               ReportErrorAndExit("General parser", "Invalid destination address", programName, FlowId,memptr);
    memcpy((char*)&DestHost.sin_addr,host->h_addr,host->h_length);

  }

  //crea canale  di signaling
  CreaCanaleSignaling(signaling,DestHost);

  //richiede un segmento di memoria condivisa
  id_shm=shmget(IPC_PRIVATE,1,IPC_CREAT|0664);
  if (id_shm==-1) ReportErrorAndExit("Error", "cannot have shared memory", programName, FlowId, memptr);
  memptr=(char*)shmat(id_shm,0,0);
  if (*memptr==-1) ReportErrorAndExit("Error", "cannot attach shared memory", programName, FlowId, memptr);


  // Create a child process for each other line
  pid = getpid();
  while (pid && fgets(temp, sizeof(temp)-1, batch)) {
      NumFlows++;
      *memptr=NumFlows;
      pid = fork();
      if (pid < 0) {
        cerr << "Cannot create a process to handle flow " << NumFlows << endl;
        exit(1);
      }
      if (!pid) {          // executed by child
        strcpy(line, temp);
        FlowId = NumFlows;
      }
    }

  // Executed by all processes
    fclose(batch);
    if (line[strlen(line)-1]=='\n') {
      line[strlen(line)-1] = '\0';
    } else {
      cerr << "No newline at the end of line " << FlowId << ", looks like too long" << endl << endl;
      exit(1);
    }

    argv = (char **)malloc(sizeof(char *) * BMaxArg);
    argc = 0;
    if ( (argv[argc]=strtok(line, " ")) == NULL || argv[argc][0] == '#' )     // kill the process if no tokens or line begins with #
      exit(1);
    while ((argv[++argc]=strtok(NULL, " ")) != NULL) {
      if (argc > BMaxArg-2) {
        cerr << "Over " << BMaxArg << " arguments in batch mode, enough!" << endl << endl;
        exit(1);
      }
    }
  }   //END Manage of script-mode

  if (!argc)
    PrintHelpAndExit();

  while (argc>0) {
    if (argv[0][0] == '-') {
     char *tail;
      long int temp;
      Real a,b;

      switch (argv[0][1]) {
        case 'm':
	 if ((strcasecmp(argv[1],"rttm")) && strcasecmp(argv[1],"owdm"))
	          ReportErrorAndExit("General parser", "Invalid metric", programName, FlowId, memptr);
          Namemsr=argv[1];
          argv+=2;
      	  argc-=2;
	  break;
        case 'a':
          if ( (argc < 2) || !(host=gethostbyname(argv[1])))
            ReportErrorAndExit("General parser", "Invalid destination address", programName, FlowId, memptr);
          memcpy((char *)&DestHost.sin_addr, host->h_addr, host->h_length);
          argv+=2;
           argc-=2;
          break;
        case 'p':
          if (argc < 2)
             ReportErrorAndExit("General parser", "Invalid port number", programName, FlowId, memptr);
          DestHost.sin_port = htons(atoi(argv[1]));
          argv+=2;
          argc-=2;
          break;
        case 't':
          if ( (argc < 2) || ((temp = strtol(argv[1],NULL,10)) <= 0) )
            ReportErrorAndExit("General parser", "Invalid Duration", programName, FlowId, memptr);
          Duration = temp;
          argv+=2;
          argc-=2;
          break;
        case 'd':
          if (argc < 2)
            ReportErrorAndExit("General parser", "Invalid Delay", programName, FlowId, memptr);
          temp = strtol(argv[1],&tail,10);
          if ( (tail == argv[1]) || (temp < 0) )
            ReportErrorAndExit("General parser", "Invalid Delay", programName, FlowId, memptr);
          Delay = temp;
          argv+=2;
          argc-=2;
          break;
        case 'b':
          if (argc < 2)
            ReportErrorAndExit("General parser", "Invalid DS Byte", programName, FlowId, memptr);
          temp = strtol(argv[1],&tail,0);
          if ( (tail == argv[1]) || (temp < 0) || (temp > 255) )
            ReportErrorAndExit("General parser", "Invalid DS Byte", programName, FlowId, memptr);
          DSByte = temp;
          argv+=2;
          argc-=2;
          break;
        case 'P':

          if (argc<2)
            ReportErrorAndExit("General parser", "Invalid Priority Settings", programName, FlowId, memptr);
          priority = atoi(argv[1]);
          if ((priority<1)||(priority>90))
            ReportErrorAndExit("General parser", "Priority must be between 1 to 90", programName, FlowId, memptr);
          if (user_id!=0)
            ReportErrorAndExit("General parser", "Must be root to set priority", programName, FlowId, memptr);
          argv+=2;
          argc-=2;
          break;
        case 'L':
           if (ScriptMode)
             ReportErrorAndExit("General parser", "-L option not allowed in script mode", programName, FlowId, memptr);
           logout = 1;
           logvar = 1;
	   if ( (argc < 4) || !(host=gethostbyname(argv[1])) )
            ReportErrorAndExit("General parser", "Invalid log-server address", programName, FlowId, memptr);
          memcpy((char *)&LogHost.sin_addr, host->h_addr, host->h_length);
	        LogHost.sin_port=htons(atoi(argv[2]));
	  strcpy(ProtoTx_Log,argv[3]);
	  argv+=4;
          argc-=4;
          break;
        case 'T':
         if (argc<2)
            ReportErrorAndExit("General parser", "Invalid Protocol Type", programName, FlowId, memptr);
         if ((strcasecmp(argv[1],"UDP") && strcasecmp(argv[1],"TCP")) && strcasecmp(argv[1],"ICMP"))
            ReportErrorAndExit("General parser", "Invalid Protocol Type", programName, FlowId, memptr);
         strcpy(protocolName,argv[1]);
         if (strcasecmp(protocolName,"ICMP")==0){
            if ((argc > 2) && (argv[2][0]!='-')){
              icmptype=atoi(argv[2]);
              argv++;
              argc--;
            }
          }
          argv+=2;
          argc-=2;
          break;
        case 's':
          if ( (argc < 2) || ((seed = strtod(argv[1], NULL)) >= 1.0) || (seed <= 0.0) )
            ReportErrorAndExit("General parser", "Invalid seed (0 < seed < 1)", programName, FlowId, memptr);
          argv+=2;
          argc-=2;
          break;
        case 'D':
          if ( (argc < 2) || ((Dim = atoi(argv[1])) < 1.0))
            ReportErrorAndExit("General parser", "Invalid array dimension", programName, FlowId, memptr);
          argv+=2;
          argc-=2;
          break;
      	case 'l':
          if (ScriptMode)
            ReportErrorAndExit("General parser", "-l option not allowed in script mode", programName, FlowId, memptr);
          logvar = 1;
          if ((argc < 2) || (argv[1][0] == '-') || findProto(argv[1]) ) {
            strcpy(LogFile, DefaultLogFile);
            argc-=1;
            argv+=1;
          }
          else {
            strcpy(LogFile, argv[1]);
            argc-=2;
            argv+=2;
          }
          break;
         case 'C':
          if ( (argc < 2) || (atoi(argv[1]) < 1) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId, memptr);
          IntArrivDistro = pdConstant;
          IntArriv.SetExpr( 1000.0 / atoi(argv[1]) * ConstantRV );
          argv+=2;
          argc-=2;
          break;
        case 'U':
          if ( (argc < 3) || (atoi(argv[1]) < 1) || (atoi(argv[2]) <= atoi(argv[1])) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId, memptr);
          IntArrivDistro = pdUniform;
          b = 1000.0 / atoi(argv[2]);
          a =1000.0 / atoi(argv[1]) - b;
          IntArriv.SetExpr(  a * UniformRV + b );
          argv+=3;
          argc-=3;
          break;
        case 'E':
          if ( (argc < 2) || (atoi(argv[1]) < 1) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId, memptr);
          IntArrivDistro = pdExponential;
          IntArriv.SetExpr( 1000.0 / atoi(argv[1]) * ExponentialRV );
          argv+=2;
          argc-=2;
          break;
        case 'V':
          if ( (argc < 3) || (strtod(argv[1],NULL) <= 0) || (strtod(argv[2],NULL) <= 0) )
             ReportErrorAndExit("Protocol Parser", "Invalid Pareto Distribution parameter values", programName, FlowId, memptr);
          a = (Real) strtod(argv[1],NULL);
          b = (Real) strtod(argv[2],NULL);
          ParetoRV.SetShape(a);
          IntArrivDistro = pdPareto;
          IntArriv.SetExpr( b * ParetoRV );
          argv+=3;
          argc-=3;
          break;
        case 'Y':
          if ((argc < 3) || (atoi(argv[2]) <= 0))//a>0, b real
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId, memptr);
          IntArrivDistro = pdCauchy;
          b = (Real) 1000.0 /atoi(argv[1]);//shape
          a = (Real) 1000.0 /atoi(argv[2]);//scale
          IntArriv.SetExpr( a * CauchyRV + b );
          argv+=3;
          argc-=3;
          break;
        case 'N':
          if ((argc < 3) || (argv[2]<=0))//standard deviation >0
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId, memptr);
          IntArrivDistro = pdNormal;
          b = (Real) 1000.0 /atoi(argv[1]);//mean
          a = (Real) 1000.0 /atoi(argv[2]);//standard deviation
          IntArriv.SetExpr( a * NormalRV + b );
          argv+=3;
          argc-=3;
          break;
        case 'O':
          if ( (argc < 2) || (atoi(argv[1]) < 0) )//mean >0
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId, memptr);
          a = (Real) atoi(argv[1]);
          PoissonRV.SetMean(a);// the constructor takes the mean as argument
          IntArrivDistro = pdPoisson;
          IntArriv.SetExpr( 1000.0/PoissonRV );
          argv+=2;
          argc-=2;
          break;
        case 'G':
          if ( (argc < 3) || (strtod(argv[1],NULL) <= 0) || (strtod(argv[2],NULL) <= 0) ) // shape, scale >0
             ReportErrorAndExit("Protocol Parser", "Invalid Gamma Distribution parameter values", programName, FlowId, memptr);
          a = (Real) strtod(argv[1],NULL);
          b = (Real) strtod(argv[2],NULL);
          GammaRV.SetGamma(a);//the constructor takes the shape parameter as argument
          IntArrivDistro = pdGamma;
          IntArriv.SetExpr( b * GammaRV );
          argv+=3;
          argc-=3;
          break;
        case 'c':
          if ( (argc < 2) || (atoi(argv[1]) < 1) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId, memptr);
          PktSizeDistro = pdConstant;
          PktSize.SetExpr( atoi(argv[1]) * ConstantRV );
          argv+=2;
          argc-=2;
          break;
        case 'u':
          if ( (argc < 3) || (atoi(argv[1]) < 1) || (atoi(argv[2]) <= atoi(argv[1])) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId, memptr);
          PktSizeDistro = pdUniform;
          b = atoi(argv[1]);
          a = atoi(argv[2]) - b;
          PktSize.SetExpr(  a * UniformRV + b );
          argv+=3;
          argc-=3;
          break;
        case 'e':
          if ( (argc < 2) || (atoi(argv[1]) < 1) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId, memptr);
          PktSizeDistro = pdExponential;
          PktSize.SetExpr( atoi(argv[1]) * ExponentialRV );
          argv+=2;
          argc-=2;
          break;
        case 'v':
          if ( (argc < 3) || (strtod(argv[2],NULL) <= 0) )//a>o, b to be real
             ReportErrorAndExit("Protocol Parser", "Invalid Pareto Distribution parameter values", programName, FlowId, memptr);
          a = (Real) strtod(argv[1],NULL);
          b = (Real) strtod(argv[2],NULL);
          ParetoRV.SetShape(a);
          PktSizeDistro = pdPareto;
          PktSize.SetExpr( b * ParetoRV );
          argv+=3;
          argc-=3;
          break;
        case 'y':
          if ((argc < 3) || (atoi(argv[2]) <= 0))//a>0, b real
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId, memptr);
          PktSizeDistro = pdCauchy;
          b = (Real) atoi(argv[1]);//shape
          a = (Real) atoi(argv[2]);//scale
          PktSize.SetExpr( a * CauchyRV + b );
          argv+=3;
          argc-=3;
          break;
        case 'n':
          if ((argc < 3) || (argv[2]<=0))//standard deviation >0
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId, memptr);
          PktSizeDistro = pdNormal;
          b = (Real) atoi(argv[1]);//mean
          a = (Real) atoi(argv[2]);//standard deviation
          PktSize.SetExpr( a * NormalRV + b );
          argv+=3;
          argc-=3;
          break;
        case 'o':
          if ( (argc < 2) || (atoi(argv[1]) < 0) ) //mean >0
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId, memptr);
          a = atoi(argv[1]);
          PoissonRV.SetMean(a);// the constructor takes the mean as argument
          PktSizeDistro = pdPoisson;
          PktSize.SetExpr( 1 * PoissonRV );
          argv+=2;
          argc-=2;
          break;
        case 'g':
          if ( (argc < 3) || (strtod(argv[2],NULL) <= 0) )
             ReportErrorAndExit("Protocol Parser", "Invalid Gamma Distribution parameter values", programName, FlowId, memptr);
          a = (Real) strtod(argv[1],NULL);
          b = (Real) strtod(argv[2],NULL);
          GammaRV.SetGamma(a); //the constructor takes the shape parameter as argument
          PktSizeDistro = pdGamma;
          PktSize.SetExpr( b * GammaRV );
          argv+=3;
          argc-=3;
          break;
       default:
	  char temp[sizeof("What is  ?")+sizeof(argv[0])];
	  ReportErrorAndExit("General parser", strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"), programName, FlowId, memptr);
	  break;
       } //end switch
     } //end if

    else  {
      			AppProtocol = (TAppProto)findProto(argv[0]);
      			switch (AppProtocol) {
        		case apTelnet:
          		  Namemsr="owdm";
          	          telnet_parser();
			  upProtocol="Telnet";
                          strcpy(protocolName,"TCP");
           		  argv++;
       		          argc--;
	  		  break;
			case apVoIP:
          		  Namemsr="owdm";
	  		  VoIP_parser(argv,argc, FlowId,memptr);
			  upProtocol="VoIP";
                          strcpy(protocolName,"UDP");
			 break;
        		case apDNS:
          		  Namemsr="owdm";
	  		  DNS_parser();
			  upProtocol="DNS";
			  strcpy(protocolName,"UDP");
	  		  argv++;
       		          argc--;
	  		  break;
	                case apNone:
          		  char temp[sizeof("What is  ?")+sizeof(argv[0])];
          		  ReportErrorAndExit("General parser", strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"), programName, FlowId, memptr);
	  		  break;
			} //end switch
        } //end else
  }// End While

 if (seed == 0.0) {                 // not specified by user
    struct timeval tv;
    gettimeofday(&tv, NULL);
    seed = 0.49 * sin(tv.tv_usec) + 0.50;    //  0.01 <= seed <= 0.99
 }

// Initialize random generators
  IntArriv.Set(seed);
  PktSize.Set(seed);


#ifdef DEBUG_PARSER
  cout << "DEBUG INFO for Flow " << FlowId << " :" << endl << endl;
  cout << "Measure method: " << Namemsr << endl;
  cout << "Dest IP Address: " << inet_ntoa(DestHost.sin_addr) << endl;
  cout << "Dest Port: " << ntohs(DestHost.sin_port) << endl;
  cout << "DS Byte: " << DSByte << endl;
  cout << "Seed: " << seed << endl;
  cout << "Inter-arrival times :" << endl << " Distro: " << DistroStrings[IntArrivDistro] << "   Mean: " << IntArriv.Mean() << " msecs";
  cout << "   Variance: " << IntArriv.Variance() << endl;
  cout << "Packet size :" << endl << " Distro: " << DistroStrings[PktSizeDistro] << "   Mean: " << PktSize.Mean() << " bytes";
  cout << "   Variance: " << PktSize.Variance() << endl;
  cout << "Duration: " << Duration << " msecs" << endl;
  cout << "Delay: " << Delay << " msecs" << endl;
#endif


#ifdef DEBUG_INTARRIV
  Real temp,sum=0.0;
  cout << "Generated inter-arrives (msecs) for flow " << FlowId << endl;
    for (int i=0; i<100; i++) {
      sum+= (temp = IntArriv.Next());
      cout << temp << "  ";
    }
    cout << endl << "Media: " << sum/100 << endl;
    IntArriv.Set(seed);    // re-initialize random generator
#endif

#ifdef DEBUG_PKTSIZE
  Real temp,sum=0.0;
  cout << "Generated payload sizes (bytes) for flow " << FlowId << endl;
    for (int i=0; i<100; i++) {
      sum+= (temp = PktSize.Next());
      cout << temp << "  ";
    }
    cout << endl << "Media: " << sum/100 << endl;
    PktSize.Set(seed);    // re-initialize random generator
#endif

// Wait Delay msecs
  if (Delay) {
    timeout.tv_sec = Delay / 1000;
    timeout.tv_usec = ( Delay % 1000 ) * 1000;
    long int result;
    do result = (long int) ( select(0, NULL, NULL, NULL, &timeout) );
    while (result == -1L && errno == EINTR);
  }

 if (!strcasecmp(protocolName,"ICMP")){   //se è ICMP ..
      if(getuid()){
        printf("\n** ERROR **  You must be root!\n\n");
        exit(1);
      }
      Namemsr="owdm";
   }
 if (strcmp(Namemsr,"owdm")==0)
   send_packowdm(ScriptMode,DSByte,Duration,user_id,icmptype,AppProtocol,logvar,FlowId,LogFile,
   timeout,DestHost,logout,LogHost,ProtoTx_Log,upProtocol,Dim,protocolName,priority,signaling);
 else
    {
    if (pid) cout << endl << "Press Enter to terminate" << endl << endl;
    send_packrttm(ScriptMode,DSByte,Duration,user_id,pid,LogFile,timeout,DestHost,logout,LogHost,
    ProtoTx_Log,upProtocol,Dim,FlowId,protocolName,priority,signaling);
    }

 if (ScriptMode){
   (*memptr)--;
 }

 if ((*memptr==0) || (!ScriptMode)){
 int size;
 Info_Scambiate.stop=true;  //manda al receiver il messaggio di fine trasmissione
 if (size=sendto(signaling,&Info_Scambiate,sizeof(InfoScambiate),0,(struct sockaddr *)&locale, sizeof(locale))<0)
         cout<<" ** Errore ** cannot send STOP messagge to receiver "<<endl;
 if (close(signaling)<0) cout<<"** Error into close"<<endl;
 //rilascia la memoria condivisa
 shmctl(id_shm,IPC_RMID,0);
 }
 
 if (ScriptMode && pid) {        // parent waits for childs to terminate
     for (int i=2; i<=NumFlows; i++)
        waitpid(-1, NULL, 0);
      }

}//END Main

// Telnet_parser
void telnet_parser(){
  int numval=15;
  Real prob[] = {0.65,0.13,0.07,0.05,0.03,0.01,0.01,0.01,0.01,0.005,0.005,0.005,0.005,0.005,0.005};

  // Set inter-arrival time (msecs)
  ParetoRV.SetShape(0.95);
  IntArrivDistro = pdPareto;
  IntArriv.SetExpr( 1.1 * ParetoRV );

  // Set the default packet size (bytes)
  PktSizeDistro = pdTelnet;
  static DiscreteGen D(numval,prob);
  PktSize.SetExpr(D+21);

} // End Telnet_parser


// VoIP_parser
void VoIP_parser(char *argv[], int &argc, unsigned int FlowId,char*memptr){
 char codec[10];
  //Default definition
  strcpy(codec,"G.711.1");
  Real samples=1.0;
  Real framesize=80.0;
  Real VAD=1.0;
  Real header=8.0;
  Real pkts=100.0;
  argv++;
  argc--;
  while (argc>0) {
    if (argv[0][0] == '-') {
      char *tail;
      switch (argv[0][1]) {
        case 'x':
          if (argc<2)
            ReportErrorAndExit("VoIP parser", "Invalid Codec Type", programName, FlowId, memptr);
          if (strcmp(argv[1],"G.711.1")==0){
              strcpy(codec,"G.711");
              framesize=80.0;
              samples=1.0;
              pkts=100.0;
          }
          else if (strcmp(argv[1],"G.711.2")==0){
              strcpy(codec,"G.711");
              framesize=80.0;
              samples=2.0;
              pkts=50.0;
          }
          else if (strcmp(argv[1],"G.729.2")==0){
              strcpy(codec,"G.729");
              framesize=10.0;
              samples=2.0;
              pkts=50.0;
              }
          else if (strcmp(argv[1],"G.729.3")==0){
              strcpy(codec,"G.729");
              framesize=10.0;
              samples=3.0;
              pkts=33.0;
              }
          else if (strcmp(argv[1],"G.723.1")==0){
              strcpy(codec,argv[1]);
              framesize=30.0;
              samples=1.0;
              pkts=26.0;
              }
	   else
	   	ReportErrorAndExit("VoIP parser", "Invalid Codec Type", programName, FlowId, memptr);
          argv+=2;
          argc-=2;
          break;
        case 'h':
          if (argc<2)
            ReportErrorAndExit("VoIP parser", "Invalid Protocol Type", programName, FlowId, memptr);
          if (strcmp(argv[1],"RTP")==0)
              header=8.0;
          else if (strcmp(argv[1],"CRTP")==0)
              header=2;
	  else
	  	ReportErrorAndExit("VoIP parser", "Invalid Protocol Type (RTP or CRTP)", programName, FlowId, memptr);
          argv+=2;
          argc-=2;
          break;
        case 'i':
          if (argc<2)
            ReportErrorAndExit("VoIP parser", "Invalid Option (VAD)", programName, FlowId, memptr);
          if (strcmp(argv[1],"VAD")==0)
              VAD=0.65;
	  else
	  	ReportErrorAndExit("VoIP parser", "Invalid Option (VAD)", programName, FlowId, memptr);
          argv+=2;
          argc-=2;
          break;
        default:
         tail = (char *)malloc(sizeof("Unknown option ")+sizeof(argv[0]));
         ReportErrorAndExit("VoIP parser", strcat(strcpy(tail, "Unknown option "), argv[0]), programName, FlowId, memptr);
         break;
          }
        }
    else {
        char temp[sizeof("What is  ?")+sizeof(argv[0])];
        ReportErrorAndExit("VoIP parser", strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"), programName, FlowId, memptr);
    }
   }
   PktSizeDistro = pdConstant;
   PktSize.SetExpr( (VAD * framesize * samples) * ConstantRV + header);
   IntArrivDistro = pdConstant;
   IntArriv.SetExpr( 1000.0 / pkts * ConstantRV );
   printf("Voice Codec: %s\t\nFramesize: %4.2f\t\nSamples: %4.0f\t\nPackets per sec.: %4.0f\t\n",codec,framesize,samples,pkts);
   if (VAD==1)
     printf("VAD: No\n");
   else
     printf("VAD: Si\n");
} // End VoIP_parser


// DNS Parser
void DNS_parser(){

 // Set inter-arrival time (msecs)
  IntArrivDistro = pdConstant;
  IntArriv.SetExpr( 1000.0 / 0.56  * ConstantRV );

  //Set packet size (bytes)
  PktSizeDistro = pdUniform;
  PktSize.SetExpr(  220.0 * UniformRV + 100.0 );
}



void PrintHelpAndExit() {
  cout << endl << " ITGSend Usage:" << endl << endl;
  cout << "  -In case of using a script file:" << endl;
  cout << "   ./ITGSend <script_file> <log_file>\n" << endl;
  cout << "  -Otherwise:" << endl;
  cout << "   ./ITGSend <ITGSend options> <Upper protocol options>" << endl << endl;
  cout << endl << " ITGSend options:" << endl << endl;
  cout << "  -m <msr_type>\t\ttype of meter.\n\t\t\tValues: owdm (one way delay meter)\n\t\t\t\trttm (round trip time meter)\n\t\t\t(Default: owdm)" << endl;
  cout << "  -a <dest_address>\t\t\t\t(Default: " << DefaultDestIP << ")" << endl;
  cout << "  -p <dest_port>\t\t\t\t(Default: " << DefaultPort << ") NOTE: User\n\t\t\t\t\t\treserved ports are >= " << IPPORT_USERRESERVED << endl;
  cout << "  -P <priority>\t\t\t\t\t(Default: 0)NOTE:0<priority<90"<< endl;
  cout << "  -T <protocol_type>\t\t\t\t(Default: "<< DefaultProto << ") NOTE: Protocol\n\t\t\t\t\t\tTypes are: UDP,TCP" << endl;
  cout << "  -b <DS_byte>\t\t\t\t\t(Default: " << DefaultDSByte << ")" << endl;
  cout << "  -C <pkts_per_sec>\t\t\t\t[DEFAULT] constant inter-arrival\n\t\t\t\t\t\t(Default: " << DefaultPktPerSec << " pkts/sec)" << endl;
  cout << "  -U <min_pkts_per_sec> <max_pkts_per_sec>\tuniformly distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -E <average_pkts_per_sec>\t\t\texponentially distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -V <shape> <scale>\t\t\t\tpareto distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -Y <shape> <scale>\t\t\t\tcauchy distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -N <mean> <std_dev>\t\t\t\tnormal distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -O <mean>\t\t\t\t\tpoisson distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -G <shape> <scale>\t\t\t\tgamma distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -c <pkt_size>\t\t\t\t\t[DEFAULT] constant payload size\n\t\t\t\t\t\t(Default: " << DefaultPktSize << " bytes)" << endl;
  cout << "  -u <min_pkt_size> <max_pkt_size>\t\tuniformly distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -e <average_pkt_size>\t\t\t\texponentially distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -v <shape> <scale>\t\t\t\tpareto distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -y <shape> <scale>\t\t\t\tcauchy distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -n <mean> <std_dev>\t\t\t\tnormal distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -o <mean>\t\t\t\t\tpoisson distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -g <shape> <scale>\t\t\t\tgamma distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -s <seed>\t\t\t\t\tseed (Default: Random)" << endl;
  cout << "  -t <duration>\t\t\t\t\tgeneration duration\n\t\t\t\t\t\t(Default: " << DefaultDuration << " msecs)" << endl;
  cout << "  -d <generation_delay>\t\t\t\t(Default: " << DefaultDelay << " msecs)" << endl;
  cout << "  -l [<logfile>]\t\t\t\tGenerate log file\n\t\t\t\t\t\t(Default: " << DefaultLogFile << "\n\t\t\t\t\t\tonly for rttm)\n" << endl;
  cout << "  -L <Log_Address> <Log_port> <Protocol_type> \t Remote Log \n\t\t\t(Default: <" <<DefaultLogIP<<"> <"<<DefaultLogPort<<"> <"<<DefaultProtoTx_Log<<">"<< "\n\t\t\t" << endl;;
  cout << "  -D <array_dimension>\t\t\t\tArray dimension\n\t\t\t\t\t\t(Default: " << DimDefault << " )" << endl;
  cout << " Upper Protocol Options: \n" << endl;
  cout << "  Telnet (without any other option)" << endl;
  cout << "  DNS (without any other option)" << endl;
  cout << "  VoIP (with option: )\t-x <codec_type>\tCodec:  G.711.<1 or 2> (samples per pkt)" << endl;
  cout << " \t\t\t\t\t\tG.729.<2 or 3> (samples per pkt)" << endl;
  cout << " \t\t\t\t\t\tG.723.1" << endl;
  cout << " \t\t\t\t\t\t(Default: G.711.1)" << endl;
  cout << "  \t\t-h <protocol_type>\t\t(Default: RTP)" << endl;
  cout << "  \t\t-i <Voice_Activity_Detection>\t(Default: VAD)" << endl;
  cout << endl;
  cout << " For more information consult ""help"" file in the same directory"<<  endl;

  exit(1);
}


void ReportErrorAndExit(char *function, char *msg, char *pname, int fid,char *memptr) {
  cerr << endl << "** ERROR **  Flow " << fid << " aborted : " << function << ": " << msg << endl;
  cerr << "Type '" << pname << "' for help" << endl << endl;
  (*memptr)--;
  exit(1);
}




void UpdateTicker(struct TTicker *Ticker) {
  struct timeval thisTime, *lastTime = &Ticker->lastTime;

  gettimeofday(&thisTime, NULL);
  Ticker->count += ((double)(thisTime.tv_sec - lastTime->tv_sec))*1000.0 +
                   ((double)(thisTime.tv_usec - lastTime->tv_usec))/1000.0;
 *lastTime = thisTime;

}

void CreaCanaleSignaling(int &signaling,struct sockaddr_in DestHost)
{
   struct sockaddr_in locale;
   signaling=socket(PF_INET,SOCK_STREAM,0);
   locale.sin_family = AF_INET;
   locale.sin_addr.s_addr=DestHost.sin_addr.s_addr; //indizzo del canale di signaling
   locale.sin_port=htons(DefaultPortSignaling);
   connect(signaling, (struct sockaddr *)&locale, sizeof(locale));
  }


void SMSSignaling(int signaling, struct sockaddr_in DestHost,char *protocolName,char *upProtocol)
{
  int inviati;
  InfoScambiate Info_Scambiate;
  Info_Scambiate.MyAddress.sin_family=AF_INET;
  Info_Scambiate.MyAddress.sin_port=DestHost.sin_port;
  Info_Scambiate.MyAddress.sin_addr.s_addr=DestHost.sin_addr.s_addr;
  Info_Scambiate.stop=false;
  Info_Scambiate.FlowIdStop=0;
  strcpy(Info_Scambiate.AppProtocolName,upProtocol);
  strcpy(Info_Scambiate.protocolName,protocolName);
  inviati=send(signaling,&Info_Scambiate,sizeof(InfoScambiate), 0);
  sleep(1);
}



// *********************************************************************************************************************************
// ****************************************Packets sender function owdn*************************************************************
// *********************************************************************************************************************************
void send_packowdm(int &ScriptMode, unsigned int &DSByte, unsigned long &Duration, uid_t user_id,
 int icmptype, TAppProto AppProtocol, int logvar, int FlowId,char *LogFile,
 struct timeval timeout, struct sockaddr_in DestHost, int &logout, struct sockaddr_in LogHost,
 char* ProtoTx_Log,char *upProtocol,int Dim,char *protocolName,int priority,int &signaling)
{
  bool buff;
  InfoScambiate Info_Scambiate;
  Signaling LogSignal;
  int count;

  struct sockaddr_in SrcHost;
  struct sockaddr_in SockAddress;
  size_t sizeAddr = sizeof(SrcHost);
  int socktype,logsocksignaling;
  int logsock;
  int prototype=0;
  unsigned int SeqNum = 1;
  struct TTicker Ticker;
  struct timeval start_time, end_time;
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  u_short help;

  Real wait;
  int size;
  long int time;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  unsigned char *ptrSize;
  char DestAddr[20];

  if (!(strcasecmp(protocolName,"UDP"))){
    socktype=SOCK_DGRAM;
 }
  else if (!(strcasecmp(protocolName,"ICMP"))){
    socktype=SOCK_RAW;
    prototype=IPPROTO_RAW;
    }
  else
    socktype=SOCK_STREAM;

  // Create the socket
  int sock = socket(PF_INET, socktype , prototype);
  if (sock < 0) {
    cerr << endl << "** ERROR **  Flow " << FlowId << " aborted : Cannot create a socket" << endl;
    exit(1);
  }

  // Set DS byte if nonzero
  #ifdef LINUX_OS
    if ( DSByte && setsockopt(sock, SOL_IP, IP_TOS, &DSByte, sizeof(DSByte)) < 0 )
  #endif
  #ifdef FREEBSD_OS
    if ( DSByte && setsockopt(sock, getprotobyname("IP")->p_proto, IP_TOS, &DSByte, sizeof(DSByte)) < 0 )
  #endif
      cerr << "** WARNING **  Flow " << FlowId << " : Cannot set DS byte to " << DSByte << endl;


  if ((!(AppProtocol==apTelnet)&&(!(AppProtocol==apDNS)))&&(socktype==SOCK_STREAM))
  {
	printf("Nagle algorithm disabled\n");
	int no_delay=1;
	if (setsockopt(sock, getprotobyname("TCP")->p_proto, TCP_NODELAY, &no_delay, sizeof(no_delay))<0)
		cerr << "** WARNING **  : Cannot disable Nagle Algorithm" << endl;
  }


  if (logvar && !ScriptMode)
      if (!logout){     // se il log è locale
        if ((logfile = open(LogFile,O_CREAT | O_TRUNC | O_WRONLY, 0666))== -1){
          cerr << "** WARNING **  Cannot create '" << LogFile << "' for writing" << endl;
          logvar = 0;
        }
      }
      else {	//.. se il log è remoto
	    logsocksignaling = socket(PF_INET, SOCK_DGRAM , 0); // ..canale per fare signaling!
	    help=LogHost.sin_port;
	    LogHost.sin_port=htons(DefaultLogPortSignaling);

            LogSignal.PortoLog=ntohs(help);
	    strcpy(LogSignal.protocol,ProtoTx_Log);
	    LogSignal.bufferdimensione=Dim;
	    if (sendto(logsocksignaling, &LogSignal, sizeof(LogSignal),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
            cerr << "** WARNING **  Error into sendto "<< endl;
	    LogHost.sin_port=help;
	    close(logsocksignaling);
	                                                     //canela TX - LOG Remoto
	    if (strcmp(ProtoTx_Log,"UDP")==0) {
	        logsock = socket(PF_INET, SOCK_DGRAM , 0);    // canale UDP TX - Log
		}
	    else {
	          logsock=socket(AF_INET,SOCK_STREAM,0);      // TCP .. canale su cui inviare i
		}

           }

  // crea canale per fare signaling con il ricevitore;
  // passa al ricevitore l'indirizzo IP del ricevitore stesso e il porto su
  // cui il ricevitore si mette in ascolto!

  if (!ScriptMode) CreaCanaleSignaling(signaling,DestHost);
  SMSSignaling(signaling,DestHost,protocolName,upProtocol);


  connect(sock, (struct sockaddr *)&DestHost, sizeof(DestHost));
  getsockname(sock, (struct sockaddr *)&SrcHost, &sizeAddr);


  strcpy(DestAddr, inet_ntoa(DestHost.sin_addr));

  if (!(strcasecmp(protocolName,"TCP")))
    	ptrSize = ptrTimeUsec + sizeof(int);

  memcpy(payload, &FlowId, sizeof(unsigned int) );

  // Disable paging for all pages mapped into the address space of the calling process
  #ifdef LINUX_OS
  if ((priority>0)&&(user_id==0)){
    if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
     ReportErrorAndExit("Send_packet", "Memory lock failed", programName, FlowId,NULL);
    //start round robin real time scheduling
    p.sched_priority=priority;
    if (sched_setscheduler(0, SCHED_RR, &p)<0)
    ReportErrorAndExit("Send_packet", "Sched_setscheduler() failed", programName, FlowId,NULL);
    }
  else mlockall(MCL_CURRENT);
  #endif

  // Get starting time
  gettimeofday(&start_time, NULL);
    // Calculate ending time
  end_time.tv_sec = start_time.tv_sec + Duration / 1000 + (end_time.tv_usec = start_time.tv_usec + (Duration % 1000) * 1000) / 1000000;
  end_time.tv_usec %= 1000000;

  #ifdef DEBUG_PACKET
    cout << "Starting time of flow " << FlowId << " : " << start_time.tv_sec << " secs  " << start_time.tv_usec << " usecs" << endl;
    cout << "Ending time of flow " << FlowId << " : " << end_time.tv_sec << " secs  " << end_time.tv_usec << " usecs" << endl;
  #endif

  //deve fare la connect per sbloccare l'accpet nel server di log!
  if (logvar && !ScriptMode)
	if (logout) connect(logsock,(struct sockaddr *)&LogHost, sizeof(LogHost));


  cout << "Sending packets of flow " << FlowId << "..." << endl;
  Ticker.count = 0.0;
  gettimeofday(&Ticker.lastTime, NULL);
  count=0;
  int sockchk=0;
  long int Time;
  buff=false;
  do {

  // send packet
      if (!(strcasecmp(protocolName,"TCP")))
      	( (size=(int) PktSize.Next()) >= MaxPayloadSize) ? size=MaxPayloadSize : (size < (MinPayloadSize + sizeof(int))) ? size=(MinPayloadSize + sizeof(int)) : 1;
      else
	( (size=(int) PktSize.Next()) >= MaxPayloadSize) ? size=MaxPayloadSize : (size < MinPayloadSize) ? size=MinPayloadSize : 1;

      memcpy( ptrSeqNum, &SeqNum, sizeof(unsigned int) );
      time=Ticker.lastTime.tv_sec%86400L;
      memcpy( ptrTimeSec, &(time), sizeof(long int) );
      memcpy( ptrTimeUsec, &(Ticker.lastTime.tv_usec), sizeof(long int) );

      if (!(strcasecmp(protocolName,"TCP")))
      	memcpy( ptrSize, &size, sizeof(int) );

      if (strcmp(protocolName,"ICMP")==0){
        //fill_packet(size,icmptype,DestHost,SrcHost);

        //sockchk=send(sock, &pkt, size+28, 0);
	if (sockchk<0) cout<<"ERRORE NELLA SEND!!!!!\n";
      }
      else
        sockchk=sendto(sock, payload, size, 0,(struct sockaddr *)&DestHost, sizeof(DestHost));
      if (sockchk < 0)
        cerr << "** WARNING **  Flow " << FlowId << " : Packet " << SeqNum << " not sent" << endl;
      else if (logvar) {

      //Logging informations using an array of structs as memory buffer
      if (count<Dim)
        {
        infos[count].FlowId=*(unsigned int *)payload;
        infos[count].SeqNum=*(unsigned int *)ptrSeqNum;
        strcpy(infos[count].src_addr,inet_ntoa(SrcHost.sin_addr));
        infos[count].src_port=ntohs(SrcHost.sin_port);
        strcpy(infos[count].dest_addr,inet_ntoa(DestHost.sin_addr));
        infos[count].dest_port=htons(DestHost.sin_port);
        infos[count].TxTime1=time/3600;
        infos[count].TxTime2=(time%3600)/60;
        infos[count].TxTime3=time%60+Ticker.lastTime.tv_usec/1000000.0;
        infos[count].RxTime1=time/3600;
        infos[count].RxTime2=(time%3600)/60;
        infos[count].RxTime3=time%60+Ticker.lastTime.tv_usec/1000000.0;
        if (AppProtocol==apTelnet)
          infos[count].size=size-20;
        else
          infos[count].size=size;
        count++;
        }
    if (count==Dim) {
        if (!logout){
         write(logfile, infos, Dim*sizeof(struct Info));
         count=0;
        }
        else {
         if (sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
           cerr << "** WARNING **  Flow " << FlowId << " : Packet " << SeqNum << " not sent" << endl;
         count=0;
        }
		 }
    }
  // wait inter-arrive
      wait = IntArriv.Next();   // wait is expressed in msecs
      UpdateTicker(&Ticker);
      if (wait <= Ticker.count)
        Ticker.count -= wait;
      else {
        while(wait > Ticker.count) {
          wait -= Ticker.count;
          Ticker.count = 0.0;
          timeout.tv_sec = (long) wait/1000;
          timeout.tv_usec = (long) (wait - (timeout.tv_sec*1000))*1000;
          select(1, NULL, NULL, NULL, &timeout);
          UpdateTicker(&Ticker);
        }
        Ticker.count -= wait;
      }

      SeqNum++;
    } while ( Ticker.lastTime.tv_sec < end_time.tv_sec || ( Ticker.lastTime.tv_sec == end_time.tv_sec && Ticker.lastTime.tv_usec < end_time.tv_usec ) );

    cout << "Flow " << FlowId << ": Done!" << endl;

    Info_Scambiate.FlowIdStop=FlowId;
    Info_Scambiate.stop=false;
    sendto(signaling,&Info_Scambiate,sizeof(InfoScambiate),0,(struct sockaddr *)&DestHost, sizeof(DestHost));
    close(sock);

  // Restore priority settings
   if ((priority > 0)&&(user_id == 0)){
      //restore the program priority
      p.sched_priority=0;
      if (sched_setscheduler(0, SCHED_OTHER, &p)<0)
        ReportErrorAndExit("Send_packet", " Priority restoring failed", programName, FlowId,NULL);
      //release locked memory
      munlockall();
    }
       // Swap to file elements that may remain into the buffer
  if (logvar){
  while (count<Dim)
  {
    buff=true;
    infos[count].size=0;
    count++;
  }
  if (buff==true)
  if (!logout)
       write(logfile, infos, Dim*sizeof(struct Info));
  else if (sendto(logsock, (char *)infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
    cerr << "** WARNING **  Flow " << FlowId << " : Packet " << SeqNum << " not sent" << endl;
  if (logout) {
   close(logsock);
   }
   close(logfile);

  }
 free (infos);

}// end send_packowdm



void Terminate(int sig) {
  close(sock);
  close(logfile);
  exit(1);
}


// *********************************************************************************************************************************
// ****************************************Packets sender function rttm*************************************************************
// *********************************************************************************************************************************

void send_packrttm(int &ScriptMode, unsigned int &DSByte, unsigned long &Duration, uid_t user_id,
pid_t pid, char *LogFile, struct timeval timeout, struct sockaddr_in DestHost, int &logout,
struct sockaddr_in LogHost,char *ProtoTx_Log,char *upProtocol,int Dim,int FlowId,
char *protocolName,int priority,int &signaling)
{
  InfoScambiate Info_Scambiate;
  Signaling LogSignal;
  bool buff;
  int count;
  u_short help;
  
  struct sockaddr_in SrcHost;
  size_t sizeAddr = sizeof(SrcHost);
  int socktype,logsocksignaling;
  int logsock;
  unsigned int SeqNum = 1;
  struct TTicker Ticker;
  struct timeval start_time, end_time, RcvTime;
  int size_r, size_p;
  unsigned char buffer[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  if (!(strcasecmp(protocolName,"UDP")))
    socktype=SOCK_DGRAM;
  else
    socktype=SOCK_STREAM;

// Create a socket
  int sock;

  sock = socket(PF_INET, socktype, 0);
  if (sock < 0) {
    cerr << endl << "** ERROR **  Flow " << FlowId << " aborted : Cannot create a socket" << endl;
    exit(1);
  }

// Set DS byte if nonzero
#ifdef LINUX_OS
  if ( DSByte && setsockopt(sock, SOL_IP, IP_TOS, &DSByte, sizeof(DSByte)) < 0 )
#endif
#ifdef FREEBSD_OS
  if ( DSByte && setsockopt(sock, getprotobyname("IP")->p_proto, IP_TOS, &DSByte, sizeof(DSByte)) < 0 )
#endif
    cerr << "** WARNING **  Flow " << FlowId << " : Cannot set DS byte to " << DSByte << endl;

    if (!ScriptMode)
      if (!logout){
        if ((logfile = open(LogFile,O_CREAT | O_TRUNC | O_WRONLY, 0666))== -1){
          cerr << "** WARNING **  Cannot create '" << LogFile << "' for writing" << endl;
          //logvar = 0;
        }
      }
      else {	//.. se il log è remoto

            logsocksignaling = socket(PF_INET, SOCK_DGRAM , 0); // ..canale per fare signaling!
	    help=LogHost.sin_port;
	    LogHost.sin_port=htons(DefaultLogPortSignaling);

            LogSignal.PortoLog=ntohs(help);
	    strcpy(LogSignal.protocol,ProtoTx_Log);
	    LogSignal.bufferdimensione=Dim;
	    if (sendto(logsocksignaling, &LogSignal, sizeof(LogSignal),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
            cerr << "** WARNING **  Error into sendto "<< endl;
	    LogHost.sin_port=help;
	    close(logsocksignaling);
	                                                     //canela TX - LOG Remoto
	    if (strcmp(ProtoTx_Log,"UDP")==0) {
	        logsock = socket(PF_INET, SOCK_DGRAM , 0);    // canale UDP TX - Log
		}
	    else {
	          logsock=socket(AF_INET,SOCK_STREAM,0);      // TCP .. canale su cui inviare i
		 }
           }

 // CreaCanaleSignaling(0,DestHost,protocolName,upProtocol);
  if (!ScriptMode) CreaCanaleSignaling(signaling,DestHost);
  SMSSignaling(signaling,DestHost,protocolName,upProtocol);

// only to get source port
  connect(sock, (struct sockaddr *)&DestHost, sizeof(DestHost));
  getsockname(sock, (struct sockaddr *)&SrcHost, &sizeAddr);

  char DestAddr[20];
  strcpy(DestAddr, inet_ntoa(DestHost.sin_addr));

// Establish a handler for SIGUSR1 signals
  signal(SIGUSR1, Terminate);

  Real wait;
  int size, terminate=0, first_time=1;
  size_t offSeqNum = sizeof(unsigned int);
  size_t offTimeSec = offSeqNum + sizeof(unsigned int);
  size_t offTimeUsec = offTimeSec + sizeof(long int);
  size_t offSize;
    if (!(strcasecmp(protocolName,"TCP")))
     offSize = offTimeUsec + sizeof(int);
  memcpy( payload, &FlowId, sizeof(unsigned int) );
  long int time1, time2,time;

// Disable paging for all pages mapped into the address space of the calling process
  #ifdef LINUX_OS
  if ((priority>0)&&(user_id==0)){
    if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
     ReportErrorAndExit("Send_packet", "Memory lock failed", programName, FlowId,NULL);
    //start round robin real time scheduling
    p.sched_priority=priority;
    if (sched_setscheduler(0, SCHED_RR, &p)<0)
    ReportErrorAndExit("Send_packet", "Sched_setscheduler() failed", programName, FlowId,NULL);
    }
  else mlockall(MCL_CURRENT);
  #endif

// Get starting time
  gettimeofday(&start_time, NULL);

// Calculate ending time
  end_time.tv_sec = start_time.tv_sec + Duration / 1000 + (end_time.tv_usec = start_time.tv_usec + (Duration % 1000) * 1000) / 1000000;
  end_time.tv_usec %= 1000000;

#ifdef DEBUG_PACKET
  cout << "Starting time of flow " << FlowId << " : " << start_time.tv_sec << " secs  " << start_time.tv_usec << " usecs" << endl;
  cout << "Ending time of flow " << FlowId << " : " << end_time.tv_sec << " secs  " << end_time.tv_usec << " usecs" << endl;
#endif

  cout << "Sending packets of flow " << FlowId << "..." << endl;

  //deve fare la connect per sbloccare l'accpet nel server di log!
  if (!ScriptMode)
      if (logout) connect(logsock,(struct sockaddr *)&LogHost, sizeof(LogHost));


  start_time.tv_sec = 0;       // re-use start_time
  start_time.tv_usec = 0;

  fd_set read_set, active_set;
  FD_ZERO(&active_set);
  FD_SET(STDIN_FILENO, &active_set);   // add stdin to the set of monitored file descriptors
  FD_SET(sock, &active_set);

  Ticker.count = 0.0;
  gettimeofday(&Ticker.lastTime, NULL);
  count=0;
  buff=false;
  while (1) {
// send packet
    if (!terminate) {
      if (!(strcasecmp(protocolName,"TCP")))
      	( (size=(int) PktSize.Next()) >= MaxPayloadSize) ? size=MaxPayloadSize : (size < (MinPayloadSize + sizeof(int))) ? size=(MinPayloadSize + sizeof(int)) : 1;
      else
        ( (size=(int) PktSize.Next()) >= MaxPayloadSize) ? size=MaxPayloadSize : (size < MinPayloadSize) ? size=MinPayloadSize : 1;
      memcpy( payload+offSeqNum, &SeqNum, sizeof(unsigned int) );
      time=Ticker.lastTime.tv_sec%86400L;
      memcpy( payload+offTimeSec, &(time), sizeof(long int) );
      memcpy( payload+offTimeUsec, &(Ticker.lastTime.tv_usec), sizeof(long int) );
      if (!(strcasecmp(protocolName,"TCP")))
      	memcpy( payload+offSize, &size, sizeof(int) );

      if (send(sock, payload, size, 0) < 0)
        cerr << "** WARNING **  Flow " << FlowId << " : Packet " << SeqNum << " not sent" << endl;
    }

// non-blocking (start_time=0) check for arrived packets
    read_set = active_set;                              // since select puts in read_set only ready file descriptors
    if ( select(FD_SETSIZE, &read_set, NULL, NULL, &start_time) < 0 ) {
      cerr << endl << "** ERROR **  : Invalid file descriptor or operation interrupted by a signal" << endl;
      exit(1);
    }

    if ( pid && FD_ISSET(STDIN_FILENO, &read_set) ) {
      char key;
      read(STDIN_FILENO, &key, 1);
      if ( key == 10 )  {     // Enter has been pressed, terminate
        cout << "Stop waiting for packets" << endl;
        if (!ScriptMode)
          break;
        else
          kill(0, SIGUSR1);
        }
      }

    if ( FD_ISSET(sock, &read_set) ) {
      gettimeofday(&RcvTime, NULL);
      if (!(strcasecmp(protocolName,"TCP"))){
	    	size_r = recv(sock, rpayload, 20, 0);
		    if (size_r < 20){
			   recv(sock, buffer, 20 - size_r, 0);
			   memcpy( payload, &buffer, sizeof(buffer) );
		     }
		size = *(int *)(rpayload + offSize);
		size_p = recv(sock, buffer, (size - 20), 0);
	        if (size_p < (size - 20) )
	         recv(sock,buffer, ((size - 20) - size_p), 0);
	}
	else
		size_r = recv(sock, rpayload, MaxPayloadSize, 0);
      time1 = (*(long int *)(rpayload+offTimeSec));
      time2 = RcvTime.tv_sec%86400L;

      //Logging informations using an array of structs as memory buffer
     if (size_r > 0) {
      if (count<Dim)
        {
	 infos[count].FlowId=*(unsigned int *)rpayload;
        infos[count].SeqNum=*(unsigned int *)(rpayload+offSeqNum);
        strcpy(infos[count].src_addr,inet_ntoa(SrcHost.sin_addr));
        infos[count].src_port=ntohs(SrcHost.sin_port);
        strcpy(infos[count].dest_addr,DestAddr);
        infos[count].dest_port=ntohs(DestHost.sin_port);
        infos[count].TxTime1=time1/3600;
        infos[count].TxTime2=(time1%3600)/60;
        infos[count].TxTime3=time1%60+(*(long int*)(rpayload+offTimeUsec))/1000000.0;
        infos[count].RxTime1=time2/3600;
        infos[count].RxTime2=(time2%3600)/60;
        infos[count].RxTime3=time2%60+RcvTime.tv_usec/1000000.0;
        infos[count].size=size;
        count++;
        }
    if (count==Dim)
        if (!logout){
         write(logfile, infos, Dim*sizeof(struct Info));
         count=0;
        }
        else {
         if (sendto(logsock,(char *)infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
           cerr << "** WARNING **  Flow " << FlowId << " : Packet " << SeqNum << " not sent" << endl;
         count=0;
        }
     }
  }
// wait inter-arrive
    if (!terminate) {
      wait = IntArriv.Next();   // wait is expressed in msecs
      UpdateTicker(&Ticker);
      if (wait <= Ticker.count)
        Ticker.count -= wait;
      else {
        while(wait > Ticker.count) {
          wait -= Ticker.count;
          Ticker.count = 0.0;
          timeout.tv_sec = (long) wait/1000;
          timeout.tv_usec = (long) (wait - (timeout.tv_sec*1000))*1000;
          select(1, NULL, NULL, NULL, &timeout);
          UpdateTicker(&Ticker);
        }
        Ticker.count -= wait;
      }
    }
    SeqNum++;
    terminate = (Ticker.lastTime.tv_sec > end_time.tv_sec || (Ticker.lastTime.tv_sec == end_time.tv_sec && Ticker.lastTime.tv_usec > end_time.tv_usec));
    if (terminate && first_time) {
      cout << "Flow " << FlowId << ": Done!" << endl;
      Info_Scambiate.FlowIdStop=FlowId;
      Info_Scambiate.stop=false;
      sendto(signaling,&Info_Scambiate,sizeof(InfoScambiate),0,(struct sockaddr *)&DestHost, sizeof(DestHost));
      first_time = 0;
    }
  }

 // Restore priority settings
    if ((priority > 0)&&(user_id == 0)){
      //restore the program priority
      p.sched_priority=0;
      if (sched_setscheduler(0, SCHED_OTHER, &p)<0)
        ReportErrorAndExit("Send_packet", " Priority restoring failed", programName, FlowId,NULL);
      //release locked memory
      munlockall();
    }

  // Swap to file elements that may remain into the buffer

  close(logsock);
  while (count<Dim)
  {
    buff=true;
    infos[count].size=0;
    count++;
  }
  if (buff=true)
  if (!logout)
       write(logfile, infos, Dim*sizeof(struct Info));
  else if (sendto(logsock,(char *)infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
           cerr << "** WARNING **  Flow " << FlowId << " : Packet " << SeqNum << " not sent" << endl;
  if (logout) {

   close(logsock);
   }
  close(logfile);
  free (infos);
}//end send_packrttm



int findProto(char *s)
{
	int i=1;

	while (strcmp(AppProto[i]," "))
		if (!strcasecmp(s,AppProto[i]))
			return i;
		else
			i++;
	return 0;
}


