// ITG.h

#include <string.h> 		// strtok(), strcasecmp()
#include <stdlib.h>		// strtol()
#include <stdio.h>
#include <iostream.h>
#include <sys/types.h>		// select()
#include <sys/socket.h>
#include <netinet/in.h>		// htons(), inet_aton(), inet_addr()
#include <arpa/inet.h>
#include <sys/time.h>		
#include <unistd.h>		// gethostbyname()
#include <fcntl.h>
#include <netdb.h>

#ifdef LINUX_OS
 #include <sys/mman.h>
 #include <sched.h> //library for scheduling functions
#endif

const int DefaultPortSignaling=9000;
const unsigned short int DefaultPort = 8999;  // porto di default
const unsigned int MaxPayloadSize = 64000;    // dimensione max del payload
char DefaultMsr[]="owdm";		      // metrica di default - owdm
char programName[100];			      // array of char for Program Name(ITGLog, ITGSend, ITGRecv!!)
struct sched_param p;
const char DefaultLogIP[10]="127.0.0.1";      // indirizzo IP di default 
const unsigned short int DefaultLogPort= 9002;// porto di default per il log file remoto
const unsigned short int DefaultLogPortSignaling = 9001;


//Logging Structure
struct Info {
   unsigned int FlowId;
   unsigned int SeqNum;
   char src_addr[15];
   unsigned int src_port;
   char dest_addr[15];
   unsigned int dest_port;
   long int TxTime1;
   long int TxTime2;
   double TxTime3;
   long int RxTime1;
   long int RxTime2;
   double RxTime3;
   int size;
   };
