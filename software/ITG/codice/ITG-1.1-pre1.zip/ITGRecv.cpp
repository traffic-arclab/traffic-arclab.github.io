#include "ITG.h"
#include <sys/uio.h>
#include <netinet/ip_icmp.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <wait.h>


// Constant definitions
const char DefaultLogFile[]="/tmp/ITGRecv.log";
char DefaultProtoTx_Log[]="UDP"; //default proto TX-Log remoto
const int DimLogFileChr=100;
const int DimDefault=10;

// Prototypes
void udp_sock(int fd[2],int logsock,int logfile, int logcheck,  char *upProtocol, char *NameMsr, struct sockaddr_in LogHost, int &logout,char* ProtoTx_Log,struct sockaddr_in DestHost, int Dim,int priority);
void tcp_sock(int fd[2],int logsock,int logfile, int logcheck,  char *upProtocol, char *NameMsr, struct sockaddr_in LogHost, int &logout,char* ProtoTx_Log,struct sockaddr_in DestHost, int Dim,int priority);
void PrintHelpAndExit(char *pname, char *DefaultProto);
void ReportErrorAndExit(char *msg, char *pname);

struct InfoScambiate{
    struct sockaddr_in MyAddress;
    char protocol[30];
    char AppProtocolName[30];
    bool stop;
    int FlowIdStop;
};

// variabili per gestione canale di signaling con il log-remoto
struct Signaling {
        int bufferdimensione;
	int PortoLog;
	char protocol[30];
 };

// Start Main
int main(int argc, char *argv[]) {
  Signaling signal;
  int priority=0; 			     // priority
  int Dim=DimDefault;			     // dimensione standard dell'array
  char *ProtoTx_Log= DefaultProtoTx_Log;     // default proto TX-Log remoto
  char *DefaultProto="UDP";
  char *protocolName;
  protocolName=DefaultProto;
  char *NameMsr;
  NameMsr=DefaultMsr;
  char LogFile[DimLogFileChr];
  strcpy(LogFile,DefaultLogFile);

  char *upProtocol;
  int logcheck=0;
  int logfile;
  int logout=0;
  uid_t user_id=getuid();		// var user_id is the id of the user who calls the process
  int size;

  int logsocksignaling;
  int help;
  int Signaling;
  int logsock;
  pid_t pid;

  // variabili per la gestione canale di signaling con il mittente
  InfoScambiate Info_Scambiate;
  struct sockaddr_in SockAddress;
  struct sockaddr_in SrcAddress;
  struct sockaddr_in Sock_Address;
  int sock_signaling,new_sock_signaling;
  socklen_t sin_len=sizeof(SockAddress);

  // Set the default IP log addr
  struct hostent *host;
  struct sockaddr_in LogHost;
  LogHost.sin_family=AF_INET;
  inet_aton(DefaultLogIP, &LogHost.sin_addr);
  LogHost.sin_port=htons(DefaultLogPort);

  #ifdef LINUX_OS
  if ((priority>0)&&(user_id==0)){
    if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
     ReportErrorAndExit("Memory lock failed", programName);
    //start round robin real time scheduling
    p.sched_priority=priority;
    if (sched_setscheduler(0, SCHED_RR, &p)<0)
    ReportErrorAndExit("Sched_setscheduler() failed", programName);
    }
  else mlockall(MCL_CURRENT);
  #endif


  // Store the program name and inc argv
  strcpy(programName, argv[0]);
  argv++;
  argc--;
  while (argc>0) {
    if (argv[0][0] == '-') {
      long int temp;
      char *tail;

      switch (argv[0][1]) {
       case 'm':
	 if ((strcasecmp(argv[1],"rttm")) && strcasecmp(argv[1],"owdm"))
	          ReportErrorAndExit("General parser",programName);
          NameMsr=argv[1];
          argv+=2;
      	  argc-=2;
	 break;
        case 'l':
          logcheck = 1;
          if ((argc < 2) || (argv[1][0] == '-')) {
            strcpy(LogFile,DefaultLogFile);
            argc-=1;
            argv+=1;
            }
          else {
            strcpy(LogFile, argv[1]);
            argc-=2;
            argv+=2;
          }
          break;
	case 'L':
          logout = 1;
          logcheck = 1;
	  if ((argc < 3) || !(host=gethostbyname(argv[1])) )
            ReportErrorAndExit("General parser Invalid log-server address or port", programName);
          memcpy((char *)&LogHost.sin_addr, host->h_addr, host->h_length);
	  LogHost.sin_port=htons(atoi(argv[2]));
	  if ((strcasecmp(argv[3],"TCP")) && strcasecmp(argv[3],"UDP"))
	          ReportErrorAndExit("General parser",programName);
	  strcpy(ProtoTx_Log,argv[3]);
          argv+=4;
          argc-=4;
          break;
        case 'D':
          if ( (argc < 2) || ((Dim = atoi(argv[1])) < 1.0))
            ReportErrorAndExit("Invalid array dimension", programName);
          argv+=2;
          argc-=2;
          break;
	case 'P':
          if (argc<2)
            ReportErrorAndExit("Invalid Priority Settings", programName);
          priority = atoi(argv[1]);
          if ((priority<1)||(priority>90))
            ReportErrorAndExit("Priority must be between 1 to 90", programName);
          if (user_id!=0)
            ReportErrorAndExit("Must be root to set priority", programName);
          argv+=2;
          argc-=2;
          break;
        case 'h':
          PrintHelpAndExit(programName,DefaultProto);
          break;
        default:
          tail = (char *)malloc(sizeof("Unknown option ")+sizeof(argv[0]));
          ReportErrorAndExit(strcat(strcpy(tail, "Unknown option "), argv[0]), programName);
          break;
      }
    }

  else {
          char temp[sizeof("What is  ?")+sizeof(argv[0])];
          ReportErrorAndExit(strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"), programName);
       }
  } // End of While



   // verifica se il log è locale o remoto
  if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
	if (!logout){
        	if ((logfile = open(LogFile,O_CREAT | O_TRUNC | O_WRONLY, 0666))== -1){
          		cerr << "Cannot create '" << LogFile << "' for writing" << endl;
          		exit(1);
        	}
      	}
      	else {  // in caso di log remoto
		logsocksignaling = socket(PF_INET, SOCK_DGRAM , 0); // ..canale per fare signaling!
	    	help=LogHost.sin_port;
	    	LogHost.sin_port=htons(DefaultLogPortSignaling);

                signal.PortoLog=ntohs(help);
		strcpy(signal.protocol,ProtoTx_Log);
	        signal.bufferdimensione=Dim;
	    	if (sendto(logsocksignaling, &signal, sizeof(signal),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
            	cerr << "** WARNING **  Error into sendto "<< endl;
	    	LogHost.sin_port=help;
	    	close(logsocksignaling);
	                                                     //canela TX - LOG Remoto
	    	if (strcmp(ProtoTx_Log,"UDP")==0) {
	         logsock = socket(PF_INET, SOCK_DGRAM , 0);    // canale UDP TX - Log
		}
	    	else {
	          logsock=socket(AF_INET,SOCK_STREAM,0);      // TCP .. canale su cui inviare i

		 }
           }
  }

  // gestione canale di signaling con il ricevitore - canale TCP!
  sock_signaling = socket(PF_INET, SOCK_STREAM, 0);
  if (sock_signaling < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }

  SockAddress.sin_addr.s_addr=htonl(INADDR_ANY);
  SockAddress.sin_port = htons(DefaultPortSignaling); //porto di default su cui mi ascolto il signaling!
  if (bind(sock_signaling, (struct sockaddr *) &SockAddress, sizeof(SockAddress))) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port - for signaling" << endl;
      exit(1);
  }

  if (listen(sock_signaling,5) < 0) {
       cerr << endl << "** ERROR **  : Cannot listen to a socket on port "  << endl;
       exit(1);
  }

  if( (new_sock_signaling = accept(sock_signaling,(struct sockaddr *) &SrcAddress, &sin_len)) < 0 ) {
       cerr << endl << "** ERROR **  : Connection fault on port " << endl;
       exit(1);
   }
  if (close(sock_signaling)<0) cout<<" *** ERROR into close(sock_signaling) "<<endl;

  int fd[2];
  pipe(fd);   //apre una pipe per consentire la comunicazione tra il processo padre e i processi figli

  Info_Scambiate.stop=false;
  while (Info_Scambiate.stop==false) {
     size=recv(new_sock_signaling,&Info_Scambiate,sizeof(Info_Scambiate),0); //nella struttura Sock_Address
     if (size<0) cout<<"*** ERROR into recv "<<endl;
     if (Info_Scambiate.stop==false){ //termina.. ha ricevuto il messaggio di stop

     if (Info_Scambiate.FlowIdStop==0)
     {
      pid=fork();
      if (!pid)
      {               //sono il figlio

       if (strcmp(Info_Scambiate.protocol,DefaultProto)==0) 	// Call UDP
             {
	      udp_sock(fd,logsock,logfile,logcheck,Info_Scambiate.AppProtocolName,NameMsr,LogHost,logout,ProtoTx_Log,Info_Scambiate.MyAddress,Dim,priority);
	     }
       else if (strcmp(Info_Scambiate.protocol,"TCP")==0) 	// Call TCP
             {
	      tcp_sock(fd,logsock,logfile,logcheck,Info_Scambiate.AppProtocolName,NameMsr,LogHost,logout,ProtoTx_Log,Info_Scambiate.MyAddress,Dim,priority);
             }
      if (close(new_sock_signaling)<0) cout<<" ** Error into close() function"<<endl;
      if (!logout) close(logfile);
      else close(logsock);
      exit(0);
      } // end codice figlio
     } //end of flowID==0
     else   // scrive sulla pipe il numero di flusso del processo da terminare
     {
       write(fd[1],&Info_Scambiate,sizeof(InfoScambiate));
     }
   }
  } //end while

  // Restore priority settings
  if ((priority > 0)&&(user_id == 0)){
      //restore the program priority
      p.sched_priority=0;
      if (sched_setscheduler(0, SCHED_OTHER, &p)<0)
        ReportErrorAndExit("Priority restoring failed", programName);
      //release locked memory
      munlockall();
    }

  int status;
  if (!logout) close(logfile);
  else close(logsock);
  sleep(1);  //è utile nel caso di rttm
  if (close(new_sock_signaling)<0) cout<<" ** Error into close() "<<endl;
  exit(0);
}

// END MAIN

char *getip (u_long in)
{
 struct in_addr s;
 s.s_addr=in;
 return inet_ntoa(s);
}


// UDP Function
void udp_sock(int fd[2],int logsock,int logfile, int logcheck,  char *upProtocol, char *NameMsr, struct sockaddr_in LogHost, int &logout,char *ProtoTx_Log,struct sockaddr_in DestHost,int Dim,int priority)
{
  bool buff; 				      // buffer flag used in log-file writing
  int count;
  int sock;
  int new_sock;
  InfoScambiate Info_Scambiate;
  unsigned char buffer[MaxPayloadSize];
  unsigned char payload[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  SockAddress.sin_family = AF_INET;
  SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  struct sockaddr_in SrcAddress;
  size_t sizeAddr = sizeof(SrcAddress);
  size_t sizeAddrD= sizeof(SockAddress);


  int size, size_p, size_r;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  unsigned char *ptrSize = ptrTimeUsec + sizeof(int);
  long int ptime;
  struct timeval RcvTime;
  int opt=1;
  int val;
  count=0;// Initialize counter variable for log-file writing
  buff=false; //Initialize buffer flag for log-file writing
  socklen_t sin_len=sizeof(SrcAddress);
  fd_set read_set, active_set;
  Signaling signal;

  //se deve fare il log remoto allora fa una connect!
    if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0))))
	if (logout) connect(logsock,(struct sockaddr *)&LogHost, sizeof(LogHost));




  DestHost.sin_family=AF_INET;
  sock = socket(PF_INET, SOCK_DGRAM, 0);
  if (sock < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }

  if (bind(sock, (struct sockaddr *) &DestHost, sizeof(DestHost)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for udp connect " << endl;
      exit(1);
  }

  cout << "Listening on port :" <<ntohs(DestHost.sin_port)<< endl;


  FD_ZERO(&active_set);
  FD_SET(fd[0],&active_set);    //	 aggiunge fd[0] all'insime dei descrittori monitorati
  FD_SET(sock,&active_set);	//	 aggiunge la socket all'insime dei descrittori monitorati


  while (1) {
     read_set=active_set;
     if ( select(FD_SETSIZE, &read_set, NULL, NULL, NULL) < 0 ) {
      cerr << endl << "** ERROR **  : Invalid file descriptor or operation interrupted by a signal" << endl;
      exit(1);
     }
     if (FD_ISSET(fd[0], &read_set) ) {
        read(fd[0],&Info_Scambiate,sizeof(InfoScambiate));
	if (Info_Scambiate.FlowIdStop==*(unsigned int *)payload)
	  break;
	else write(fd[1],&Info_Scambiate,sizeof(InfoScambiate));
      }
    else {

        size_r = recvfrom (sock, payload, MaxPayloadSize,0,(struct sockaddr *) &SrcAddress, &sin_len);
	if (size_r > 0) {
		gettimeofday(&RcvTime, NULL);
		//Logging informations using an array of structs as memory buffer
	  	if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
  			if (count<Dim) {
				infos[count].FlowId=*(unsigned int *)payload;
      				infos[count].SeqNum=*(unsigned int *)ptrSeqNum;
		      		strcpy(infos[count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      				infos[count].src_port=ntohs(SrcAddress.sin_port);
      				strcpy(infos[count].dest_addr,inet_ntoa(DestHost.sin_addr));
      				infos[count].dest_port=ntohs(DestHost.sin_port);
      				ptime = (*(long int *)ptrTimeSec);
      				infos[count].TxTime1=ptime/3600;
      				infos[count].TxTime2=(ptime%3600)/60;
      				infos[count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
      				ptime = RcvTime.tv_sec % 86400L;
      				infos[count].RxTime1=ptime/3600;
      				infos[count].RxTime2=(ptime%3600)/60;
      				infos[count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      				infos[count].size=size_r;
         			count++;
  				}
     			if(count==Dim) {
          			if (!logout){
       				write(logfile, infos, Dim*sizeof(struct Info));
				count=0;
          			}
          			else {
		           	 sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
         	     		 count=0;
     	  			}
			} //end if count==Dim
  		} //end check for log file
  	        if (strcmp(NameMsr,"rttm")==0)
     	        sendto(sock, payload, size_r, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
  	} //end if size_r>0
     } //end else
  }// END While
  close(sock);
  buff=false;
  if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
     // Swap to file elements that may remain into the buffer
    while (count<Dim)
  	{
        	buff=true;
        	infos[count].size=0;
        	count++;
   	}
   if (buff=true)
     if (!logout)
    	write(logfile, infos, Dim*sizeof(struct Info));
     else {
	       sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
          }

  } //end if logcheck..
 cout<<"Finish on port :" <<ntohs(DestHost.sin_port)<< endl;
 free (infos);
}//END UDP Function



// TCP Function
void tcp_sock(int fd[2],int logsock,int logfile, int logcheck, char *upProtocol, char *NameMsr, struct sockaddr_in LogHost, int &logout,char *ProtoTx_Log,struct sockaddr_in DestHost,int Dim,int priority)
{
  int count;
  bool buff; 				      // buffer flag used in log-file writing
  int sock;
  int new_sock;
  InfoScambiate Info_Scambiate;
  unsigned char buffer[MaxPayloadSize];
  unsigned char payload[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  SockAddress.sin_family = AF_INET;
  SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  struct sockaddr_in SrcAddress;
  size_t sizeAddr = sizeof(SrcAddress);
  size_t sizeAddrD= sizeof(SockAddress);
 
  int size, size_p, size_r;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  unsigned char *ptrSize = ptrTimeUsec + sizeof(int);
  long int ptime;
  struct timeval RcvTime;
  int opt=1;
  count=0;// Initialize counter variable for log-file writing
  buff=false; //Initialize buffer flag for log-file writing
  fd_set read_set, active_set;
  Signaling signal;

  //se deve fare il log remoto allora fa una connect!
  if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0))))
	if (logout) connect(logsock,(struct sockaddr *)&LogHost, sizeof(LogHost));


  sock = socket(PF_INET, SOCK_STREAM, 0);
  if (sock < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);

  }

  if (bind(sock, (struct sockaddr *) &DestHost, sizeof(DestHost)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for Tcp connect" << endl;
      exit(1);
  }

  if (listen(sock,5) < 0) {
       cerr << endl << "** ERROR **  : Cannot listen to a socket on port "  << endl;
       exit(1);
  }
  else cout << "Listening on port :" <<ntohs(DestHost.sin_port)<< endl;
  socklen_t sin_len=sizeof(DestHost);
  if( (new_sock = accept(sock,(struct sockaddr *) &SrcAddress, &sin_len)) < 0 ) {
       cerr << endl << "** ERROR **  : Connection fault on port " << endl;
       exit(1);
  }
  
  FD_ZERO(&active_set);
  FD_SET(fd[0],&active_set);    //	 aggiunge stdin all'insime dei descrittori monitorati
  FD_SET(new_sock,&active_set);	//	 aggiunge la socket all'insime dei descrittori monitorati

  while (1) {
     read_set=active_set;
     if ( select(FD_SETSIZE, &read_set, NULL, NULL, NULL) < 0 ) {
      cerr << endl << "** ERROR **  : Invalid file descriptor or operation interrupted by a signal" << endl;
      exit(1);
     }
     if (FD_ISSET(fd[0], &read_set) ) {
        read(fd[0],&Info_Scambiate,sizeof(InfoScambiate));
	if (Info_Scambiate.FlowIdStop==*(unsigned int *)payload)
	  break;
	else write(fd[1],&Info_Scambiate,sizeof(InfoScambiate));
      }
    else {


        size_r = recv(new_sock, payload, 20, 0);
        gettimeofday(&RcvTime, NULL);
      	if (size_r < 20){
		    recv(new_sock, buffer, 20 - size_r, 0);
		    memcpy( payload, &buffer, sizeof(buffer) );
	    }
        size = *(int *)ptrSize;
        size_p = recv(new_sock, buffer, (size - 20), 0);
        if (size_p < (size - 20) )
         recv(new_sock,buffer, ((size - 20) - size_p), 0);

        if (size_r > 0) {
		//Logging informations using an array of structs as memory buffer
	  	if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
  			if (count<Dim) {
      				infos[count].FlowId=*(unsigned int *)payload;
      				infos[count].SeqNum=*(unsigned int *)ptrSeqNum;
		      		strcpy(infos[count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      				infos[count].src_port=ntohs(SrcAddress.sin_port);
      				strcpy(infos[count].dest_addr,inet_ntoa(DestHost.sin_addr));
      				infos[count].dest_port=ntohs(DestHost.sin_port);
      				ptime = (*(long int *)ptrTimeSec);
      				infos[count].TxTime1=ptime/3600;
      				infos[count].TxTime2=(ptime%3600)/60;
      				infos[count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
    				ptime = RcvTime.tv_sec % 86400L;
      				infos[count].RxTime1=ptime/3600;
      				infos[count].RxTime2=(ptime%3600)/60;
      				infos[count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      				infos[count].size=size_r;

				if (upProtocol=="Telnet")
        				infos[count].size=size%20;
				else
            			infos[count].size=size;
            			count++;
     			} //end count<Dim
     			if(count==Dim) {
          			if (!logout){
         				write(logfile, infos, Dim*sizeof(struct Info));
         				count=0;
          			}
          			else {
		           		sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
         	     			count=0;
     	  			}
			} //end count=Dim
  		} //end if logcheck ||

    	if (strcmp(NameMsr,"rttm")==0)
     	sendto(new_sock, payload, size, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
  	}//end size_r>0
     } //end else
  }// END While
  close(sock);
  buff=false;
  if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
     // Swap to file elements that may remain into the buffer
    while (count<Dim)
  	{
        	buff=true;
        	infos[count].size=0;
        	count++;
   	}
   if (buff=true)
     if (!logout)
    	write(logfile, infos, Dim*sizeof(struct Info));
     else {
	       sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
          }

  } //end if logcheck..
 cout<<"Finish on port :" <<ntohs(DestHost.sin_port)<< endl;
 free (infos);
}//END TCP Function






void PrintHelpAndExit(char *pname, char *DefaultProto) {
  cout << endl << " ITGRecv Usage:" << endl << endl;
  cout << " ./ITGRecv <ITGRecv options>" << endl << endl;
  cout << " ITGRecv options:" << endl << endl;
  cout << "  -m <msr_type>\t\ttype of meter.\n\t\t\tValues: owdm (one way delay meter)\n\t\t\t\trttm (round trip time meter)\n\t\t\t(Default: owdm)" << endl;
  cout << "  -P <priority>\t\t(Default: 0 ) NOTE: 0 < priority < 90" << endl;
  cout << "  -D <array_dimension>\tArray Dimension (Default: " << DimDefault <<")"<< endl;
  cout << "  -l <local_logfile>\tLocal log file name "<<"\n\t\t\t(Default: " << DefaultLogFile <<"; only for owdm)" << endl;
  cout << "  -L <Log_Address> <Log_port> <Protocol_type> \t Remote Log \n\t\t\t(Default: <" <<DefaultLogIP<<"> <"<<DefaultLogPort<<"> <"<<DefaultProtoTx_Log<<">"<< "\n\t\t\t" << endl;;
  cout << " For more information consult ""help"" file in the same directory"<<  endl;
  exit(1);
}

void ReportErrorAndExit(char *msg, char *pname) {
  cerr << endl << "** ERROR ** : " << msg << endl;
  cerr << "Type '" << pname << " -h'  for help" << endl << endl;
  exit(1);
}
