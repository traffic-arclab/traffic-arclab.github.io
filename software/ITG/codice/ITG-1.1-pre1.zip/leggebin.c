#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

struct Info {
		unsigned int FlowId;
		unsigned int SeqNum;
		char src_addr[15];
		unsigned int src_port;
		char dest_addr[15];
		unsigned int dest_port;
		long int TxTime1;
		long int TxTime2;
		double TxTime3;
		long int RxTime1;
		long int RxTime2;
		double RxTime3;
		int size;
		};
struct Info infos[1];

int main(int argc, char *argv[])
{
	int fd,check,i,j,hold;
	FILE *fp;
	if (argc<3) {
   printf("ERROR: few arguments\n");
   exit(1);
   }
  fd=open(argv[1],O_RDONLY);
	fp=fopen(argv[2],"w");
	i=1;
	while (1)
	//for(i=1;i<6;i++)
	{
		hold=read(fd, infos,sizeof(struct Info));
		if (hold==0)
		{
			close(fd);
			close(fp);
			exit(1);
		}
			j=0;
			if (infos[j].size!=0)
			{
				fprintf(fp,"Flow>%04u ",infos[j].FlowId);
        			fprintf(fp,"Seq>%7u ",infos[j].SeqNum);
        			fprintf(fp,"Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
        			fprintf(fp,"Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
        			fprintf(fp,"TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
        			fprintf(fp,"RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
        			fprintf(fp,"Size>%5u\n",infos[j].size);
			}
		i++;
	}
	close(fp);
	close(fd);
}
