#include "ITG.h"

struct Signaling {
        int bufferdimensione;
	int PortoLog;
	char protocol[30];
 } signal;

const char DefaultLogFile[]="/tmp/ITGLog.log";       // default log file name

void riceve_DIM(int &Dim,int &PortoLog,char protocolName[30])
{
       int signalsocket;
       struct sockaddr_in signalsock;
       				  //crea canale per fare signaling con il mittente!
	signalsock.sin_family = AF_INET;	             //setta signalsock
  	signalsock.sin_addr.s_addr = htonl(INADDR_ANY);
   	signalsock.sin_port = htons(DefaultLogPortSignaling);

	signalsocket = socket(PF_INET, SOCK_DGRAM, 0);
	if (signalsocket < 0){
      		printf("** ERROR **  Cannot create a socket on port %d\n");
		exit(1);
		}
						//lega socket al porto specificato prima
	if ( bind(signalsocket, (struct sockaddr *) &signalsock, sizeof(signalsock)) < 0 ) {
      		printf("** ERROR **  : Cannot bind a socket on port %d\n");
		exit(1);
		}

        //deve ricevere dal mittente la dimensione del log!

	recv(signalsocket, &signal, sizeof(signal),0);
	Dim=signal.bufferdimensione;  		    //setta la dimensione del log come indicato dal mittente
	PortoLog=signal.PortoLog;
	strcpy(protocolName,signal.protocol);
	printf("La dimensione del buffer di log è :%d:\n",Dim);
 	close(signalsocket);

}


void log_pkt_TCP(char LogFile[100],int PORTO,int Dim)
{
	int newsocklog;
	struct sockaddr_in SockAddress;
	struct sockaddr_in SrcAddress;
	int logsock,fd,hold;
        struct Info *infos=(struct Info*)malloc(Dim*sizeof(Info));
	
	char* help;
	fd_set read_set, active_set;
 	FD_ZERO(&active_set);
  	FD_SET(STDIN_FILENO, &active_set);   // add stdin to the set of monitored file descriptors

			    //open log file!
	if ((fd = open(LogFile,O_CREAT | O_TRUNC | O_WRONLY, 0666))== -1) {
    		printf("Cannot create logfile for writing\n");
    		exit(1);
  	}

						    //crea socket su cui riceve i dati dal mittente
	SockAddress.sin_family = AF_INET;	    //setta SockAddress
  	SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
   	SockAddress.sin_port = htons(PORTO);

	logsock = socket(PF_INET, SOCK_STREAM, 0);
	if (logsock < 0){
      		printf("** ERROR **  Cannot create a socket on port %d\n",PORTO);
		exit(1);
		}
			//lega socket al porto specificato prima
	if ( bind(logsock, (struct sockaddr *) &SockAddress, sizeof(SockAddress)) < 0 ){
      		printf("** ERROR **  : Cannot bind a socket on port %d\n",PORTO);
		exit(1);
		}
	if (listen(logsock,5)<0){
      		printf("** ERROR **  : into listen \n");
		exit(1);
		}
	socklen_t sin_len=sizeof(SrcAddress);

	newsocklog=accept(logsock,(struct sockaddr *) &SrcAddress, &sin_len);
        if  (newsocklog<0) {
      		printf("** ERROR **  : into accept \n");
		exit(1);
                }

 	printf("Receaving data on port: %d\n",PORTO);
        cout <<"Press Enter to stop " << endl;
        cout<<endl;
        bzero(infos,Dim*sizeof(struct Info));	        //azzera la struttura dati infos
	FD_SET(newsocklog, &active_set);
        while (1)
	{
          bzero(infos,Dim*sizeof(struct Info));
	  read_set = active_set;                              // since select puts in read_set only ready file descriptors
          if ( select(FD_SETSIZE, &read_set, NULL, NULL, 0) < 0 ) {
   		   printf("** ERROR **  : Invalid file descriptor or operation interrupted by a signal\n");
		   exit(1);
   	  }
        if (FD_ISSET(STDIN_FILENO, &read_set) ) {
         char key;
         read(STDIN_FILENO, &key, 1);
         if ( key == 10 )  break;       // Enter has been pressed, terminate
          }
	else if ( FD_ISSET(newsocklog, &read_set) ) {
	    hold=recv(newsocklog, infos, Dim*sizeof(struct Info),0);
            if (hold<0)				    //errore nella recv
		printf("** WARNING **  Data lost!\n");
 	    if (write(fd, infos, hold) < 0)	    //scrive i dati sul disco
           	printf("** WARNING **  Can't write data!\n");\
	   }
	}
	close(fd);			//close file descriptor e socket descriptor
	close(logsock);
	close(newsocklog);
}


void log_pkt_UDP(char LogFile[100],int PORTO,int Dim) {
        struct Signaling {
         int bufferdimensione;
        } signal;

	int newsocklog;
	int signalsocket;
	struct sockaddr_in SockAddress;

	int logsock,fd,hold;
        struct Info *infos=(struct Info*)malloc(Dim*sizeof(Info));


	fd_set read_set, active_set;
 	FD_ZERO(&active_set);
  	FD_SET(STDIN_FILENO, &active_set);   					    //open log file!
	if ((fd = open(LogFile,O_CREAT | O_TRUNC | O_WRONLY, 0666))== -1) {
    		printf("Cannot create logfile for writing\n");
    		exit(1);
  	}
                     		       //crea canale per signaling con il mittente!
					    //crea socket su cui riceve i dati dal mittente
	SockAddress.sin_family = AF_INET;	    //setta SockAddress
  	SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
   	SockAddress.sin_port = htons(PORTO);
   	logsock = socket(PF_INET, SOCK_DGRAM, 0);
	if (logsock < 0){
      		printf("** ERROR **  Cannot create a socket on port %d\n",PORTO);
		exit(1);
		}
						//lega socket al porto specificato prima
	if ( bind(logsock, (struct sockaddr *) &SockAddress, sizeof(SockAddress)) < 0 ){
      		printf("** ERROR **  : Cannot bind a socket on port %d\n",PORTO);
		exit(1);
		}


	printf("Receaving data on port: %d\n",PORTO);
        cout <<"Press Enter to stop" << endl;
        cout<<endl;
        bzero(infos,Dim*sizeof(struct Info));	        //azzera la struttura dati infos
	FD_SET(logsock, &active_set);
        while (1)
	{
          bzero(infos,Dim*sizeof(struct Info));
	  read_set = active_set;                              // since select puts in read_set only ready file descriptors
          if ( select(FD_SETSIZE, &read_set, NULL, NULL, 0) < 0 ) {
   		   printf("** ERROR **  : Invalid file descriptor or operation interrupted by a signal\n");
		   exit(1);
   	  }
        if (FD_ISSET(STDIN_FILENO, &read_set) ) {
         char key;
         read(STDIN_FILENO, &key, 1);
         if ( key == 10 )  break;       // Enter has been pressed, terminate
          }
	else if ( FD_ISSET(logsock, &read_set) ) {
	    hold=recv(logsock, infos, Dim*sizeof(struct Info),0);
            if (hold<0)				    //errore nella recv
		printf("** WARNING **  Data lost!\n");
 	    if (write(fd, infos, hold) < 0)	    //scrive i dati sul disco
           	printf("** WARNING **  Can't write data!\n");
	   }
	}
	close(fd);			//close file descriptor e socket descriptor
	close(logsock);

}



int main(int argc,char *argv[])
{
	int Dim;
	char LogFile[100];   		// dimensione max log file
  	int PORTO = DefaultLogPort;
        char protocolName[30];

	if (argc<2){
		printf("\nYou must specify an option\n\n");
		printf("Type: ./ITGLog -h for help\n\n");
		exit(1);
		}
	argv++;
	argc--;
	while (argc>0) {
    		if (argv[0][0] == '-') {
      			switch (argv[0][1]) {
             		   case 'l':
          			if ((argc < 2) || (argv[1][0] == '-')) //default name for log file
				{
            			 strcpy(LogFile,DefaultLogFile);
            		         argc-=1;
            			 argv+=1;
            			}
          			else
				{
				 strcpy(LogFile, argv[1]);
 				 argc-=2;
            			 argv+=2;
				}
         		        break;
     		   case 'h':				//help
          			{
				 printf(" ITGLog Usage:\n\n");
  				 printf("  -l <logfile>\t\tLog file name (Default: %s)\n",DefaultLogFile);
				 printf("  -h\t\t\tPrint help\n\n");
                  		 printf( " For more information consult ""help"" file in the same directory\n\n");;

				 exit(1);
				}
          		   	break;
        	   	   default:
				cout<<"default\n";
			 	printf("Unknown option\n");
				exit(1);
				break;
			}
    		} else {
 			printf("What is: %s ?\n",argv[0]);
			printf("Type: ./ITGLog -h for help\n");
			exit(1);
		        }
    	}
   riceve_DIM(Dim,PORTO,protocolName);
   if (strcmp(protocolName,"TCP")==0) log_pkt_TCP(LogFile,PORTO,Dim);
        else log_pkt_UDP(LogFile,PORTO,Dim);
}
