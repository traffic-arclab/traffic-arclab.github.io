 //ITGRecv.cpp 
 /***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *
 *                                                                         *
 ***************************************************************************/

#include "ITG.h"

#ifdef WIN32
 const char DefaultLogFile[]="ITGRecv.log";
 static LARGE_INTEGER freq;
 #include <signal.h>
 #include <math.h> //funzione ceil
#endif

#ifdef LINUX_OS
 #include <sys/uio.h>
// #include <netinet/ip_icmp.h>
 #include <netinet/ip.h>
 #include <netinet/udp.h>
 #include <wait.h>
 #include <pthread.h>
 const char DefaultLogFile[]="/tmp/ITGRecv.log";
#endif



// Constant definitions
char DefaultProtoTx_Log[]="UDP";		 //default proto TX-Log remoto
const int DimLogFileChr=100;
const int DimDefault=10;
const int MaxNumThread=200;
char DefaultProto[]="UDP";



// struct per realizzare il protocollo di signaling con il ricevitore
struct InfoScambiate{
    unsigned int daddr;
    unsigned short dport;
    char protocol[30];
    char AppProtocolName[30];
    bool ClosedCanal;
    int FlowId;
    int FlowIdStop;
};

// struct per il passaggio dei parametri al thread-iesimo
struct parametriThread {
   	char upProtocol[30];
	struct sockaddr_in DestHost;
	int FlowId;
	Info *indirizzoinfos;
	int count;
	int socket;
};


// struct per gestione canale di signaling con il log-remoto
struct Signaling {
    int Dim;
    int LogPort;
    char protocolName[30];
    bool stop;
};


//variabili globali, condivise tra i thread
  int logsock;
  int logcheck=0;
  int logout=0;
  int Dim=DimDefault;			 // dimensione standard dell'array
  char *NameMsr;			     // tipo di misura : owdm o rttm
  struct sockaddr_in LogHost;	 // Log remoto
  char *Prototx_Log;			 // protocollo di livello trasporto tra Receiver e Log
  ofstream out;				     // Logfile locale
  int logfile;
  int sock_signaling;
  int logsocksignaling;
  int numpacchettiricevuti=0;
    
// Prototypes
#ifdef WIN32
 DWORD WINAPI udp_sock(parametriThread* para);
 DWORD WINAPI tcp_sock(parametriThread* para);
 DWORD WINAPI acceptConnection(parametriThread* para);
 DWORD WINAPI icmp_sock(parametriThread* para);

#endif

#ifdef LINUX_OS
 void *acceptConnection(void* param);
 void *udp_sock(void* param);
 void *icmp_sock(void* param);
 void *tcp_sock(void* param);
#endif

void PrintHelpAndExit(char *pname, char *DefaultProto);
void ReportErrorAndExit(char *msg, char *pname);
void createRemotLogFile(struct sockaddr_in LogHost,char *Prototx_Log,int Dim);	  
void Terminate(int sig);


//////////////////////////////////////// Start Main ///////////////////////////////////////////
int main(int argc, char *argv[]) {

  signal(SIGINT,Terminate);
  cout<<"Press Ctrl-C to terminate"<<endl;
  parametriThread para[MaxNumThread]; 	  //parametri da passare al thread i_esimo
  #ifdef WIN32
  HANDLE hThr[MaxNumThread];		  //handle associato al thread i_esimo
  //SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS) ;
  #endif
  #ifdef LINUX_OS
  pthread_t hThr[MaxNumThread];	  //handle associato al thread i_esimo
  #endif

  char *protocolName;	    	      //setta il protocollo di livello trasporto di default
  protocolName=DefaultProto;

  char LogFile[DimLogFileChr];		  //setta il log file di default
  strcpy(LogFile,DefaultLogFile);


  NameMsr=DefaultMsr;    			  //setta per default il tipo di misura
  Prototx_Log=DefaultProtoTx_Log;	  // protocollo di trasporto di default per il log remoto

  int size;
  pid_t pid;


  // variabili per la gestione canale di signaling con il mittente

  int new_sock_signaling;
  struct sockaddr_in SockAddress;
  struct sockaddr_in SrcAddress;
  socklen_t sin_len=sizeof(SockAddress);

  // Set the default IP log addr
  struct hostent *host;
  LogHost.sin_family=AF_INET;
  LogHost.sin_port=htons(DefaultLogPort);

  #ifdef LINUX_OS
  inet_aton(DefaultLogIP, &LogHost.sin_addr);
  uid_t user_id=getuid();		// var user_id is the id of the user who calls the process
  #endif

  #ifdef WIN32
  LogHost.sin_addr.S_un.S_addr=inet_addr(DefaultLogIP);
  int user_id=1;
  #endif

  // parser
  strcpy(programName, argv[0]);
  argv++;
  argc--;
  while (argc>0) {
    if (argv[0][0] == '-') {
      char *tail;

      switch (argv[0][1]) {
       case 'm':
    	 if ((strcasecmp(argv[1],"rttm")) && strcasecmp(argv[1],"owdm"))
	          ReportErrorAndExit("General parser",programName);
          strcpy(NameMsr,argv[1]);
          argv+=2;
      	  argc-=2;
	     break;
         case 'l':
          logcheck = 1;
          if ((argc < 2) || (argv[1][0] == '-')) {
            strcpy(LogFile,DefaultLogFile);
            argc-=1;
            argv+=1;
            }
          else {
            strcpy(LogFile, argv[1]);
            argc-=2;
            argv+=2;
          }
          break;
		case 'L':
          logout = 1;
          logcheck = 1;
		  LogHost.sin_family=AF_INET;
		  #ifdef LINUX_OS
		  if ((argc < 3) || !(host=gethostbyname(argv[1])) )
		    ReportErrorAndExit("General parser Invalid log-server address or port", programName);
	         memcpy((char *)&LogHost.sin_addr, host->h_addr, host->h_length);
		  #endif
		  LogHost.sin_port=htons(atoi(argv[2]));
		  if ((strcasecmp(argv[3],"TCP")) && strcasecmp(argv[3],"UDP"))
	          ReportErrorAndExit("General parser",programName);
		  strcpy(Prototx_Log,argv[3]);
          #ifdef WIN32
		  LogHost.sin_addr.S_un.S_addr=inet_addr(argv[1]);
		  #endif

		  argv+=4;
          argc-=4;
          break;
        case 'D':
          if ( (argc < 2) || ((Dim = atoi(argv[1])) < 1.0))
            ReportErrorAndExit("Invalid array dimension", programName);
          argv+=2;
          argc-=2;
          break;
    	case 'h':
          PrintHelpAndExit(programName,DefaultProto);
          break;
        default:
          tail = (char *)malloc(sizeof("Unknown option ")+sizeof(argv[0]));
          ReportErrorAndExit(strcat(strcpy(tail, "Unknown option "), argv[0]), programName);
          break;
      }
    }

  else {
          char temp[sizeof("What is  ?")+sizeof(argv[0])];
          ReportErrorAndExit(strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"), programName);
       }
  } // End of While


  // controlla se il log � locale o remoto
  if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
	if (!logout){
        //	logfile=open(LogFile,O_CREAT | O_TRUNC | O_WRONLY,0666);
			out.open(LogFile,ios::out | ios::binary | ios::trunc);
			if (!out)
			{
				cerr<< "** WARNING **  Error into open this file: "<<LogFile<< endl;
				exit(1);
			}
   		}
      	else createRemotLogFile(LogHost,Prototx_Log,Dim);
  } //end if


 // server concorrente
 #ifdef WIN32
 WSADATA wsaData;
 if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
	{
	 cerr<<"** ERROR ** WSAStartup() failed "<<endl;
	 exit(1);
	}
 #endif

 SockAddress.sin_family=AF_INET;
		//porto di default su cui mi ascolto il signaling!
 SockAddress.sin_port = htons(DefaultPortSignaling);
 sock_signaling = socket(PF_INET, SOCK_STREAM, 0);
  if (sock_signaling < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }
  

 #ifdef LINUX_OS
 SockAddress.sin_addr.s_addr=htonl(INADDR_ANY);
 #endif
 #ifdef WIN32
 SockAddress.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
 #endif

 if (bind(sock_signaling, (struct sockaddr *) &SockAddress, sizeof(SockAddress))) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port - for signaling" << endl;
      exit(1);
  }

 if (listen(sock_signaling,5) < 0) {
       cerr << endl << "** ERROR **  : Cannot listen to a socket on port "  << endl;
       exit(1);
  }
 int i=0;
 while (1){
  	if( (new_sock_signaling = accept(sock_signaling,(struct sockaddr *) &SrcAddress, &sin_len)) < 0 ) {
       	cerr << endl << "** ERROR **  : Connection fault on port " << endl;
       	exit(1);
   	}
 	para[i].socket=new_sock_signaling;
	#ifdef LINUX_OS
	pthread_create(&hThr[i],NULL,acceptConnection,&para[i]);
	#endif
	#ifdef WIN32
    hThr[i]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) acceptConnection, &para[i], (DWORD)NULL,(unsigned long*)&pid);
	#endif
	i++;
  }
} //end main


// gestione dell'interruzione legata alla pressione dei tasti CNTRL+C
void Terminate(int sig) {
  if (!logout)
	out.close();
  else {
	  Signaling signaling_log;		 //per la gestione del canale di signaling con il log remoto
      signaling_log.stop=true;
	  sendto(logsocksignaling, (char*)&signaling_log, sizeof(signaling_log),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
		
  }
  #ifdef WIN32
  closesocket(logsock);
  closesocket(sock_signaling);
  closesocket(logsocksignaling);
  #endif

  #ifdef LINUX_OS
  close(logsock);
  close(sock_signaling);
  close(logsocksignaling);
  #endif
  exit(1);
}


//Crea il canale di signaling con il log remoto
void createRemotLogFile(struct sockaddr_in LogHost,char *Prototx_Log,int Dim){	  // protocollo di trasporto di default per il log remoto
    Signaling signal;			  //per la gestione del canale di signaling con il log remoto
    char buffer[4];
    int help;
    int logsocksignaling;
    #ifdef WIN32
 	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0){
	    	cerr<<"** ERROR ** WSAStartup() failed "<<endl;
		exit(1);
	}
    #endif
    logsocksignaling = socket(PF_INET, SOCK_STREAM , 0); // ..canale per fare signaling!
    help=LogHost.sin_port;
    LogHost.sin_port=htons(DefaultLogPortSignaling);
    signal.LogPort=ntohs(help);
    strcpy(signal.protocolName,Prototx_Log);
    signal.Dim=Dim;
    connect(logsocksignaling, (struct sockaddr *)&LogHost, sizeof(LogHost));
    recv(logsocksignaling,buffer,sizeof(buffer),0);

    #ifdef WIN32
	if (sendto(logsocksignaling, (char*)&signal, sizeof(signal),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
    		cerr << "** WARNING **  Error into sendto "<< endl;
	#endif
    #ifdef LINUX_OS
	if (sendto(logsocksignaling, &signal, sizeof(signal),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
                cerr << "** WARNING **  Error into sendto "<< endl;
	#endif
    LogHost.sin_port=help;
                                            //canela TX - LOG Remoto
    if (strcmp(Prototx_Log,"UDP")==0) {
	logsock = socket(PF_INET, SOCK_DGRAM , 0);    // canale UDP TX - Log
   }
   else {
        logsock=socket(AF_INET,SOCK_STREAM,0);      // canale TCP TX - Log..
   }

   //se deve fare il log remoto allora fa una connect!
   recv(logsocksignaling,buffer,sizeof(buffer),0);
   connect(logsock,(struct sockaddr *)&LogHost, sizeof(LogHost));
}


// Questa routine gestisce il canale di signaling con il sender
#ifdef WIN32
	DWORD WINAPI acceptConnection(parametriThread* para) {
    HANDLE hThr[MaxNumThread];		  	//handle associato al thread i_esimo
#endif
#ifdef LINUX_OS
void* acceptConnection(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
	pthread_t hThr[MaxNumThread];		//handle associato al thread i_esimo
#endif

 struct mem{                  //struttura dati con cui il gestore del canale di
			int FlowId;       //signaling realizza l'associazione tra il numero del flusso
   		    char protocol[30];//e l'identificativo del flusso stesso
 };
 mem FlowIdNumFlusso[MaxNumThread];

 struct sockaddr_in SrcHost;
 socklen_t sizeAddr=sizeof(SrcHost);
 InfoScambiate Info_Scambiate;
 int size;
 int pid;


  //massima priorit� per il thread i_esimo
  #ifdef LINUX_OS
  struct sched_param parametriT;
  pthread_attr_t attrib;
  pthread_attr_init(&attrib);
  pthread_attr_setinheritsched(&attrib, PTHREAD_EXPLICIT_SCHED);
  pthread_attr_setschedpolicy(&attrib,SCHED_RR);
  parametriT.sched_priority=99;
  pthread_attr_setschedparam(&attrib,&parametriT);
  #endif

  int numflusso=0;
  int new_sock_signaling=para->socket;
  // il ricevitore si mette in ascolto sul porto di default e per ogni "registrazione" ..
  // attiva un thread
  Info_Scambiate.FlowIdStop=0;
  Info_Scambiate.ClosedCanal=false;
  // comunica al sender che il canale di signaling � stato creato
  send(new_sock_signaling,"Sinc",4,0);
  while (Info_Scambiate.ClosedCanal==false) {
	 #ifdef WIN32
  	 size=recv(new_sock_signaling,(char*)&Info_Scambiate,sizeof(Info_Scambiate),0);
  	 #endif

	 #ifdef LINUX_OS
	 size=recv(new_sock_signaling,&Info_Scambiate,sizeof(Info_Scambiate),0);
 	 #endif

	 if (size<0) { 
			cerr<<"*** ERROR into recv() "<<endl;
	 }
     else if ((Info_Scambiate.ClosedCanal==false) && (size>0))
			if (Info_Scambiate.FlowIdStop==0)
			{
				#ifdef WIN32
				para[numflusso].DestHost.sin_addr.S_un.S_addr=Info_Scambiate.daddr;
				#endif
				#ifdef LINUX_OS
				para[numflusso].DestHost.sin_addr.s_addr=Info_Scambiate.daddr;
				#endif
                //realizza la corrispondenza identificativo-numero del flusso
				FlowIdNumFlusso[numflusso].FlowId=Info_Scambiate.FlowId;
				strcpy(FlowIdNumFlusso[numflusso].protocol,Info_Scambiate.protocol);
                //parametri da passare al thread che gestir� il flusso i-esimo
				para[numflusso].DestHost.sin_family;
				para[numflusso].DestHost.sin_family=AF_INET;
				para[numflusso].DestHost.sin_port=Info_Scambiate.dport;
				strcpy(para[numflusso].upProtocol,Info_Scambiate.AppProtocolName);
				para[numflusso].socket=new_sock_signaling;
				para[numflusso].FlowId=Info_Scambiate.FlowId;
				if (strcmp(Info_Scambiate.protocol,DefaultProto)==0) 	// Call UDP
					{
					#ifdef WIN32
					hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) udp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
					SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);     
					#endif
					#ifdef LINUX_OS
					pthread_create(&hThr[numflusso],&attrib,udp_sock,&para[numflusso]);
					#endif
  					}
				else if (strcmp(Info_Scambiate.protocol,"TCP")==0) 	// Call TCP
             		{
					#ifdef WIN32
        			hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) tcp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
					SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);     
					#endif
					#ifdef LINUX_OS
					pthread_create(&hThr[numflusso],NULL,tcp_sock,&para[numflusso]);
					#endif
           			}
				else if (strcmp(Info_Scambiate.protocol,"ICMP")==0) 	// Call ICMP
					{
					#ifdef WIN32
             		hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) icmp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
					SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);     
					#endif
					#ifdef LINUX_OS
					pthread_create(&hThr[numflusso],NULL,icmp_sock,&para[numflusso]);
					#endif
           			}
					numflusso++;
		 } //end if Info_Scambiate.FlowIdstop==0
		else 
		{   //  il flusso di Id FlowIdStop � terminato...
			int k=0;
			while (Info_Scambiate.FlowIdStop!=FlowIdNumFlusso[k].FlowId){
				k++;
			}
			
			if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
			// Swap to file elements that may remain into the buffer
			if (!logout)
				out.write((const char*)para[k].indirizzoinfos, para[k].count*sizeof(struct Info));
			else  size= sendto(logsock,(char *) para[k].indirizzoinfos, para[k].count*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
			} //end if logcheck..
			if (strcmp(FlowIdNumFlusso[k].protocol,"ICMP")==0) 
				cout<<"Finish ICMP packets"<<endl;
			else cout<<"Finish on port :" <<htons(para[k].DestHost.sin_port)<< endl;
			#ifdef WIN32
			free(para[k].indirizzoinfos);  //libera la memoria dinamica associata al thread
			TerminateThread(hThr[k],0);    //uccide il thread con handle hThr[k]
			#endif
			#ifdef LINUX_OS
			pthread_cancel(hThr[k]);
			#endif
			Info_Scambiate.FlowIdStop=0;
		}
	 } //end while
  sleep(1);          //	�utile nel caso di rttm
  #ifdef WIN32
  if (closesocket(new_sock_signaling)<0) cout<<" ** Error into close() "<<endl;
  WSACleanup();
  #endif

  #ifdef LINUX_OS
  if (close(new_sock_signaling)<0) cout<<" ** Error into close() "<<endl;
  #endif

  #ifdef WIN32
  ExitThread(0);
  return 0;
  #endif
  #ifdef LINUX_OS
  pthread_exit(0);
 #endif

}
// END MAIN





char *getip (u_long in)
{
 struct in_addr s;
 s.s_addr=in;
 return inet_ntoa(s);
}


#ifdef WIN32
void tstart(LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi,int &first){
    SYSTEMTIME lpSystemTime;
	if (first) {
		QueryPerformanceFrequency(&freq);
		first=0;
	}
	QueryPerformanceCounter(&_tstart);
	GetSystemTime(&lpSystemTime);
	secondi=lpSystemTime.wHour*3600+lpSystemTime.wMinute*60+lpSystemTime.wSecond;
	microsecondi=lpSystemTime.wMilliseconds;
}

void gettimeofday(struct timeval* thisTime,LARGE_INTEGER &_tend,LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi){
   double secondieusecond;
   long micro;
   QueryPerformanceCounter(&_tend);
   secondieusecond=((((double)_tend.QuadPart-(double)_tstart.QuadPart))/(double)freq.QuadPart);
   thisTime->tv_sec=((unsigned long)secondieusecond)+secondi;
   micro=ceil(((secondieusecond-(unsigned long)secondieusecond)*1e6)/1000);
   if ((thisTime->tv_usec=(micro+microsecondi))>=1e3) {
		thisTime->tv_sec++;
		thisTime->tv_usec=((double)(thisTime->tv_usec*1e-3)-1)*1e3;
   }
   thisTime->tv_usec=thisTime->tv_usec*1e3;
} 
#endif


void PrintHelpAndExit(char *pname, char *DefaultProto) {
  cout << endl << " ITGRecv Usage:" << endl << endl;
  cout << " ./ITGRecv <ITGRecv options>" << endl << endl;
  cout << " ITGRecv options:" << endl << endl;
  cout << "  -m <msr_type>\t\ttype of meter.\n\t\t\tValues: owdm (one way delay meter)\n\t\t\t\trttm (round trip time meter)\n\t\t\t(Default: owdm)" << endl;
  cout << "  -D <array_dimension>\tArray Dimension (Default: " << DimDefault <<")"<< endl;
  cout << "  -l <local_logfile>\tLocal log file name "<<"\n\t\t\t(Default: " << DefaultLogFile <<"; only for owdm)" << endl;
  cout << "  -L <Log_Address> <Log_port> <Protocol_type> \t Remote Log \n\t\t\t(Default: <" <<DefaultLogIP<<"> <"<<DefaultLogPort<<"> <"<<DefaultProtoTx_Log<<">"<< "\n\t\t\t" << endl;;
  cout << " For more information consult ""help"" file in the same directory"<<  endl;
  getchar();
  exit(1);
}

void ReportErrorAndExit(char *msg, char *pname) {
  cerr << endl << "** ERROR ** : " << msg << endl;
  cerr << "Type '" << pname << " -h'  for help" << endl << endl;
  exit(1);
}



// ICMP Function
#ifdef WIN32
	DWORD WINAPI icmp_sock(parametriThread* para) {
#endif
#ifdef LINUX_OS
void* icmp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif
  para->count=0;
  int first=1;
  int sock;
  unsigned char buffer[MaxPayloadSize+28];
  unsigned char payload[MaxPayloadSize];

  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  struct sockaddr_in SrcAddress;
  size_t sizeAddr = sizeof(SrcAddress);
  socklen_t sin_len=sizeof(SrcAddress);
  size_t sizeAddrD= sizeof(SockAddress);


  int size_r,size;
  long int ptime;
  struct timeval RcvTime;
  int opt=1;
  #ifdef WIN32
   LARGE_INTEGER _tstart,_tend;
   unsigned long secondi=0,microsecondi=0;
  #endif


  int dimheader=sizeof(icmp)+sizeof(iphdr);
  char *ptrSeqNum = (char*)payload + sizeof(unsigned int);
  char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  char *ptrSize=ptrTimeUsec+sizeof(int);

  //salva l'indirizzo della struttura dove memorizza i dati
  para->indirizzoinfos=infos;

 #ifdef LINUX_OS
   if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
    cout<<"Memory lock failed"<<endl;
  #endif

 #ifdef WIN32
 WSADATA wsaData;
 if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
 {
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
  }
 #endif


  sock=socket(AF_INET,SOCK_RAW,IPPROTO_ICMP);     //apre una socket Raw
  if (socket < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }

  #ifdef WIN32
  SockAddress.sin_family=AF_INET;
  SockAddress.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
  if (bind(sock, (struct sockaddr *) &SockAddress, sizeof(SockAddress)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for dp connect " << endl;
      exit(1);
  }
  #endif 
  	
  cout <<"Listening ICMP traffic" << endl;

  InfoScambiate Info_Scambiate;
  Info_Scambiate.FlowId=para->FlowId;
  send(para->socket,(char*)&Info_Scambiate,sizeof(Info_Scambiate),0);

  para->socket=sock;

  #ifdef WIN32
  tstart(_tstart,secondi,microsecondi,first);
  #endif

  while (1) {
  #ifdef LINUX_OS
    size_r=recvfrom(sock,buffer,MaxPayloadSize+dimheader,0,(struct sockaddr *) &SrcAddress, &sin_len);
  #endif
  #ifdef WIN32
    size_r=recvfrom(sock,(char*)buffer,MaxPayloadSize+dimheader,0,(struct sockaddr *) &SrcAddress, &sin_len);
  #endif
	char *ptr=(char*)buffer;
    ptr=ptr+32;
    size_r=size_r-32;
    memcpy(&payload,ptr,size_r);
  if (size_r > 0)  {
		#ifdef LINUX_OS
        	gettimeofday(&RcvTime, NULL);
		#endif
		#ifdef WIN32
     		gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);
		#endif
		//Logging informations using an array of structs as memory buffer
	  	if (logcheck){
				infos[para->count].FlowId=*(unsigned int *)payload;
      			infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
		      	strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      			infos[para->count].src_port=0;
      			strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
      			infos[para->count].dest_port=0;
      			ptime = (*(long int *)ptrTimeSec);
      			infos[para->count].TxTime1=ptime/3600;
      			infos[para->count].TxTime2=(ptime%3600)/60;
      			infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
				#ifdef LINUX_OS
				ptime = RcvTime.tv_sec%86400L;
				#endif
				#ifdef WIN32
				ptime = RcvTime.tv_sec;
				#endif
      			infos[para->count].RxTime1=ptime/3600;
      			infos[para->count].RxTime2=(ptime%3600)/60;
      			infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      			infos[para->count].size=size_r;
				numpacchettiricevuti++;
				/*int j=para->count;
				printf("%d\n",infos[j].FlowId);
				printf("%d\n",infos[j].SeqNum);
				printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
				printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
				printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
				printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
				printf("Size>%5u\n",infos[j].size);
				printf("ICMP\n");*/
				para->count++;
  				if(para->count==Dim) {
          				if (!logout)
							out.write((const char*)infos, Dim*sizeof(struct Info));
	      				else
		        	   	 sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
     	  				para->count=0;
				} //end if count==Dim
	  		} //end check for log file
  		} //end if size_r>0
   }  // END While
}//END ICMP Function




// UDP Function
#ifdef WIN32
	DWORD WINAPI udp_sock(parametriThread* para) {
#endif
#ifdef LINUX_OS
void* udp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif
  para->count=0;
  int first=1;
  int sock;
  unsigned char payload[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  SockAddress.sin_family = AF_INET;
  SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  struct sockaddr_in SrcAddress;
  size_t sizeAddr = sizeof(SrcAddress);
  size_t sizeAddrD= sizeof(SockAddress);

  int size_r;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  unsigned char *ptrSize = ptrTimeUsec + sizeof(int);
  long int ptime;
  struct timeval RcvTime;
  int opt=1;
  #ifdef WIN32
   LARGE_INTEGER _tstart,_tend;
   unsigned long secondi=0,microsecondi=0;
  #endif
  
  #ifdef LINUX_OS
   if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
    cout<<"Memory lock failed"<<endl;
  #endif

  socklen_t sin_len=sizeof(SrcAddress);

  //salva l'indirizzo della struttura dove memorizza i dati
  para->indirizzoinfos=infos;


 #ifdef WIN32
 WSADATA wsaData;
 if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
 {
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
  }
 #endif

  para->DestHost.sin_family=AF_INET;
  sock = socket(PF_INET, SOCK_DGRAM, 0);
  if (socket < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }

  if (bind(sock, (struct sockaddr *) &para->DestHost, sizeof(para->DestHost)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for udp connect " << endl;
      exit(1);
  }
  cout <<"Listening on port :" <<ntohs(para->DestHost.sin_port)<< endl;

  InfoScambiate Info_Scambiate;
  Info_Scambiate.FlowId=para->FlowId;
  send(para->socket,(char*)&Info_Scambiate,sizeof(Info_Scambiate),0);
 // cout<<"ho inviato ok per il flusso"<<Info_Scambiate.FlowId<<endl;
  
  para->socket=sock;
  //cout<<"socket su cui sono in ascolto!"<<para->socket;

  #ifdef WIN32
  tstart(_tstart,secondi,microsecondi,first);
  #endif
  while (1) {

	#ifdef LINUX_OS
    size_r = recvfrom (sock, payload, MaxPayloadSize,0,(struct sockaddr *) &SrcAddress, &sin_len);
 	#endif

	#ifdef WIN32
    size_r = recvfrom (sock, (char*)payload, MaxPayloadSize,0,(struct sockaddr *) &SrcAddress, &sin_len);
    #endif

	if (size_r > 0)  {

		#ifdef LINUX_OS
     	gettimeofday(&RcvTime, NULL);
		#endif

		#ifdef WIN32
  		gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);
		#endif
		//Logging informations using an array of structs as memory buffer
	  	if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
  				infos[para->count].FlowId=*(unsigned int *)payload;
      			infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
				strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      			infos[para->count].src_port=ntohs(SrcAddress.sin_port);
      			strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
		  		infos[para->count].dest_port=ntohs(para->DestHost.sin_port);
	      		ptime = (*(long int *)ptrTimeSec);
      			infos[para->count].TxTime1=ptime/3600;
      			infos[para->count].TxTime2=(ptime%3600)/60;
      			infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
				#ifdef LINUX_OS
				ptime = RcvTime.tv_sec%86400L;
				#endif
				#ifdef WIN32
				ptime = RcvTime.tv_sec;
				#endif
      			infos[para->count].RxTime1=ptime/3600;
      			infos[para->count].RxTime2=(ptime%3600)/60;
      			infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      			infos[para->count].size=size_r;
				//	numpacchettiricevuti++;
		/*			int j=para->count;
           			printf("%d\n",infos[j].FlowId);
					printf("%d\n",infos[j].SeqNum);
					printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
					printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
					printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
					printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
					printf("Size>%5u\n",infos[j].size);
					printf("UDP\n");
	*/			para->count++;
     			if(para->count==Dim) {
          			if (!logout)
					out.write((const char*)infos, Dim*sizeof(struct Info));
	      			else
		           	 sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
     	  			para->count=0;

			} //end if count==Dim
  		} //end check for log file
  	    if (strcmp(NameMsr,"rttm")==0)
				#ifdef LINUX_OS
     	        sendto(sock, payload, size_r, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
				#endif

				#ifdef WIN32
     	        sendto(sock,(char*)payload, size_r, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
				#endif
	} //end if size_r>0
   }  // END While
}//END UDP Function



// TCP Function
#ifdef WIN32
	DWORD WINAPI tcp_sock(parametriThread* para) {
#endif
#ifdef LINUX_OS
void* tcp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif

  para->count=0;
  int first=1;
  int sock;
  unsigned char buffer[MaxPayloadSize];
  unsigned char payload[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  SockAddress.sin_family = AF_INET;
  SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  struct sockaddr_in SrcAddress;
  size_t sizeAddr = sizeof(SrcAddress);
  size_t sizeAddrD= sizeof(SockAddress);
  int new_sock;
  int size, size_p, size_r;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  unsigned char *ptrSize = ptrTimeUsec + sizeof(int);
  long int ptime;
  struct timeval RcvTime;
  #ifdef WIN32
  LARGE_INTEGER _tstart,_tend;
  unsigned long secondi=0,microsecondi=0;
  #endif

  #ifdef LINUX_OS
  if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
  cout<<"Memory lock failed"<<endl;
  #endif

  //salva l'indirizzo della struttura dove memorizza i dati
  para->indirizzoinfos=infos;

  #ifdef WIN32
  WSADATA wsaData;
  if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
  {
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
  }
  #endif

  sock = socket(PF_INET, SOCK_STREAM, 0);
  if (sock < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);

  }
  para->DestHost.sin_family=AF_INET;

  if (bind(sock, (struct sockaddr *) &para->DestHost, sizeof(para->DestHost)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for Tcp connect" << endl;
      exit(1);
  }

  if (listen(sock,5) < 0) {
       cerr << endl << "** ERROR **  : Cannot listen to a socket on port "  << endl;
       exit(1);
  }
  else cout << "Listening on port :" <<ntohs(para->DestHost.sin_port)<< endl;
  socklen_t sin_len=sizeof(para->DestHost);

  
  InfoScambiate Info_Scambiate;
  Info_Scambiate.FlowId=para->FlowId;
  send(para->socket,(char*)&Info_Scambiate,sizeof(Info_Scambiate),0);
 // cout<<"ho inviato ok per il flusso"<<Info_Scambiate.FlowId<<endl;
    
  if( (new_sock = accept(sock,(struct sockaddr *) &SrcAddress, &sin_len)) < 0 ) {
       cerr << endl << "** ERROR **  : Connection fault on port " << endl;
       exit(1);
  }
 #ifdef WIN32
 closesocket(sock);
 tstart(_tstart,secondi,microsecondi,first);
 #endif
 #ifdef LINUX_OS
 close(sock);
 #endif
 para->socket=new_sock;
  while (1) {
	    #ifdef LINUX_OS
        size_r = recv(new_sock, payload, 20, 0);
       	gettimeofday(&RcvTime, NULL);
      	if (size_r < 20){
		    recv(new_sock, buffer, 20 - size_r, 0);
		    memcpy( payload, &buffer, sizeof(buffer) );
	    }
        size = *(int *)ptrSize;
        size_p = recv(new_sock, buffer, (size - 20), 0);
        if (size_p < (size - 20) )
         recv(new_sock,buffer, ((size - 20) - size_p), 0);
		#endif

		#ifdef WIN32
        size_r = recv(new_sock,(char*) payload, 20, 0);
	    gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);

      	if (size_r < 20){
		    recv(new_sock, (char*)buffer, 20 - size_r, 0);
		    memcpy( payload, &buffer, sizeof(buffer) );
	    }
        size = *(int *)ptrSize;
        size_p = recv(new_sock, (char*)buffer, (size - 20), 0);
        if (size_p < (size - 20) )
         recv(new_sock,(char*)buffer, ((size - 20) - size_p), 0);
		#endif

        if (size_r > 0) {
		//Logging informations using an array of structs as memory buffer
	  	if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
  				infos[para->count].FlowId=*(unsigned int *)payload;
      				infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
		      		strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      				infos[para->count].src_port=ntohs(SrcAddress.sin_port);
      				strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
      				infos[para->count].dest_port=ntohs(para->DestHost.sin_port);
      				ptime = (*(long int *)ptrTimeSec);
      				infos[para->count].TxTime1=ptime/3600;
      				infos[para->count].TxTime2=(ptime%3600)/60;
      				infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
					#ifdef LINUX_OS
					ptime = RcvTime.tv_sec%86400L;
					#endif
					#ifdef WIN32
					ptime = RcvTime.tv_sec;
					#endif
      				infos[para->count].RxTime1=ptime/3600;
      				infos[para->count].RxTime2=(ptime%3600)/60;
      				infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      				infos[para->count].size=size_r;
					if (para->upProtocol=="Telnet")
        				infos[para->count].size=size%20;
					else
            			infos[para->count].size=size;
         		/*	int j=para->count;
					printf("%d\n",infos[j].FlowId);
					printf("%d\n",infos[j].SeqNum);
					printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
					printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
					printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
					printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
					printf("Size>%5u\n",infos[j].size);
					printf("TCP\n");*/
	     			para->count++;
     				if(para->count==Dim) {
          				if (!logout)
	 				    	out.write((const char*)infos, Dim*sizeof(struct Info));
	     				else  sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
       	     				para->count=0;
    	  			} //end count=Dim
  		} //end if logcheck ||

    	if (strcmp(NameMsr,"rttm")==0)
		#ifdef LINUX_OS
     		sendto(new_sock, payload, size, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
		#endif

		#ifdef WIN32
     		sendto(new_sock,(char*) payload, size, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
		#endif
		}//end size_r>0
	}// END While
}



