/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */




typedef enum TDistro { pdConstant, pdUniform, pdExponential, pdPareto, pdCauchy,

pdNormal, pdPoisson, pdGamma, pdTelnet, pdAoM, pdDiscrete, pdExtreme_Largest, pdQuake, pdStudent, pdCSa,pdCSi };

extern const char *DistroStrings[];
extern const unsigned int DefaultPktPerSec;
extern const unsigned int DefaultPktSize;
extern const unsigned long DefaultDuration;
extern const unsigned long DefaultDelay;

extern Constant *ConstantRV;
extern Uniform *UniformRV;
extern Exponential *ExponentialRV;
extern Pareto *ParetoRV;
extern Cauchy *CauchyRV;
extern Normal *NormalRV;
extern Poisson *PoissonRV;
extern Gamma *GammaRV;

extern Extreme_Largest *Extreme_LargestRV;
extern Student *StudentRV;


void telnetParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);
void voIPParser(int h, char *argv[], int &argc, unsigned int flowId, SumRandom ** pIntArriv,
    SumRandom ** pPktSize, TDistro & IntArrivDistro, TDistro & PktSizeDistro);
void dnsParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);

void CSParsera(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);
void QuakeParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro, TDistro & PktSizeDistro);
void CSParseri(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);

