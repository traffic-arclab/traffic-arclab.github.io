/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */









#ifndef STRING_LIB
#define STRING_LIB

#ifndef INCLUDE_LIB
#include "include.h"
#endif

#include "myexcept.h"

#ifdef use_namespace
namespace RBD_STRING { using namespace RBD_COMMON; }
namespace RBD_LIBRARIES { using namespace RBD_STRING; }
namespace RBD_STRING {
#endif

typedef unsigned int uint;




class StrBase;                    
   class CharSeq;                 
      class StrRep;               
         class StrRepMult;        
         class StrRepCap;         
         class StrRepNullTerm;    
            class StrNull;        
   class CharSingle;              
      class CharRepeated;         
   class StrSumBase;              
      class StrSum;               
      class StrSumLC;             
      class StrSumRC;             



class String : public Janitor



{
   StrBase *px;                   

   char* GetData() const;         
   StrBase* Clone() const;	  
   StrRep* GetStrRep() const;     
   StrRep* GetStrRepW();          
   StrRep* Protect() const;       
				  
   bool HasCapacity() const;      
   String(StrBase* sb);           
   static uint s_index;           
   static StrNull* ASN;           

public:
   unsigned int refcount() const; 
   StrBase* WhereIsIt() const
      { return px; }              
   const char* StringType() const;
   void CleanUp();                

   static uint npos;              

   String();
   String(const String& str);     
   String(const String& str, uint pos, uint n = npos);
   String(const char* s, uint n);
   String(const char* s);
   String(uint n, char c);
   ~String();

   String& operator=(const String& str);
   String& operator=(const char* s);
   String& operator=(const char c);

   uint size() const;
   uint length() const;
   uint max_size() const;
   void resize(uint n, char c = 0);    
   uint capacity() const;
   void reserve(uint res_arg = 0);
   void clear();
   bool empty() const;

   char operator[](uint pos) const;
   char& operator[](uint pos);
   char at(uint n) const;
   char& at(uint n);

   String& operator+=(const String& rhs);
   String& operator+=(const char* s);
   String& operator+=(char c);
   void push_back(char c) { operator+=(c); }

   String& append(const String& str);  
   String& append(const String& str, uint pos, uint n = npos);
   String& append(const char* s, uint n);
   String& append(const char* s);
   String& append(uint n, char c = 0);

   String& assign(const String& str);  
   String& assign(const String& str, uint pos, uint n = npos);
   String& assign(const char* s, uint n);
   String& assign(const char* s);
   String& assign(uint n, char c = 0);

   String& insert(uint pos1, const String& str);
                                       
   String& insert(uint pos1, const String& str, uint pos2, uint n = npos);
   String& insert(uint pos, const char* s, uint n = npos);
                                       
   String& insert(uint pos, uint n, char c = 0);

   String& erase(uint pos = 0, uint n = npos);

   String& replace(uint pos1, uint n1, const String& str);
   String& replace(uint pos1, uint n1, const String& str, uint pos2, uint n2);
   String& replace(uint pos, uint n1, const char* s, uint n2 = npos);
                                       
   String& replace(uint pos, uint n1, uint n2, char c = 0);

   uint copy(char* s, uint n, uint pos = 0) const;
   void swap(String&);

   const char* c_str() const;
   const char* data() const;

   uint find(const String& str, uint pos = 0) const;
   uint find(const char* s, uint pos, uint n) const;
   uint find(const char* s, uint pos = 0) const;
   uint find(const char c, uint pos = 0) const;

   uint rfind(const String& str, uint pos = npos) const;
   uint rfind(const char* s, uint pos, uint n) const;
   uint rfind(const char* s, uint pos = npos) const;
   uint rfind(const char c, uint pos = npos) const;

   uint find_first_of(const String& str, uint pos = 0) const;
   uint find_first_of(const char* s, uint pos, uint n) const;
   uint find_first_of(const char* s, uint pos = 0) const;
   uint find_first_of(const char c, uint pos = 0) const;

   uint find_last_of(const String& str, uint pos = npos) const;
   uint find_last_of(const char* s, uint pos, uint n) const;
   uint find_last_of(const char* s, uint pos = npos) const;
   uint find_last_of(const char c, uint pos = npos) const;

   uint find_first_not_of(const String& str, uint pos = 0) const;
   uint find_first_not_of(const char* s, uint pos, uint n) const;
   uint find_first_not_of(const char* s, uint pos = 0) const;
   uint find_first_not_of(const char c, uint pos = 0) const;

   uint find_last_not_of(const String& str, uint pos = npos) const;
   uint find_last_not_of(const char* s, uint pos, uint n) const;
   uint find_last_not_of(const char* s, uint pos = npos) const;
   uint find_last_not_of(const char c, uint pos = npos) const;

   String substr(uint pos = 0, uint n = npos) const;

   int compare(const String& str) const;
   int compare(uint pos1, uint n1, const String& str) const;
   int compare(uint pos1, uint n1, const String& str, uint pos2, uint n2) const;
   int compare(const char* s) const;
   int compare(uint pos, uint n1, const char* s, uint n2 = npos) const;

   friend String operator+(const String& lhs, const String& rhs);
   friend String operator+(const char* lhs, const String& rhs);
   friend String operator+(char lhs, const String& rhs);
   friend String operator+(const String& lhs, const char* rhs);
   friend String operator+(const String& lhs, char rhs);

   friend bool operator==(const String& lhs, const String& rhs);
   friend bool operator==(const char* lhs, const String& rhs);
   friend bool operator==(const String& lhs, const char* rhs);

   friend bool operator!=(const String& lhs, const String& rhs);
   friend bool operator!=(const char* lhs, const String& rhs);
   friend bool operator!=(const String& lhs, const char* rhs);

   friend bool operator<(const String& lhs, const String& rhs);
   friend bool operator<(const char* lhs, const String& rhs);
   friend bool operator<(const String& lhs, const char* rhs);

   friend bool operator>(const String& lhs, const String& rhs);
   friend bool operator>(const char* lhs, const String& rhs);
   friend bool operator>(const String& lhs, const char* rhs);

   friend bool operator<=(const String& lhs, const String& rhs);
   friend bool operator<=(const char* lhs, const String& rhs);
   friend bool operator<=(const String& lhs, const char* rhs);

   friend bool operator>=(const String& lhs, const String& rhs);
   friend bool operator>=(const char* lhs, const String& rhs);
   friend bool operator>=(const String& lhs, const char* rhs);

   friend void swap(String& A, String& B);

   friend istream& operator>>(istream& is, String& str);
   friend ostream& operator<<(ostream& os, const String& str);
   friend istream& getline(istream& is, String& str, char delim = '\n');

   friend class CharSeq;
   friend class StrSum;
   friend class StringPackageInitialise;

private:

   
   int compare(uint pos, uint n, const CharSeq& sb) const;
   String& my_append(const StrBase& sb);
   String& my_assign(const StrBase& sb);
   String& my_insert(uint pos, const StrBase& sb);
   String& my_replace(uint pos1, uint n1, const StrBase& str);
   uint find(const CharSeq& str, uint pos) const;
   uint rfind(const CharSeq& str, uint pos) const;
   uint find_first_of(const CharSeq& str, uint pos) const;
   uint find_last_of(const CharSeq& str, uint pos) const;
   uint find_first_not_of(const CharSeq& str, uint pos) const;
   uint find_last_not_of(const CharSeq& str, uint pos) const;

   
   
   FREE_CHECK(String)
};





class StrBase
{
public:
   virtual uint size() const = 0;
   virtual uint capacity() const;
   virtual void Load(char*& ps) const = 0; 
   virtual StrBase* Clone(StrBase**) = 0;  
   virtual StrRep* GetStrRep(StrBase**);   
   virtual StrRep* GetStrRepW(StrBase**);  
   virtual StrRep* Protect(StrBase**);     
   virtual void Drop();
   virtual StrBase* UnProtect();           
   virtual void WithCapacity(StrBase**);   
   virtual const char* NullTerminate(StrBase**);
					   
   virtual bool HasCapacity() const;       
   virtual unsigned int refcount() const;  
   virtual ~StrBase() {}
   virtual const char* StringType() const = 0; 
};




class CharSeq : public StrBase
{
protected:
   CharSeq(uint SZ) : sz(SZ) {}
public:
   uint sz;                            
   char* s;                            
   CharSeq() : sz(0), s(0) {}
   CharSeq(char* S);
   CharSeq(char* S, uint SZ);
   CharSeq(const String& str);
   CharSeq(const String& str, uint pos, uint n);
   uint size() const;
   uint capacity() const;
   void Load(char*& ps) const;
   StrBase* Clone(StrBase**);
   const char* StringType() const { return "CharSeq"; }
};





class StrRep : public CharSeq
{
public:
   StrRep() {}
   StrRep(uint SZ);
   StrRep(uint n, char c);
   StrRep(const char* x);
   StrRep(const char* x, uint len);
   StrRep(const char* x, uint len, uint n, char c);
			     
   ~StrRep();

   StrRep* GetStrRep(StrBase**);
   StrRep* GetStrRepW(StrBase**);
   StrRep* Protect(StrBase**);
   void WithCapacity(StrBase**);
   StrBase* Clone(StrBase**);
   StrBase* UnProtect();
   const char* StringType() const { return "StrRep"; }
};






class StrRepMult : public StrRep
{
public:
   unsigned int refcnt;      
   StrRepMult() : refcnt(0) {}
   StrRepMult(uint SZ);
   StrRepMult(uint n, char c);
   StrRepMult(const char* x);
   StrRepMult(const char* x, uint len);
   StrRepMult(const char* x, uint len, uint n, char c);
			     
   void Drop();              

   StrRep* GetStrRepW(StrBase**);
   StrRep* Protect(StrBase**);
   void WithCapacity(StrBase**);
   StrBase* Clone(StrBase**);
   unsigned int refcount() const;
   StrBase* UnProtect();
   const char* StringType() const { return "StrRepMult"; }
};




class StrRepCap : public StrRep
{
public:
   uint cpx;                            
   StrRepCap() : StrRep(), cpx(0) {}
   StrRepCap(uint len, uint cp);        
   StrRepCap(const char* s, uint len);  
   uint capacity() const;
   StrBase* UnProtect();
   void WithCapacity(StrBase**);
   const char* NullTerminate(StrBase**);
   bool HasCapacity() const;            
   const char* StringType() const { return "StrRepCap"; }
};



class StrRepNullTerm : public StrRep
{
public:
   StrRepNullTerm(uint len);
   void WithCapacity(StrBase**);
   StrBase* UnProtect();
   const char* NullTerminate(StrBase**);
   const char* StringType() const { return "StrRepNullTerm"; }
};




class CharSingle : public StrBase
{
protected:
   char c;
public:
   CharSingle(char C) : c(C) {}
   uint size() const;
   void Load(char*& ps) const;
   StrBase* Clone(StrBase**);
   const char* StringType() const { return "CharSingle"; }
};




class CharRepeated : public CharSingle
{
protected:
   uint n;
public:
   CharRepeated(int N, char C);
   uint size() const;
   void Load(char*& ps) const;
   StrBase* Clone(StrBase**);
   const char* StringType() const { return "CharRepeated"; }
};




class StrSumBase : public StrBase
{
protected:
   bool ref;                      
   StrSumBase();
public:
   StrBase* Clone(StrBase**);
   unsigned int refcount() const;
   const char* StringType() const { return "StrSumBase"; }
};




class StrSum : public StrSumBase
{
protected:
   StrBase* lhs;
   StrBase* rhs;
public:
   StrSum(StrBase* L, StrBase* R);
   uint size() const;
   void Load(char*& ps) const;
   void Drop();
   const char* StringType() const { return "StrSum"; }
};




class StrSumLC : public StrSumBase
{
protected:
   char lhs;
   StrBase* rhs;
public:
   StrSumLC(char L, StrBase* R);
   uint size() const;
   void Load(char*& ps) const;
   void Drop();
   const char* StringType() const { return "StrSumLC"; }
};




class StrSumRC : public StrSumBase
{
protected:
   StrBase* lhs;
   char rhs;
public:
   StrSumRC(StrBase* L, char R);
   uint size() const;
   void Load(char*& ps) const;
   void Drop();
   const char* StringType() const { return "StrSumRC"; }
};




class StrNull : public StrRepNullTerm
{
public:
   StrNull();
   uint size() const;
   void Load(char*& ps) const;
   StrBase* Clone(StrBase**);
   StrBase* UnProtect();
   void Drop();
   const char* StringType() const { return "StrNull"; }
};



inline void swap(String& A, String& B) { A.swap(B); }






class StringPackageInitialise
{
public:
   StringPackageInitialise();
};

static StringPackageInitialise DoStringPackageInitialise;


#ifdef use_namespace
}
#endif


#endif                                 






