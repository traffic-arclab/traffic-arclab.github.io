/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */







#ifndef INCLUDE_LIB
#define INCLUDE_LIB










#define UseExceptions                   




					


					



#define USING_DOUBLE                    


#define bool_LIB 0                      










                                        
                                        

#define TypeDefException





#if defined __GNUG__ && __GNUG__ >= 3
   #define _STANDARD_                   
   #define ios_format_flags ios::fmtflags
#endif


#if defined __ICC
   #define _STANDARD_                   
   #define ios_format_flags ios::fmtflags
#endif


#if defined _MSC_VER && _MSC_VER >= 1300
   #define _STANDARD_                   
#endif


#ifdef _STANDARD_                       
   #include <cstdlib>
   #if defined _MSC_VER && _MSC_VER == 1200
      #include <limits>              
   #endif
   #ifdef WANT_STREAM
      #include <iostream>
      #include <iomanip>
   #endif
   #ifdef WANT_MATH
      #include <cmath>
   #endif
   #ifdef WANT_STRING
      #include <cstring>
   #endif
   #ifdef WANT_TIME
      #include <ctime>
   #endif
   #ifdef WANT_FSTREAM
      #include <fstream>
   #endif
   using namespace std;
#else

#define DEFAULT_HEADER                  
                                        

#ifdef _MSC_VER                         
   #include <stdlib.h>









   #ifdef WANT_STREAM
      #include <iostream.h>
      #include <iomanip.h>
   #endif
   #ifdef WANT_MATH
      #include <math.h>
      #include <float.h>
   #endif
   #ifdef WANT_STRING
      #include <string.h>
   #endif
   #ifdef WANT_TIME
      #include <time.h>
   #endif
   #ifdef WANT_FSTREAM
      #include <fstream.h>
   #endif
   #undef DEFAULT_HEADER
#endif

#ifdef __ZTC__                          
   #include <stdlib.h>
   #ifdef WANT_STREAM
      #include <iostream.hpp>
      #include <iomanip.hpp>
      #define flush ""                  
   #endif
   #ifdef WANT_MATH
      #include <math.h>
      #include <float.h>
   #endif
   #ifdef WANT_STRING
      #include <string.h>
   #endif
   #ifdef WANT_TIME
      #include <time.h>
   #endif
   #ifdef WANT_FSTREAM
      #include <fstream.h>
   #endif
   #undef DEFAULT_HEADER
#endif

#if defined __BCPLUSPLUS__ || defined __TURBOC__  
   #include <stdlib.h>
   #ifdef WANT_STREAM
      #include <iostream.h>
      #include <iomanip.h>
   #endif
   #ifdef WANT_MATH
      #include <math.h>
      #include <float.h>            
                                    
                                    
   #endif
   #ifdef WANT_STRING
      #include <string.h>
   #endif
   #ifdef WANT_TIME
      #include <time.h>
   #endif
   #ifdef WANT_FSTREAM
      #include <fstream.h>
   #endif
   #undef DEFAULT_HEADER
#endif

#ifdef __GNUG__                         
   #include <stdlib.h>
   #ifdef WANT_STREAM
      #include <iostream.h>
      #include <iomanip.h>
   #endif
   #ifdef WANT_MATH
      #include <math.h>
      #include <float.h>
   #endif
   #ifdef WANT_STRING
      #include <string.h>
   #endif
   #ifdef WANT_TIME
      #include <time.h>
   #endif
   #ifdef WANT_FSTREAM
      #include <fstream.h>
   #endif
   #undef DEFAULT_HEADER
#endif

#ifdef __WATCOMC__                      
   #include <stdlib.h>
   #ifdef WANT_STREAM
      #include <iostream.h>
      #include <iomanip.h>
   #endif
   #ifdef WANT_MATH
      #include <math.h>
      #include <float.h>
   #endif
   #ifdef WANT_STRING
      #include <string.h>
   #endif
   #ifdef WANT_TIME
      #include <time.h>
   #endif
   #ifdef WANT_FSTREAM
      #include <fstream.h>
   #endif
   #undef DEFAULT_HEADER
#endif


#ifdef macintosh                        
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <float.h>
#include <math.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif

#ifdef use_float_h                      
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <float.h>
#include <math.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif


#ifdef DEFAULT_HEADER                   
#define ATandT
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <math.h>
#define SystemV                         
#include <values.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#endif                                  

#endif                                  

#ifdef use_namespace
namespace RBD_COMMON {
#endif


#ifdef USING_FLOAT                      
typedef float Real;
typedef double long_Real;
#endif

#ifdef USING_DOUBLE                     
typedef double Real;
typedef long double long_Real;
#endif




#ifndef bool_LIB
#define bool_LIB 0

class bool
{
	int value;
public:
	bool(const int b) { value = b ? 1 : 0; }
	bool(const void* b) { value = b ? 1 : 0; }
	bool() {}
	operator int() const { return value; }
	int operator!() const { return !value; }
};


const bool true = 1;
const bool false = 0;

#endif


#ifdef use_namespace
}
#endif


#ifdef use_namespace
namespace RBD_COMMON {}
namespace RBD_LIBRARIES                 
{
   using namespace RBD_COMMON;
}
#endif


#endif




