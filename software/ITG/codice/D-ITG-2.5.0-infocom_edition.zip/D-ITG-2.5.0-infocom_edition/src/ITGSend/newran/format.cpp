/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */



#define WANT_STREAM
#define WANT_MATH
#define WANT_STRING


#include "include.h"
#include "str.h"
#include "format.h"

#ifdef use_namespace
namespace RBD_STRING { using namespace RBD_COMMON; }
namespace RBD_LIBRARIES { using namespace RBD_STRING; }
namespace RBD_STRING {
#endif


#ifdef use_namespace

OstreamWithFormat& endl(OstreamWithFormat& osf)
   { osf.os << ::endl; return osf; }

OstreamWithFormat& ends(OstreamWithFormat& osf)
   { osf.os << ::ends; return osf; }

OstreamWithFormat& flush(OstreamWithFormat& osf)
   { osf.os << ::flush; return osf; }

#else

OstreamWithFormat& endl(OstreamWithFormat& osf)
   { osf.os << endl; return osf; }

OstreamWithFormat& ends(OstreamWithFormat& osf)
   { osf.os << ends; return osf; }

OstreamWithFormat& flush(OstreamWithFormat& osf)
   { osf.os << flush; return osf; }

#endif


OstreamWithFormat& OstreamWithFormat::operator<<(const char* value)
   { f.StringPrint(os, value, strlen(value)); return *this; }


void Format::FormatOut(ostream& os, double value) const
{
   os << prefix_val;
   switch (format_type_val)
   {
      case Format::SIG_FIGS:
         SigFig(os, value, precision_val);
         break;

      case Format::DEC_FIGS:
         DecFig(os, value, precision_val);
         break;

      case Format::SCIENTIFIC:
         Scientific(os, value, precision_val);
         break;

      case Format::INTEGER:
         DecFig(os, value, 0);
         break;
   }
   os << suffix_val;
}

void Format::IntegerPrint(ostream& os, double value) const
   { os << prefix_val; DecFig(os, value, 0); os << suffix_val; }


void Format::StringPrint(ostream& os, const char* value, int size) const
{
   int i;

   
   os << prefix_val;

   
   if (size > max_width_val) { ErrorOut(os); return; }

   
   int spaces;
   if (size < min_width_val) spaces = min_width_val - size;  else spaces = 0;
   int s1, s2;                                
   if (alignment_val == Format::LEFT) { s1 = 0; s2 = spaces; }
   else if (alignment_val == Format::RIGHT) { s1 = spaces; s2 = 0; }
   else { s1 = spaces / 2; s2 = spaces - s1; }

   
   for (i = 0; i < s1; i++) os << ' ';

   
   for (i = 0; i < size; i++) os << value[i];

   
   for (i = 0; i < s2; i++) os << ' ';

   
   os << suffix_val;
}

void Format::SigFig(ostream& os, double value, int nsig) const
{
   bool variant1 = (variant_val == Format::VAR1);
   double v = value;
   if (v == 0.0)
   {
      if (variant1) DecFig(os, 0.0, nsig);
      else DecFig(os, 0.0, nsig-1);
      return;
   }

   
   bool neg;
   if (v < 0) { v = -v; neg = true; }
   else neg = false;

   
   int ndec = nsig - (int)floor(log10(v)) - 1;    

   
   double p = pow(10.0, ndec);                    
   double rv = floor(v * p + 0.5);                

   
   if (rv >= pow(10.0, nsig)) { ndec--; p /= 10; rv = floor(v * p + 0.5); }

   
   v = rv / p;
   if (neg) v = -v;

   
   int w = nsig;
   if (ndec > 0)
   {
      w++;                                        
      if (ndec >= nsig)
      {
         if (!variant1) ++w;                      
         w += (ndec - nsig);                      
      }
   }
   else { w -= ndec; ndec = 0; }                  
   if (neg || positive_val != Format::NX) w++;    

   
   
   
   
   if (w > max_width_val)
   {
      if (ndec == 0) Scientific(os, value, nsig);
      else if (underflow_policy_val == Format::E)
         Scientific(os, value, nsig);
      else DecFig(os, value, ndec, true);
   }
   else DecFig(os, v, ndec, true);
}

void Format::DecFig(ostream& os, double value, int ndec,
   bool force_decimal) const
{
   int i;
   double v = value;
   bool variant1 = (variant_val == Format::VAR1);

   
   bool neg;
   if (v < 0) { v = -v; neg = true; } else neg = false;

   
   
   
   double p = pow(10.0,ndec);                  
   double iv;                                  
   v = modf(v, &iv);                           
   v = floor(v * p + 0.5);                     
   if (v >= p) { iv += 1.0; v -= p; }          

   
   if ( iv == 0 &&
        value != 0.0 &&
        underflow_policy_val == Format::E &&
        !force_decimal &&
        (!variant1 || v < 0.1) )
      { Scientific(os, value, ndec+1); return; }
      
   
   int li = max_width_val - ndec;                 
   int lj = min_width_val - ndec;                 

   
   if (neg || positive_val != Format::NX) { li--; lj--; }

   
   bool dp = (ndec > 0);
   if (dp) { li--; lj--; }                        

   
   if (variant1)
   {                                               
      if (li < 0)
         { DecFig(os, value, ndec+li, force_decimal); return; }
   }
   else
   {                                               
      if (li < 1)
         { DecFig(os, value, ndec+li-1, force_decimal); return; }
   }

   String si(li, ' ');
   int nchar = 0;
   for (i = li-1; i >= 0; i--)
   {
      if (iv < 0.5) break;
      nchar++;                                    
      double x; x = modf(iv/10, &iv);
      si[i] = (char)('0' + (int)floor(x * 10 + 0.5));
   }
   if (iv > 0.5)                                  
   {
      if (overflow_policy_val == Format::HASH) ErrorOut(os);
      else  Scientific(os, value, max_width_val-4);
      return;
   }
   if (nchar == 0 && !variant1)
      { nchar = 1; si[li-1] = '0'; }              

   int spaces = lj - nchar;                       
   if (spaces < 0) spaces = 0;
   int s1, s2;                                    
   if (alignment_val == Format::LEFT) { s1 = 0; s2 = spaces; }
   else if (alignment_val == Format::RIGHT) { s1 = spaces; s2 = 0; }
   else { s1 = spaces / 2; s2 = spaces - s1; }
   
   
   
   if (ndec == 0 && variant1 && s1 > 0) { dp = true; --s1; }

   
   for (i = 0; i < s1; i++) os << ' ';

   
   if (neg) os << '-';
   else if (positive_val == Format::SPACE) os << ' ';
   else if (positive_val == Format::PLUS) os << '+';

   
   for (i = 0; i < nchar; i++) os << si[li - nchar + i];

   
   if (dp)
   {
      os << '.';
      String sv(ndec, '0');
      for (i = ndec-1;  i >= 0; i--)
      {
         double x; x = modf(v/10, &v);
         sv[i] = (char)('0' + (int)floor(x * 10 + 0.5));
      }
      for (i = 0; i < ndec; i++) os << sv[i];
   }

   
   for (i = 0; i < s2; i++) os << ' ';

}

void Format::Scientific(ostream& os, double value, int nsig) const
{
   int i;
   double v = value;

   
   if (nsig < 0) { ErrorOut(os); return; }

   
   bool neg;
   if (v < 0) { v = -v; neg = true; }
   else neg = false;

   
   int lv;
   if (v == 0.0) lv = 0;
   else lv = (int)floor(log10(v));           
   v /= pow(10.0,lv);                        

   
   double p = pow(10.0,nsig-1);              
   double rv = floor(v * p + 0.5);           

   
   if (rv >= 10.0 * p)
      { lv++; v /= 10.0; rv = floor(v * p + 0.5); }

   
   int w = nsig;
   if (nsig > 1) w++;                          
   if (neg || positive_val != Format::NX) w++; 
   int np;                                     
   if (lv >=100 || lv <= -100)
      { if (lv >=1000 || lv <= -1000) np = 4; else np = 3; }
   else np = 2;
   w += np + 2;                                
   if (w > max_width_val)
   {
      int ov = w - max_width_val;              
      
      if ((lv == -100 || lv == -1000) && ov == 1)
      {
         double p1 = p / 10.0; 
         double rv1 = floor(v * p1 + 0.5);
         if (rv1 >= p)
         {
            double v1 = rv1 * pow(10.0, lv) / p1;
            if (neg) v1 = -v1;
            Scientific(os, v1, nsig);    
            return;
         }
      }
      if (overflow_policy_val == Format::HASH) { ErrorOut(os); return; }
      if (ov > 1) --ov;                        
                                               
      if (ov > 1) --ov;                        
      nsig -= ov;                              
      if (nsig <= 0) { ErrorOut(os); return; } 
      Scientific(os, value, nsig);             
      return;
   }

   
   int spaces = min_width_val - w;
   if (spaces < 0) spaces = 0;
   int s1, s2;                                    
   if (alignment_val == Format::LEFT) { s1 = 0; s2 = spaces; }
   else if (alignment_val == Format::RIGHT) { s1 = spaces; s2 = 0; }
   else { s1 = spaces / 2; s2 = spaces - s1; }

   
   for (i = 0; i < s1; i++) os << ' ';

   
   if (neg) os << '-';
   else if (positive_val == Format::SPACE) os << ' ';
   else if (positive_val == Format::PLUS) os << '+';

   
   String sv; sv.resize(nsig);
   for (i = nsig-1;  i >= 0; i--)
   {
      double x; x = modf(rv/10, &rv);
      sv[i] = (char)('0' + (int)floor(x * 10 + 0.5));
   }
   os << sv[0];                            
   if (nsig > 1)                           
      { os << '.'; for (int i = 1; i < nsig; i++) os << sv[i]; }

   
   os << 'e';
   if (lv >= 0) os << '+'; else { os << '-'; lv = -lv; }
   sv.resize(np);
   for (i = np-1; i >= 0; i--)
   {
      int lv1 = lv / 10; int x = lv - lv1 * 10; lv = lv1;
      sv[i] = (char)('0' + x);
   }
   for (i = 0; i < np; i++) os << sv[i];

   
   for (i = 0; i < s2; i++) os << ' ';
}

void Format::ErrorOut(ostream& os) const
{
   if (min_width_val == 0) os << '#';
   else { for (int i = 0; i < min_width_val; i++) os << '#'; }
}


#ifdef use_namespace
}
#endif

