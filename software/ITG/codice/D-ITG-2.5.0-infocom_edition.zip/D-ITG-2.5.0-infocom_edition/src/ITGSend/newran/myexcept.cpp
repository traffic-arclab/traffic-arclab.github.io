/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */
















#define WANT_STREAM                    
#define WANT_STRING

#include "include.h"                   


#include "myexcept.h"                  

#ifdef use_namespace
namespace RBD_COMMON {
#endif




                                       

#ifdef SimulateExceptions

void Throw()
{
   for (Janitor* jan = JumpBase::jl->janitor; jan; jan = jan->NextJanitor)
      jan->CleanUp();
   JumpItem* jx = JumpBase::jl->ji;    
   if ( !jx ) { Terminate(); }         
   JumpBase::jl = jx;                  
                                       
   Tracer::last = JumpBase::jl->trace;
   longjmp(JumpBase::jl->env, 1);
}

#endif                                 


unsigned long BaseException::Select;
char* BaseException::what_error;
int BaseException::SoFar;
int BaseException::LastOne;

BaseException::BaseException(const char* a_what)
{
   Select++; SoFar = 0;
   if (!what_error)                   
   {
      LastOne = 511;
      what_error = new char[512];
      if (!what_error)                
      {
         LastOne = 0;
         what_error = (char *)"No heap space for exception message\n";
      }
   }
   AddMessage("\n\nAn exception has been thrown\n");
   AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}

void BaseException::AddMessage(const char* a_what)
{
   if (a_what)
   {
      int l = strlen(a_what); int r = LastOne - SoFar;
      if (l < r) { strcpy(what_error+SoFar, a_what); SoFar += l; }
      else if (r > 0)
      {
         strncpy(what_error+SoFar, a_what, r);
         what_error[LastOne] = 0;
         SoFar = LastOne;
      }
   }
}

void BaseException::AddInt(int value)
{
   bool negative;
   if (value == 0) { AddMessage("0"); return; }
   else if (value < 0) { value = -value; negative = true; }
   else negative = false;
   int n = 0; int v = value;        
   while (v > 0) { v /= 10; n++; }
   if (negative) n++;
   if (LastOne-SoFar < n) { AddMessage("***"); return; }

   SoFar += n; n = SoFar; what_error[n] = 0;
   while (value > 0)
   {
      int nv = value / 10; int rm = value - nv * 10;  value = nv;
      what_error[--n] = (char)(rm + '0');
   }
   if (negative) what_error[--n] = '-';
   return;
}

void Tracer::PrintTrace()
{
   cout << "\n";
   for (Tracer* et = last; et; et=et->previous)
      cout << "  * " << et->entry << "\n";
}

void Tracer::AddTrace()
{
   if (last)
   {
      BaseException::AddMessage("Trace: ");
      BaseException::AddMessage(last->entry);
      for (Tracer* et = last->previous; et; et=et->previous)
      {
         BaseException::AddMessage("; ");
         BaseException::AddMessage(et->entry);
      }
      BaseException::AddMessage(".\n");
   }
}

#ifdef SimulateExceptions


Janitor::Janitor()
{
   if (do_not_link)
   {
      do_not_link = false; NextJanitor = 0; OnStack = false;
#ifdef CLEAN_LIST
      cout << "Not added to clean-list " << (unsigned long)this << "\n";
#endif
   }
   else
   {
      OnStack = true;
#ifdef CLEAN_LIST
      cout << "Add to       clean-list " << (unsigned long)this << "\n";
#endif
      NextJanitor = JumpBase::jl->janitor; JumpBase::jl->janitor=this;
   }
}

Janitor::~Janitor()
{
   
   
   if (OnStack)
   {
#ifdef CLEAN_LIST
      cout << "Delete from  clean-list " << (unsigned long)this << "\n";
#endif
      Janitor* lastjan = JumpBase::jl->janitor;
      if (this == lastjan) JumpBase::jl->janitor = NextJanitor;
      else
      {
	 for (Janitor* jan = lastjan->NextJanitor; jan;
	    jan = lastjan->NextJanitor)
	 {
	    if (jan==this)
	       { lastjan->NextJanitor = jan->NextJanitor; return; }
	    lastjan=jan;
	 }

	 Throw(BaseException(
"Cannot resolve memory linked list\nSee notes in myexcept.cpp for details\n"
         ));



























      }
   }
}

JumpItem* JumpBase::jl;              
jmp_buf JumpBase::env;
bool Janitor::do_not_link;           


int JanitorInitializer::ref_count;

JanitorInitializer::JanitorInitializer()
{
   if (ref_count++ == 0) new JumpItem;
                                    
}

#endif                              

Tracer* Tracer::last;               


void Terminate()
{
   cout << "\n\nThere has been an exception with no handler - exiting";
   const char* what = BaseException::what();
   if (what) cout << what << "\n";
   exit(1);
}



#ifdef DO_FREE_CHECK


FreeCheckLink::FreeCheckLink() : next(FreeCheck::next)
   { FreeCheck::next = this; }

FCLClass::FCLClass(void* t, char* name) : ClassName(name) { ClassStore=t; }

FCLRealArray::FCLRealArray(void* t, char* o, int s)
  : Operation(o), size(s) { ClassStore=t; }

FCLIntArray::FCLIntArray(void* t, char* o, int s)
  : Operation(o), size(s) { ClassStore=t; }

FreeCheckLink* FreeCheck::next;
int FreeCheck::BadDelete;

void FCLClass::Report()
{ cout << "   " << ClassName << "   " << (unsigned long)ClassStore << "\n"; }

void FCLRealArray::Report()
{
   cout << "   " << Operation << "   " << (unsigned long)ClassStore <<
      "   " << size << "\n";
}

void FCLIntArray::Report()
{
   cout << "   " << Operation << "   " << (unsigned long)ClassStore <<
      "   " << size << "\n";
}

void FreeCheck::Register(void* t, char* name)
{
   FCLClass* f = new FCLClass(t,name);
   if (!f) { cout << "Out of memory in FreeCheck\n"; exit(1); }
#ifdef REG_DEREG
   cout << "Registering   " << name << "   " << (unsigned long)t << "\n";
#endif
}

void FreeCheck::RegisterR(void* t, char* o, int s)
{
   FCLRealArray* f = new FCLRealArray(t,o,s);
   if (!f) { cout << "Out of memory in FreeCheck\n"; exit(1); }
#ifdef REG_DEREG
   cout << o << "   " << s << "   " << (unsigned long)t << "\n";
#endif
}

void FreeCheck::RegisterI(void* t, char* o, int s)
{
   FCLIntArray* f = new FCLIntArray(t,o,s);
   if (!f) { cout << "Out of memory in FreeCheck\n"; exit(1); }
#ifdef REG_DEREG
   cout << o << "   " << s << "   " << (unsigned long)t << "\n";
#endif
}

void FreeCheck::DeRegister(void* t, char* name)
{
   FreeCheckLink* last = 0;
#ifdef REG_DEREG
   cout << "Deregistering " << name << "   " << (unsigned long)t << "\n";
#endif
   for (FreeCheckLink* fcl = next; fcl; fcl = fcl->next)
   {
      if (fcl->ClassStore==t)
      {
	 if (last) last->next = fcl->next; else next = fcl->next;
	 delete fcl; return;
      }
      last = fcl;
   }
   cout << "\nRequest to delete non-existent object of class and location:\n";
   cout << "   " << name << "   " << (unsigned long)t << "\n";
   BadDelete++;
   Tracer::PrintTrace();
   cout << "\n";
}

void FreeCheck::DeRegisterR(void* t, char* o, int s)
{
   FreeCheckLink* last = 0;
#ifdef REG_DEREG
   cout << o << "   " << s << "   " << (unsigned long)t << "\n";
#endif
   for (FreeCheckLink* fcl = next; fcl; fcl = fcl->next)
   {
      if (fcl->ClassStore==t)
      {
	 if (last) last->next = fcl->next; else next = fcl->next;
	 if (s >= 0 && ((FCLRealArray*)fcl)->size != s)
	 {
	    cout << "\nArray sizes do not agree:\n";
	    cout << "   " << o << "   " << (unsigned long)t
	       << "   " << ((FCLRealArray*)fcl)->size << "   " << s << "\n";
	    Tracer::PrintTrace();
	    cout << "\n";
	 }
	 delete fcl; return;
      }
      last = fcl;
   }
   cout << "\nRequest to delete non-existent real array:\n";
   cout << "   " << o << "   " << (unsigned long)t << "   " << s << "\n";
   BadDelete++;
   Tracer::PrintTrace();
   cout << "\n";
}

void FreeCheck::DeRegisterI(void* t, char* o, int s)
{
   FreeCheckLink* last = 0;
#ifdef REG_DEREG
   cout << o << "   " << s << "   " << (unsigned long)t << "\n";
#endif
   for (FreeCheckLink* fcl = next; fcl; fcl = fcl->next)
   {
      if (fcl->ClassStore==t)
      {
	 if (last) last->next = fcl->next; else next = fcl->next;
	 if (s >= 0 && ((FCLIntArray*)fcl)->size != s)
	 {
	    cout << "\nArray sizes do not agree:\n";
	    cout << "   " << o << "   " << (unsigned long)t
	       << "   " << ((FCLIntArray*)fcl)->size << "   " << s << "\n";
	    Tracer::PrintTrace();
	    cout << "\n";
	 }
	 delete fcl; return;
      }
      last = fcl;
   }
   cout << "\nRequest to delete non-existent int array:\n";
   cout << "   " << o << "   " << (unsigned long)t << "   " << s << "\n";
   BadDelete++;
   Tracer::PrintTrace();
   cout << "\n";
}

void FreeCheck::Status()
{
   if (next)
   {
      cout << "\nObjects of the following classes remain undeleted:\n";
      for (FreeCheckLink* fcl = next; fcl; fcl = fcl->next) fcl->Report();
      cout << "\n";
   }
   else cout << "\nNo objects remain undeleted\n\n";
   if (BadDelete)
   {
      cout << "\nThere were " << BadDelete << 
         " requests to delete non-existent items\n\n";
   }
}

#endif                            



Logic_error::Logic_error(const char* a_what) : BaseException()
{
   Select = BaseException::Select;
   AddMessage("Logic error:- "); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}

Runtime_error::Runtime_error(const char* a_what)
   : BaseException()
{
   Select = BaseException::Select;
   AddMessage("Runtime error:- "); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}

Domain_error::Domain_error(const char* a_what) : Logic_error()
{
   Select = BaseException::Select;
   AddMessage("domain error\n"); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}

Invalid_argument::Invalid_argument(const char* a_what) : Logic_error()
{
   Select = BaseException::Select;
   AddMessage("invalid argument\n"); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}

Length_error::Length_error(const char* a_what) : Logic_error()
{
   Select = BaseException::Select;
   AddMessage("length error\n"); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}

Out_of_range::Out_of_range(const char* a_what) : Logic_error()
{
   Select = BaseException::Select;
   AddMessage("out of range\n"); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}















Range_error::Range_error(const char* a_what) : Runtime_error()
{
   Select = BaseException::Select;
   AddMessage("range error\n"); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}

Overflow_error::Overflow_error(const char* a_what) : Runtime_error()
{
   Select = BaseException::Select;
   AddMessage("overflow error\n"); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}

Bad_alloc::Bad_alloc(const char* a_what) : BaseException()
{
   Select = BaseException::Select;
   AddMessage("bad allocation\n"); AddMessage(a_what);
   if (a_what) Tracer::AddTrace();
}




unsigned long Logic_error::Select;
unsigned long Runtime_error::Select;
unsigned long Domain_error::Select;
unsigned long Invalid_argument::Select;
unsigned long Length_error::Select;
unsigned long Out_of_range::Select;


unsigned long Range_error::Select;
unsigned long Overflow_error::Select;
unsigned long Bad_alloc::Select;

#ifdef use_namespace
}
#endif




