/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */







#ifdef use_namespace
using namespace NEWRAN;
using namespace RBD_STRING;
using namespace RBD_COMMON;
#endif




void test1(int);
void test2(int);
void test3(int);
void test4(int);
void test5(int);
void test6(int);
void Histogram(Random*, int);          

OstreamWithFormat operator<<( OstreamWithFormat, const ExtReal& );













