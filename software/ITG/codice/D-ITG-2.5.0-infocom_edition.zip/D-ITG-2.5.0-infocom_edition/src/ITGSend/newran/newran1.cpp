/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */








#define WANT_MATH
#define WANT_STRING
#define WANT_FSTREAM

#include "include.h"

#include "newran.h"

#ifdef use_namespace
namespace NEWRAN { using namespace RBD_COMMON; }
namespace RBD_LIBRARIES { using namespace NEWRAN; }
namespace NEWRAN {
#endif

static char hex(unsigned long s, int n)
{
   unsigned long sn = (s >> n) & 0xF;
   if (sn < 10) return (char)('0' + sn);
   else return (char)('A' + (sn - 10));
}

static unsigned long unhex(char c, int n)
{
   if (c < '0') Throw(Runtime_error("newran: invalid character in unhex"));
   if (c <= '9') return ((unsigned long)(c - '0')) << n;
   if (c < 'A') Throw(Runtime_error("newran: invalid character in unhex"));
   if (c <= 'F') return ((unsigned long)(c - 'A' + 10)) << n;
   Throw(Runtime_error("newran: invalid character in unhex"));
#ifndef UseExceptions
   return 0;
#endif
}





const char* Random::Name() { return "Random"; }

Random* Random::RNG = new DummyRNG; 
Random* Random::Dummy = RNG;        
SimpleString Random::Dir;           

Real Random::Density(Real) const
{
   Throw(Logic_error("Newran: density function not available"));
#ifndef UseExceptions
   return 0;
#endif
}

unsigned long Random::ulNext()
{
   Throw(Logic_error("Newran: ulNext function not available"));
#ifndef UseExceptions
   return 0;
#endif
}

void Random::Set(Random& r)   
{
   RNG = &r;
}

void Random::CopySeedFromDisk(bool update)
{
   if (Dir.size() == 0) Throw(Logic_error("Newran: directory not defined"));
   RNG->CSFD(update);
}

void Random::CopySeedToDisk()
{
   if (Dir.size() == 0) Throw(Logic_error("Newran: directory not defined"));
   RNG->CSTD();
}

void Random::SetDirectory(const char* dir)
{
   Dir = dir;
}



static void ReadVerify(ifstream& in, bool missing_ok = false)
{
   if (!in || in.eof())
   {
      if (missing_ok) return;
      Throw(Runtime_error("Newran: can't open seed file"));
   }
   const char* v_string = "!Newran03!"; char c;
   for (int i = 0; i < 10; ++i)
   {
      in >> c;
      if (in.eof())
      {
         if (i==0 && missing_ok) return;
         Throw(Runtime_error("Newran: seed file verification fails"));
      }
      if (c != v_string[i])
         Throw(Runtime_error("Newran: seed file verification fails"));
   }
}

static void WriteVerify(ofstream& out)
{
   if (!out) Throw(Runtime_error("Newran: can't access seed file"));
   const char* v_string = "!Newran03!";
   for (int i = 0; i < 10; ++i) out << v_string[i];
}




const char* LGM_base::Name() { return "LGM_base"; }

LGM_base::LGM_base(double s)
{
   if (s>=1.0 || s<=0.0)
      Throw(Logic_error("Newran: seed out of range"));
   seed = (long)(s*2147483648UL);
   Update = false;
}

void LGM_base::NextValue()
{
   
   
   long hi = seed / 127773L;                 
   long lo = seed - hi * 127773L;            
   seed = 16807 * lo - 2836 * hi;
   if (seed <= 0) seed += 2147483647L;
}

Real LGM_base::Next() { NextValue(); return (double)seed / 2147483648.0; }

unsigned long LGM_base::ulNext() { NextValue(); return (unsigned long)seed << 1; }




const char* LGM_mixed::Name() { return "LGM_mixed"; }

LGM_mixed::LGM_mixed(double s) : LGM_base(s)
{
   for (int i = 0; i<128; i++) { LGM_base::NextValue(); Buffer[i] = seed; }
}

void LGM_mixed::NextValue()                    
{
   int i = (int)(LGM_base::Next()*128);       
   LGM_base::NextValue();
   seed_mixed = Buffer[i]; Buffer[i] = seed;
}

Real LGM_mixed::Next() { NextValue(); return (double)seed_mixed / 2147483648.0; }

unsigned long LGM_mixed::ulNext()
{ NextValue(); return (unsigned long)seed_mixed << 1; }


void LGM_mixed::CSFD(bool update)
{
   Update = false;
   ifstream in((Dir+"lgm_mix.txt").c_str());
   ReadVerify(in);
   char x; seed = 0;
   for (int n = 28; n >= 0; n -= 4) { in >> x; seed |= unhex(x, n); }
   ReadVerify(in);
   in.close();
   for (int i = 0; i<128; i++) { LGM_base::NextValue(); Buffer[i] = seed; }
   Update = update;
}

void LGM_mixed::CSTD()
{
   ifstream in; in.open((Dir+"lgm_mix.txt").c_str(), ios::in);
   ReadVerify(in, true); if (in) in.close();
   ofstream out((Dir+"lgm_mix.txt").c_str());
   WriteVerify(out);
   for (int n = 28; n >= 0; n -= 4) out << hex(seed, n);
   WriteVerify(out);
   out << endl;
   out.close();
}


LGM_mixed::~LGM_mixed()
{
   if (Update) CSTD();
   if (RNG == this) RNG = Dummy;
}



const char* LGM_simple::Name() { return "LGM_simple"; }

LGM_simple::LGM_simple(double s) : LGM_base(s) {}

void LGM_simple::CSFD(bool update)
{
   Update = false;
   ifstream in((Dir+"lgm.txt").c_str());
   ReadVerify(in);
   seed = 0;
   char x;
   for (int n = 28; n >= 0; n -= 4) { in >> x; seed |= unhex(x, n); }
   ReadVerify(in);
   in.close();
   Update = update;
}

void LGM_simple::CSTD()
{
   ifstream in; in.open((Dir+"lgm_mix.txt").c_str(), ios::in);
   ReadVerify(in, true); if (in) in.close();
   ofstream out((Dir+"lgm.txt").c_str());
   WriteVerify(out);
   for (int n = 28; n >= 0; n -= 4) out << hex(seed, n);
   WriteVerify(out);
   out << endl;
   out.close();
}


LGM_simple::~LGM_simple()
{
   if (Update) CSTD();
   if (RNG == this) RNG = Dummy;
}









const char* WH::Name() { return "Wichmann Hill"; }

WH::WH(double s)
{
   if (s>=1.0 || s<=0.0)
      Throw(Logic_error("Newran: seed out of range"));
   seed1 = (unsigned long)(s*30269);
   seed2 = 1234;
   seed3 = 5678;
   Update = false;
}

Real WH::Next()                           
{
   seed1 = 171 * seed1 % 30269; 
   seed2 = 172 * seed2 % 30307; 
   seed3 = 170 * seed3 % 30323;
   double x = seed1 / 30269.0 + seed2 / 30307.0 + seed3 / 30323.0;
   if (x < 1) return x;
   else if (x < 2) return x - 1;
   else return x - 2; 
}

unsigned long WH::ulNext() { return (unsigned long)floor(WH::Next() * 4294967296.0); }

void WH::CSFD(bool update)
{
   Update = false;
   ifstream in((Dir+"wh.txt").c_str());
   ReadVerify(in);
   seed1 = seed2 = seed3 = 0;
   char x; int n;
   for (n = 28; n >= 0; n -= 4) { in >> x; seed1 |= unhex(x, n); }
   for (n = 28; n >= 0; n -= 4) { in >> x; seed2 |= unhex(x, n); }
   for (n = 28; n >= 0; n -= 4) { in >> x; seed3 |= unhex(x, n); }
   ReadVerify(in);
   in.close();
   Update = update;
}

void WH::CSTD()
{
   ifstream in; in.open((Dir+"lgm_mix.txt").c_str(), ios::in);
   ReadVerify(in, true); if (in) in.close();
   ofstream out((Dir+"wh.txt").c_str());
   WriteVerify(out);
   int n;
   for (n = 28; n >= 0; n -= 4) out << hex(seed1, n);
   for (n = 28; n >= 0; n -= 4) out << hex(seed2, n);
   for (n = 28; n >= 0; n -= 4) out << hex(seed3, n);
   WriteVerify(out);
   out << endl;
   out.close();
}


WH::~WH()
{
   if (Update) CSTD();
   if (RNG == this) RNG = Dummy;
}






const char* MotherOfAll::Name() { return "MotherOfAll"; }



MotherOfAll::MotherOfAll(double s) : mStart(1)
{
   
   if (s>=1.0 || s<=0.0)
      Throw(Logic_error("Newran: seed out of range"));
   seed = (unsigned long)(s*2147483648.0);
   
   if (seed>2147483647 || seed==0)
      Throw(Logic_error("Newran: seed out of range"));
   Update = false;
}


#define m16Long 65536L           
#define m16Mask 0xFFFF           
#define m15Mask 0x7FFF           
#define m31Mask 0x7FFFFFFF       
#define m32Double  4294967295.0  



























void MotherOfAll::Mother()
{
   unsigned long  number, number1, number2;
   short n, *p;
   unsigned short sNumber;

   
   if (mStart)
   {
      sNumber = (unsigned short)(seed & m16Mask);   
      number = seed & m31Mask;                      

      p = mother1;
      for (n = 18; n--;)
      {
         number = 30903*sNumber + (number>>16); 
         *p++ = sNumber = (unsigned short)(number & m16Mask);
         if (n==9) p = mother2;
      }
      
      mother1[0] &= m15Mask; mother2[0] &= m15Mask; mStart = 0;
   }

   
   memmove(mother1+2, mother1+1, 8*sizeof(short));
   memmove(mother2+2, mother2+1, 8*sizeof(short));

   
   number1 = mother1[0]; number2 = mother2[0];

   
   number1 += 1941*mother1[2]+1860*mother1[3]+1812*mother1[4]+1776*mother1[5]+
      1492*mother1[6]+1215*mother1[7]+1066*mother1[8]+12013*mother1[9];
   number2 += 1111*mother2[2]+2222*mother2[3]+3333*mother2[4]+4444*mother2[5]+
      5555*mother2[6]+6666*mother2[7]+7777*mother2[8]+9272*mother2[9];

   
   mother1[0] = (short)(number1 / m16Long);
   mother2[0] = (short)(number2 / m16Long);
   
   mother1[1] = (short)(m16Mask & number1);
   mother2[1] = (short)(m16Mask & number2);

   
   seed = (((long)mother1[1]) << 16) + (long)mother2[1];

}

Real MotherOfAll::Next() { Mother(); return ((double)seed + 0.5) / 4294967296.0; }

unsigned long MotherOfAll::ulNext() { Mother(); return seed; }


void MotherOfAll::CSFD(bool update)
{
   Update = false;
   ifstream in((Dir+"mother.txt").c_str());
   ReadVerify(in);
   char x;
   for (int i = 0; i < 10; ++i)
   {
      int n; unsigned long m1 = 0, m2 = 0;
      for (n = 12; n >= 0; n -= 4) { in >> x; m1 |= unhex(x, n); }
      for (n = 12; n >= 0; n -= 4) { in >> x; m2 |= unhex(x, n); }
      mother1[i] = (short)m1;
      mother2[i] = (short)m2;
   }
   ReadVerify(in);
   in.close();
   mStart = 0;
   Update = update;
}

void MotherOfAll::CSTD()
{
   ifstream in; in.open((Dir+"lgm_mix.txt").c_str(), ios::in);
   ReadVerify(in, true); if (in) in.close();
   ofstream out((Dir+"mother.txt").c_str());
   WriteVerify(out);
   for (int i = 0; i < 10; ++i)
   {
      int n; unsigned long m1 = mother1[i], m2 = mother2[i];
      for (n = 12; n >= 0; n -= 4) out << hex(m1, n);
      for (n = 12; n >= 0; n -= 4) out << hex(m2, n);
   }
   WriteVerify(out);
   out << endl;
   out.close();
}


MotherOfAll::~MotherOfAll()
{
   if (Update) CSTD();
   if (RNG == this) RNG = Dummy;
}

#undef m16Long
#undef m16Mask
#undef m15Mask
#undef m31Mask
#undef m32Double






const char* MultWithCarry::Name() { return "MultWithCarry"; }

MultWithCarry::MultWithCarry(double s)
{
   if (s>=1.0 || s<=0.0)
      Throw(Logic_error("Newran: seed out of range"));
   x = (unsigned long)(s * 4294967296.0);
   crry = 1234567;
   Update = false;
}


#ifdef HAS_INT64

void MultWithCarry::NextValue()
{
   unsigned _int64 axc = (unsigned _int64)x * 2083801278 + crry;
   crry = (unsigned long)(axc >> 32);
   x = (unsigned long)axc;
}

#else



void MultWithCarry::NextValue()
{
   unsigned long  mult = 2083801278;
   unsigned long  m_hi = mult >> 16;
   unsigned long  m_lo = mult & 0xFFFF;

   unsigned long  x_hi = x >> 16;
   unsigned long  x_lo = x & 0xFFFF;

   unsigned long  c_hi = crry >> 16;
   unsigned long  c_lo = crry & 0xFFFF;

   x = x_lo * m_lo + c_lo;
   unsigned long axc = x_lo * m_hi + x_hi * m_lo + c_hi + (x >> 16);
   crry = x_hi * m_hi + (axc >> 16);

   x = (x & 0xFFFF) + (axc << 16);

}

#endif


Real MultWithCarry::Next() { NextValue(); return ((double)x + 0.5) / 4294967296.0; }

unsigned long MultWithCarry::ulNext() { NextValue(); return x; }



void MultWithCarry::CSFD(bool update)
{
   Update = false;
   ifstream in((Dir+"multwc.txt").c_str());
   ReadVerify(in);
   x = 0; crry = 0;
   char xx;
   int n;
   for (n = 28; n >= 0; n -= 4) { in >> xx; x |= unhex(xx, n); }
   for (n = 28; n >= 0; n -= 4) { in >> xx; crry |= unhex(xx, n); }
   ReadVerify(in);
   in.close();
   Update = update;
}

void MultWithCarry::CSTD()
{
   ifstream in; in.open((Dir+"lgm_mix.txt").c_str(), ios::in);
   ReadVerify(in, true); if (in) in.close();
   ofstream out((Dir+"multwc.txt").c_str());
   WriteVerify(out);
   int n;
   for (n = 28; n >= 0; n -= 4) out << hex(x, n);
   for (n = 28; n >= 0; n -= 4) out << hex(crry, n);
   WriteVerify(out);
   out << endl;
   out.close();
}

MultWithCarry::~MultWithCarry()
{
   if (Update) CSTD();
   if (RNG == this) RNG = Dummy;
}








#define N 624
#define M 397
#define MATRIX_A 0x9908b0dfUL   
#define UPPER_MASK 0x80000000UL 
#define LOWER_MASK 0x7fffffffUL 

static unsigned long mt[N]; 
static int mti=N+1;         


void MT::init_genrand(unsigned long s)
{
    mt[0]= s & 0xffffffffUL;
    for (mti=1; mti<N; mti++)
    {
        mt[mti] = (1812433253UL * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti); 
        
        
        
        
        mt[mti] &= 0xffffffffUL;
        
    }
}



unsigned long MT::genrand_int32()
{
    unsigned long y;
    static unsigned long mag01[2]={0x0UL, MATRIX_A};
    

    if (mti >= N)   
    {
        int kk;

        if (mti == N+1)           
            init_genrand(5489UL); 

        for (kk=0;kk<N-M;kk++)
        {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }

        for (;kk<N-1;kk++)
        {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }

        y = (mt[N-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
        mt[N-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];

        mti = 0;
    }
  
    y = mt[mti++];

    
    y ^= (y >> 11);
    y ^= (y << 7) & 0x9d2c5680UL;
    y ^= (y << 15) & 0xefc60000UL;
    y ^= (y >> 18);

    return y;
}


void MT::CSFD(bool update)
{
   Update = false;
   ifstream in((Dir+"mt19937.txt").c_str());
   ReadVerify(in);

   char xx;
   for (int i = 0; i < N; ++i)
   {
      unsigned long x = 0;
      for (int n = 28; n >= 0; n -= 4) { in >> xx; x |= unhex(xx, n); }
      mt[i] = x; 
   }
   mti = 0;
   for (int n = 28; n >= 0; n -= 4) { in >> xx; mti |= unhex(xx, n); }
   ReadVerify(in);
   in.close();
   Update = update;
}

void MT::CSTD()
{
   ifstream in; in.open((Dir+"lgm_mix.txt").c_str(), ios::in);
   ReadVerify(in, true); if (in) in.close();
   ofstream out((Dir+"mt19937.txt").c_str());
   WriteVerify(out);
   for (int i = 0; i < N; ++i)
   {
      unsigned long x = mt[i];
      for (int n = 28; n >= 0; n -= 4) out << hex(x, n);
   }
   for (int n = 28; n >= 0; n -= 4) out << hex(mti, n);

   WriteVerify(out);
   out << endl;
   out.close();
}

MT::MT(double s)
{
   init_genrand((unsigned long)(s*4294967296.0));
   Update = false;
}


Real MT::Next()
{
   return ((double)genrand_int32() + 0.5) / 4294967296.0; 
   
}


const char* MT::Name() { return "MT19937"; }

MT::~MT()
{
   if (Update) CSTD();
   if (RNG == this) RNG = Dummy;
}

#undef N
#undef M
#undef MATRIX_A
#undef UPPER_MASK
#undef LOWER_MASK











#define D31M1	2147483647L	
#define a	950706376.0	
#define a1	0x000038AAL	
#define a0	0x0000A0C8L	
#define	a1ma0	0xFFFF97E2L	

void FM::NextValue()
{
    unsigned long x = seed;
    unsigned long a1x1;
    unsigned long a0x0;
    unsigned long a1x0pa0x1;

    a1x1 = a1 * (x >> 16);
    a0x0 = a0 * (x & 0x0000FFFF);
    a1x0pa0x1 = a1ma0 * ((x & 0x0000FFFF) - (x >> 16) ) + a1x1 + a0x0;
    a1x1 += (a1x0pa0x1 >> 16);
    a0x0 += (a1x0pa0x1 << 16);
    if (a0x0 < (a1x0pa0x1 << 16)) a1x1++;
    x = (a1x1 << 1) + (a0x0 >> 31) + (a0x0 & 0x7FFFFFFF);
    if (x & 0x80000000) x -= D31M1;
    seed = x;
}

Real FM::Next() { NextValue(); return (double)seed / 2147483648.0; }

unsigned long FM::ulNext() { NextValue(); return seed << 1; }


const char* FM::Name() { return "Fishman Moore"; }

FM::FM(double s)
{
   if (s>=1.0 || s<=0.0)
      Throw(Logic_error("Newran: seed out of range"));
   seed = (unsigned long)(s*2147483648UL);
   Update = false;
}

void FM::CSFD(bool update)
{
   Update = false;
   ifstream in((Dir+"fm.txt").c_str());
   ReadVerify(in);
   unsigned long iseed = 0;
   char x;
   for (int n = 28; n >= 0; n -= 4) { in >> x; iseed |= unhex(x, n); }
   ReadVerify(in);
   in.close();
   seed = iseed;
   Update = update;
}

void FM::CSTD()
{
   ifstream in; in.open((Dir+"lgm_mix.txt").c_str(), ios::in);
   ReadVerify(in, true); if (in) in.close();
   ofstream out((Dir+"fm.txt").c_str());
   WriteVerify(out);
   unsigned long iseed = (unsigned long)seed;
   for (int n = 28; n >= 0; n -= 4) out << hex(iseed, n);
   WriteVerify(out);
   out << endl;
   out.close();
}


FM::~FM()
{
   if (Update) CSTD();
   if (RNG == this) RNG = Dummy;
}

#undef D31M1
#undef a
#undef a1
#undef a0
#undef a1ma0








const char* DummyRNG::Name() { return "DummyRNG"; }

Real DummyRNG::Next()
{
   Throw(Runtime_error("Newran: uniform rng not setup"));
#ifndef UseExceptions
   return 0;
#endif
}

void DummyRNG::CSFD(bool)
{
   Throw(Runtime_error("Newran: uniform rng not setup"));
}

void DummyRNG::CSTD()
{
   Throw(Runtime_error("Newran: uniform rng not setup"));
}


#ifdef use_namespace
}
#endif








































