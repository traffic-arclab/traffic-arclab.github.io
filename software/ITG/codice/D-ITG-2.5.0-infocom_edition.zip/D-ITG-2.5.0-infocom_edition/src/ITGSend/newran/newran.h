/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */







#ifndef NEWRAN_LIB
#define NEWRAN_LIB 0



#include "include.h"
#include "myexcept.h"
#include "extreal.h"
#include "simpstr.h"

#ifdef use_namespace
namespace NEWRAN { using namespace RBD_COMMON; }
namespace RBD_LIBRARIES { using namespace NEWRAN; }
namespace NEWRAN {
using RBD_COMMON::Real;
using RBD_COMMON::long_Real;
#endif


typedef Real (*PDF)(Real);


Real gamma_series(long_Real z);
inline Real gamma_g_value() { return 10.0; }
Real ln_gamma(Real z, int& sign);
Real ln_gamma(Real z);
Real ln_gamma_lanczos(Real z);
Real rbd_gamma(Real z);


class RepeatedRandom;
class SelectedRandom;


class Random                              
{

private:
   void operator=(const Random&) {}       

   virtual void CSFD(bool update) {}
   virtual void CSTD() {}

protected:
   static Random* RNG;                    
   static Random* Dummy;                  
   static SimpleString Dir;               

public:
   static void Set(Random& r);            
   static void CopySeedFromDisk(bool update=false);
   static void CopySeedToDisk();
   static void SetDirectory(const char* dir); 

   virtual Real Next() { return RNG->Next(); } 
   virtual unsigned long ulNext();        
   virtual const char* Name();            
   virtual Real Density(Real) const;      
   Random() {}                            
   virtual ~Random() {}                   
   SelectedRandom& operator()(double);    
   RepeatedRandom& operator()(int);       
   virtual ExtReal Mean() const { return 0.5; }
                                          
   virtual ExtReal Variance() const { return 1.0/12.0; }
					  
   virtual void tDelete() {}              
   virtual int nelems() const { return 1; }
                                          
   virtual void load(int*,Real*,Random**);
   friend class RandomPermutation;
};



class LGM_base : public Random
{
   void operator=(const LGM_base&) {}      
protected:
   long seed;
   void NextValue();
   bool Update;                            

public:
   LGM_base(double s);                     
   Real Next();                            
   unsigned long ulNext();                 
   const char* Name();                     
};


class LGM_simple : public LGM_base
{
   void operator=(const LGM_simple&) {}    
   void CSFD(bool update);
   void CSTD();

public:
   LGM_simple(double s=0.46875);           
   const char* Name();                     
   ~LGM_simple();
};


class LGM_mixed : public LGM_base
{
   long Buffer[128];                       
   void NextValue();
   long seed_mixed;
   void operator=(const LGM_mixed&) {}     
   void CSFD(bool update);
   void CSTD();

public:
   LGM_mixed(double s=0.46875);            
   Real Next();                            
   unsigned long ulNext();                 
   const char* Name();                     
   ~LGM_mixed();
};


class WH : public Random
{
   bool Update;                            
   void operator=(const WH&) {}            
   unsigned long seed1, seed2, seed3;
   void CSFD(bool update);
   void CSTD();

public:
   WH(double s=0.46875);                   
   Real Next();                            
   unsigned long ulNext();                 
   const char* Name();                     
   ~WH();
};


class FM : public Random
{
   bool Update;                            
   void operator=(const FM&) {}            
   unsigned long seed;
   void NextValue();
   void CSFD(bool update);
   void CSTD();

public:
   FM(double s=0.46875);                   
   Real Next();
   unsigned long ulNext();                 
   const char* Name();                     
   ~FM();
};


class MotherOfAll : public Random
{
   bool Update;                           
   short mother1[10];
   short mother2[10];
   short mStart;
   unsigned long seed;
   void Mother();
   void operator=(const MotherOfAll&) {}  
   void CSFD(bool update);
   void CSTD();

public:
   MotherOfAll(double s=0.9375);
   Real Next();
   unsigned long ulNext();                
   const char* Name();
   ~MotherOfAll();
};   


class MultWithCarry : public Random
{
   bool Update;                           
   unsigned long x;
   unsigned long crry;

   void NextValue();

   void operator=(MultWithCarry&) {}      
   void CSFD(bool update);
   void CSTD();

public:
   MultWithCarry(double s=0.46875);
   Real Next();
   unsigned long ulNext();                
   const char* Name();
   ~MultWithCarry();
};   


class MT : public Random
{
   bool Update;                           
   void init_genrand(unsigned long s);
   unsigned long genrand_int32();
   void operator=(const MT&) {}           
   void CSFD(bool update);
   void CSTD();

public:
   MT(double s=0.46875);
   Real Next();
   unsigned long ulNext() { return genrand_int32(); }
   const char* Name();
   ~MT();
};   



class DummyRNG : public Random
{
   void operator=(const DummyRNG&) {}    
   void CSFD(bool update);
   void CSTD();

public:
   Real Next();
   const char* Name();
};   



class Uniform : public Random
{
   void operator=(const Uniform&) {}      

public:
   const char* Name();                    
   Uniform() {}                           
   Real Next() { return RNG->Next(); }
   ExtReal Mean() const { return 0.5; }
   ExtReal Variance() const { return 1.0/12.0; }
   Real Density(Real x) const { return (x < 0.0 || x > 1.0) ? 0 : 1.0; }
};


class Constant : public Random
{
   void operator=(const Constant&) {}     
   Real value;                            

public:
   const char* Name();                    
   Constant(Real v) { value=v; }          
   Real Next() { return value; }
   ExtReal Mean() const { return value; }
   ExtReal Variance() const { return 0.0; }
};


class PosGen : public Random              
{
   void operator=(const PosGen&) {}       

protected:
   Real xi, *sx, *sfx;
   bool NotReady;
   void Build(bool);                      

public:
   const char* Name();                    
   PosGen();                              
   ~PosGen();                             
   Real Next();                           
   ExtReal Mean() const { return (ExtReal)Missing; }
   ExtReal Variance() const { return (ExtReal)Missing; }
};


class SymGen : public PosGen              
{
   void operator=(const SymGen&) {}       

public:
   const char* Name();                    
   Real Next();                           
};


class Normal : public SymGen              
{
   void operator=(const Normal&) {}       
   static Real Nxi, *Nsx, *Nsfx;          
   static long count;                     

public:
   const char* Name();                    
   Normal();
   ~Normal();
   Real Density(Real) const;              
   ExtReal Mean() const { return 0.0; }
   ExtReal Variance() const { return 1.0; }
};


class ChiSq : public Random               
{
   void operator=(const ChiSq&) {}        
   Random* c1;                            
   Random* c2;                            
   int version;                           
   Real mean, var;

public:
   const char* Name();                    
   ChiSq(int, Real=0.0);                  
   ~ChiSq();
   ExtReal Mean() const { return mean; }
   ExtReal Variance() const { return var; }
   Real Next();
};


class Cauchy : public SymGen              
{
   void operator=(const Cauchy&) {}       

public:
   const char* Name();                    
   Real Density(Real) const;              
   ExtReal Mean() const { return Indefinite; }
   ExtReal Variance() const { return PlusInfinity; }
};



class Exponential : public Uniform
{
  Uniform U;
  double mean;
  double variance;

public:

  Exponential(double md=1):mean(md){}
  Real Next();
  char* Name();			 		
  Real Density(Real) const; 			
  ExtReal Mean() const { return mean; }
  ExtReal Variance() const { return mean*mean; }
};

class Weibull : public Uniform
{
  Uniform U;
  double scale;
  double shape;
public:
  Weibull(double scale_, double shape_)
    {
      scale = scale_;
      shape = shape_;
    }
  Real Next();
  char* Name();
};


class Extreme_Largest : public Uniform
{
  Uniform U;
  double mu;
  double sigma;
public:
  Extreme_Largest(double mu_, double sigma_)
    {
      mu = mu_;
      sigma = sigma_;
    }
  Real Next();
  char* Name();
};


class Student : public Uniform
{
private:
  Real mu;
  Real sigma;
  Real nu;

public:
  Student(Real mu_, Real sigma_, Real nu_)
    {
      mu = mu_;
      sigma = sigma_;
      nu=nu_;
    }
  Real Next();
  char* Name();
};


class AsymGen : public Random             
{
   void operator=(const AsymGen&) {}      
   Real xi, *sx, *sfx; int ic;
   bool NotReady;
   void Build();                          

protected:
   Real mode;

public:
   const char* Name();                    
   AsymGen(Real);                         
   ~AsymGen();                            
   Real Next();                           
   ExtReal Mean() const { return (ExtReal)Missing; }
   ExtReal Variance() const { return (ExtReal)Missing; }
};


class Gamma : public Random               
{
   void operator=(const Gamma&) {}        
   Random* method;

public:
   const char* Name();                    
   Gamma(Real);                           
   ~Gamma() { delete method; }
   Real Next() { return method->Next(); }
   ExtReal Mean() const { return method->Mean(); }
   ExtReal Variance() const { return method->Variance(); }
};


class PosGenX : public PosGen
{
   void operator=(const PosGenX&) {}      
   PDF f;

public:
   const char* Name();                    
   PosGenX(PDF fx);
   Real Density(Real x) const { return (*f)(x); }
};


class SymGenX : public SymGen
{
   void operator=(const SymGenX&) {}      
   PDF f;

public:
   const char* Name();                    
   SymGenX(PDF fx);
   Real Density(Real x) const { return (*f)(x); }
};


class AsymGenX : public AsymGen
{
   void operator=(const AsymGenX&) {}     
   PDF f;

public:
   const char* Name();                          
   AsymGenX(PDF fx, Real mx);
   Real Density(Real x) const { return (*f)(x); }
};




class Pareto : public Random
{
   void operator=(const Pareto&) {}       
   Real Shape, RS;

public:
   const char* Name();                    
   Pareto(Real shape);                    
   ~Pareto() {}
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
};


class DiscreteGen : public Random
{
   void operator=(const DiscreteGen&) {}  
   Real *p; int *ialt; int n; Real *val;
   void Gen(int, Real*);                  
   Real mean, var;                        

public:
   const char* Name();                    
   DiscreteGen(int,Real*);                
   DiscreteGen(int,Real*,Real*);          
   ~DiscreteGen();                        
   Real Next();                           
   ExtReal Mean() const { return mean; }
   ExtReal Variance() const { return var; }
};


class Poisson : public Random             
{
   void operator=(const Poisson&) {}      
   Random* method;

public:
   const char* Name();                    
   Poisson(Real);                         
   ~Poisson() { delete method; }
   Real Next() { return method->Next(); }
   ExtReal Mean() const { return method->Mean(); }
   ExtReal Variance() const { return method->Variance(); }
};


class Binomial : public Random            
{
   void operator=(const Binomial&) {}     
   Random* method;

public:
   const char* Name();                    
   Binomial(int p, Real n);               
   ~Binomial() { delete method; }
   Real Next() { return method->Next(); }
   ExtReal Mean() const { return method->Mean(); }
   ExtReal Variance() const { return method->Variance(); }
};


class NegativeBinomial : public AsymGen   
{
   Real N, P, Q, p, ln_q, c;

public:
   const char* Name();
   NegativeBinomial(Real NX, Real PX);    
   Real Density(Real) const;              
   Real Next();
   ExtReal Mean() const { return N * P; }
   ExtReal Variance() const { return N * P * Q; }
};


class Stable : public Random
{
public:
   enum Notation { Chambers, Standard, Kalpha, Default };
private:
   Real alpha, bprime;
   Real beta;
   Notation notation;
   Real d2(Real z);
   Real tan2(Real x);
   Real k(Real a);
   const Real piby2;
   const Real piby4;

public:
   const char* Name();
   Stable(Real a, Real bx, Notation n = Default);
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   Real beta_prime() const { return bprime; }
};   






class NegatedRandom : public Random
{
protected:
   Random* rv;
   NegatedRandom(Random& rvx) : rv(&rvx) {}
   void tDelete() { rv->tDelete(); delete this; }

public:
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   friend NegatedRandom& operator-(Random&);
};



class ScaledRandom : public Random
{
protected:
   Random* rv; Real s;
   ScaledRandom(Random& rvx, Real sx) : rv(&rvx), s(sx) {}
   void tDelete() { rv->tDelete(); delete this; }

public:
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   friend ScaledRandom& operator*(Real, Random&);
   friend ScaledRandom& operator*(Random&, Real);
   friend ScaledRandom& operator/(Random&, Real);
};



class ReciprocalRandom : public Random
{
protected:
   Random* rv; Real s;
   ReciprocalRandom(Random& rvx, Real sx) : rv(&rvx), s(sx) {}
   void tDelete() { rv->tDelete(); delete this; }

public:
   Real Next();
   ExtReal Mean() const { return Missing; }
   ExtReal Variance() const { return Missing; }
   friend ReciprocalRandom& operator/(Real, Random&);
};



class ShiftedRandom : public ScaledRandom
{
   ShiftedRandom(Random& rvx, Real sx) : ScaledRandom(rvx, sx) {}

public:
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   friend ShiftedRandom& operator+(Real, Random&);
   friend ShiftedRandom& operator+(Random&, Real);
   friend ShiftedRandom& operator-(Random&, Real);
};



class ReverseShiftedRandom : public ScaledRandom
{
   ReverseShiftedRandom(Random& rvx, Real sx) : ScaledRandom(rvx, sx) {}

public:
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   friend ReverseShiftedRandom& operator-(Real, Random&);
};



class RepeatedRandom : public Random
{
   Random* rv; int n;
   void tDelete() { rv->tDelete(); delete this; }
   RepeatedRandom(Random& rvx, int nx)  : rv(&rvx), n(nx) {}

public:
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   friend class Random;
};



class MultipliedRandom : public Random
{
protected:
   Random* rv1; Random* rv2;
   void tDelete() { rv1->tDelete(); rv2->tDelete(); delete this; }
   MultipliedRandom(Random& rv1x, Random& rv2x) : rv1(&rv1x), rv2(&rv2x) {}

public:
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   friend MultipliedRandom& operator*(Random&, Random&);
};



class AddedRandom : public MultipliedRandom
{
   AddedRandom(Random& rv1x, Random& rv2x) : MultipliedRandom(rv1x, rv2x) {}

public:
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   friend AddedRandom& operator+(Random&, Random&);
};



class SubtractedRandom : public MultipliedRandom
{
   SubtractedRandom(Random& rv1x, Random& rv2x)
      : MultipliedRandom(rv1x, rv2x) {}

public:
   Real Next();
   ExtReal Mean() const;
   ExtReal Variance() const;
   friend SubtractedRandom& operator-(Random&, Random&);
};



class DividedRandom : public MultipliedRandom
{
   DividedRandom(Random& rv1x, Random& rv2x)
      : MultipliedRandom(rv1x, rv2x) {}

public:
   Real Next();
   ExtReal Mean() const { return Missing; }
   ExtReal Variance() const { return Missing; }
   friend DividedRandom& operator/(Random&, Random&);
};


class SumRandom : public Random
{
   void operator=(const SumRandom&) {}    
   Random* rv;

public:
   const char* Name();                    
   SumRandom(NegatedRandom& rvx) : rv(&rvx) {}
   SumRandom(AddedRandom& rvx) : rv(&rvx) {}
   SumRandom(MultipliedRandom& rvx) : rv(&rvx) {}
   SumRandom(SubtractedRandom& rvx) : rv(&rvx) {}
   SumRandom(DividedRandom& rvx) : rv(&rvx) {}
   SumRandom(ShiftedRandom& rvx) : rv(&rvx) {}
   SumRandom(ReverseShiftedRandom& rvx) : rv(&rvx) {}
   SumRandom(ScaledRandom& rvx) : rv(&rvx) {}
   SumRandom(ReciprocalRandom& rvx) : rv(&rvx) {}
   SumRandom(RepeatedRandom& rvx) : rv(&rvx) {}
   Real Next() { return rv->Next(); }
   ExtReal Mean() const { return rv->Mean(); }
   ExtReal Variance() const { return rv->Variance(); }
   ~SumRandom() { rv->tDelete(); }
};





class SelectedRandom : public Random
{
   friend class Random;
   Random* rv; Real p;
   SelectedRandom(Random& rvx, Real px) : rv(&rvx), p(px) {}
   void tDelete() { rv->tDelete(); delete this; }

public:
   void load(int*, Real*, Random**);
   Real Next();
};



class AddedSelectedRandom : public Random
{
   friend class Random;
protected:
   Random* rv1; Random* rv2;
   AddedSelectedRandom(Random& rv1x, Random& rv2x)
      : rv1(&rv1x), rv2(&rv2x) {}
   void tDelete() { rv1->tDelete(); rv2->tDelete(); delete this; }

public:
   int nelems() const;
   void load(int*, Real*, Random**);
   Real Next();
   friend AddedSelectedRandom& operator+(SelectedRandom&,
      SelectedRandom&);
   friend AddedSelectedRandom& operator+(AddedSelectedRandom&,
      SelectedRandom&);
   friend AddedSelectedRandom& operator+(SelectedRandom&,
      AddedSelectedRandom&);
   friend AddedSelectedRandom& operator+(AddedSelectedRandom&,
      AddedSelectedRandom&);
};


class MixedRandom : public Random 
{
   void operator=(const MixedRandom&) {}  
   int n;                                 
   DiscreteGen* dg;                       
   Random** rv;                           
   ExtReal mean, var;
   void Build(Real*);                     

public:
   const char* Name();                    
   MixedRandom(int, Real*, Random**);
   MixedRandom(AddedSelectedRandom&);
   ~MixedRandom();
   Real Next();
   ExtReal Mean() const { return mean; }
   ExtReal Variance() const { return var; }
};


class RandomPermutation
{
   Random U;

public:
   void Next(int N, int M, int p[], int start = 0);
                                          
                                          
                                          
   void Next(int N, int p[], int start = 0) { Next(N, N, p, start); }
};



class RandomCombination : public RandomPermutation
{
   void SortAscending(int n, int gm[]);

public:
   void Next(int N, int M, int p[], int start = 0)
      { RandomPermutation::Next(N, M, p, start); SortAscending(M, p); }
   void Next(int N, int p[], int start = 0) { Next(N, N, p, start); }
};


class VariPoisson
{
   Uniform U;
   Normal N;
   Poisson P100;
   Poisson P200;
   Real Next_very_small(Real mu);
   Real Next_small(Real mu);
   Real Next_large(Real mu);
public:
   VariPoisson();
   int iNext(Real mu);
   Real Next(Real mu);
};


class VariBinomial
{
   Uniform U;
   Normal N;
   Real Next_very_small(int n, Real p);
   Real Next_small(int n, Real p);
   Real Next_large(int n, Real p);
public:
   VariBinomial();
   int iNext(int n, Real p);
   Real Next(int n, Real p);
};


class VariLogNormal
{
   Normal N;
public:
   VariLogNormal() {}
   Real Next(Real mean, Real sd);
};


NegatedRandom& operator-(Random&);
ScaledRandom& operator*(Real, Random&);
ScaledRandom& operator*(Random&, Real);
ScaledRandom& operator/(Random&, Real);
ReciprocalRandom& operator/(Real, Random&);
ShiftedRandom& operator+(Real, Random&);
ShiftedRandom& operator+(Random&, Real);
ShiftedRandom& operator-(Random&, Real);
ReverseShiftedRandom& operator-(Real, Random&);
MultipliedRandom& operator*(Random&, Random&);
AddedRandom& operator+(Random&, Random&);
SubtractedRandom& operator-(Random&, Random&);
DividedRandom& operator/(Random&, Random&);
AddedSelectedRandom& operator+(SelectedRandom&, SelectedRandom&);
AddedSelectedRandom& operator+(AddedSelectedRandom&, SelectedRandom&);
AddedSelectedRandom& operator+(SelectedRandom&, AddedSelectedRandom&);
AddedSelectedRandom& operator+(AddedSelectedRandom&, AddedSelectedRandom&);




#ifdef use_namespace
}
#endif

#endif






