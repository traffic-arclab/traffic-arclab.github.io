/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */









#ifndef SIMPLE_STRING_LIB
#define SIMPLE_STRING_LIB

#ifdef use_namespace
namespace RBD_COMMON {
#endif



class SimpleString
{
   char* S;        
   unsigned int n; 
public:
   SimpleString();
   ~SimpleString() { delete [] S; }
   SimpleString(const SimpleString& s);
   SimpleString(const char* c);
   SimpleString(unsigned int i, char c);
   void operator=(const SimpleString& s);
   void operator=(const char*);
   void operator=(char);
   void operator+=(const SimpleString& s);
   void operator+=(const char*);
   void operator+=(char);
   friend SimpleString operator+(const SimpleString& s1, const SimpleString& s2);
   friend SimpleString operator+(const char* c1, const SimpleString& s2);
   friend SimpleString operator+(const SimpleString& s1, const char* c2);
   friend SimpleString operator+(char c1, const SimpleString& s2);
   friend SimpleString operator+(const SimpleString& s1, char c2);
   unsigned int length() const { return n; }
   unsigned int size() const { return n; }
   const char* c_str() const { return S; }
   const char* data() const { return S; }
};

#ifdef use_namespace
}
#endif


#endif                             







