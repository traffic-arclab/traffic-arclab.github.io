/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */







#define WANT_STREAM

#include "newran.h"

#ifdef use_namespace
using namespace NEWRAN;
#endif


int main()
{

   Try
   {
      bool copy_seed_from_disk = false;    


      Random::SetDirectory("c:\\seed\\");  
 
      MotherOfAll urng;                    

      Random::Set(urng);                   

      if (copy_seed_from_disk)
         Random::CopySeedFromDisk(true);   

      Normal normal;                       
     
      for (int i = 1; i <= 10; ++i)        
         cout << setprecision(5) << setw(10) << normal.Next() << endl;

   }
   Catch(BaseException)
   {
      cout << "\nTest program fails - exception generated\n\n";
      cout << BaseException::what() << "\n";
   }
   CatchAll
   {
      cout << "\nTest program fails - exception generated\n\n"; 
   }

   return 0;
}




