/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */



















#ifndef UTILITY_H
#define UTILITY_H

#ifdef use_namespace
using namespace RBD_COMMON;
#endif


inline double square(double x) { return x*x; }  

inline double cube(double x) { return x*x*x; }  

inline long iround(double x) { return (long)floor(x + 0.5); }
                                                



double invchi95(int N);



double invchi99(int N);



double invchi999(int N);



Real invchi(Real p, int df, bool upper = false);



double cdfnml(double x);


double invcdfnml(double p);



double cdf_chisq(double x, int df, bool upper=false);



double KS_probabilities(double z);




class time_lapse
{
   double start_time;
public:
   time_lapse();
   ~time_lapse();
};





#endif






