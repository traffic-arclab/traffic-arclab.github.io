/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */








#ifndef EXTREAL_LIB
#define EXTREAL_LIB 0

#ifdef use_namespace
namespace RBD_COMMON {
#endif



enum EXT_REAL_CODE
   { Finite, PlusInfinity, MinusInfinity, Indefinite, Missing };

class ExtReal
{
   Real value;
   EXT_REAL_CODE c;
public:
   ExtReal operator+(const ExtReal&) const;
   ExtReal operator-(const ExtReal&) const;
   ExtReal operator*(const ExtReal&) const;
   ExtReal operator-() const;
   friend ostream& operator<<( ostream&, const ExtReal& );
   ExtReal(Real v) { c=Finite; value=v; }
   ExtReal(const EXT_REAL_CODE& cx) { c = cx; }
   ExtReal() { c = Missing; }
   Real Value() const { return value; }
   bool IsReal() const { return c==Finite; }
   EXT_REAL_CODE Code() const { return c; }
};

#ifdef use_namespace
}
#endif


#endif






