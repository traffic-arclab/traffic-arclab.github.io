/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */









#ifndef TEST_OUT
#define TEST_OUT

#ifdef use_namespace
using namespace RBD_STRING;
using namespace RBD_COMMON;
namespace NEWRAN {
#endif



class BaseTest
{
public:
   double SigProb;                        
protected:
   const String LongName;                 
   double Statistic;                      
   void WrapUp(double sig_prob);          
public:
   BaseTest(const String& ln, double stat)
      : LongName(ln), Statistic(stat) {}
   virtual void DoTest() = 0;             
   static const char* Header;
   virtual ~BaseTest() {}
};




class NormalTestUpper : public BaseTest
{
   double Mean, Var;
public:
   NormalTestUpper(const String& ln, double stat, double mean, double var)
      : BaseTest(ln, stat), Mean(mean), Var(var) {}
   void DoTest();                         
};



class NormalTestTwoSided : public BaseTest
{
   double Mean, Var;
public:
   NormalTestTwoSided(const String& ln, double stat, double mean, double var)
      : BaseTest(ln, stat), Mean(mean), Var(var) {}
   void DoTest();                         
};



class ChiSquaredTestUpper : public BaseTest
{
   int DF;
public:
   ChiSquaredTestUpper(const String& ln, double stat, int df)
      : BaseTest(ln, stat), DF(df) {}
   void DoTest();                         
};



class ChiSquaredTestLower : public BaseTest
{
   int DF;
public:
   ChiSquaredTestLower(const String& ln, double stat, int df)
      : BaseTest(ln, stat), DF(df) {}
   void DoTest();                         
};



class ChiSquaredTestTwoSided : public BaseTest
{
   int DF;
public:
   ChiSquaredTestTwoSided(const String& ln, double stat, int df)
      : BaseTest(ln, stat), DF(df) {}
   void DoTest();                         
};



class QuasiUniformLower : public BaseTest
{
public:
   QuasiUniformLower(const String& ln, double stat)
      : BaseTest(ln, stat) {}
   void DoTest();                         
};



class UniformLower : public BaseTest
{
public:
   UniformLower(const String& ln, double stat)
      : BaseTest(ln, stat) {}
   void DoTest();                         
};



class KS_Upper : public BaseTest
{
public:
   KS_Upper(const String& ln, double stat)
      : BaseTest(ln, stat) {}
   void DoTest();                         
};

#ifdef use_namespace
}
#endif


#endif








