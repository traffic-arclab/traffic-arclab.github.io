 /*	Component of the D-ITG 2.4 Platform
 *
 * 	
 *	copyright	: (C) 2004  	by Stefano Avallone, Alessio Botta, Donato Emma, 
 *					Salvatore Guadagno, Antonio Pescape'
 *					DIS Dipartimento di Informatica e Sistemistica				 
 *					(Computer Science Department)
 *					University of Naples "Federico II"	
 *	email:		: {stavallo, pescape}@unina.it, {abotta, demma, sguadagno}@napoli.consorzio-cini.it
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */
 
 


#include "../common/ITG.h"
#include "../common/thread.h"
#include "ITGLog.h"
#include "channel.h"



void logPacketTCP(int newSockSignal, ofstream * out)
{
	
	int port;
	
	
	int newSockLog;
	
	
	struct sockaddr_in sockAddress;
	
	
	struct sockaddr_in srcAddress;

	
	
	
	int logSock, hold;
	
	
	struct info *infos = (struct info *) malloc(DIM * sizeof(info));
	
	
	socklen_t sinLen = sizeof(srcAddress);
	
	
	
	
	fd_set activeSet;

#ifdef DEBUG    
	
    int numRecvdPkt=0;
    
	
    int numTrip=0;
#endif

	

	
	sockAddress.sin_family = AF_INET;
	
	sockAddress.sin_addr.s_addr = htonl(INADDR_ANY);

	

    createDataChannel(sockAddress,newSockSignal,logSock,port,"TCP");

	
	if (listen(logSock, 5) < 0) 
		reportErrorAndExit("logPacketTCP","listen","Error into listen on logSock");
	

	
	newSockLog = accept(logSock, (struct sockaddr *) &srcAddress, &sinLen);
#ifdef DEBUG
	printf("newSockLog TCP : %d \n",newSockLog);
#endif
	if (newSockLog < 0) 
		reportErrorAndExit("logPacketTCP","accept","Error into accept on logSock");

	

	while (1) {
		
		FD_ZERO(&activeSet);
		
		FD_SET((unsigned int)newSockSignal, &activeSet);
		
		FD_SET((unsigned int)newSockLog, &activeSet);

		
		if (select(FD_SETSIZE, &activeSet, NULL, NULL, 0) < 0)
			reportErrorAndExit("logPacketTCP","select",
			"Invalid file descriptor or operation interrupted by a signal - Close first Receiver");
		
		if (FD_ISSET(newSockSignal, &activeSet)) {
			
			break;
		
		} else if (FD_ISSET(newSockLog, &activeSet)) {
			
			hold = recv(newSockLog, (char *) infos, DIM * sizeof(struct info), 0);
#ifdef DEBUG
           		numRecvdPkt = numRecvdPkt + hold / sizeof(struct info);
			numTrip++;
#endif
			
			if (hold < 0)
				printf("** WARNING **  Data lost - Close First Receiver!\n");
			
			else if (!(*out).write((char *) infos, hold))
				printf("** WARNING **  Can't write data!\n");
		}
	}
	
#ifdef DEBUG
	
	char hostName[50];
	
	char hostIP[20];
	int rit1 = getnameinfo((sockaddr*)&senderLog,sizeof(senderLog),hostName, INET_ADDRSTRLEN, NULL, 0,
			NI_NOFQDN);
	int rit2 = getnameinfo((sockaddr*)&senderLog,sizeof(senderLog),hostIP, INET_ADDRSTRLEN, NULL, 0,
			NI_NUMERICHOST);
	if ((rit1 == 0) & (rit2 == 0))
		printf("Data transmission ended on TCP channel from %s(%s)\n",hostName,hostIP);
	else if ((rit1 != 0) & (rit2 == 0))
			printf("Data transmission ended on TCP channel from %s\n",hostIP);
	else
#endif
	printf("Data transmission ended on TCP channel!\n");

	
	free(infos);
	if (closeSock(logSock) < 0)
		reportErrorAndExit("logPacketTCP","closeSock","Cannot close logSock");
	if (closeSock(newSockLog) < 0)
		reportErrorAndExit("logPacketTCP","closeSock","Cannot close newLogSock");
#ifdef DEBUG
	printf("Number of received packets : %d \n",numRecvdPkt);
	printf("Number of received infos : %d \n",numTrip);
#endif
}



void logPacketUDP(int newSockSignal, ofstream * out)
{
	
	int port;

	
	struct sockaddr_in sockAddress;
	
	
	
	
	int logSock, hold;
	
	
	struct info *infos = (struct info *) malloc(DIM * sizeof(info));

	
	
	
	fd_set  activeSet;

#ifdef DEBUG
	
    int numRecvdPkt=0;

	
    int numTrip=0;
#endif

	

	
	sockAddress.sin_family = AF_INET;
	
	sockAddress.sin_addr.s_addr = htonl(INADDR_ANY);

	

	createDataChannel(sockAddress,newSockSignal,logSock,port,"UDP");

	

	while (1) {
		
		FD_ZERO(&activeSet);
		
		FD_SET((unsigned int)newSockSignal, &activeSet);
		
		FD_SET((unsigned int)logSock, &activeSet);


		
		if (select(FD_SETSIZE, &activeSet, NULL, NULL, 0) < 0)
			reportErrorAndExit("logPacketUDP","select",
			"Invalid file descriptor or operation interrupted by a signal - Close first Receiver");
		
		if (FD_ISSET(newSockSignal, &activeSet)) {
			
			break;
		
		} else if (FD_ISSET(logSock, &activeSet)) {
			
			hold = recv(logSock, (char *) infos, DIM * sizeof(struct info), 0);

#ifdef DEBUG
			numRecvdPkt = numRecvdPkt + hold / sizeof(struct info);
			numTrip++;
#endif
			
			if (hold < 0)
				printf("** WARNING ** Data lost - Close First Receiver!\n");
			
			if (!(*out).write((char *) infos, hold))
				printf("** WARNING ** Can't write data!\n");
		}
	}

#ifdef DEBUG
	
	char hostName[50];
	
	char hostIP[20];
	int rit1 = getnameinfo((sockaddr*)&senderLog,sizeof(senderLog),hostName, INET_ADDRSTRLEN, NULL, 0,
			NI_NOFQDN);
	int rit2 = getnameinfo((sockaddr*)&senderLog,sizeof(senderLog),hostIP, INET_ADDRSTRLEN, NULL, 0,
			NI_NUMERICHOST);
	if ((rit1 == 0) & (rit2 == 0))
		printf("Data transmission ended on UDP channel from %s(%s)\n",hostName,hostIP);
	else if ((rit1 != 0) & (rit2 == 0))
			printf("Data transmission ended on UDP channel from %s\n",hostIP);
	else
#endif
	printf("Data transmission ended on UDP channel\n");

	
	free(infos);
	if (closeSock(logSock) < 0)
		reportErrorAndExit("logPacketUDP","closeSock","Cannot close logSock");
#ifdef DEBUG
	printf("Number of received packets : %d \n",numRecvdPkt);
	printf("Number of received infos : %d \n",numTrip);
#endif
}



void createDataChannel(sockaddr_in sockAddress,int newSockSignal,int &logSock,int &port,
					   char* protocolName) 
{
	
	char msg[100];

	
	int size;

	if (strcmp(protocolName, "TCP") == 0)
	{
		
		logSock = socket(PF_INET, SOCK_STREAM, 0);
#ifdef DEBUG
		printf("logSock TCP : %d \n", logSock);
#endif
		if (logSock < 0) 
			reportErrorAndExit("createDataChannel","socket","Cannot create STREAM socket");
	}
	else 
	{
		
		logSock = socket(PF_INET, SOCK_DGRAM, 0);
#ifdef DEBUG
		printf("logSock UDP : %d \n", logSock);
#endif
		if (logSock < 0) 
			reportErrorAndExit("createdataChannel","socket","Cannot create DATAGRAM socket");
	}

	
	port = findPortFree(logSock);
#ifdef DEBUG
    printf("Port : %d \n", port);
#endif
	if (port == 1 ) 
		reportErrorAndExit("createDataChannel","findPortFree","Cannot find a port free");
	
	memcpy(msg, &port, sizeof(int));
	
	size = sendto(newSockSignal, (const char *) &msg, sizeof(int), 0,
	    (struct sockaddr *) &senderLog, sizeof(senderLog));
#ifdef DEBUG
    printf("Size bytes sent: %d \n", size);
#endif
	if (size < 0)
		reportErrorAndExit("createDataChannel","sendto","Cannot send port on newSockSignal");
	printf("Receiving data on port: %d \n", port);
}
