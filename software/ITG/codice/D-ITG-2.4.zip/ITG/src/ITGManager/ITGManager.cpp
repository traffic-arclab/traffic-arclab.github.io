 /*	Component of the D-ITG 2.4 Platform
 *
 * 	
 *	copyright	: (C) 2004  	by Stefano Avallone, Alessio Botta, Donato Emma, 
 *					Salvatore Guadagno, Antonio Pescape'
 *					DIS Dipartimento di Informatica e Sistemistica				 
 *					(Computer Science Department)
 *					University of Naples "Federico II"	
 *	email:		: {stavallo, pescape}@unina.it, {abotta, demma, sguadagno}@napoli.consorzio-cini.it
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */
 
 
#include "../libITG/ITGapi.h"
#include <stdio.h>
#include <string.h>

int main()
{
	char *sender, *msg;
	int i;
	char command[] = "-C 10 -c 1001 -sp 9005 -rp 9006 -t 5000 -a 127.0.0.1";
	DITGsend("localhost", command);

	do {
		if ((i = catchManagerMsg(&sender, &msg)) != MNG_NOMSG)
			printf("Received msg type %d   %s   %s\n", i, sender, msg);
 } while (1);
}
