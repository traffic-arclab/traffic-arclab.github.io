 /*	Component of the D-ITG 2.4 Platform
 *
 * 	
 *	copyright	: (C) 2004  	by Stefano Avallone, Alessio Botta, Donato Emma, 
 *					Salvatore Guadagno, Antonio Pescape'
 *					DIS Dipartimento di Informatica e Sistemistica				 
 *					(Computer Science Department)
 *					University of Naples "Federico II"	
 *	email:		: {stavallo, pescape}@unina.it, {abotta, demma, sguadagno}@napoli.consorzio-cini.it
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */
 
 


#include "../common/ITG.h"
#include "newran/newran.h"	

#ifdef LINUX_OS
#include <netdb.h>
#include <sys/wait.h>
#include <math.h>
#include <netinet/tcp.h>	
#include <netinet/ip.h>
#include <sys/timeb.h>
#include <sys/shm.h>
#include <pthread.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#endif
#ifdef WIN32
#include <math.h>
#include <sys/timeb.h>
#include <time.h>
static LARGE_INTEGER freq;
#include <signal.h>
#endif

#include "traffic.h"
#include "ITGSend.h"

const char *DistroStrings[] = { "Constant", "Uniform", "Exponential", "Pareto",
	"Cauchy", "Normal", "Poisson", "Gamma", "Telnet" };

const unsigned int DefaultPktPerSec = 1000;
const unsigned int DefaultPktSize = 512;
const unsigned long DefaultDuration = 10000;
const unsigned long DefaultDelay = 0;
const int MinPayloadSize = 2 * (sizeof(unsigned int) + sizeof(long int));


Constant *ConstantRV;
Uniform *UniformRV;
Exponential *ExponentialRV;
Pareto *ParetoRV;
Cauchy *CauchyRV;
Normal *NormalRV;
Poisson *PoissonRV;
Gamma *GammaRV;

void telnetParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro)
{
	int numval = 15;
	Real prob[] =
	    { 0.65, 0.13, 0.07, 0.05, 0.03, 0.01, 0.01, 0.01, 0.01, 0.005, 0.005, 0.005, 0.005,
		    0.005, 0.005 };
	
	ParetoRV = new Pareto(0.95);
	IntArrivDistro = pdPareto;
	delete(*pIntArriv);
	*pIntArriv = new SumRandom(1.1 * (*ParetoRV));
	
	PktSizeDistro = pdTelnet;
	delete(*pPktSize);
	static DiscreteGen D(numval, prob);
	*pPktSize = new SumRandom(D + 21);
}

void voIPParser(int h, char *argv[], int &argc, unsigned int flowId, SumRandom ** pIntArriv,
    SumRandom ** pPktSize, TDistro & IntArrivDistro, TDistro & PktSizeDistro)
{
	char codec[10];
	
	strcpy(codec, "G.711.1");
	Real samples = 1.0;
	Real framesize = 80.0;
	Real VAD = 1.0;
	Real header = 12.0;
	Real pkts = 100.0;
	argv++;
	argc--;
	while (argc > 0) {
		if (argv[h][0] == '-') {
			char *tail;
			switch (argv[h][1]) {
			case 'x':
				if (argc < 2)
					ReportErrorAndExit("VoIP parser", "Invalid Codec Type",
					    programName, flowId);
				if (strcmp(argv[h + 1], "G.711.1") == 0) {
					strcpy(codec, "G.711");
					framesize = 80.0;
					samples = 1.0;
					pkts = 100.0;
				} else if (strcmp(argv[h + 1], "G.711.2") == 0) {
					strcpy(codec, "G.711");
					framesize = 80.0;
					samples = 2.0;
					pkts = 50.0;
				} else if (strcmp(argv[h + 1], "G.729.2") == 0) {
					strcpy(codec, "G.729");
					framesize = 10.0;
					samples = 2.0;
					pkts = 50.0;
				} else if (strcmp(argv[h + 1], "G.729.3") == 0) {
					strcpy(codec, "G.729");
					framesize = 10.0;
					samples = 3.0;
					pkts = 33.0;
				} else if (strcmp(argv[h + 1], "G.723.1") == 0) {
					strcpy(codec, argv[h + 1]);
					framesize = 30.0;
					samples = 1.0;
					pkts = 26.0;
				} else
					ReportErrorAndExit("VoIP parser", "Invalid Codec Type",
					    programName, flowId);
				
				h += 2;
				argc -= 2;
				break;
			case 'h':
				if (argc < 2)
					ReportErrorAndExit("VoIP parser", "Invalid Protocol Type",
					    programName, flowId);
				if (strcmp(argv[h + 1], "RTP") == 0)
					header = 8.0;
				else if (strcmp(argv[h + 1], "CRTP") == 0)
					header = 2;
				else
					ReportErrorAndExit("VoIP parser",
					    "Invalid Protocol Type (RTP or CRTP)", programName,
					    flowId);
				h += 2;
				argc -= 2;
				break;
			case 'V':
				if ((argv[h][2] == 'A') && (argv[h][3] == 'D'))    
					VAD = 0.65;
				else
					ReportErrorAndExit("VoIP parser", "Invalid Option (VAD)",
					    programName, flowId);
				h += 1;
				argc -= 1;
				break;
			default:
				tail = (char *) malloc(sizeof("Unknown option ") + sizeof(argv[0]));
				ReportErrorAndExit("VoIP parser",
				    strcat(strcpy(tail, "Unknown option "), argv[0]),
				    programName, flowId);
				break;
			}
		} else {
			char temp[sizeof("What is  ?") + sizeof(argv[h])];
			ReportErrorAndExit("VoIP parser",
			    strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"),
			    programName, flowId);
		}
	}
	delete(*pPktSize);
	PktSizeDistro = pdConstant;
	ConstantRV = new Constant(1);
	*pPktSize = new SumRandom((VAD * framesize * samples) * (*ConstantRV) + header);
	delete(*pIntArriv);
	IntArrivDistro = pdConstant;
	ConstantRV = new Constant(1);
	*pIntArriv = new SumRandom(1000.0 / pkts * (*ConstantRV));
	printf
	    ("Voice Codec: %s\t\nFramesize: %4.2f\t\nSamples: %4.0f\t\nPackets per sec.: %4.0f\t\n",
	    codec, framesize, samples, pkts);
	if (VAD == 1)
		printf("VAD: No\n");
	else
		printf("VAD: Si\n");
}

void dnsParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro)
{
	
	delete(*pIntArriv);
	IntArrivDistro = pdConstant;
	ConstantRV = new Constant(1);
	*pIntArriv = new SumRandom(1000.0 / 0.56 * (*ConstantRV));

	
	delete(*pPktSize);
	PktSizeDistro = pdUniform;
	UniformRV = new Uniform;
	*pPktSize = new SumRandom(220.0 * (*UniformRV) + 100.0);
}

