 /*	Component of the D-ITG 2.4 Platform
 *
 * 	
 *	copyright	: (C) 2004  	by Stefano Avallone, Alessio Botta, Donato Emma, 
 *					Salvatore Guadagno, Antonio Pescape'
 *					DIS Dipartimento di Informatica e Sistemistica				 
 *					(Computer Science Department)
 *					University of Naples "Federico II"	
 *	email:		: {stavallo, pescape}@unina.it, {abotta, demma, sguadagno}@napoli.consorzio-cini.it
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */
 
 


typedef enum TDistro { pdConstant, pdUniform, pdExponential, pdPareto, pdCauchy,
	pdNormal, pdPoisson, pdGamma, pdTelnet };

extern const char *DistroStrings[];
extern const unsigned int DefaultPktPerSec;
extern const unsigned int DefaultPktSize;
extern const unsigned long DefaultDuration;
extern const unsigned long DefaultDelay;
extern const int MinPayloadSize;

extern Constant *ConstantRV;
extern Uniform *UniformRV;
extern Exponential *ExponentialRV;
extern Pareto *ParetoRV;
extern Cauchy *CauchyRV;
extern Normal *NormalRV;
extern Poisson *PoissonRV;
extern Gamma *GammaRV;

void telnetParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);
void voIPParser(int h, char *argv[], int &argc, unsigned int flowId, SumRandom ** pIntArriv,
    SumRandom ** pPktSize, TDistro & IntArrivDistro, TDistro & PktSizeDistro);
void dnsParser(SumRandom ** pIntArriv, SumRandom ** pPktSize, TDistro & IntArrivDistro,
    TDistro & PktSizeDistro);


