 /*	Component of the D-ITG 2.4 Platform
 *
 * 	
 *	copyright	: (C) 2004  	by Stefano Avallone, Alessio Botta, Donato Emma, 
 *					Salvatore Guadagno, Antonio Pescape'
 *					DIS Dipartimento di Informatica e Sistemistica				 
 *					(Computer Science Department)
 *					University of Naples "Federico II"	
 *	email:		: {stavallo, pescape}@unina.it, {abotta, demma, sguadagno}@napoli.consorzio-cini.it
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */
 
 




#define MSG_FT_OK 1
#define MSG_FT_ERR1 2
#define MSG_FT_ERR2 3





struct paramThread {
	BYTE l7Proto;				    
	struct addrinfo destHost;		
	int flowId;				        
	info *addressInfos;			    
	int count;				        
	int socket;				        
	int socketClose;		    	
	BYTE meter;				        
	char *fileLog;
	int logSock;				        
    struct addrinfo *logHost;
    char serial[DIM_NAME_SERIAL_INTERFACE];
#ifdef LINUX_OS
	int rPipe[2];
#endif
#ifdef WIN32
	HANDLE rPipe[3];
#endif

};


struct memChannel {		
	int flowId;				
	BYTE l4Proto;			
};


struct manageLogFile{
	ofstream out;				 
	int num;
	char logFile[DIM_LOG_FILE]; 
};



extern const char DEFAULT_LOG_FILE[];


extern int flagTerm;


extern struct addrinfo *logHost;


extern int logCheck;


extern int logRemote;


extern BYTE l4ProtoLog;	


extern ofstream out;


extern int sockSignaling;


extern char logFile[DIM_LOG_FILE];

#ifdef WIN32

extern HANDLE mutexLog;

extern int userId;
#endif

#ifdef LINUX_OS

extern pthread_mutex_t mutexLog;

extern uid_t userId;
#endif




void *signalManager(void *param);


void printHelpAndExit();



void terminate(int sign);


void reportErrorAndExit(char *function, char *program, char *msg);


int sendAck(int signaling, BYTE typeMessage);


int sendAckFlow(int signaling,BYTE typeMessage,int flowId);



void recvInit();



void parserRecv(int argc , char *argv[]);






#ifdef WIN32
int typeParser(BYTE type, int &numFlow, int newSockSignaling , memChannel flowIdNum[],
		  paramThread paraThread[], pthread_t hThr[], HANDLE rPipe[], char *fileLog, int logSock, int logSockSignaling,
          struct addrinfo *logHost);
#endif

#ifdef LINUX_OS
int typeParser(BYTE type, int &numFlow, int newSockSignaling , memChannel flowIdNum[],
		  paramThread paraThread[], pthread_t hThr[], int rPipe[], char *fileLog, int logSock, int logSockSignaling,
          struct addrinfo *logHost);
#endif


#ifdef WIN32
void pipeParser(int newSockSignaling,int &numFlow, HANDLE rPipe[], memChannel flowIdNum[],
		   paramThread paraThread[], pthread_t hThr[]);
#endif

#ifdef LINUX_OS
void pipeParser(int newSockSignaling,int &numFlow, int rPipe[], memChannel flowIdNum[],
		   paramThread paraThread[], pthread_t hThr[]);
#endif



void createRemoteLogFile(struct addrinfo &logHost, char logFile[DIM_LOG_FILE], BYTE protocolLog, int & logSockSignaling, int & logSock);



void createSignalingLogChannel(struct addrinfo logHost, char logFile[DIM_LOG_FILE], BYTE protocolLog, int & logSockSignaling);


void recvFlowLog(int newSockSignaling, struct addrinfo & logHost, BYTE &protocolLog, char logFile[]);



void flushBuffer(ofstream *, struct info *infos , int count);
void recvNameLog(char nameFile[DIM_LOG_FILE],int newSockSignaling);
void copia(const struct addrinfo* src, struct addrinfo & dst);

