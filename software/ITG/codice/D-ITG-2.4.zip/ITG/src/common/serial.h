 /*	Component of the D-ITG 2.4 Platform
 *
 * 	
 *	copyright	: (C) 2004  	by Stefano Avallone, Alessio Botta, Donato Emma, 
 *					Salvatore Guadagno, Antonio Pescape'
 *					DIS Dipartimento di Informatica e Sistemistica				 
 *					(Computer Science Department)
 *					University of Naples "Federico II"	
 *	email:		: {stavallo, pescape}@unina.it, {abotta, demma, sguadagno}@napoli.consorzio-cini.it
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */
 
 


#ifdef WIN32
#include <windows.h>
#endif
#ifdef LINUX_OS
typedef int HANDLE;
#endif

HANDLE serialUp(char *nameSerial);
void DTR_Enable(HANDLE hComm);
void DTR_Disable(HANDLE hComm);
void RTS_Enable(HANDLE hComm);
void RTS_Disable(HANDLE hComm);

