#!/bin/sh
# This unix shell script builds the .tgz and .zip packages for 
# D-ITG from a CVS checkout
# It must be run from D-ITG directory  (./tools/make_package.sh)
#
# $Id: make_package.sh,v 1.1.1.1 2004/07/22 13:04:29 alberto Exp $

VERSION=`cat VERSION`
DIR="D-ITG-$VERSION"

(cd src && make clean)
(cd doc && make)

rm -rf $DIR ; mkdir $DIR
cp DEVELOPERS INSTALL LICENSE VERSION $DIR
cp -R bin $DIR
cp -R doc $DIR
rm -rf $DIR/doc/dox
rm $DIR/doc/Makefile $DIR/doc/doxygen.cnf
cp -R extra $DIR
cp -R src $DIR
rm -rf $DIR/src/newran
cp -R tools $DIR
rm $DIR/tools/make_package.sh

find ./$DIR -name "CVS" | xargs rm -rf

tar zcvf $DIR.tgz $DIR
zip -r $DIR.zip $DIR
rm -rf $DIR

