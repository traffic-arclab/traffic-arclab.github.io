 //ITGRecv.cpp
 /***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *
 *                                                                         *
 ***************************************************************************/
#define Dim 50

#include "ITG.h"

#ifdef WIN32
 const char DefaultLogFile[]="ITGRecv.log";
 static LARGE_INTEGER freq;
 #include <signal.h>
 #include <math.h> //funzione ceil
#endif

#ifdef LINUX_OS
 #include <sys/uio.h>
 #include <netinet/ip.h>
 #include <netinet/udp.h>
 #include <wait.h>
 #include <pthread.h>
 const char DefaultLogFile[]="/tmp/ITGRecv.log";
#endif



// Constant definitions
char DefaultProtoTx_Log[]="UDP";		 //default proto TX-Log remoto
const int DimLogFileChr=100;
const int MaxNumThread=200;
char DefaultProto[]="UDP";




// struct per il passaggio dei parametri al thread-iesimo
struct parametriThread {
   	char upProtocol[30];
	struct sockaddr_in DestHost;
	int FlowId;
	Info *indirizzoinfos;
	int count;
	int socket;
};


// struct per gestione canale di signaling con il log-remoto
struct Signaling {
    int LogPort;
    char protocolName[30];
    bool stop;
    char LogFile[30];

};


//variabili globali, condivise tra i thread
  int logsock;
  int logcheck=0;
  int logout=0;
  char *NameMsr;			     // tipo di misura : owdm o rttm
  struct sockaddr_in LogHost;	 // Log remoto
  char *Prototx_Log;			 // protocollo di livello trasporto tra Receiver e Log
  ofstream out;				     // Logfile locale
  int logfile;
  int sock_signaling;
  int logsocksignaling;
  int numpacchettiricevuti=0;
  int logSender=0;
  char LogFile[30];

 // Prototypes
#ifdef WIN32
 DWORD WINAPI udp_sock(parametriThread* para);
 DWORD WINAPI tcp_sock(parametriThread* para);
 DWORD WINAPI acceptConnection(parametriThread* para);
 DWORD WINAPI icmp_sock(parametriThread* para);
#endif

#ifdef LINUX_OS
 void *acceptConnection(void* param);
 void *udp_sock(void* param);
 void *icmp_sock(void* param);
 void *tcp_sock(void* param);
#endif

void PrintHelpAndExit(char *pname, char *DefaultProto);
void ReportErrorAndExit(char *msg, char *pname);
void createRemotLogFile(struct sockaddr_in LogHost,char *Prototx_Log);
void Terminate(int sig);


//////////////////////////////////////// Start Main ///////////////////////////////////////////
int main(int argc, char *argv[]) {

  signal(SIGINT,Terminate);
  cout<<"Press Ctrl-C to terminate"<<endl;
  parametriThread para[MaxNumThread]; 	  //parametri da passare al thread i_esimo
  #ifdef WIN32
  HANDLE hThr[MaxNumThread];		  //handle associato al thread i_esimo
  //SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS) ;
  #endif
  #ifdef LINUX_OS
  pthread_t hThr[MaxNumThread];	  //handle associato al thread i_esimo
  #endif

  char *protocolName;	    	      //setta il protocollo di livello trasporto di default
  protocolName=DefaultProto;

  char LogFile[DimLogFileChr];		  //setta il log file di default
  strcpy(LogFile,DefaultLogFile);


  NameMsr=DefaultMsr;    			  //setta per default il tipo di misura
  Prototx_Log=DefaultProtoTx_Log;	  // protocollo di trasporto di default per il log remoto



  // variabili per la gestione canale di signaling con il mittente

  int new_sock_signaling;
  struct sockaddr_in SockAddress;
  struct sockaddr_in SrcAddress;
  socklen_t sin_len=sizeof(SockAddress);

  // Set the default IP log addr
  #ifdef LINUX_OS
  struct hostent *host;
  #endif 
  LogHost.sin_family=AF_INET;
  LogHost.sin_port=htons(DefaultLogPort);

  #ifdef LINUX_OS
  inet_aton(DefaultLogIP, &LogHost.sin_addr);
  #endif

  #ifdef WIN32
  LogHost.sin_addr.S_un.S_addr=inet_addr(DefaultLogIP);
  int user_id=1;
  #endif

  // parser
  strcpy(programName, argv[0]);
  argv++;
  argc--;
  while (argc>0) {
    if (argv[0][0] == '-') {
      char *tail;

      switch (argv[0][1]) {
         case 'm':
    	  if ((strcasecmp(argv[1],"rttm")) && strcasecmp(argv[1],"owdm"))
	          ReportErrorAndExit("General parser",programName);
          strcpy(NameMsr,argv[1]);
          argv+=2;
      	  argc-=2;
	     break;
         case 'l':
          logcheck = 1;
          if ((argc < 2) || (argv[1][0] == '-')) {
            strcpy(LogFile,DefaultLogFile);
            argc-=1;
            argv+=1;
            }
          else {
            strcpy(LogFile, argv[1]);
            argc-=2;
            argv+=2;
          }
          break;
	case 'L':
           logout = 1;
           logcheck = 1;
	   LogHost.sin_family=AF_INET;
	   #ifdef LINUX_OS
	   if ((argc < 3) || !(host=gethostbyname(argv[1])) )
	    ReportErrorAndExit("General parser Invalid log-server address or port", programName);
	   memcpy((char *)&LogHost.sin_addr, host->h_addr, host->h_length);
	   #endif
	   LogHost.sin_port=htons(atoi(argv[2]));
	   if ((strcasecmp(argv[3],"TCP")) && strcasecmp(argv[3],"UDP"))
	     ReportErrorAndExit("General parser",programName);
	   strcpy(Prototx_Log,argv[3]);
           #ifdef WIN32
	   LogHost.sin_addr.S_un.S_addr=inet_addr(argv[1]);
	   #endif
   	   argv+=4;
           argc-=4;
           break;
        case 'h':
          PrintHelpAndExit(programName,DefaultProto);
          break;
        case 'Z':
          logSender = 1;
          logout = 1;
	  argc-=1;
          argv+=1;
          break;
        default:
          tail = (char *)malloc(sizeof("Unknown option ")+sizeof(argv[0]));
          ReportErrorAndExit(strcat(strcpy(tail, "Unknown option "), argv[0]), programName);
          break;
      }
    }

  else {
          char temp[sizeof("What is  ?")+sizeof(argv[0])];
          ReportErrorAndExit(strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"), programName);
       }
  } // End of While


  // controlla se il log �locale o remoto
  if (logSender==0)
  if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
	if (!logout){
			out.open(LogFile,ios::out | ios::binary | ios::trunc);
			if (!out)
			{
				cerr<< "** WARNING **  Error into open this file: "<<LogFile<< endl;
				exit(1);
			}
   		}
      	else createRemotLogFile(LogHost,Prototx_Log);
  } //end if


 // server concorrente
 #ifdef WIN32
 WSADATA wsaData;
 if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
	{
	 cerr<<"** ERROR ** WSAStartup() failed "<<endl;
	 exit(1);
	}
 #endif

 SockAddress.sin_family=AF_INET;
 //porto di default su cui mi ascolto il signaling!
 SockAddress.sin_port = htons(DefaultPortSignaling);
 sock_signaling = socket(PF_INET, SOCK_STREAM, 0);
  if (sock_signaling < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }
  
 #ifdef LINUX_OS
 SockAddress.sin_addr.s_addr=htonl(INADDR_ANY);
 #endif
 #ifdef WIN32
 SockAddress.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
 #endif

 if (bind(sock_signaling, (struct sockaddr *) &SockAddress, sizeof(SockAddress))) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port - for signaling" << endl;
      exit(1);
  }

 if (listen(sock_signaling,5) < 0) {
       cerr << endl << "** ERROR **  : Cannot listen to a socket on port "  << endl;
       exit(1);
  }
 int i=0;
 while (1){
  	if( (new_sock_signaling = accept(sock_signaling,(struct sockaddr *) &SrcAddress, &sin_len)) < 0 ) {
       	cerr << endl << "** ERROR **  : Connection fault on port " << endl;
       	exit(1);
   	}
 	para[i].socket=new_sock_signaling;
	#ifdef LINUX_OS
	pthread_create(&hThr[i],NULL,acceptConnection,&para[i]);
	#endif
	#ifdef WIN32
	int pid;
    hThr[i]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) acceptConnection, &para[i], (DWORD)NULL,(unsigned long*)&pid);
	#endif
	i++;
  }
 return 0;
} //end main


// gestione dell'interruzione legata alla pressione dei tasti CNTRL+C
void Terminate(int sig) {
  if (!logout)
	out.close();
  else {
      Signaling signaling_log;		 //per la gestione del canale di signaling con il log remoto
      signaling_log.stop=true;
      sendto(logsocksignaling, (char*)&signaling_log, sizeof(signaling_log),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
  }
  #ifdef WIN32
  closesocket(logsock);
  closesocket(sock_signaling);
  closesocket(logsocksignaling);
  #endif

  #ifdef LINUX_OS
  close(logsock);
  close(sock_signaling);
  close(logsocksignaling);
  #endif
  exit(1);
}


//Crea il canale di signaling con il log remoto
void createRemotLogFile(struct sockaddr_in LogHost,char *Prototx_Log){	  
    Signaling signal;			  
    char buffer[4];
    int help;
    int logsocksignaling;
    #ifdef WIN32
 	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0){
	    	cerr<<"** ERROR ** WSAStartup() failed "<<endl;
		exit(1);
	}
    #endif
    logsocksignaling = socket(PF_INET, SOCK_STREAM , 0); // ..canale per fare signaling!
    help=LogHost.sin_port;
    LogHost.sin_port=htons(DefaultLogPortSignaling);
    signal.LogPort=ntohs(help);
    strcpy(signal.protocolName,Prototx_Log);
    if (logSender==1)
	strcpy(signal.LogFile,LogFile);
    connect(logsocksignaling, (struct sockaddr *)&LogHost, sizeof(LogHost));
    recv(logsocksignaling,buffer,sizeof(buffer),0);
    
    if (sendto(logsocksignaling, (char*)&signal, sizeof(signal),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
      cerr << "** WARNING **  Error into sendto "<< endl;

    LogHost.sin_port=help;
                                           //canela TX - LOG Remoto
    if (strcmp(Prototx_Log,"UDP")==0) {
	logsock = socket(PF_INET, SOCK_DGRAM , 0);    // canale UDP TX - Log
    }
    else {
        logsock=socket(AF_INET,SOCK_STREAM,0);      // canale TCP TX - Log..
    }

    //se deve fare il log remoto allora fa una connect!
    recv(logsocksignaling,buffer,sizeof(buffer),0);
    connect(logsock,(struct sockaddr *)&LogHost, sizeof(LogHost));
}



// Questa routine gestisce il canale di signaling
#ifdef WIN32
	DWORD WINAPI acceptConnection(parametriThread* para) {
    HANDLE hThr[MaxNumThread];		  	//handle associato al thread i_esimo
	int pid;
#endif
#ifdef LINUX_OS
void* acceptConnection(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
	pthread_t hThr[MaxNumThread];		//handle associato al thread i_esimo
#endif

  struct mem{                  //struttura dati con cui il gestore del canale di
	int FlowId;       //signaling realizza l'associazione tra il numero del flusso
        char protocol[30];//e l'identificativo del flusso stesso
  };
  mem FlowIdNumFlusso[MaxNumThread];

//  struct sockaddr_in SrcHost;
//  socklen_t sizeAddr=sizeof(SrcHost);
  int size;
  BYTE type;
  Messaggio1 Connect;
  Messaggio1 Connect_Ack;
  Messaggio3 SendFlow;
  //Messaggio5 Send_Ack; //2 campi
  Messaggio5 ClosedFlow;
  Messaggio5 Closed_Ack; //2 campi
  Messaggio4 Discovery;
  Messaggio4 Relase_Ack;
  Messaggio2 SenderLog;
  Messaggio4 SenderLog_Ack;


  //massima priorit�per il thread i_esimo
  #ifdef LINUX_OS
  struct sched_param parametriT;
  pthread_attr_t attrib;
  pthread_attr_init(&attrib);
  pthread_attr_setinheritsched(&attrib, PTHREAD_EXPLICIT_SCHED);
  pthread_attr_setschedpolicy(&attrib,SCHED_RR);
  parametriT.sched_priority=99;
  pthread_attr_setschedparam(&attrib,&parametriT);
  #endif

  int numflusso=0;
  int new_sock_signaling=para->socket;

   //Il ricevitore si mette in attesa di un messaggio di connect!
  do{

	size=recv(new_sock_signaling,(char*)&Connect,sizeof(Connect),0);
  } while (Connect.type!=1);

  //ricevuto il messaggio di connect il receiver risponde con un messaggio di
  //connect_Ack
  Connect_Ack.type=2;
  send(new_sock_signaling,(char*)&Connect_Ack,sizeof(Connect_Ack),0);


  fd_set read_set,active_set;
  FD_ZERO(&active_set);
  FD_SET(new_sock_signaling,&active_set);
  timeval timeout;
  timeout.tv_sec=600;
  timeout.tv_usec=0;
  	
  while (1) {
	  do {
		 read_set=active_set;
		 if (select(FD_SETSIZE,&read_set,NULL,NULL,&timeout)<0) {
			cerr<<endl<<" Error ** : Invalid file descriptor "<<endl;
			exit(1);
		 }
		 if (FD_ISSET(new_sock_signaling,&read_set)) {
			size=recv(new_sock_signaling,(char*)&type,sizeof(type),0);
  			//cout<<"il primo carattere"<<size<<endl;
			if (type==2) {
				Connect_Ack.type=2;
				send(new_sock_signaling,(char*)&Connect_Ack,sizeof(Connect_Ack),0);
			}
		 }
		 else {
		  //manda al sender un messaggio di discovery... per vedere se il sender �ancora presente
		  Discovery.type=8;
		  send(new_sock_signaling,(char*)&Discovery,sizeof(Discovery),0);
	          //mi metto in attesa dell'ack in seguito al msg di discovery
		  read_set=active_set;
		  if (select(FD_SETSIZE,&read_set,NULL,NULL,&timeout)<0) {
			cerr<<endl<<" Error ** : Invalid file descriptor "<<endl;
			exit(1);
		  }
		  if (FD_ISSET(new_sock_signaling,&read_set)) {
			size=recv(new_sock_signaling,(char*)&type,sizeof(type),0);
  			if (type==2) {
				Connect_Ack.type=2;
				send(new_sock_signaling,(char*)&Connect_Ack,sizeof(Connect_Ack),0);
			}
			cout<<" Il sender �ancora attivo "<<endl;

		  }
		  else {
  				cout<<"E' caduto il sender "<<endl;
				type=11;

		  }
		 }
	}while ((type!=11) && (type!=3) && (type!=4) && (type!=12));
	if ((type==12) && (numflusso==0)  && (logSender==1)) {
     	char buffer[30],temp[30];
	    char *ptr=(char*)&SenderLog;
        	size=recv(new_sock_signaling,(char*)buffer,sizeof(SenderLog)-sizeof(type),0);
		ptr++;
		memcpy(ptr,buffer,size);
		converti(SenderLog.Lprotocol,temp);
		#ifdef WIN32
		LogHost.sin_addr.S_un.S_addr=SenderLog.Laddr;
		#endif
		#ifdef LiINUX_OS
		LogHost.sin_addr.S_addr=SenderLog.Laddr;
		#endif
		LogHost.sin_port=SenderLog.Lport;
		strcpy(LogFile,SenderLog.LogFile);
		createRemotLogFile(LogHost,temp);
		SenderLog_Ack.type=13;
		size=send(new_sock_signaling,(char*)&SenderLog_Ack,sizeof(SenderLog_Ack),0);
  		}
        else if (type==3){
		char buffer[30];
		char *ptr=(char*)&SendFlow;
        	size=recv(new_sock_signaling,(char*)buffer,sizeof(SendFlow)-sizeof(type),0);
		//cout<<size<<endl;
		ptr++;
		memcpy(ptr,buffer,size);
		#ifdef WIN32
		para[numflusso].DestHost.sin_addr.S_un.S_addr=SendFlow.daddr;
		#endif
		#ifdef LINUX_OS
		para[numflusso].DestHost.sin_addr.s_addr=SendFlow.daddr;
		#endif
               //realizza la corrispondenza identificativo-numero del flusso

		FlowIdNumFlusso[numflusso].FlowId=SendFlow.FlowId;
		char temp[30],temp1[30];
		converti(SendFlow.protocol,temp);
                strcpy(FlowIdNumFlusso[numflusso].protocol,temp);

		//parametri da passare al thread che gestir�il flusso i-esimo
		para[numflusso].DestHost.sin_family=AF_INET;
		para[numflusso].DestHost.sin_port=SendFlow.dport;
		converti_app(SendFlow.AppProtocolName,temp1);
		strcpy(para[numflusso].upProtocol,temp1);
		para[numflusso].socket=new_sock_signaling;
		para[numflusso].FlowId=SendFlow.FlowId;
		if (strcmp(temp,DefaultProto)==0) 	// Call UDP
			{
			 #ifdef WIN32
		 	 hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) udp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
			 SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);
			 #endif
			 #ifdef LINUX_OS
			 pthread_create(&hThr[numflusso],&attrib,udp_sock,&para[numflusso]);
			 #endif
  			}
		else if (strcmp(temp,"TCP")==0) 	// Call TCP
             		{
			#ifdef WIN32
        		hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) tcp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
			SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);
			#endif
			#ifdef LINUX_OS
			pthread_create(&hThr[numflusso],&attrib,tcp_sock,&para[numflusso]);
			#endif
           		}
		else if (strcmp(temp,"ICMP")==0) 	// Call ICMP
			{
			#ifdef WIN32
             		hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) icmp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
			SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);
			#endif
			#ifdef LINUX_OS
			pthread_create(&hThr[numflusso],&attrib,icmp_sock,&para[numflusso]);
			#endif
           		}
			numflusso++;
	 }
	  else if (type==4){
	     		char buffer[30];
	    		char *ptr=(char*)&ClosedFlow;
        		size=recv(new_sock_signaling,(char*)buffer,sizeof(ClosedFlow)-sizeof(type),0);
	     		ptr++;
		    	memcpy(ptr,buffer,size);
		        //  il flusso di Id FlowIdStop �terminato...
			int k=0;
			while (ClosedFlow.FlowId!=FlowIdNumFlusso[k].FlowId){
				k++;
			}

			if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
			// Swap to file elements that may remain into the buffer
			if (!logout)
				out.write((const char*)para[k].indirizzoinfos, para[k].count*sizeof(struct Info));
			else  	size= sendto(logsock,(char *) para[k].indirizzoinfos, para[k].count*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
			} //end if logcheck..
			if (strcmp(FlowIdNumFlusso[k].protocol,"ICMP")==0)
				cout<<"Finish ICMP packets"<<endl;
			else cout<<"Finish on port :" <<htons(para[k].DestHost.sin_port)<< endl;
			#ifdef WIN32
			free(para[k].indirizzoinfos);  //libera la memoria dinamica associata al thread
			TerminateThread(hThr[k],0);    //uccide il thread con handle hThr[k]
			#endif
			#ifdef LINUX_OS
			pthread_cancel(hThr[k]);
			#endif
			numflusso--;
			//manda al receiver il messaggio di Closed_ACK
			Closed_Ack.type=6;
			Closed_Ack.FlowId=ClosedFlow.FlowId;
			send(new_sock_signaling,(char*)&Closed_Ack,sizeof(Closed_Ack),0);
		}
	  else if (type==11){
			 break;
	  }
 } //end while

 Relase_Ack.type=7;
 size=send(new_sock_signaling,(char*)&Relase_Ack,sizeof(Relase_Ack),0);

 sleep(1);          //	�utile nel caso di rttm
 #ifdef WIN32
 if (closesocket(new_sock_signaling)<0) cout<<" ** Error into close() "<<endl;
 WSACleanup();
 #endif

 #ifdef LINUX_OS
 if (close(new_sock_signaling)<0) cout<<" ** Error into close() "<<endl;
 #endif

 #ifdef WIN32
 ExitThread(0);
 return 0;
 #endif
 #ifdef LINUX_OS
 pthread_exit(0);
 #endif

}
// END MAIN





char *getip (u_long in)
{
 struct in_addr s;
 s.s_addr=in;
 return inet_ntoa(s);
}


#ifdef WIN32
void tstart(LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi,int &first){
    SYSTEMTIME lpSystemTime;
	if (first) {
		QueryPerformanceFrequency(&freq);
		first=0;
	}
	QueryPerformanceCounter(&_tstart);
	GetSystemTime(&lpSystemTime);
	secondi=lpSystemTime.wHour*3600+lpSystemTime.wMinute*60+lpSystemTime.wSecond;
	microsecondi=lpSystemTime.wMilliseconds;
}

void gettimeofday(struct timeval* thisTime,LARGE_INTEGER &_tend,LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi){
   double secondieusecond;
   long micro;
   QueryPerformanceCounter(&_tend);
   secondieusecond=((((double)_tend.QuadPart-(double)_tstart.QuadPart))/(double)freq.QuadPart);
   thisTime->tv_sec=((unsigned long)secondieusecond)+secondi;
   micro=ceil(((secondieusecond-(unsigned long)secondieusecond)*1e6)/1000);
   if ((thisTime->tv_usec=(micro+microsecondi))>=1e3) {
		thisTime->tv_sec++;
		thisTime->tv_usec=((double)(thisTime->tv_usec*1e-3)-1)*1e3;
   }
   thisTime->tv_usec=thisTime->tv_usec*1e3;
}
#endif


void PrintHelpAndExit(char *pname, char *DefaultProto) {
  cout << endl << " ITGRecv Usage:" << endl << endl;
  cout << " ./ITGRecv <ITGRecv options>" << endl << endl;
  cout << " ITGRecv options:" << endl << endl;
  cout << "  -m <msr_type>\t\ttype of meter.\n\t\t\tValues: owdm (one way delay meter)\n\t\t\t\trttm (round trip time meter)\n\t\t\t(Default: owdm)" << endl;
  cout << "  -l <local_logfile>\tLocal log file name "<<"\n\t\t\t(Default: " << DefaultLogFile <<"; only for owdm)" << endl;
  cout << "  -L <Log_Address> <Log_port> <Protocol_type> \t Remote Log \n\t\t\t(Default: <" <<DefaultLogIP<<"> <"<<DefaultLogPort<<"> <"<<DefaultProtoTx_Log<<">"<< "\n\t\t\t" << endl;;
  cout << " For more information consult ""help"" file in the same directory"<<  endl;
  getchar();
  exit(1);
}

void ReportErrorAndExit(char *msg, char *pname) {
  cerr << endl << "** ERROR ** : " << msg << endl;
  cerr << "Type '" << pname << " -h'  for help" << endl << endl;
  exit(1);
}



// ICMP Function
#ifdef WIN32
	DWORD WINAPI icmp_sock(parametriThread* para) {
    int first=1;
  
#endif
#ifdef LINUX_OS
void* icmp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif
  para->count=0;
  int sock;
  unsigned char buffer[MaxPayloadSize+28];
  unsigned char payload[MaxPayloadSize];

  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  #ifdef WIN32
	    struct sockaddr_in SockAddress;
  #endif
  struct sockaddr_in SrcAddress;
  //size_t sizeAddr = sizeof(SrcAddress);
  socklen_t sin_len=sizeof(SrcAddress);
  //size_t sizeAddrD= sizeof(SockAddress);


  int size_r,size;
  long int ptime;
  struct timeval RcvTime;
  #ifdef WIN32
   LARGE_INTEGER _tstart,_tend;
   unsigned long secondi=0,microsecondi=0;
  #endif


  int dimheader=sizeof(icmp)+sizeof(iphdr);
  char *ptrSeqNum = (char*)payload + sizeof(unsigned int);
  char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  char *ptrTimeUsec = ptrTimeSec + sizeof(long int);

  //salva l'indirizzo della struttura dove memorizza i dati
  para->indirizzoinfos=infos;

 #ifdef LINUX_OS
   if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
    cout<<"Memory lock failed"<<endl;
  #endif

 #ifdef WIN32
 WSADATA wsaData;
 if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
 {
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
  }
 #endif


  sock=socket(AF_INET,SOCK_RAW,IPPROTO_ICMP);     //apre una socket Raw
  if (socket < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }

  #ifdef WIN32
  SockAddress.sin_family=AF_INET;
  SockAddress.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
  if (bind(sock, (struct sockaddr *) &SockAddress, sizeof(SockAddress)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for dp connect " << endl;
      exit(1);
  }
  #endif 
  	
  cout <<"Listening ICMP traffic" << endl;

//manda al receiver il messaggio di Send_ACK
  Messaggio5 Send_Ack;
  Send_Ack.type=5;
  Send_Ack.FlowId=para->FlowId;
  size=send(para->socket,(char*)&Send_Ack,sizeof(Send_Ack),0);
 
  para->socket=sock;

  #ifdef WIN32
  tstart(_tstart,secondi,microsecondi,first);
  #endif

  while (1) {
  //#ifdef LINUX_OS
  //size_r=recvfrom(sock,buffer,MaxPayloadSize+dimheader,0,(struct sockaddr *) &SrcAddress, &sin_len);
  //#endif
  //#ifdef WIN32
  size_r=recvfrom(sock,(char*)buffer,MaxPayloadSize+dimheader,0,(struct sockaddr *) &SrcAddress, &sin_len);
  //#endif
  char *ptr=(char*)buffer;
  ptr=ptr+32;
  size_r=size_r-32;
  memcpy(&payload,ptr,size_r);
  if (size_r > 0)  {
		#ifdef LINUX_OS
        	gettimeofday(&RcvTime, NULL);
		#endif
		#ifdef WIN32
     		gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);
		#endif
		//Logging informations using an array of structs as memory buffer
	  	if (logcheck){
			infos[para->count].FlowId=*(unsigned int *)payload;
     			infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
		      	strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      			infos[para->count].src_port=0;
      			strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
      			infos[para->count].dest_port=0;
      			ptime = (*(long int *)ptrTimeSec);
      			infos[para->count].TxTime1=ptime/3600;
      			infos[para->count].TxTime2=(ptime%3600)/60;
      			infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
			#ifdef LINUX_OS
			ptime = RcvTime.tv_sec%86400L;
			#endif
			#ifdef WIN32
			ptime = RcvTime.tv_sec;
			#endif
      			infos[para->count].RxTime1=ptime/3600;
      			infos[para->count].RxTime2=(ptime%3600)/60;
      			infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      			infos[para->count].size=size_r;
			numpacchettiricevuti++;
		/*	int j=para->count;
			printf("%d\n",infos[j].FlowId);
			printf("%d\n",infos[j].SeqNum);
			printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
			printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
			printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
			printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
			printf("Size>%5u\n",infos[j].size);
			printf("ICMP\n");
		*/	para->count++;
			if(para->count==Dim) {
       				if (!logout)
					out.write((const char*)infos, Dim*sizeof(struct Info));
      				else
	        	   	 sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
  				para->count=0;
				} //end if count==Dim
	  		} //end check for log file
  		} //end if size_r>0
   }  // END While
}//END ICMP Function




// UDP Function
#ifdef WIN32
	DWORD WINAPI udp_sock(parametriThread* para) {
	int first=1;
#endif
#ifdef LINUX_OS
void* udp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif
  para->count=0;
  int sock;
  unsigned char payload[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  SockAddress.sin_family = AF_INET;
  SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  struct sockaddr_in SrcAddress;
  //size_t sizeAddr = sizeof(SrcAddress);
  //size_t sizeAddrD= sizeof(SockAddress);

  int size_r;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  long int ptime;
  struct timeval RcvTime;
  #ifdef WIN32
  LARGE_INTEGER _tstart,_tend;
  unsigned long secondi=0,microsecondi=0;
  #endif
  
 #ifdef LINUX_OS
 if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
 cout<<"Memory lock failed"<<endl;
 #endif

 socklen_t sin_len=sizeof(SrcAddress);
 //salva l'indirizzo della struttura dove memorizza i dati
 para->indirizzoinfos=infos;


 #ifdef WIN32
 WSADATA wsaData;
 if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
 {
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
  }
 #endif

 para->DestHost.sin_family=AF_INET;
 sock = socket(PF_INET, SOCK_DGRAM, 0);
 if (socket < 0) {
     cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
     exit(1);
 }

 if (bind(sock, (struct sockaddr *) &para->DestHost, sizeof(para->DestHost)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for udp connect " << endl;
      exit(1);
 }
 cout <<"Listening on port :" <<ntohs(para->DestHost.sin_port)<< endl;

 //manda al receiver il messaggio di Send_ACK
 int size;
 Messaggio5 Send_Ack;
 Send_Ack.type=5;
 Send_Ack.FlowId=para->FlowId;
 size=send(para->socket,(char*)&Send_Ack,sizeof(Send_Ack),0);
  
 para->socket=sock;
 //cout<<"socket su cui sono in ascolto!"<<para->socket;

 #ifdef WIN32
 tstart(_tstart,secondi,microsecondi,first);
 #endif
 while (1) {
	size_r = recvfrom (sock, (char*)payload, MaxPayloadSize,0,(struct sockaddr *) &SrcAddress, &sin_len);
	if (size_r > 0)  {
		#ifdef LINUX_OS
 	    	gettimeofday(&RcvTime, NULL);
		#endif
		#ifdef WIN32
  		gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);
		#endif
		//Logging informations using an array of structs as memory buffer
	  	if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
			infos[para->count].FlowId=*(unsigned int *)payload;
      			infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
			strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      			infos[para->count].src_port=ntohs(SrcAddress.sin_port);
      			strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
	  		infos[para->count].dest_port=ntohs(para->DestHost.sin_port);
	      		ptime = (*(long int *)ptrTimeSec);
      			infos[para->count].TxTime1=ptime/3600;
      			infos[para->count].TxTime2=(ptime%3600)/60;
      			infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
			#ifdef LINUX_OS
			ptime = RcvTime.tv_sec%86400L;
			#endif
			#ifdef WIN32
			ptime = RcvTime.tv_sec;
			#endif
      			infos[para->count].RxTime1=ptime/3600;
      			infos[para->count].RxTime2=(ptime%3600)/60;
      			infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      			infos[para->count].size=size_r;
			//numpacchettiricevuti++;
			/*int j=para->count;
           		printf("%d\n",infos[j].FlowId);
			printf("%d\n",infos[j].SeqNum);
			printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
			printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
			printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
			printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
			printf("Size>%5u\n",infos[j].size);
			printf("UDP\n");*/
			para->count++;
     			if(para->count==Dim) {
          		 if (!logout)
				out.write((const char*)infos, Dim*sizeof(struct Info));
	      		  else
		                sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
     	  		 para->count=0;
			} //end if count==Dim
  		} //end check for log file
  	        if (strcmp(NameMsr,"rttm")==0)
	          sendto(sock,(char*)payload, size_r, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
	} //end if size_r>0
   }  // END While
}//END UDP Function



// TCP Function
#ifdef WIN32
	DWORD WINAPI tcp_sock(parametriThread* para) {
	int first=1;
#endif
#ifdef LINUX_OS
void* tcp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif

  para->count=0;
  int sock;
  unsigned char buffer[MaxPayloadSize];
  unsigned char payload[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  SockAddress.sin_family = AF_INET;
  SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  struct sockaddr_in SrcAddress;
  //size_t sizeAddr = sizeof(SrcAddress);
  //size_t sizeAddrD= sizeof(SockAddress);
  int new_sock;
  int size, size_p, size_r;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  unsigned char *ptrSize = ptrTimeUsec + sizeof(int);
  long int ptime;
  struct timeval RcvTime;
  #ifdef WIN32
  LARGE_INTEGER _tstart,_tend;
  unsigned long secondi=0,microsecondi=0;
  #endif

  #ifdef LINUX_OS
  if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
  cout<<"Memory lock failed"<<endl;
  #endif

  //salva l'indirizzo della struttura dove memorizza i dati
  para->indirizzoinfos=infos;

  #ifdef WIN32
  WSADATA wsaData;
  if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
  {
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
  }
  #endif

  sock = socket(PF_INET, SOCK_STREAM, 0);
  if (sock < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);

  }
  para->DestHost.sin_family=AF_INET;

  if (bind(sock, (struct sockaddr *) &para->DestHost, sizeof(para->DestHost)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for Tcp connect" << endl;
      exit(1);
  }

  if (listen(sock,5) < 0) {
       cerr << endl << "** ERROR **  : Cannot listen to a socket on port "  << endl;
       exit(1);
  }
  else cout << "Listening on port :" <<ntohs(para->DestHost.sin_port)<< endl;
  socklen_t sin_len=sizeof(para->DestHost);


 //manda al receiver il messaggio di Send_ACK
  Messaggio5 Send_Ack;
  Send_Ack.type=5;
  Send_Ack.FlowId=para->FlowId;
  size=send(para->socket,(char*)&Send_Ack,sizeof(Send_Ack),0);
    
  if( (new_sock = accept(sock,(struct sockaddr *) &SrcAddress, &sin_len)) < 0 ) {
       cerr << endl << "** ERROR **  : Connection fault on port " << endl;
       exit(1);
  }
  #ifdef WIN32
  closesocket(sock);
  tstart(_tstart,secondi,microsecondi,first);
  #endif
  #ifdef LINUX_OS
  close(sock);
  #endif
  para->socket=new_sock;
  while (1) {
        size_r = recv(new_sock,(char*) payload, 20, 0);
        #ifdef LINUX_OS
		gettimeofday(&RcvTime,NULL);
		#endif
		#ifdef WIN32
		gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);
      	#endif
		if (size_r < 20){
			int size_l=0;
			int size_prec=size_r;
			unsigned char *ptr;
			ptr=buffer;
			while ((20 - size_prec)>0){			//leggo le info cont. nel pktto
		    size_l=recv(new_sock, (char*)buffer, 20 - size_prec, 0);
		    size_prec=size_l+size_prec;
			memcpy( payload, ptr, size_l);
			ptr=ptr+size_l;
			}
		}
        size = *(int *)ptrSize;
        size_p = recv(new_sock, (char*)buffer, (size - 20), 0);
        if (size_p < (size - 20)){
			int size_l=0;
			int size_prec=size_p;
			while (size_prec < (size - 20)) {  //leggo il payload
		    size_l=recv(new_sock,(char*)buffer, ((size - 20) - size_prec), 0);
		    size_prec=size_l+size_prec;
			}
		}
         
        if (size_r > 0) {
		//Logging informations using an array of structs as memory buffer
	  	if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
  				infos[para->count].FlowId=*(unsigned int *)payload;
      				infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
		      		strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      				infos[para->count].src_port=ntohs(SrcAddress.sin_port);
      				strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
      				infos[para->count].dest_port=ntohs(para->DestHost.sin_port);
      				ptime = (*(long int *)ptrTimeSec);
      				infos[para->count].TxTime1=ptime/3600;
      				infos[para->count].TxTime2=(ptime%3600)/60;
      				infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
				#ifdef LINUX_OS
				ptime = RcvTime.tv_sec%86400L;
				#endif
				#ifdef WIN32
				ptime = RcvTime.tv_sec;
				#endif
      				infos[para->count].RxTime1=ptime/3600;
      				infos[para->count].RxTime2=(ptime%3600)/60;
      				infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      				infos[para->count].size=size_r;
				if (para->upProtocol=="Telnet")
	       				infos[para->count].size=size%20;
				else
            			infos[para->count].size=size;
         	/*int j=para->count;
				printf("%d\n",infos[j].FlowId);
				printf("%d\n",infos[j].SeqNum);
				printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
				printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
				printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
				printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
				printf("Size>%5u\n",infos[j].size);
				printf("TCP\n");*/
	     			para->count++;
     				if(para->count==Dim) {
                     			if (!logout)
	 				    	out.write((const char*)infos, Dim*sizeof(struct Info));
	     				else  sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
       	     				para->count=0;
    	  			} //end count=Dim
  		} //end if logcheck ||
        	if (strcmp(NameMsr,"rttm")==0)
        		sendto(new_sock,(char*) payload, size, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
	}//end size_r>0
  }// END While
}



