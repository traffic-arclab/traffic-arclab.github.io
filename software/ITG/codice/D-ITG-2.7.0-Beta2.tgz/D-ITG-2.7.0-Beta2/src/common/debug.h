/*
 *   Component of the D-ITG v2.7.0-Beta2 platform (http://www.grid.unina.it/software/ITG)
 *
 *   Copyright    : (C) 2004-2009 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                     Walter de Donato, Antonio Pescape' (PI)
 *                                     of the COMICS (COMputer for Interaction and 
 *                                     CommunicationS) Group, Dipartimento di Informatica
 *                                     e Sistemistica of the University of Napoli "Federico II".
 *   email        : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                  walter.dedonato@unina.it , pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 * 
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 * 		     
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *				     
 *   For commercial use please refer to D-ITG Professional.
 */


#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <stdio.h>

#ifdef DEBUG
	#define PRINTD(level, ...)		if (DEBUG >= level) { printf(__VA_ARGS__); fflush(stdout); }
#else
	#define PRINTD(level, ...)
#endif

#ifdef DEBUG
	#ifdef LINUX_OS
		#define PRINTDS(level, ...)	    if (DEBUG >= level) { usleep(1000); printf(__VA_ARGS__); fflush(stdout); }
	#endif
	#ifdef WIN32
		#define PRINTDS(level, ...)	    if (DEBUG >= level) { Sleep(1000); printf(__VA_ARGS__); fflush(stdout); }
	#endif
#else
	#define PRINTDS(level, ...)
#endif

#endif

