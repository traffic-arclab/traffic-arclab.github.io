/*
 *	Component of the D-ITG v2.6.1 platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright    : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                      Walter de Donato, Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and 
 *                                      CommunicationS) Group, Dipartimento di Informatica
 *                                      e Sistemistica of the University of Napoli "Federico II".
 *      email        : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                     walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is open-source and completely free for Universities, Schools,
 *      Research Institutes, and Individuals; it is also free for Companies that 
 *      use D-ITG for their internal research; you can redistribute it and/or modify
 *      it under the terms of the D-ITG NON-COMMERCIAL LICENSE as reported in the 
 *      LICENSE file of this ditribution; either version 1 of the License, or
 *      (at your option) any later version.
 *
 *      For commercial use please refer to D-ITG Professional.
 */


#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <stdio.h>

#ifdef DEBUG
	#define PRINTD(level, ...)		if (DEBUG >= level) { printf(__VA_ARGS__); fflush(stdout); }
#else
	#define PRINTD(level, ...)
#endif

#ifdef DEBUG
	#ifdef LINUX_OS
		#define PRINTDS(level, ...)	    if (DEBUG >= level) { usleep(1000); printf(__VA_ARGS__); fflush(stdout); }
	#endif
	#ifdef WIN32
		#define PRINTDS(level, ...)	    if (DEBUG >= level) { Sleep(1000); printf(__VA_ARGS__); fflush(stdout); }
	#endif
#else
	#define PRINTDS(level, ...)
#endif

#endif

