// ITG.h

#include <string.h> 	// strtok(), strcasecmp()
#include <stdlib.h>		// strtol()
#include <stdio.h>
#include <fstream.h>
#include <iostream.h>
#include <sys/types.h>		// select()


#ifdef WIN32
 #include <winsock2.h>
 typedef int pid_t;
 typedef int socklen_t;
 typedef int uid_t;
 int strcasecmp(char *input1,char *input2) {
	 if (strcmp(input1,input2)!=0)
		 return 1;
	 else return 0;
 }
 #include <io.h>     //per aprire i file
 #include <fcntl.h>  //per aprire i flle
 #include <fstream.h>
#endif


#ifdef LINUX_OS
 #include <netinet/in.h>	// htons(), inet_aton(), inet_addr()
 #include <arpa/inet.h>
 #include <sys/time.h>		
 #include <unistd.h>		// gethostbyname()
 #include <fcntl.h>
 #include <netdb.h>
 #include <sys/socket.h>
 #include <sys/mman.h> //for mlockall
 #include <sched.h> //library for scheduling functions
 struct sched_param p;
#endif

const int DefaultPortSignaling=9000;
const unsigned short int DefaultPort = 8999;  // porto di default
const unsigned int MaxPayloadSize = 64000;    // dimensione max del payload
char DefaultMsr[]="owdm";		      // metrica di default - owdm
char programName[100];			      // array of char for Program Name(ITGLog, ITGSend, ITGRecv!!)
const char DefaultLogIP[10]="127.0.0.1";      // indirizzo IP di default
const unsigned short int DefaultLogPort= 9002;// porto di default per il log file remoto
const unsigned short int DefaultLogPortSignaling = 9001;

//Logging Structure
struct Info {
   unsigned int FlowId;
   unsigned int SeqNum;
   char src_addr[15];
   unsigned int src_port;
   char dest_addr[15];
   unsigned int dest_port;
   long int TxTime1;
   long int TxTime2;
   double TxTime3;
   long int RxTime1;
   long int RxTime2;
   double RxTime3;
   int size;
   };


#ifdef WIN32
// ip header
struct iphdr {
	unsigned int ihl:4;          // length of the header
	unsigned int version:4;        // Version of IP
	unsigned char tos;             // Type of service
	unsigned short tot_len;      // total length of the packet
	unsigned short id;          // unique identifier
	unsigned short frag_off; // flags
	unsigned char  ttl;
	unsigned char protocol;           // protocol (TCP, UDP etc)
	unsigned short check;       // IP checksum
	unsigned int saddr;
	unsigned int daddr;
};
 // // ICMP header //
struct icmphdr {
	BYTE type;
	BYTE code; /* type sub code */
	USHORT i_cksum;
	USHORT i_id;
	USHORT i_seq;   /* This is not the std header, but we reserve space for time */
	ULONG timestamp;
};

// to calculate checksum
USHORT checksum(USHORT *buffer, int size) {

  unsigned long cksum=0;

  while(size >1) {
	cksum+=*buffer++;
	size -=sizeof(USHORT);
  }

  if(size ) {
	cksum += *(UCHAR*)buffer;
  }

  cksum = (cksum >> 16) + (cksum & 0xffff);
  cksum += (cksum >>16);
  return (USHORT)(~cksum);
}
#endif
