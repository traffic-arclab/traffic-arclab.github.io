// ITGLog.cpp

#include "ITG.h"

struct Signaling {
    int bufferdimensione;
    int PortoLog;
    char protocol[30];
} si_gnal;

//variabili globali
ofstream out;						 // Logfile locale

int newsocksignal;
struct sockaddr_in SenderLog;


#ifdef LINUX_OS
const char DefaultLogFile[]="/tmp/ITGLog.log";       // default log file name
#endif

#ifdef WIN32
const char DefaultLogFile[]="ITGLog.log";       // default log file name
#endif


void PrintHelpAndExit() {
  cout << endl << " ITGLog Usage:" << endl << endl;
  cout << " ./ITGLog <ITGLog options>" << endl << endl;
  cout << " ITGLog options:" << endl << endl;
  cout << "  -l <local_logfile>\tLocal log file name "<<"\n\t\t\t(Default: " << DefaultLogFile <<"; only for owdm)" << endl;
  cout << " For more information consult ""help"" file in the same directory"<<  endl;
  getchar();
  exit(1);
}

void riceve_DIM(int &Dim,int &PortoLog,char protocolName[30])
{
    int	signalsocket;
    struct sockaddr_in signalsock;
    socklen_t sin_len=sizeof(SenderLog);
							  //crea canale per fare signaling con il mittente!
    signalsock.sin_family = AF_INET;	             //setta signalsock
    signalsock.sin_port = htons(DefaultLogPortSignaling);

#ifdef LINUX_OS
    signalsock.sin_addr.s_addr = htonl(INADDR_ANY);
#endif
#ifdef WIN32
   signalsock.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
#endif

   signalsocket = socket(PF_INET, SOCK_STREAM, 0);
   if (signalsocket < 0){
   		printf("** ERROR **  Cannot create a socket on port %d\n");
		exit(1);
		}
						//lega socket al porto specificato prima
   if (bind(signalsocket, (struct sockaddr *) &signalsock, sizeof(signalsock)) < 0 ) {
   		printf("** ERROR **  : Cannot bind a socket on port %d\n");
		exit(1);
		}

  if (listen(signalsocket,5)<0){
      		printf("** ERROR **  : into listen \n");
		exit(1);
		}

   newsocksignal=accept(signalsocket,(struct sockaddr *) &SenderLog, &sin_len);
   if  (newsocksignal<0) {
      	printf("** ERROR **  : into accept \n");
        exit(1);
    	}
   sendto(newsocksignal,"Sinc",4,0,(struct sockaddr *)&SenderLog, sizeof(SenderLog));
  //deve ricevere dal mittente la dimensione del log!.. il mittente gli passa anche il protocollo

#ifdef LINUX_OS
    recv(newsocksignal, &si_gnal, sizeof(si_gnal),0);
#endif

#ifdef WIN32
    recv(newsocksignal, (char*)&si_gnal, sizeof(si_gnal),0);
#endif

	Dim=si_gnal.bufferdimensione;  		    //setta la dimensione del log come indicato dal mittente
	PortoLog=si_gnal.PortoLog;
	strcpy(protocolName,si_gnal.protocol);
	printf("Protocol used : %s \n",protocolName);
}


void log_pkt_TCP(char LogFile[100],int PORTO,int Dim)
{
	int newsocklog;
	struct sockaddr_in SockAddress;
	struct sockaddr_in SrcAddress;
	int logsock,hold;
        struct Info *infos=(struct Info*)malloc(Dim*sizeof(Info));

	out.open(LogFile,ios::out | ios::binary | ios::trunc);
	if (!out) {
	    	cerr<< "** WARNING **  Error into open this file: "<<LogFile<< endl;
			exit(1);
	}

					    //crea socket su cui riceve i dati dal mittente
	SockAddress.sin_family = AF_INET;	    //setta SockAddress
  	SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
   	SockAddress.sin_port = htons(PORTO);

	logsock = socket(PF_INET, SOCK_STREAM, 0);
	if (logsock < 0){
      		printf("** ERROR **  Cannot create a socket on port %d\n",PORTO);
			exit(1);
	}
			//lega socket al porto specificato prima
	if ( bind(logsock, (struct sockaddr *) &SockAddress, sizeof(SockAddress)) < 0 ){
      		printf("** ERROR **  : Cannot bind a socket on port %d\n",PORTO);
		exit(1);
	}

	if (listen(logsock,5)<0){
      		printf("** ERROR **  : into listen \n");
		exit(1);
		}
	socklen_t sin_len=sizeof(SrcAddress);
	sendto(newsocksignal,"Sinc",4,0,(struct sockaddr *)&SenderLog, sizeof(SenderLog));

	newsocklog=accept(logsock,(struct sockaddr *) &SrcAddress, &sin_len);
    	if  (newsocklog<0) {
      	printf("** ERROR **  : into accept \n");
		exit(1);
    	}

	printf("Receaving data on port: %d\n",PORTO);
	fd_set read_set,active_set;
	FD_ZERO(&active_set);
	FD_SET(newsocksignal,&active_set);
	FD_SET(newsocklog,&active_set);
    while (1){
		//        bzero(infos,Dim*sizeof(struct Info));
	  read_set = active_set;                              // since select puts in read_set only ready file descriptors
          if ( select(FD_SETSIZE, &read_set, NULL, NULL, 0) < 0 ) {
   		   printf("** ERROR **  : Invalid file descriptor or operation interrupted by a signal\n");
		   exit(1);
    	  }
         if (FD_ISSET(newsocksignal, &read_set)) {
			 break;     // terminate
          }
	else if ( FD_ISSET(newsocklog, &read_set) ) {

#ifdef LINUX_OS
		hold=recv(newsocklog, infos, Dim*sizeof(struct Info),0);
#endif
#ifdef WIN32
		hold=recv(newsocklog, (char*)infos, Dim*sizeof(struct Info),0);
#endif

		if (hold<0)				    //errore nella recv
		printf("** WARNING **  Data lost!\n");
	    out.write((char*)infos, hold); //scrive i dati sul disco
            if (!out) printf("** WARNING **  Can't write data!\n");
 	    }
	}

#ifdef LINUX_OS	
		close(logsock);
		close(newsocklog);
#endif 

#ifdef WIN32
		closesocket(logsock);
		closesocket(newsocklog);
#endif

	out.close();
}


void log_pkt_UDP(char LogFile[100],int PORTO,int Dim) {

	struct sockaddr_in SockAddress;

	int logsock,hold;
    struct Info *infos=(struct Info*)malloc(Dim*sizeof(Info));



	out.open(LogFile,ios::out | ios::binary | ios::trunc);
	if (!out) {
	    	cerr<< "** WARNING **  Error into open this file: "<<LogFile<< endl;
			exit(1);
	}
   	                 		       //crea canale per signaling con il mittente!
					    //crea socket su cui riceve i dati dal mittente
	SockAddress.sin_family = AF_INET;	    //setta SockAddress
  	SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
   	SockAddress.sin_port = htons(PORTO);
   	logsock = socket(PF_INET, SOCK_DGRAM, 0);
	if (logsock < 0){
      		printf("** ERROR **  Cannot create a socket on port %d\n",PORTO);
		exit(1);
	}
						//lega socket al porto specificato prima
	if ( bind(logsock, (struct sockaddr *) &SockAddress, sizeof(SockAddress)) < 0 ){
      		printf("** ERROR **  : Cannot bind a socket on port %d\n",PORTO);
		exit(1);
	}

	int size;
	size=sendto(newsocksignal,"Sinc",4,0,(struct sockaddr *)&SenderLog, sizeof(SenderLog));
   	printf("Receaving data on port: %d\n",PORTO);
	fd_set read_set,active_set;
	FD_ZERO(&active_set);
	FD_SET(newsocksignal,&active_set);
	FD_SET(logsock,&active_set);
    int numpacchettiricevuti=0;
	int numviaggi=0;
	while (1){
  //      bzero(infos,Dim*sizeof(struct Info));
		  read_set = active_set;                              // since select puts in read_set only ready file descriptors
          if ( select(FD_SETSIZE, &read_set, NULL, NULL, 0) < 0 ) {
   		   printf("** ERROR **  : Invalid file descriptor or operation interrupted by a signal\n");
		   exit(1);
    	  }
          if (FD_ISSET(newsocksignal, &read_set) ) {
			 break;     // terminate
          }
		  else if (FD_ISSET(logsock, &read_set)) {

          #ifdef LINUX_OS
			hold=recv(logsock, infos, Dim*sizeof(struct Info),0);
		  #endif
		  #ifdef WIN32
			hold=recv(logsock, (char*)infos, Dim*sizeof(struct Info),0);
		  #endif
		  numpacchettiricevuti=numpacchettiricevuti+hold/sizeof(struct Info);
		  numviaggi++;
          if (hold<0)						  // errore nella recv
				printf("** WARNING **  Data lost!\n");
	      if (!out.write((char*)infos, hold)) // scrive i dati sul disco
           		printf("** WARNING **  Can't write data!\n");
 	    }
	}
	printf("pacchetti ricevuti %d \n",numpacchettiricevuti);
	printf("numero di viaggi %d \n",numviaggi);
	getchar();
//close file descriptor e socket descriptor
#ifdef LINUX_OS	
	close(logsock);
#endif 
#ifdef WIN32
	closesocket(logsock);
#endif
	out.close();
}



int main(int argc,char *argv[])
{
#ifdef WIN32
  WSADATA wsaData;
  if (WSAStartup(MAKEWORD(2,0),&wsaData)!=0)
  {
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
  }
#endif

	int Dim;
	char LogFile[100];   		// dimensione max log file
  	int PORTO = DefaultLogPort;
        char protocolName[30];

	if (argc<2){
		printf("\nYou must specify an option\n\n");
		printf("Type: ./ITGLog -h for help\n\n");
		exit(1);
		}
	argv++;
	argc--;
	while (argc>0) {
    		if (argv[0][0] == '-') {
      			switch (argv[0][1]) {
             		   case 'l':
          			if ((argc < 2) || (argv[1][0] == '-')) //default name for log file
						{
            			 strcpy(LogFile,DefaultLogFile);
            		         argc-=1;
            			 argv+=1;
            			}
          			else
						{
				 strcpy(LogFile, argv[1]);
 				 argc-=2;
            			 argv+=2;
				}
         		        break;
     		   case 'h':				//help
          				
		         PrintHelpAndExit();
			     
				break;
        	   	
          		default:
				cout<<"default\n";
			 	printf("Unknown option\n");
				exit(1);
				break;
			}
    		} else {
 			printf("What is: %s ?\n",argv[0]);
			printf("Type: ./ITGLog -h for help\n");
			exit(1);
		        }
    	}
   riceve_DIM(Dim,PORTO,protocolName);
   if (strcmp(protocolName,"TCP")==0) log_pkt_TCP(LogFile,PORTO,Dim);
        else log_pkt_UDP(LogFile,PORTO,Dim);

#ifdef WIN32
	WSACleanup();
	if (closesocket(newsocksignal<0)) cout<<" ** Error into close() "<<endl;
#endif
#ifdef LINUX_OS
	if (close(newsocksignal)<0) cout<<" ** Error into close() "<<endl;
#endif
    printf("Finish!\n");	


}

