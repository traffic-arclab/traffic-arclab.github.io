#include "ITG.h"


int DITGsend(char *sender, char *message)
{
   #ifdef WIN32
   WSADATA wsaData;
   if (WSAStartup(MAKEWORD(1,1),&wsaData)!=0){
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
   }
   #endif

   int socket_r;
   struct sockaddr_in Sender;
   struct hostent *host;

   socket_r=socket(PF_INET,SOCK_DGRAM,0);
   Sender.sin_family = AF_INET;

   if (!(host=gethostbyname(sender)))
   {  
         cerr << endl << "DITGsend: Invalid destination address" << endl;
         return -1;
   }
   memcpy((char *)&Sender.sin_addr, host->h_addr, host->h_length);

   Sender.sin_port=htons(DefaultPortSenderManager);
   
   if (sendto(socket_r,message,strlen(message),0,(struct sockaddr*)&Sender,sizeof(Sender)) != (int)strlen(message))
         return -1;
   
   return 0;
}

