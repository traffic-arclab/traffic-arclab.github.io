
/* 
   Send a message to a D-ITG sender 
   sender: D-ITG sender IP address 
   message: message sent to the D-ITG sender
   
   return value
   0  - success
   -1 - error 
*/

int DITGsend(char *sender, char *message);
