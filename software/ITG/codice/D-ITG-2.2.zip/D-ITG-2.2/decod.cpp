#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#ifdef WIN32
 #include <io.h>
#endif

#include <fstream.h>
#include <iostream.h>


struct Info {
   unsigned int FlowId;
   unsigned int SeqNum;
   char src_addr[15];
   unsigned int src_port;
   char dest_addr[15];
   unsigned int dest_port;
   long int TxTime1;
   long int TxTime2;
   double TxTime3;
   long int RxTime1;
   long int RxTime2;
   double RxTime3;
   int size;
};

struct Info *infos = (struct Info *) malloc (sizeof(struct Info));

int main(int argc, char *argv[])

{
	int j;
	ifstream in;

	FILE *fp;
	if (argc<3) {
        printf("ERROR: few arguments\n");
		exit(1);
	}
	in.open(argv[1],ios::in | ios::binary);
	fp=fopen(argv[2],"w");
	j=0;
	int size=0;
	int numpacchetti=0;
	while (1)
	{
		in.read((char*)infos,sizeof(struct Info));  //legge dal file binario
		size=in.gcount();
		if (size==0)
		{
			break;
		}
		else {
           		j=0;
				if (infos[j].size!=0)
				{
				fprintf(fp,"Flow>%04u ",infos[j].FlowId);
        			fprintf(fp,"Seq>%7u ",infos[j].SeqNum);
        			fprintf(fp,"Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
        			fprintf(fp,"Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
        			fprintf(fp,"TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
        			fprintf(fp,"RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
        			fprintf(fp,"Size>%5u\n",infos[j].size);
				numpacchetti++;
				}
		}
	}
 return 0;
}



