//ITG.h
 /***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *
 *                                                                         *
 ***************************************************************************/

#define DefaultPortSignaling 9000 //porto assegnato al canale di signaling
#define DefaultPort 8999     // porto di default su cui il receiver � in ascolto
#define DefaultLogPort 9002 // porto di default per il log file remoto
#define DefaultLogPortSignaling 9001
#define DefaultPortSenderManager 8998

 

#include <string.h> 	// strtok(), strcasecmp()
#include <stdlib.h>		// strtol()
#include <stdio.h>
#include <fstream.h>
#include <iostream.h>
#include <sys/types.h>		// select()


#ifdef WIN32
 #include <winsock.h>
 typedef int pid_t;
 typedef int socklen_t;
 typedef int uid_t;
 #include <io.h>     //per aprire i file
 #include <fcntl.h>  //per aprire i flle
 #include <fstream.h>
#endif


#ifdef LINUX_OS
 #include <netinet/in.h>	// htons(), inet_aton(), inet_addr()
 #include <arpa/inet.h>
 #include <sys/time.h>
 #include <unistd.h>		// gethostbyname()
 #include <fcntl.h>
 #include <netdb.h>
 #include <sys/socket.h>
 #include <sys/mman.h> //for mlockall
 #include <sched.h> //library for scheduling functions
 struct sched_param p;
 typedef unsigned short USHORT;
 typedef char UCHAR;
 typedef unsigned char BYTE;
 typedef long int ULONG;
#endif

const int MaxPayloadSize = 64000;    // dimensione max del payload
char DefaultMsr[]="owdm";		      // metrica di default - owdm
char programName[100];			      // array of char for Program Name(ITGLog, ITGSend, ITGRecv!!)
const char DefaultLogIP[10]="127.0.0.1";      // indirizzo IP di default




//Logging Structure
struct Info {
   unsigned int FlowId;
   unsigned int SeqNum;
   char src_addr[15];
   unsigned int src_port;
   char dest_addr[15];
   unsigned int dest_port;
   long int TxTime1;
   long int TxTime2;
   double TxTime3;
   long int RxTime1;
   long int RxTime2;
   double RxTime3;
   int size;
   };

// ICMP HEADER
struct icmp {
	BYTE icmp_type;
	BYTE icmp_code;
	USHORT icmp_cksum;
	USHORT icmp_id;
	USHORT icmp_seq;
	ULONG timestamp;
};


#ifdef WIN32
// ip header
struct iphdr {
	unsigned char ihl:4;          // length of the header
	unsigned char version:4;        // Version of IP
	unsigned char tos;             // Type of service
	unsigned short tot_len;      // total length of the packet
	unsigned short id;          // unique identifier
	unsigned short frag_off; // flags
	unsigned char  ttl;
	unsigned char protocol;           // protocol (TCP, UDP etc)
	unsigned short check;       // IP checksum
	unsigned int saddr;
	unsigned int daddr;
};

 /*int strcasecmp(char *input1,char *input2) {
  if (strcmp(input1,input2)!=0)
		 return 1;
	 else return 0;
 }*/

  void sleep(int tempo) {
       Sleep(tempo*1000);
      }
#endif


void converti(BYTE protocollo,char *protocol){
 	  switch (protocollo) {
		  case 0:
			strcpy(protocol,"TCP");
		   break;
		  case 1:
			strcpy(protocol,"UDP");
		   break;
		  case 2:
			strcpy(protocol,"ICMP");
		   break;

	  }
}

void converti_app(BYTE protocollo,char *protocol){
 	  switch (protocollo) {
		  case 0:
			strcpy(protocol,"NULL");
		   break;
		  case 1:
			strcpy(protocol,"Telnet");
			break;
		  case 2:
			strcpy(protocol,"VoIP");
		   break;
		  case 3:
			strcpy(protocol,"DNS");
		   break;
	  }
}


BYTE INVconverti(char* protocollo){
 	if (strcmp("TCP",protocollo)==0) 
		return 0;
	else  if (strcmp("UDP",protocollo)==0)
		return 1;
		else if (strcmp("ICMP",protocollo)==0)
		   return 2;
		   else return 0;
}

BYTE INVconverti_app(char *protocollo){
 	if (strcmp("none",protocollo)==0)
		return 0;
	else  if (strcmp("Telnet",protocollo)==0)
		return 1;
		else if (strcmp("VoIP",protocollo)==0)
		   return 2;
		else if (strcmp("DNS",protocollo)==0)
		   return 3;
		   else return 0;
}

// to calculate checksum
USHORT checksum(USHORT *buffer, int size) {
  unsigned long cksum=0;

  while(size >1) {
	cksum+=*buffer++;
	size -=sizeof(USHORT);
  }

  if(size ) {
	cksum += *(UCHAR*)buffer;
  }

  cksum = (cksum >> 16) + (cksum & 0xffff);
  cksum += (cksum >>16);
  return (USHORT)(~cksum);
}

