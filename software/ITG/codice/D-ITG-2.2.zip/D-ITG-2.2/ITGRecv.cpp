 //ITGRecv.cpp
 /***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *
 *                                                                         *
 ***************************************************************************/
#define Dim 50
#define TimeOut 60

#include "ITG.h"

#ifdef WIN32
 #include <errno.h>
 const char DefaultLogFile[]="ITGRecv.log";
 static LARGE_INTEGER freq;
 #include <signal.h>
 #include <math.h> //funzione ceil
#endif

#ifdef LINUX_OS
 #include <limits.h>
 #include <sys/uio.h>
 #include <netinet/ip.h>
 #include <netinet/udp.h>
 #include <wait.h>
 #include <pthread.h>
 const char DefaultLogFile[]="/tmp/ITGRecv.log";
 uid_t user_id;
#endif



// Constant definitions
char DefaultProtoTx_Log[]="UDP";		 //default proto TX-Log remoto
const int DimLogFileChr=100;
const int MaxNumThread=200;
char DefaultProto[]="UDP";




// struct per il passaggio dei parametri al thread-iesimo
struct parametriThread {
   	char upProtocol[30];
	struct sockaddr_in DestHost;
	int FlowId;
	Info *indirizzoinfos;
	int count;
	int socket;
	int socket_close;
};


// struct per gestione canale di signaling con il log-remoto
struct Signaling {
    int LogPort;
    char protocolName[30];
    bool stop;
    char LogFile[30];

};


//variabili globali, condivise tra i thread
  int logsock;
  int logcheck=0;
  int logout=0;
  char *NameMsr;			     // tipo di misura : owdm o rttm
  struct sockaddr_in LogHost;	 // Log remoto
  char *Prototx_Log;			 // protocollo di livello trasporto tra Receiver e Log
  ofstream out;				     // Logfile locale
  int logfile;
  int sock_signaling;
  int logsocksignaling;
  int numpacchettiricevuti=0;
  int logSender=0;
  char LogFile[30];

 // Prototypes
#ifdef WIN32
 DWORD WINAPI udp_sock(parametriThread* para);
 DWORD WINAPI tcp_sock(parametriThread* para);
 DWORD WINAPI acceptConnection(parametriThread* para);
 DWORD WINAPI icmp_sock(parametriThread* para);
 int InitializeWinsock(WORD wVersionRequested);

#endif

#ifdef LINUX_OS
 void *acceptConnection(void* param);
 void *udp_sock(void* param);
 void *icmp_sock(void* param);
 void *tcp_sock(void* param);
 pthread_mutex_t mutex_log = PTHREAD_MUTEX_INITIALIZER;

#endif

void PrintHelpAndExit(char *pname, char *DefaultProto);
void ReportErrorAndExit(char *msg, char *pname);
void createRemotLogFile(struct sockaddr_in LogHost,char *Prototx_Log);
void Terminate(int sig);



//////////////////////////////////////// Start Main ///////////////////////////////////////////

int main(int argc, char *argv[]) {

  signal(SIGINT,Terminate);
  cout<<"Press Ctrl-C to terminate"<<endl;
  parametriThread para[MaxNumThread]; 	  //parametri da passare al thread i_esimo
  #ifdef WIN32
  HANDLE hThr[MaxNumThread];		  //handle associato al thread i_esimo
  //SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS) ;
  #endif
  #ifdef LINUX_OS
  pthread_t hThr[MaxNumThread];	  //handle associato al thread i_esimo
  user_id=getuid();
  #endif

  char *protocolName;	    	      //setta il protocollo di livello trasporto di default
  protocolName=DefaultProto;

  char LogFile[DimLogFileChr];		  //setta il log file di default
  strcpy(LogFile,DefaultLogFile);


  NameMsr=DefaultMsr;    			  //setta per default il tipo di misura
  Prototx_Log=DefaultProtoTx_Log;	  // protocollo di trasporto di default per il log remoto


 // server concorrente
 #ifdef WIN32
 if (!InitializeWinsock (MAKEWORD(1,1) ) ) return 1;
 #endif

  // variabili per la gestione canale di signaling con il mittente

  int new_sock_signaling;
  struct sockaddr_in SockAddress;
  struct sockaddr_in SrcAddress;
  socklen_t sin_len=sizeof(SockAddress);

  // Set the default IP log addr
  struct hostent *host;
  LogHost.sin_family=AF_INET;
  LogHost.sin_port=htons(DefaultLogPort);

  #ifdef LINUX_OS
  inet_aton(DefaultLogIP, &LogHost.sin_addr);
  #endif

  #ifdef WIN32
  LogHost.sin_addr.S_un.S_addr=inet_addr(DefaultLogIP);
  int user_id=1;
  #endif

  // parser
  strcpy(programName, argv[0]);
  argv++;
  argc--;
  while (argc>0) {
    if (argv[0][0] == '-') {
      char *tail;
       switch (argv[0][1]) {
         case 'm':
    	  if ((strcasecmp(argv[1],"rttm")) && strcasecmp(argv[1],"owdm"))
	          ReportErrorAndExit("General parser",programName);
          strcpy(NameMsr,argv[1]);
          argv+=2;
      	  argc-=2;
	     break;
         case 'l':
          logcheck = 1;
          if ((argc < 2) || (argv[1][0] == '-')) {
            strcpy(LogFile,DefaultLogFile);
            argc-=1;
            argv+=1;
            }
          else {
            strcpy(LogFile, argv[1]);
            argc-=2;
            argv+=2;
          }
          break;
		case 'L':
           logout = 1;
           logcheck = 1;
		   LogHost.sin_family=AF_INET;
           if ((argc < 3) || !(host=gethostbyname(argv[1])))
				if (!(host=gethostbyname(argv[1])))
				 ReportErrorAndExit("General parser Invalid log-server address or port", programName);
		   memcpy((char *)&LogHost.sin_addr, host->h_addr, host->h_length);
		   LogHost.sin_port=htons(atoi(argv[2]));
		   if ((strcasecmp(argv[3],"TCP")) && strcasecmp(argv[3],"UDP"))
				ReportErrorAndExit("General parser",programName);
		   strcpy(Prototx_Log,argv[3]);
           argv+=4;
           argc-=4;
           break;
        case 'h':
          PrintHelpAndExit(programName,DefaultProto);
          break;
        case 'Z':
          logSender = 1;
          logout = 1;
		  argc-=1;
          argv+=1;
          break;
        default:
          tail = (char *)malloc(sizeof("Unknown option ")+sizeof(argv[0]));
          ReportErrorAndExit(strcat(strcpy(tail, "Unknown option "), argv[0]), programName);
          break;
      }
    }

  else {
          char temp[sizeof("What is  ?")+sizeof(argv[0])];
          ReportErrorAndExit(strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"), programName);
       }
  } // End of While


  // controlla se il log �locale o remoto
  if (logSender==0)
  if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
	if (!logout){
		        out.open(LogFile, ios::out | ios::binary | ios::trunc);
			if (!out)
			{
			   cerr<< "** WARNING **  Error into open this file: "<<LogFile<< endl;
				exit(1);
			}
   		}
      	else createRemotLogFile(LogHost,Prototx_Log);
  } //end if



 sock_signaling = socket(AF_INET, SOCK_STREAM, 0);
 if (sock_signaling < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }

 #ifdef LINUX_OS
 SockAddress.sin_addr.s_addr=htonl(INADDR_ANY);
 #endif
 #ifdef WIN32
 SockAddress.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
 #endif
 SockAddress.sin_family=AF_INET;
 //porto di default su cui mi ascolto il signaling!
 SockAddress.sin_port = htons(DefaultPortSignaling);

 if (bind(sock_signaling, (struct sockaddr *) &SockAddress, sizeof(SockAddress))) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port - for signaling" << endl;
      exit(1);
  }

 if (listen(sock_signaling,5) < 0) {
       cerr << endl << "** ERROR **  : Cannot listen to a socket on port "  << endl;
       exit(1);
  }
 int i=0;
 while (1){
  	if( (new_sock_signaling = accept(sock_signaling,(struct sockaddr *) &SrcAddress, &sin_len)) < 0 ) {
       	 cerr << endl << "** ERROR **  : Connection fault on port for signaling " << endl;
	 #ifdef WIN32
	 WSACleanup();
	 #endif
	 exit(1);
   	}
	para[i].socket=new_sock_signaling;
	#ifdef LINUX_OS
	pthread_create(&hThr[i],NULL,acceptConnection,&para[i]);
	#endif
	#ifdef WIN32
	int pid;
        hThr[i]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) acceptConnection, &para[i], (DWORD)NULL,(unsigned long*)&pid);
	#endif
	i++;
  }

  return 0;
} //end main


// gestione dell'interruzione legata alla pressione dei tasti CNTRL+C
void Terminate(int sig) {
  if (!logout)
	out.close();
  else {
      Signaling signaling_log;		 //per la gestione del canale di signaling con il log remoto
      signaling_log.stop=true;
      sendto(logsocksignaling, (char*)&signaling_log, sizeof(signaling_log),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
      #ifdef WIN32
      closesocket(logsock);
      closesocket(logsocksignaling);
      #endif

      #ifdef LINUX_OS
      close(logsock);
      close(logsocksignaling);
      #endif
  }
  #ifdef LINUX_OS
  if (close(sock_signaling)<0) cout<<" ** Error into close socket for signaling "<<endl;
  #endif
  exit(1);
}


//Crea il canale di signaling con il log remoto
void createRemotLogFile(struct sockaddr_in LogHost,char *Prototx_Log){
    Signaling signal;
    char buffer[4];
    int help;
    int logsocksignaling;
    logsocksignaling = socket(PF_INET, SOCK_STREAM , 0); // ..canale per fare signaling!
    help=LogHost.sin_port;
    LogHost.sin_port=htons(DefaultLogPortSignaling);
    signal.LogPort=ntohs(help);
    strcpy(signal.protocolName,Prototx_Log);
    if (logSender==1)
	strcpy(signal.LogFile,LogFile);
    connect(logsocksignaling, (struct sockaddr *)&LogHost, sizeof(LogHost));
    recv(logsocksignaling,buffer,sizeof(buffer),0);

    if (sendto(logsocksignaling, (char*)&signal, sizeof(signal),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
      cerr << "** WARNING **  Error into sendto "<< endl;

    LogHost.sin_port=help;
                                           //canela TX - LOG Remoto
    if (strcmp(Prototx_Log,"UDP")==0) {
	logsock = socket(PF_INET, SOCK_DGRAM , 0);    // canale UDP TX - Log
    }
    else {
        logsock=socket(AF_INET,SOCK_STREAM,0);      // canale TCP TX - Log..
    }

    //se deve fare il log remoto allora fa una connect!
    recv(logsocksignaling,buffer,sizeof(buffer),0);
    connect(logsock,(struct sockaddr *)&LogHost, sizeof(LogHost));
}


char *putValue(void* startpos,void* data,int size){
	char *endpos;
	memcpy(startpos,data,size);
	endpos=(char*)startpos+size;
	return endpos;
}

void SendAck(int signaling,BYTE typeMessag){
  char Messaggio[1];
  putValue(&Messaggio,(void*)&typeMessag,sizeof(typeMessag));
  send(signaling,(char*)&Messaggio,sizeof(Messaggio),0);
}

void SendAckFlow(int signaling,BYTE typeMessag,int FlowId){
  char Messaggio[5];
  char *next;
  int size;
  next=putValue(&Messaggio,(void*)&typeMessag,sizeof(typeMessag));
  next=putValue(next,(void*)&FlowId,sizeof(FlowId));
  size=send(signaling,(char*)&Messaggio,sizeof(Messaggio),0);
}



// Questa routine gestisce il canale di signaling
#ifdef WIN32
	DWORD WINAPI acceptConnection(parametriThread* para) {
    HANDLE hThr[MaxNumThread];		  	//handle associato al thread i_esimo
	int pid;
#endif
#ifdef LINUX_OS
void* acceptConnection(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
	pthread_t hThr[MaxNumThread];		//handle associato al thread i_esimo
#endif

  struct mem{                  //struttura dati con cui il gestore del canale di
	int FlowId;       //signaling realizza l'associazione tra il numero del flusso
    char protocol[30];//e l'identificativo del flusso stesso
  };
  mem FlowIdNumFlusso[MaxNumThread];

  int size;
  BYTE type;

  //massima priorita' per il thread i_esimo
  #ifdef LINUX_OS
  pthread_attr_t attrib;
  if (user_id==0) {
      struct sched_param parametriT;
	  pthread_attr_init(&attrib);
	  pthread_attr_setinheritsched(&attrib, PTHREAD_EXPLICIT_SCHED);
	  pthread_attr_setschedpolicy(&attrib,SCHED_RR);
	  parametriT.sched_priority=99;
	  pthread_attr_setschedparam(&attrib,&parametriT);
  }
  #endif

  int numflusso=0;
  int new_sock_signaling=para->socket;

   //Il ricevitore si mette in attesa di un messaggio di connect!
  char buffer[1];
  do{
	size=recv(new_sock_signaling,(char*)&buffer,sizeof(BYTE),0);

  } while (*(BYTE*)buffer!=1);

//  cout<<"Connect with sender!"<<endl;
  SendAck(new_sock_signaling,2);  //ack connect


  fd_set active_set;
  timeval timeout;



  while (1) {
	  do {
		 FD_ZERO(&active_set);
  		 FD_SET(new_sock_signaling,&active_set);
		 timeout.tv_sec=TimeOut;
  		 timeout.tv_usec=0;
		 if (select(FD_SETSIZE,&active_set,NULL,NULL,&timeout)<0) {
			cerr<<endl<<" Error ** : Invalid file descriptor "<<endl;
			exit(1);
		 }
		 if (FD_ISSET(new_sock_signaling,&active_set)) {
			size=recv(new_sock_signaling,(char*)&type,sizeof(type),0);
			if (type==2) { //se �un connect risponde con 1 ack
				SendAck(new_sock_signaling,2);
			}
		 }
		 else {
		  //manda al sender un messaggio di discovery... per vedere se il sender e' ancora presente
		  type=8;
		  send(new_sock_signaling,(char*)&type,sizeof(type),0);
	     	  //mi metto in attesa dell'ack in seguito al msg di discovery
		 FD_ZERO(&active_set);
  		 FD_SET(new_sock_signaling,&active_set);
		 timeout.tv_sec=TimeOut*2;
  		 timeout.tv_usec=0;
		  if (select(FD_SETSIZE,&active_set,NULL,NULL,&timeout)<0) {
			cerr<<endl<<" Error ** : Invalid file descriptor "<<endl;
			exit(1);
		  }
		  if (FD_ISSET(new_sock_signaling,&active_set)) {
			size=recv(new_sock_signaling,(char*)&type,sizeof(type),0);
  			if (type==2) {
				SendAck(new_sock_signaling,2);  //conncet ack
			}
		  }
		  else {
  				cout<<" ** Error ** Sender is down! "<<endl;
				type=21;
		  }
		 }

	}while ((type!=11) && (type!=21) && (type!=3) && (type!=4) && (type!=12));

	  if ((type==12) && (numflusso==0)  && (logSender==1)) { //sendflowlog
	    	char buffer[50];
		char temp[30];
	    char *logport=buffer;
		char *logIP=logport+sizeof(unsigned short);
		char *logprotocol=logIP+sizeof(unsigned int);
		char *FileName=logprotocol+sizeof(BYTE);
		size=recv(new_sock_signaling,(char*)buffer,50,0);

		converti(*(BYTE*)logprotocol,temp);
		#ifdef WIN32
		LogHost.sin_addr.S_un.S_addr=*(unsigned int*)logIP;
		#endif
		#ifdef LiINUX_OS
		LogHost.sin_addr.S_addr=*(unsigned int*)logIP;
		#endif
		LogHost.sin_port=*(unsigned int*)logport;
		strcpy(LogFile,FileName);
		createRemotLogFile(LogHost,temp);
		SendAck(new_sock_signaling,13);  //send ack flow log
  		}
	  else if (type==3){  //sendflow
	        char buffer[12];
	        char *ptrProtocol = buffer;
		char *ptrUpProtocol = ptrProtocol+sizeof(type);
		char *ptrIP = ptrUpProtocol + sizeof(type);
		char *ptrport = ptrIP+ sizeof(unsigned int);
		char *ptrFlowId = ptrport + sizeof(unsigned short);
		size=recv(new_sock_signaling,(char*)buffer,sizeof(buffer),0);

		#ifdef WIN32
		para[numflusso].DestHost.sin_addr.S_un.S_addr=*(unsigned int *)ptrIP;
		#endif
		#ifdef LINUX_OS
		para[numflusso].DestHost.sin_addr.s_addr=*(unsigned int *)ptrIP;
		#endif

        //realizza la corrispondenza identificativo-numero del flusso
		FlowIdNumFlusso[numflusso].FlowId=*(unsigned int *)ptrFlowId;
		char temp[30],temp1[30];
		converti(*(unsigned int *)ptrProtocol,temp);
        strcpy(FlowIdNumFlusso[numflusso].protocol,temp);

		//parametri da passare al thread che gestire il flusso i-esimo
		para[numflusso].DestHost.sin_family=AF_INET;
		para[numflusso].DestHost.sin_port=*(unsigned int *)ptrport;
		converti_app(*(unsigned int *)ptrUpProtocol,temp1);
		strcpy(para[numflusso].upProtocol,temp1);
		para[numflusso].socket=new_sock_signaling;
		para[numflusso].FlowId=*(unsigned int *)ptrFlowId;
		if (strcmp(temp,DefaultProto)==0) 	// Call UDP
			{
			 #ifdef WIN32
		 	 hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) udp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
			 //SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);
			 #endif
			 #ifdef LINUX_OS
			 if (user_id==0) pthread_create(&hThr[numflusso],NULL,udp_sock,&para[numflusso]);
			   else pthread_create(&hThr[numflusso],NULL,udp_sock,&para[numflusso]);
			 #endif
  			}
		else if (strcmp(temp,"TCP")==0) 	// Call TCP
             		{
			#ifdef WIN32
        	hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) tcp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
			//SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);
			#endif
			#ifdef LINUX_OS
			 if (user_id==0) pthread_create(&hThr[numflusso],NULL,tcp_sock,&para[numflusso]);
			   else pthread_create(&hThr[numflusso],NULL,tcp_sock,&para[numflusso]);
			#endif
           		}
		else if (strcmp(temp,"ICMP")==0) 	// Call ICMP
			{
			#ifdef WIN32
            		hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) icmp_sock, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
			//SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);
			#endif
			#ifdef LINUX_OS
			 if (user_id==0) pthread_create(&hThr[numflusso],NULL,icmp_sock,&para[numflusso]);
			   else pthread_create(&hThr[numflusso],NULL,icmp_sock,&para[numflusso]);
			#endif
           		}
			numflusso++;
	 }
	  else if (type==4){ //closedflow
      	    char buffer[6];
	        char *ptrFlowId = buffer;
			size=recv(new_sock_signaling,(char*)buffer,sizeof(buffer),0);

			int k=0;
			while (*(int *)ptrFlowId!=FlowIdNumFlusso[k].FlowId){
				k++;
			}

			if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
			// Swap to file elements that may remain into the buffer
			if (!logout){
			#ifdef LINUX_OS
  			pthread_mutex_lock(&mutex_log);	// blocca sul semaforo
  			#endif
			out.write((const char*)para[k].indirizzoinfos, para[k].count*sizeof(struct Info));
			#ifdef LINUX_OS
 			pthread_mutex_unlock(&mutex_log);		// blocca sul semaforo
  			#endif
				}
			else  size= sendto(logsock,(char *) para[k].indirizzoinfos, para[k].count*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
			} //end if logcheck..
			if (strcmp(FlowIdNumFlusso[k].protocol,"ICMP")==0)
				cout<<"Finish ICMP packets"<<endl;
			else cout<<"Finish on port :" <<htons(para[k].DestHost.sin_port)<< endl;
			//chiude la socket TCP o UDP!

			#ifdef WIN32
			TerminateThread(hThr[k],0);    //uccide il thread con handle hThr[k]
			if (closesocket(para[k].socket_close)<0) cout<<" ** ERROR into close socket "<<endl;
			free(para[k].indirizzoinfos);  //libera la memoria dinamica associata al thread
			#endif
			#ifdef LINUX_OS
			pthread_cancel(hThr[k]);
			if (close(para[k].socket_close)<0) cout<<" ** ERROR into close socket "<<endl;
			#endif
			numflusso--;
			SendAckFlow(new_sock_signaling,6,*(int *)ptrFlowId); //send ack closed flow Id
			}
	  else if (type==11){  //sendrelease
			break;
	  }
	  else if (type==21){
	  		break;	
	  }
 } //end while
 
 
 if (type!=21) SendAck(new_sock_signaling,7);  //send ack release
 #ifdef WIN32
 //if (closesocket(new_sock_signaling)<0) cout<<" ** Error into close() "<<endl;
 #endif

 #ifdef LINUX_OS
 sleep(1);
 if (close(new_sock_signaling)<0) cout<<" ** Error into close() "<<endl;
 #endif

 #ifdef WIN32
 ExitThread(0);
 return 0;
 #endif
 #ifdef LINUX_OS
 pthread_exit(0);
 #endif
}
// END MAIN





char *getip (u_long in)
{
 struct in_addr s;
 s.s_addr=in;
 return inet_ntoa(s);
}


#ifdef WIN32
void tstart(LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi,int &first){
    SYSTEMTIME lpSystemTime;
	if (first) {
		QueryPerformanceFrequency(&freq);
		first=0;
	}
	QueryPerformanceCounter(&_tstart);
	GetSystemTime(&lpSystemTime);
	secondi=lpSystemTime.wHour*3600+lpSystemTime.wMinute*60+lpSystemTime.wSecond;
	microsecondi=lpSystemTime.wMilliseconds;
}

void gettimeofday(struct timeval* thisTime,LARGE_INTEGER &_tend,LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi){
   double secondieusecond;
   long micro;
   QueryPerformanceCounter(&_tend);
   secondieusecond=((((double)_tend.QuadPart-(double)_tstart.QuadPart))/(double)freq.QuadPart);
   thisTime->tv_sec=((unsigned long)secondieusecond)+secondi;
   micro=ceil(((secondieusecond-(unsigned long)secondieusecond)*1e6)/1000);
   if ((thisTime->tv_usec=(micro+microsecondi))>=1e3) {
		thisTime->tv_sec++;
		thisTime->tv_usec=((double)(thisTime->tv_usec*1e-3)-1)*1e3;
   }
   thisTime->tv_usec=thisTime->tv_usec*1e3;
}
#endif

#ifdef WIN32
int InitializeWinsock(WORD wVersionRequested)
{
WSADATA wsaData;
int err;

	err = WSAStartup(wVersionRequested, &wsaData);

	// ritorna errore se, ad esempio, l'applicazione supporta al massimo
	// la versione 1.1 e la DLL supporta da 2.0 in su (le versioni non si sovrappongono)
	if (err!=0) return 0; // Tell the user that we couldn't find a usable winsock.dll

	// WSAStartup returns in wHighVersion (struct wsaData) the highest version it supports
	//  and in wVersion the minimum of its high version and wVersionRequested.
	//  wVersion is the The version of the Windows Sockets specification
	//  that the Windows Sockets DLL expects the caller to use.

	// Se WSAStartup ritorna un risultato accettabile, l'applicazione deve ancora
	//  verificare che il risultato sia compatibile con la sua richiesta. Ad esempio,
	//  con wVersionRequested=1.1 e DLL version 1.0, wVersion=1.0. Se l'applicazione
	//  vuole assolutamente usare la DLL 1.1, deve ancora verificare di non trovarsi
	//  in questo caso

	// Tell the user that we couldn't find a usable winsock.dll.
	if (LOBYTE(wsaData.wVersion )!=1 || HIBYTE(wsaData.wVersion)!=1) return 0;

	//Everything is fine: proceed
	return 1;
}


#endif


void PrintHelpAndExit(char *pname, char *DefaultProto) {
  cout << endl << " ITGRecv Usage:" << endl << endl;
  cout << " ./ITGRecv <ITGRecv options>" << endl << endl;
  cout << " ITGRecv options:" << endl << endl;
  cout << "  -m <msr_type>\t\ttype of meter.\n\t\t\tValues: owdm (one way delay meter)\n\t\t\t\trttm (round trip time meter)\n\t\t\t(Default: owdm)" << endl;
  cout << "  -l <local_logfile>\tLocal log file name "<<"\n\t\t\t(Default: " << DefaultLogFile <<"; only for owdm)" << endl;
  cout << "  -L <Log_Address> <Log_port> <Protocol_type> \t Remote Log \n\t\t\t(Default: <" <<DefaultLogIP<<"> <"<<DefaultLogPort<<"> <"<<DefaultProtoTx_Log<<">"<< "\n\t\t\t" << endl;;
  cout << " For more information consult ""help"" file in the same directory"<<  endl;
  getchar();
  exit(1);
}

void ReportErrorAndExit(char *msg, char *pname) {
  cerr << endl << "** ERROR ** : " << msg << endl;
  cerr << "Type '" << pname << " -h'  for help" << endl << endl;
  exit(1);
}



// ICMP Function
#ifdef WIN32
	DWORD WINAPI icmp_sock(parametriThread* para) {
    int first=1;

#endif
#ifdef LINUX_OS
void* icmp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif
  para->count=0;
  int sock;
  unsigned char buffer[MaxPayloadSize+28];
  unsigned char payload[MaxPayloadSize];

  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  #ifdef WIN32
	    struct sockaddr_in SockAddress;
  #endif
  struct sockaddr_in SrcAddress;
  //size_t sizeAddr = sizeof(SrcAddress);
  socklen_t sin_len=sizeof(SrcAddress);
  //size_t sizeAddrD= sizeof(SockAddress);


  int size_r;
  long int ptime;
  struct timeval RcvTime;
  #ifdef WIN32
   LARGE_INTEGER _tstart,_tend;
   unsigned long secondi=0,microsecondi=0;
  #endif


  int dimheader=sizeof(icmp)+sizeof(iphdr);
  char *ptrSeqNum = (char*)payload + sizeof(unsigned int);
  char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  char *ptrTimeUsec = ptrTimeSec + sizeof(long int);

  //salva l'indirizzo della struttura dove memorizza i dati
  para->indirizzoinfos=infos;

 #ifdef LINUX_OS
   if ((mlockall(MCL_CURRENT|MCL_FUTURE)<0) && (user_id==0))
    cout<<"Memory lock failed"<<endl;
  #endif



  sock=socket(AF_INET,SOCK_RAW,IPPROTO_ICMP);     //apre una socket Raw
  if (socket < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);
  }

  #ifdef WIN32
  SockAddress.sin_family=AF_INET;
  SockAddress.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
  if (bind(sock, (struct sockaddr *) &SockAddress, sizeof(SockAddress)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for dp connect " << endl;
      exit(1);
  }
  #endif

  cout <<"Listening ICMP traffic" << endl;

//manda al receiver il messaggio di Send_ACK
  /*Messaggio5 Send_Ack;
  Send_Ack.type=5;
  Send_Ack.FlowId=para->FlowId;
  size=send(para->socket,(char*)&Send_Ack,sizeof(Send_Ack),0);*/
  SendAckFlow(para->socket,5,para->FlowId);
  para->socket_close=sock;

  #ifdef WIN32
  tstart(_tstart,secondi,microsecondi,first);
  #endif

  while (1) {
  //#ifdef LINUX_OS
  //size_r=recvfrom(sock,buffer,MaxPayloadSize+dimheader,0,(struct sockaddr *) &SrcAddress, &sin_len);
  //#endif
  //#ifdef WIN32
  size_r=recvfrom(sock,(char*)buffer,MaxPayloadSize+dimheader,0,(struct sockaddr *) &SrcAddress, &sin_len);
  //#endif
  char *ptr=(char*)buffer;
  ptr=ptr+32;
  size_r=size_r-32;
  memcpy(&payload,ptr,size_r);
  if (size_r > 0)  {
		#ifdef LINUX_OS
        	gettimeofday(&RcvTime, NULL);
		#endif
		#ifdef WIN32
     		gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);
		#endif
		//Logging informations using an array of structs as memory buffer
	  	if (logcheck){
			infos[para->count].FlowId=*(unsigned int *)payload;
     			infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
		      	strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      			infos[para->count].src_port=0;
      			strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
      			infos[para->count].dest_port=0;
      			ptime = (*(long int *)ptrTimeSec);
      			infos[para->count].TxTime1=ptime/3600;
      			infos[para->count].TxTime2=(ptime%3600)/60;
      			infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
			#ifdef LINUX_OS
			ptime = RcvTime.tv_sec%86400L;
			#endif
			#ifdef WIN32
			ptime = RcvTime.tv_sec;
			#endif
      			infos[para->count].RxTime1=ptime/3600;
      			infos[para->count].RxTime2=(ptime%3600)/60;
      			infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      			infos[para->count].size=size_r;
			numpacchettiricevuti++;
			int j=para->count;
			printf("%d\n",infos[j].FlowId);
			printf("%d\n",infos[j].SeqNum);
			printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
			printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
			printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
			printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
			printf("Size>%5u\n",infos[j].size);
			printf("ICMP\n");
			para->count++;
     			if(para->count==Dim) {
          		 if (!logout){
 				#ifdef LINUX_OS
  				pthread_mutex_lock(&mutex_log);		// blocca sul semaforo
  				#endif
				out.write((const char*)infos, Dim*sizeof(struct Info));
				#ifdef LINUX_OS
 				pthread_mutex_unlock(&mutex_log);		// blocca sul semaforo
  				#endif
				}
			  else
		                sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
     	  		 para->count=0;
			} //endif count==Dim
	  } //end if siz
	  } //end if count==Dime_r>0
   }  // END While
}//END ICMP Function




// UDP Function
#ifdef WIN32
	DWORD WINAPI udp_sock(parametriThread* para) {
	int first=1;
#endif
#ifdef LINUX_OS
void* udp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif
  para->count=0;
  int sock;
  unsigned char payload[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  SockAddress.sin_family = AF_INET;
  SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  struct sockaddr_in SrcAddress;
  //int size;

  int size_r;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  long int ptime;
  struct timeval RcvTime;
  #ifdef WIN32
  LARGE_INTEGER _tstart,_tend;
  unsigned long secondi=0,microsecondi=0;
  #endif

 #ifdef LINUX_OS
 if (mlockall(MCL_CURRENT|MCL_FUTURE)<0 && user_id==0)
 cout<<"Memory lock failed"<<endl;
 #endif

 socklen_t sin_len=sizeof(SrcAddress);
 //salva l'indirizzo della struttura dove memorizza i dati
 para->indirizzoinfos=infos;




 para->DestHost.sin_family=AF_INET;
 sock = socket(PF_INET, SOCK_DGRAM, 0);
 if (socket < 0) {
     cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
     exit(1);
 }


 if (bind(sock, (struct sockaddr *) &para->DestHost, sizeof(para->DestHost)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for udp connect " << endl;
	  exit(1);
 }
 cout <<"Listening on port :" <<ntohs(para->DestHost.sin_port)<< endl;
 SendAckFlow(para->socket,5,para->FlowId);

 //cout<<"socket"<<para->socket<<endl;
			
 #ifdef WIN32
 tstart(_tstart,secondi,microsecondi,first);
 #endif
 //para->socket=sock;
 para->socket_close=sock;
 while (1) {
	size_r = recvfrom (sock, (char*)payload, MaxPayloadSize,0,(struct sockaddr *) &SrcAddress, &sin_len);
	if (size_r > 0)  {
		#ifdef LINUX_OS
 	    	gettimeofday(&RcvTime, NULL);
		#endif
		#ifdef WIN32
  		gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);
		#endif
		//Logging informations using an array of structs as memory buffer
	  	if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
			infos[para->count].FlowId=*(unsigned int *)payload;
 			infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
			strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
 			infos[para->count].src_port=ntohs(SrcAddress.sin_port);
 			strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
	  		infos[para->count].dest_port=ntohs(para->DestHost.sin_port);
	      	ptime = (*(long int *)ptrTimeSec);
      		infos[para->count].TxTime1=ptime/3600;
      		infos[para->count].TxTime2=(ptime%3600)/60;
      		infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
			#ifdef LINUX_OS
			ptime = RcvTime.tv_sec%86400L;
			#endif
			#ifdef WIN32
			ptime = RcvTime.tv_sec;
			#endif
      			infos[para->count].RxTime1=ptime/3600;
      			infos[para->count].RxTime2=(ptime%3600)/60;
      			infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      			infos[para->count].size=size_r;
			//numpacchettiricevuti++;*
			
         /*    		int j=para->count;
      			printf("%d\n",infos[j].FlowId);
			printf("%d\n",infos[j].SeqNum);
			printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
			printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
			printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
			printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
			printf("Size>%5u\n",infos[j].size);
			printf("UDP\n");*/
			para->count++;
     			if(para->count==Dim) {
          		 if (!logout){
 				#ifdef LINUX_OS
  				pthread_mutex_lock(&mutex_log);		// blocca sul semaforo
  				#endif
				out.write((const char*)infos, Dim*sizeof(struct Info));
				#ifdef LINUX_OS
 				pthread_mutex_unlock(&mutex_log);		// blocca sul semaforo
  				#endif
				}
			  else
		                sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
     	  		 para->count=0;
			} //end if count==Dim
  		} //end check for log file
  	        if (strcmp(NameMsr,"rttm")==0)
	          sendto(sock,(char*)payload, size_r, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
	} //end if size_r>0
   }  // END While
}//END UDP Function



// TCP Function
#ifdef WIN32
	DWORD WINAPI tcp_sock(parametriThread* para) {
	int first=1;
#endif
#ifdef LINUX_OS
void* tcp_sock(void* param){
	parametriThread* para;
	para=(parametriThread*)param;
#endif

  para->count=0;
  int sock;
  unsigned char buffer[MaxPayloadSize];
  unsigned char payload[MaxPayloadSize];
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  struct sockaddr_in SockAddress;
  SockAddress.sin_family = AF_INET;
  SockAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  struct sockaddr_in SrcAddress;
  //size_t sizeAddr = sizeof(SrcAddress);
  //size_t sizeAddrD= sizeof(SockAddress);
  int new_sock;
  int size, size_p, size_r;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  unsigned char *ptrSize = ptrTimeUsec + sizeof(int);
  long int ptime;
  struct timeval RcvTime;
  #ifdef WIN32
  LARGE_INTEGER _tstart,_tend;
  unsigned long secondi=0,microsecondi=0;
  #endif

  #ifdef LINUX_OS
  if (mlockall(MCL_CURRENT|MCL_FUTURE)<0 && user_id==0)
  cout<<"Memory lock failed"<<endl;
  #endif

  //salva l'indirizzo della struttura dove memorizza i dati
  para->indirizzoinfos=infos;


  sock = socket(PF_INET, SOCK_STREAM, 0);
  if (sock < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      exit(1);

  }
  para->DestHost.sin_family=AF_INET;

  if (bind(sock, (struct sockaddr *) &para->DestHost, sizeof(para->DestHost)) < 0 ) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port for Tcp connect" << endl;
      exit(1);
  }

  if (listen(sock,5) < 0) {
       cerr << endl << "** ERROR **  : Cannot listen to a socket on port "  << endl;
       exit(1);
  }
  else cout << "Listening on port :" <<ntohs(para->DestHost.sin_port)<< endl;
  socklen_t sin_len=sizeof(para->DestHost);


 //manda al receiver il messaggio di Send_ACK
  /*Messaggio5 Send_Ack;
  Send_Ack.type=5;
  Send_Ack.FlowId=para->FlowId;
  size=send(para->socket,(char*)&Send_Ack,sizeof(Send_Ack),0);*/

  SendAckFlow(para->socket,5,para->FlowId);
  if( (new_sock = accept(sock,(struct sockaddr *) &SrcAddress, &sin_len)) < 0 ) {
       cerr << endl << "** ERROR **  : Connection fault on port " << endl;
       exit(1);
  }
  #ifdef WIN32
  closesocket(sock);
  tstart(_tstart,secondi,microsecondi,first);
  #endif
  #ifdef LINUX_OS
  close(sock);
  #endif
  para->socket_close=new_sock;
	while (1) {
        size_r = recv(new_sock,(char*) payload, 20, 0);
        #ifdef LINUX_OS
		gettimeofday(&RcvTime,NULL);
		#endif
		#ifdef WIN32
		gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi);
      	#endif
		if (size_r < 20){
			int size_l=0;
			int size_prec=size_r;
			unsigned char *ptr;
			ptr=buffer;
			while ((20 - size_prec)>0){			//leggo le info cont. nel pktto
		    size_l=recv(new_sock, (char*)buffer, 20 - size_prec, 0);
		    size_prec=size_l+size_prec;
			memcpy( payload, ptr, size_l);
			ptr=ptr+size_l;
			}
		}
        size = *(int *)ptrSize;
        size_p = recv(new_sock, (char*)buffer, (size - 20), 0);
        if (size_p < (size - 20)){
			int size_l=0;
			int size_prec=size_p;
			while (size_prec < (size - 20)) {  //leggo il payload
		    size_l=recv(new_sock,(char*)buffer, ((size - 20) - size_prec), 0);
		    size_prec=size_l+size_prec;
			}
		}
        if (size_r > 0) {
		//Logging informations using an array of structs as memory buffer
	  	if ((logcheck)||((!logcheck)&&(!(strcmp(NameMsr,"rttm")==0)))){
  				infos[para->count].FlowId=*(unsigned int *)payload;
      				infos[para->count].SeqNum=*(unsigned int *)ptrSeqNum;
		      		strcpy(infos[para->count].src_addr,inet_ntoa(SrcAddress.sin_addr));
      				infos[para->count].src_port=ntohs(SrcAddress.sin_port);
      				strcpy(infos[para->count].dest_addr,inet_ntoa(para->DestHost.sin_addr));
      				infos[para->count].dest_port=ntohs(para->DestHost.sin_port);
      				ptime = (*(long int *)ptrTimeSec);
      				infos[para->count].TxTime1=ptime/3600;
      				infos[para->count].TxTime2=(ptime%3600)/60;
      				infos[para->count].TxTime3=ptime%60+(*(long int*)ptrTimeUsec)/1000000.0;
				#ifdef LINUX_OS
				ptime = RcvTime.tv_sec%86400L;
				#endif
				#ifdef WIN32
				ptime = RcvTime.tv_sec;
				#endif
      				infos[para->count].RxTime1=ptime/3600;
      				infos[para->count].RxTime2=(ptime%3600)/60;
      				infos[para->count].RxTime3=ptime%60+RcvTime.tv_usec/1000000.0;
      				infos[para->count].size=size_r;
				if (para->upProtocol=="Telnet")
	       				infos[para->count].size=size%20;
				else
            			infos[para->count].size=size;
         		/*	int j=para->count;
				printf("%d\n",infos[j].FlowId);
				printf("%d\n",infos[j].SeqNum);
				printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
				printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
				printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
				printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
				printf("Size>%5u\n",infos[j].size);
				printf("TCP\n");*/
	     			para->count++;
     				if(para->count==Dim) {
         		if (!logout){
 				#ifdef LINUX_OS
  				pthread_mutex_lock(&mutex_log);		// blocca sul semaforo
  				#endif
				out.write((const char*)infos, Dim*sizeof(struct Info));
				#ifdef LINUX_OS
 				pthread_mutex_unlock(&mutex_log);		// blocca sul semaforo
  				#endif
				}
			  else
		                sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
     	  		 para->count=0;
			} //end if count==Dim
  		} //end if logcheck ||
        	if (strcmp(NameMsr,"rttm")==0)
        		sendto(new_sock,(char*) payload, size, 0, (struct sockaddr *)&SrcAddress, sizeof(SrcAddress));
	}//end size_r>0
  }// END While
}
