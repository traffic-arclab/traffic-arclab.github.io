/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2006 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */




#define SOL_IP IPPROTO_IP

#include "../common/ITG.h"

#ifdef LINUX_OS
#include <netdb.h>
#include "newran.h"		
#include <sys/wait.h>
#include <math.h>
#include <netinet/tcp.h>	
#include <netinet/ip.h>
#include <sys/timeb.h>
#include <sys/shm.h>
#include <pthread.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#endif

#ifdef WIN32
#include "newran/newran.h"	
#include <math.h>
#include <sys/timeb.h>
#include <time.h>
#include <signal.h>
#endif

#include "../common/thread.h"
#include "../common/timestamp.h"
#include "../common/serial.h"
#include "traffic.h"
#include "../common/pipes.h"
#include "ITGSend.h"

#ifdef LINUX_OS
const char DefaultLogFile[] = "/tmp/ITGSend.log";
const char DefaultRecvLogFile[] = "/tmp/ITGRecv.log";
#endif
#ifdef WIN32
char DefaultLogFile[] = "ITGSend.log";
char DefaultRecvLogFile[] = "ITGRecv.log";
#endif
const char DefaultDestIP[] = "127.0.0.1";


flowDescriptor flows[MAX_NUM_THREAD];		
signalChannel signalChannels[MAX_NUM_THREAD];	
pthread_t h_flowParser[MAX_NUM_THREAD];		
flowParserParams parserParams[MAX_NUM_THREAD];	
int multiFlows = 0;
struct addrinfo *logHost = 0;
struct sockaddr_in ManagerIP;
socklen_t ManagerIPslen = sizeof(ManagerIP);
int isFirst = 1;
int isFirstThread = 1;
int isFirstThreadRttm = 1;
int signalChanCount = 0;
char logFile[DIM_LOG_FILE];	
int logging = 0;		
int logremoto = 0;
int logSock;
int logSockSignaling;
int namelogReceiver = 0;
bool setPriority = false;
ofstream out;			
BYTE protoTxLog = DEFAULT_PROTOCOL_TX_LOG;
BYTE protoTx_ServerLogReceiver = DEFAULT_PROTOCOL_TX_LOG_OPZ;
struct addrinfo *serverLogReceiver = 0;

char logFileReceiver[DIM_LOG_FILE];
int logServer = 0;
int managerMode;
int managerSock;
#ifdef LINUX_OS
pthread_mutex_t mutex;
pthread_mutex_t mutexLog;
pthread_mutex_t mutexErrLog;
#endif
#ifdef WIN32
HANDLE mutex;
HANDLE mutexLog;
#endif
char nameProgram[]="ITGSend";


int modeManager(int argc, char *argv[])
{

	int flowCount = 0;

	managerMode = 1;	
	multiFlows = 1;
	struct addrinfo* localHost = 0;
	int size_r = 0, size_s = 0;
	char buffer[80];

	signal(SIGINT, Terminate);
	printf("Press Ctrl-C to terminate\n");

	argv++;
	argc--;
	parserMultiFlows(argv, argc);


	 getaddrinfo("0.0.0.0", NULL, NULL, &localHost);
	 managerSock = socket(localHost->ai_family, SOCK_DGRAM, 0);
	if (managerSock <0)
			printf("XXX error socket()!\n");


	
	SET_PORT(localHost, htons(DEFAULT_PORT_SENDER_MANAGER));
	
	if (bind(managerSock, localHost->ai_addr, localHost->ai_addrlen)) {
			printf("XXX error bind()!\n");
	}


	do {
		size_r = recvfrom(managerSock, buffer, sizeof(buffer), 0,(struct sockaddr *) &ManagerIP, &ManagerIPslen);
#ifdef DEBUG
		printf("Data receveid from SignalManager %d, \n",size_r);
#endif

		buffer[size_r] = '\n';
		buffer[size_r + 1] = '\0';
		
		strcpy(parserParams[flowCount].line, buffer);
		
		parserParams[flowCount].flowId = flowCount + 1;

		
		memmove(buffer + 2 * sizeof(int), buffer, size_r);
		((int *) buffer)[0] = MNG_FLOWSTART;	
		((int *) buffer)[1] = size_r;	

                size_s = sendto(managerSock, buffer, size_r + 2 * sizeof(int), 0,  (struct sockaddr *) &ManagerIP, ManagerIPslen);
#ifdef DEBUG
		printf("Notify ITGManager about the start of the generation %d, \n",size_s);
#endif

		CREATE_THREAD(&parserParams[flowCount], flowParser, NULL, h_flowParser[flowCount]);
		if (h_flowParser[flowCount] < 0) {
			cerr << "Cannot create a process to handle flow " << flowCount +
			    1 << endl;
		}
		flowCount++;
	} while (1);
 return 0;
}


int modeScript(int argc, char *argv[])
{
	char temp[MAX_NUM_THREAD];
	char line[MAX_NUM_THREAD];
	int flowCount = 0;

	multiFlows = 1;
	FILE *batch;

	if ((batch = fopen(argv[0], "r")) == NULL) {
		
		perror("ITGServer Main: ");
		memClean();
		cerr << "Cannot open '" << argv[0] << "' for reading" << endl;
		exit(1);
	}
	argv++;
	argc--;
	parserMultiFlows(argv, argc);
	
	if (fgets(line, sizeof(line) - 1, batch) == NULL) {
		cerr << "errore" << endl;
		memClean();
		exit(1);
	}

	
	strcpy(temp, line);
	do {
		
		strcpy(parserParams[flowCount].line, temp);
		
		parserParams[flowCount].flowId = flowCount + 1;
		CREATE_THREAD(&parserParams[flowCount], flowParser, NULL, h_flowParser[flowCount]);
		if (h_flowParser[flowCount] < 0) {
			perror("ITGSend Main: ");
			cerr << "Cannot create a process to handle flow "
			    << flowCount + 1 << endl;
		}
		flowCount++;
	} while (fgets(temp, sizeof(temp) - 1, batch));
	fclose(batch);


	
	joinThread(flowCount, h_flowParser);
 return 0;
}


int modeCommandLine(int argc, char *argv[])
{
#ifdef DEBUG
	printf("modeCommandLine() started\n");
#endif
	parserParams[0].flowId = 1;
	argvToString(argv, argc, parserParams[0].line);
	flowParser(&parserParams[0]);
	
	return (0);
}

int main(int argc, char *argv[])
{
	
	strcpy(programName, argv[0]);
	argv++;
	argc--;
 	if (!argc) {
		printf("\nMissing argument!!!\nTry ITGSend -h or --help for more information\n");
		exit(1);
	} else if (((argv[0][0] == '-') && (argv[0][1] == 'h')) || ((argv[0][0] == '-')
		&& (argv[0][1] == '-') && (argv[0][2] == 'h'))) {
		printHelp();
		exit(1);
	}

	
	MUTEX_THREAD_INIT(mutex);
	MUTEX_THREAD_INIT(mutexLog);
	strcpy(logFile, DefaultLogFile);
	strcpy(logFileReceiver, DefaultRecvLogFile);
#ifdef WIN32
	MUTEX_THREAD_INIT(mutex_numPipes);
	if (!InitializeWinsock(MAKEWORD(1, 1))) {
		printf("** ERROR ** WSAStartup() failed\n");
		exit(1);
	}
#endif

	for (int i = 0; i < MAX_NUM_THREAD; i++) {
		signalChannels[i].socket = -1;
		signalChannels[i].flows = 0;
		signalChannels[i].errorLog = false;

	}

	
	if ((argc > 0) && (argv[0][0] == '-') && (argv[0][1] == 'Q'))
		modeManager(argc, argv);
	else if ((argc > 0) && (argv[0][0] != '-') && (findL7Proto(argv[0]) == LX_ERROR_BYTE)) {
		modeScript(argc, argv);
	} else {
		modeCommandLine(argc, argv);
	}

	
	Terminate(0);

} 

void parserMultiFlows(char *argv[], int argc)
{
	strcpy(logFile, DefaultLogFile);
	getaddrinfo(DefaultDestIP, NULL, NULL, &logHost);
	SET_PORT(logHost, htons(DEFAULT_LOG_PORT));
	protoTxLog = DEFAULT_PROTOCOL_TX_LOG;

	getaddrinfo(DefaultDestIP, NULL, NULL, &serverLogReceiver);
	SET_PORT(serverLogReceiver, htons(DEFAULT_LOG_PORT));
	protoTx_ServerLogReceiver = DEFAULT_PROTOCOL_TX_LOG_OPZ;

	while (argc > 0) {
		if (argv[0][0] == '-') {
			switch (argv[0][1]) {
			case 'h':
				printHelp();
				Terminate(0);
				break;
			case 'l':
                logging = 1;
				if ((argc < 2) || (argv[1][0] == '-') || !findL7Proto(argv[1])) {
					strcpy(logFile, DefaultLogFile);
					argc -= 1;
					argv += 1;
				} else {
					strcpy(logFile, argv[1]);
					argc -= 2;
					argv += 2;
				}
				break;				
			case 'L':
				logging = 1;
				logremoto = 1;
				
				if ((argc < 2) || (argv[1][0] == '-') || 
                            (findL7Proto(argv[1]) != LX_ERROR_BYTE)){	
				    argc -= 1;
					argv += 1;
				} else {    
                            
                            if (findL4Proto(argv[1]) == LX_ERROR_BYTE){
                   				if (logHost)
                                   freeaddrinfo(logHost);
                                 
                                if (getaddrinfo(argv[1], NULL, NULL, &logHost))
                                  ReportErrorAndExit("General parser",
            					    " Invalid log-server address or protocol", programName, 0);
                       		    argc -= 1;
                     		    argv += 1;				            
               		        } else {  
                                
           						protoTxLog = findL4Proto(argv[1]);
            					argc -= 1;
		       				    argv += 1;
                            }  
                            if ((argc >= 2) && (argv[1][0] != '-') && (findL7Proto(argv[1]) == LX_ERROR_BYTE)) {
                                   if (findL4Proto(argv[1]) == LX_ERROR_BYTE){
                        				if (logHost)
                                       freeaddrinfo(logHost);
                                     
                                     if (getaddrinfo(argv[1], NULL, NULL, &logHost))
                                       ReportErrorAndExit("General parser",
            					       " Invalid log-server address", programName, 0);
                       		         argc -= 2;
                     		         argv += 2;				            
               		               } else {  
                                        
                    			     	protoTxLog = findL4Proto(argv[1]);
            					        argc -= 2;
	       				                argv += 2;
                                    }  
                             } 
                             else {
                       		    argc -= 1;
                     		    argv += 1;                                                       
               		         }  
                 } 
				break;
			case 'X':
				logServer = 1;
				
				if ((argc < 2) || (argv[1][0] == '-') || 
                            (findL7Proto(argv[1]) != LX_ERROR_BYTE)){	
				    argc -= 1;
					argv += 1;
				} else {    
                            
                            if (findL4Proto(argv[1]) == LX_ERROR_BYTE){
                   				if (serverLogReceiver)
                   				freeaddrinfo(serverLogReceiver);
                                 
                                if (getaddrinfo(argv[1], NULL, NULL, &serverLogReceiver))
                                  ReportErrorAndExit("General parser",
            					    " Invalid log-server address or protocol", programName, 0);
                       		    argc -= 1;
                     		    argv += 1;				            
               		        } else {  
                                
           						protoTx_ServerLogReceiver = findL4Proto(argv[1]);
            					argc -= 1;
		       				    argv += 1;
                            }  
                            if ((argc >= 2) && (argv[1][0] != '-') && (findL7Proto(argv[1]) == LX_ERROR_BYTE)) {
                                   if (findL4Proto(argv[1]) == LX_ERROR_BYTE){
                       				if (serverLogReceiver)
                       					freeaddrinfo(serverLogReceiver);
                                     
                                     if (getaddrinfo(argv[1], NULL, NULL, &serverLogReceiver))
                                       ReportErrorAndExit("General parser",
            					       " Invalid log-server address", programName, 0);
                       		         argc -= 2;
                     		         argv += 2;				            
               		               } else {  
                                        
                    			     	protoTx_ServerLogReceiver = findL4Proto(argv[1]);
            					        argc -= 2;
	       				                argv += 2;
                                    }  
                             } 
                             else {
                       		    argc -= 1;
                     		    argv += 1;				            
               		         }  
                 } 
				break;
			case 'x':
	            namelogReceiver = 1;
	            if ((argc < 2) || (argv[1][0] == '-') || !findL7Proto(argv[1])){
					argc -= 1;
					argv += 1;
				} else {
			     	strcpy(logFileReceiver, argv[1]);
					argc -= 2;
					argv += 2;
				}
				break;
			} 
		} 
	} 
} 


void *flowParser(void *param)
{
	int argc;
	char *argv[200];
	char *token;
	flowParserParams *para = (flowParserParams *)param;
#ifdef WIN32
	struct _timeb tstruct;
#endif
	char *ManagerMsg = NULL;
	double seed = 0.0;
#ifdef LINUX_OS
	timeval timeout;
#endif	
	int j = 0;
	int h = 0;
	int id = para->flowId;
	long int Delay = DefaultDelay;
	int chanId;
	struct pipeMsg msg;

#ifdef DEBUG
	printf("flowParser() started\n");
#endif
	
	flows[id].id = id;
	flows[id].meter = METER_OWDM;
	flows[id].l7Proto = LX_PROTO_NONE;
	flows[id].l4Proto = L4_PROTO_UDP;
	flows[id].DSByte = DefaultDSByte;
	flows[id].Duration = DefaultDuration;
	flows[id].icmptype = 8;
	flows[id].TTL = 0;
	flows[id].Nagle = true;
	flows[id].srcPortSpecify = false;

	strcpy(flows[id].serialReceiver,"noSerial");
	flows[id].serial = INVALID_HANDLE_VALUE;



	
	if (para->line[strlen(para->line) - 1] == '\n') {
		para->line[strlen(para->line) - 1] = '\0';
	} else {
		cerr << " No newline at the end of file" << endl;
		memClean();
		exit(1);
	}

	if (managerMode) {
		ManagerMsg = (char *) malloc(sizeof(char) * strlen(para->line) + sizeof(int) * 2);
		strcpy(ManagerMsg, para->line);
	}

	
	getaddrinfo(DefaultDestIP, NULL, NULL, &flows[id].DestHost);
	SET_PORT(flows[id].DestHost, htons(DEFAULT_PORT));

	
	getaddrinfo(DefaultDestIP, NULL, NULL, &flows[id].SrcHost);

	
	if (!multiFlows) {
		strcpy(logFile, DefaultLogFile);
		getaddrinfo(DefaultDestIP, NULL, NULL, &logHost);
		SET_PORT(logHost, htons(DEFAULT_LOG_PORT));
		protoTxLog = DEFAULT_PROTOCOL_TX_LOG;

		getaddrinfo(DefaultDestIP, NULL, NULL, &serverLogReceiver);
		SET_PORT(serverLogReceiver, htons(DEFAULT_LOG_PORT));
		protoTx_ServerLogReceiver = DEFAULT_PROTOCOL_TX_LOG_OPZ;
	}

	
	flows[id].IntArrivDistro = pdConstant;
	ConstantRV = new Constant(1);
	flows[id].IntArriv = new SumRandom(1000.0 / DefaultPktPerSec * (*ConstantRV));

	
	flows[id].PktSizeDistro = pdConstant;
	ConstantRV = new Constant(1);
	flows[id].PktSize = new SumRandom(DefaultPktSize * (*ConstantRV));

	
	token = strtok(para->line, " ");
	while (token != NULL) {
		argv[j] = token;
		j++;
		token = strtok(NULL, " ");
	}
	argc = j;
	while (argc > 0) {
		if (argv[h][0] == '-') {
			char *tail;

			long int temp = 0;
			Real a, b;
			switch (argv[h][1]) {
			case 'm':
				flows[id].meter = findMeter(argv[h + 1]);
				if (flows[id].meter == 255)
					ReportErrorAndExit("General parser", "Invalid measure type",
					    programName, 0);
				h += 2;
				argc -= 2;
				break;
			case 'a':
 				in_port_t tmp_port;
				if (flows[id].DestHost) {
					GET_PORT(flows[id].DestHost, tmp_port);
					freeaddrinfo(flows[id].DestHost);
				}
				if ((argc < 2) || getaddrinfo(argv[h + 1], NULL, NULL, &flows[id].DestHost))
					ReportErrorAndExit("General parser",
					    "Invalid destination address", programName, id);
				SET_PORT(flows[id].DestHost, tmp_port);
				h += 2;
				argc -= 	2;
				break;
			case 'r':
  			    	if (argv[h][2] == 'p') {
    			    	if (argc < 2)
			        		ReportErrorAndExit("General parser", "Invalid port number",
								        			programName, id);
	        			SET_PORT(flows[id].DestHost, htons(atoi(argv[h + 1])));
        			    h += 2;
				        argc -= 2;
				    } 
			        else if (argv[h][2] == 'k') {
			        		if (argc < 2)
			        		ReportErrorAndExit("General parser", "Invalid Serial Port",
			        						    programName, id);

                            strcpy(flows[id].serialReceiver, argv[h+1]);
#ifdef DEBUG
			    	        printf("at Receiver Side %s is up \n", argv[h + 1]);
#endif
                            h += 2;
				            argc -= 2;

                		  }
                    else {
                  			char tempS[sizeof("What is  ?") + sizeof(argv[h])];
                  			ReportErrorAndExit("General parser", strcat(strcat(strcpy(tempS,
					                  	"What is "), argv[h]), " ?"), programName, id);
        			}
				break;
			case 'f':
				if (argc < 2)
					ReportErrorAndExit("General parser", "Invalid TTL",
					    programName, id);
				temp = strtol(argv[h + 1], &tail, 0);
				strcpy(flows[id].serialReceiver,"noSerial");if ((tail == argv[h + 1]) || (temp < 0) || (temp > 255))
					ReportErrorAndExit("General parser", "Invalid TTL",
					    programName, id);
				flows[id].TTL = temp;
				h += 2;
				argc -= 2;
				break;
   			case 't':
				if ((argc < 2) || ((temp = strtol(argv[h + 1], NULL, 10)) <= 0))
					ReportErrorAndExit("General parser", "Invalid Duration",
					    programName, id);
				flows[id].Duration = temp;
				h += 2;
				argc -= 2;
				break;
			case 'd':
				if (argc < 2)
					ReportErrorAndExit("General parser", "Invalid Delay",
					    programName, id);
				temp = strtol(argv[h + 1], &tail, 10);
				if ((tail == argv[h + 1]) || (temp < 0))
					ReportErrorAndExit("General parser", "Invalid Delay",
					    programName, id);
				Delay = temp;
				h += 2;
				argc -= 2;
				break;
			case 'b':
				if (argc < 2)
					ReportErrorAndExit("General parser", "Invalid DS Byte",
					    programName, id);
				temp = strtol(argv[h + 1], &tail, 0);
				if ((tail == argv[h + 1]) || (temp < 0) || (temp > 255))
					ReportErrorAndExit("General parser", "Invalid DS Byte",
					    programName, id);
				flows[id].DSByte = temp;
				h += 2;
				argc -= 2;
				break;
			case 'L':
				if (multiFlows)
					ReportErrorAndExit("General parser",
					    "-L option not allowed into script file", programName,
					    id);
				logging = 1;
				logremoto = 1;
				
				if ((argc < 2) || (argv[h+1][0] == '-') || 
                            (findL7Proto(argv[h+1]) != LX_ERROR_BYTE)){	
				    argc -= 1;
					h += 1;
				} else {    
                            
                            if (findL4Proto(argv[h + 1]) == LX_ERROR_BYTE){
                   				if (logHost)
                                   freeaddrinfo(logHost);
                                 
                                if (getaddrinfo(argv[h + 1], NULL, NULL, &logHost))
                                  ReportErrorAndExit("General parser",
            					    " Invalid log-server address or protocol", programName, id);
                       		    argc -= 1;
                     		    h += 1;				            
               		        } else {  
                                
           						protoTxLog = findL4Proto(argv[h + 1]);
            					argc -= 1;
		       				    h += 1;
                            }  
                            if ((argc >= 2) && (argv[h+1][0] != '-') && (findL7Proto(argv[h+1]) == LX_ERROR_BYTE)) {
                                   if (findL4Proto(argv[h + 1]) == LX_ERROR_BYTE){
                        				if (logHost)
                                       freeaddrinfo(logHost);
                                     
                                     if (getaddrinfo(argv[h + 1], NULL, NULL, &logHost))
                                       ReportErrorAndExit("General parser",
            					       " Invalid log-server address", programName, id);
                       		         argc -= 2;
                     		         h += 2;				            
               		               } else {  
                                        
                    			     	protoTxLog = findL4Proto(argv[h + 1]);
            					        argc -= 2;
	       				                h += 2;
                                    }  
                             } 
                             else {
                       		    argc -= 1;
                     		    h += 1;				            
               		         }  
                 } 
				break;
			case 'X':
				if (multiFlows)
					ReportErrorAndExit("General parser",
					    "-X option not allowed into script file", programName,
					    id);



				logServer = 1;
				
				if ((argc < 2) || (argv[h+1][0] == '-') || 
                            (findL7Proto(argv[h+1]) != LX_ERROR_BYTE)){	
				    argc -= 1;
					h += 1;
				} else {    
                            
                            if (findL4Proto(argv[h + 1]) == LX_ERROR_BYTE){
                   				if (serverLogReceiver)
                   				freeaddrinfo(serverLogReceiver);
                                 
                                if (getaddrinfo(argv[h + 1], NULL, NULL, &serverLogReceiver))
                                  ReportErrorAndExit("General parser",
            					    " Invalid log-server address or protocol", programName, id);
                       		    argc -= 1;
                     		    h += 1;				            
               		        } else {  
                                
           						protoTx_ServerLogReceiver = findL4Proto(argv[h + 1]);
            					argc -= 1;
		       				    h += 1;
                            }  
                            if ((argc >= 2) && (argv[h+1][0] != '-') && (findL7Proto(argv[h+1]) == LX_ERROR_BYTE)) {
                                   if (findL4Proto(argv[h + 1]) == LX_ERROR_BYTE){
                       				if (serverLogReceiver)
                       					freeaddrinfo(serverLogReceiver);
                                     
                                     if (getaddrinfo(argv[h + 1], NULL, NULL, &serverLogReceiver))
                                       ReportErrorAndExit("General parser",
            					       " Invalid log-server address", programName, id);
                       		         argc -= 2;
                     		         h += 2;				            
               		               } else {  
                                        
                    			     	protoTx_ServerLogReceiver = findL4Proto(argv[h + 1]);
            					        argc -= 2;
	       				                h += 2;
                                    }  
                             } 
                             else {
                       		    argc -= 1;
                     		    h += 1;				            
               		         }  
                 } 
				break;
			case 'T':
				if (argc < 2)
					ReportErrorAndExit("General parser",
					    "Invalid Protocol Type", programName, id);

				flows[id].l4Proto = findL4Proto(argv[h + 1]);
#ifdef DEBUG
				printf("Level 4 Protocol: %s\n", invFindL4Proto(flows[id].l4Proto));
#endif
				if (flows[id].l4Proto == LX_ERROR_BYTE)
					ReportErrorAndExit("General parser",
					    "Invalid Protocol Type", programName, id);

				if (flows[id].l4Proto == L4_PROTO_ICMP) {
					if ((argc > 2) && (argv[h + 2][0] != '-')) {
						flows[id].icmptype = atoi(argv[h + 2]);
						h += 1;
						argc--;
					}
				}
				h += 2;
				argc -= 2;
				break;
			case 's':
				if (strlen(argv[h])==2){
				  	if ((argc < 2) || ((seed = strtod(argv[h + 1], NULL)) >= 1.0)
				    		|| (seed <= 0.0))
					ReportErrorAndExit("General parser",
					    "Invalid seed (0 < seed < 1)", programName, id);
					h += 2;
					argc -= 2;
			
			    }
			    else if (argv[h][2] == 'p') {
			   		if (argc < 2)
			   			ReportErrorAndExit("General parser", "Invalid port number",
					    programName, id);
				    SET_PORT(flows[id].SrcHost, htons(atoi(argv[h + 1])));
				    flows[id].srcPortSpecify = true;
 				    h += 2;
				    argc -= 2;
			    }
			    else if (argv[h][2] == 'k'){
       					if (argc < 2)
					ReportErrorAndExit("General parser", "Invalid Serial Port",
					    programName, id);
	                		flows[id].serial = serialUp(argv[h + 1]);
				    	if (flows[id].serial == INVALID_HANDLE_VALUE)
                         			printf("Error opening interface \n");
				    	strcpy(flows[id].serialReceiver,"noSerial");
					h += 2;
					argc -= 2;

#ifdef DEBUG
					printf("at Sender Side %s is up \n", argv[h + 1]);
#endif
			    } else {
        	        	  	char tempS[sizeof("What is  ?") + sizeof(argv[h])];
                	  		ReportErrorAndExit("General parser", strcat(strcat(strcpy(tempS,
					                  	"What is "), argv[h]), " ?"), programName, id);
                  		}
				break;
			case 'l':
				if (multiFlows)
					ReportErrorAndExit("General parser",
					    "-l option not allowed into script file", programName,
					    id);
				logging = 1;
				if ((argc < 2) || (argv[h + 1][0] == '-') || !findL7Proto(argv[h + 1])) {
					strcpy(logFile, DefaultLogFile);
					argc -= 1;
					h += 1;
				} else {
					strcpy(logFile, argv[h + 1]);
					argc -= 2;
					h += 2;
				}
				break;
			case 'x':
				if (multiFlows)
					ReportErrorAndExit("General parser",
					    "-x option not allowed into script file", programName,
					    id);
	            		namelogReceiver = 1;
	            		if ((argc < 2) || (argv[h + 1][0] == '-') || !findL7Proto(argv[h + 1])){
					argc -= 1;
					h += 1;
				} else {
			     	strcpy(logFileReceiver, argv[h+1]);
					argc -= 2;
					h += 2;
				}
				break;
			case 'C':	
				if ((argc < 2) ||  (strtod(argv[h+1],NULL) <= 0.))
					ReportErrorAndExit("Protocol Parser",
					    "Invalid pkts per sec", programName, id);
				flows[id].IntArrivDistro = pdConstant;
				delete flows[id].IntArriv;
				ConstantRV = new Constant(1);
				flows[id].IntArriv =
				new SumRandom(1000.0 /  strtod(argv[h+1],NULL) * (*ConstantRV));
				h += 2;
				argc -= 2;
				break;		
    			case 'U':
   				if ((argc < 3) ||  (strtod(argv[h+1],NULL) <= 0.)
				    ||  (strtod(argv[h+2],NULL) <= strtod(argv[h+1],NULL)) )
					ReportErrorAndExit("Protocol Parser",
					    "Invalid pkts per sec", programName, id);
				delete flows[id].IntArriv;
				flows[id].IntArrivDistro = pdUniform;
				a = (1000.0 / strtod(argv[h+2],NULL));
				b = (1000.0 / strtod(argv[h+1],NULL)) - a ;
				UniformRV = new Uniform;
				flows[id].IntArriv = new SumRandom( b * (*UniformRV) +  a);
				h += 3;
				argc -= 3;
				break;								
			case 'E':
				if ((argc < 2) || (strtod(argv[h+1],NULL) <= 0.))
					ReportErrorAndExit("Protocol Parser",
					    "Invalid pkts per sec", programName, id);
				delete flows[id].IntArriv;
				flows[id].IntArrivDistro = pdExponential;
				ExponentialRV = new Exponential;
				flows[id].IntArriv =
				new SumRandom(1000.0 /  strtod(argv[h+1],NULL) * (*ExponentialRV));
				h += 2;
				argc -= 2;
				break;
			case 'V':
				if ((argc < 3) || (strtod(argv[h + 1], NULL) <= 0)
				    || (strtod(argv[h + 2], NULL) <= 0))
					ReportErrorAndExit("Protocol Parser",
					    "Invalid Pareto Distribution parameter values",
					    programName, id);
				a = (Real) strtod(argv[h + 1], NULL);
				b = (Real) strtod(argv[h + 2], NULL);
				ParetoRV = new Pareto(a);
				delete flows[id].IntArriv;
				flows[id].IntArrivDistro = pdPareto;
				flows[id].IntArriv = new SumRandom(b * (*ParetoRV));
				h += 3;
				argc -= 3;
				break;
			case 'Y':
				if ((argc < 3) || (strtod(argv[h + 2], NULL) <= 0))	
					ReportErrorAndExit("Protocol Parser",
					    "Invalid pkts per sec", programName, id);
				flows[id].IntArrivDistro = pdCauchy;
				b = strtod(argv[h + 1], NULL); 
				a = strtod(argv[h + 2], NULL); 
				delete flows[id].IntArriv;
				CauchyRV = new Cauchy;
				flows[id].IntArriv = new SumRandom(a * (*CauchyRV) + b);
				h += 3;
				argc -= 3;
				break;
			case 'N':
				if ((argc < 3) || (argv[h + 2] <= 0))	
					ReportErrorAndExit("Protocol Parser",
					    "Invalid pkts per sec", programName, id);
				flows[id].IntArrivDistro = pdNormal;
				b = strtod(argv[h + 1], NULL); 	
				a = strtod(argv[h + 2], NULL); 	
                		delete flows[id].IntArriv;
				NormalRV = new Normal;
				flows[id].IntArriv = new SumRandom(a * (*NormalRV) + b);
				h += 3;
				argc -= 3;
				break;
			case 'O':
				if ((argc < 2) || (strtod(argv[h + 1], NULL) <= 0))	
					ReportErrorAndExit("Protocol Parser",
					    "Invalid pkts per sec", programName, id);
				a = strtod(argv[h + 1], NULL);
				delete flows[id].IntArriv;
				
				PoissonRV = new Poisson(a);
				flows[id].IntArrivDistro = pdPoisson;
				flows[id].IntArriv = new SumRandom(1000.0 / (*PoissonRV));
				h += 2;
				argc -= 2;
				break;
			case 'G':
				if ((argc < 3) || (strtod(argv[h + 1], NULL) <= 0) || (strtod(argv[h + 2], NULL) <= 0))	
					ReportErrorAndExit("Protocol Parser",
					    "Invalid Gamma Distribution parameter values",
					    programName, id);
				a = (Real) strtod(argv[h + 1], NULL);
				b = (Real) strtod(argv[h + 2], NULL);
    				delete flows[id].IntArriv;
				
				GammaRV = new Gamma(a);
				flows[id].IntArrivDistro = pdGamma;
				flows[id].IntArriv = new SumRandom(b * (*GammaRV));
				h += 3;
				argc -= 3;
				break;
			case 'c':
				if ((argc < 2) || (atoi(argv[h + 1]) < 1))
					ReportErrorAndExit("Protocol Parser", "Invalid pkt size",
					    programName, id);
				delete flows[id].PktSize;
				flows[id].PktSizeDistro = pdConstant;
				ConstantRV = new Constant(1);
				flows[id].PktSize = new SumRandom(atoi(argv[h + 1]) * (*ConstantRV));
				h += 2;
				argc -= 2;
				break;
			case 'u':
				if ((argc < 3) || (atoi(argv[h + 1]) < 1)
				    || (atoi(argv[h + 2]) <= atoi(argv[h + 1])))
					ReportErrorAndExit("Protocol Parser", "Invalid pkt size",
					    programName, id);
				delete flows[id].PktSize;
				flows[id].PktSizeDistro = pdUniform;
				b = atoi(argv[h + 1]);
				a = atoi(argv[h + 2]) - b;
				UniformRV = new Uniform;
				flows[id].PktSize = new SumRandom(a * (*UniformRV) + b);
				argc -= 3;
				h += 3;
				break;
			case 'e':
				if ((argc < 2) || (atoi(argv[h + 1]) < 1))
					ReportErrorAndExit("Protocol Parser", "Invalid pkt size",
					    programName, id);
				delete flows[id].PktSize;
				flows[id].PktSizeDistro = pdExponential;
				ExponentialRV = new Exponential;
				flows[id].PktSize = new SumRandom(atoi(argv[h + 1]) * (*ExponentialRV));
				h += 2;
				argc -= 2;
				break;
			case 'v':
				if ((argc < 3) || (strtod(argv[h + 2], NULL) <= 0))	
					ReportErrorAndExit("Protocol Parser",
					    "Invalid Pareto Distribution parameter values",
					    programName, id);
				a = (Real) strtod(argv[h + 1], NULL);
				b = (Real) strtod(argv[h + 2], NULL);
				delete flows[id].PktSize;
				ParetoRV = new Pareto(a);
				flows[id].PktSizeDistro = pdPareto;
				flows[id].PktSize = new SumRandom(b * (*ParetoRV));
				argc -= 3;
				h += 3;
				break;
			case 'y':
				if ((argc < 3) || (atoi(argv[h + 2]) <= 0))	
					ReportErrorAndExit("Protocol Parser",
					    "Invalid pkts per sec", programName, id);
				delete flows[id].PktSize;
				flows[id].PktSizeDistro = pdCauchy;
				b = (Real) atoi(argv[h + 1]);	
				a = (Real) atoi(argv[h + 2]);	
				CauchyRV = new Cauchy;
				flows[id].PktSize = new SumRandom(a * (*CauchyRV) + b);
				h += 3;
				argc -= 3;
				break;
			case 'n':
				if ((argc < 3) || (argv[h + 2] <= 0))	
					ReportErrorAndExit("Protocol Parser", "Invalid pkt size",
					    programName, id);
				delete flows[id].PktSize;
				flows[id].PktSizeDistro = pdNormal;
				b = (Real) atoi(argv[h + 1]);	
				a = (Real) atoi(argv[h + 2]);	
				NormalRV = new Normal;
				flows[id].PktSize = new SumRandom(a * (*NormalRV) + b);
				h += 3;
				argc -= 3;
				break;
			case 'o':
				if ((argc < 2) || (atoi(argv[h + 1]) < 0))	
					ReportErrorAndExit("Protocol Parser", "Invalid pkt size",
					    programName, id);
				a = atoi(argv[h + 1]);
				delete flows[id].PktSize;
				
				PoissonRV = new Poisson(a);
				flows[id].PktSizeDistro = pdPoisson;
				flows[id].PktSize = new SumRandom(1 * (*PoissonRV));
				h += 2;
				argc -= 2;
				break;
			case 'g':
				if ((argc < 3) || (strtod(argv[h + 2], NULL) <= 0))
					ReportErrorAndExit("Protocol Parser",
					    "Invalid Gamma Distribution parameter values",
					    programName, id);
				delete flows[id].PktSize;
				a = (Real) strtod(argv[h + 1], NULL);
				b = (Real) strtod(argv[h + 2], NULL);
				
				GammaRV = new Gamma(a);
				flows[id].PktSizeDistro = pdGamma;
				flows[id].PktSize = new SumRandom(b * (*GammaRV));
				h += 3;
				argc -= 3;
				break;
			case 'D':
				
				
#ifdef DEBUG
				printf("Nagle algorithm disabled\n");
#endif
				flows[id].Nagle=false;
				h += 1;
				argc -= 1;
				break;
#ifdef WIN32				
			case 'P':
				
				
				if (SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS) == 0){
				        printf("Error - Impossible set priority class - %d \n", GetLastError());
			    }
#ifdef DEBUG
				printf(" Enabled thread priority \n");
#endif
				setPriority = true;
				h += 1;
				argc -= 1;
				break;
#endif
			default:
				char temp[sizeof("What is  ?") + sizeof(argv[h])];
				ReportErrorAndExit("General parser", strcat(strcat(strcpy(temp,
						"What is "), argv[h]), " ?"), programName, id);
				break;
			} 
		} else {
			flows[id].l7Proto = findL7Proto(argv[h]);
			switch (flows[id].l7Proto) {
			case L7_PROTO_TELNET:

				telnetParser(&flows[id].IntArriv, &flows[id].PktSize, flows[id].IntArrivDistro, flows[id].PktSizeDistro);
				flows[id].l4Proto = L4_PROTO_TCP;
				h++;
				argc--;
				break;
			case L7_PROTO_VOIP:

				voIPParser(h, argv, argc, flows[id].id, &flows[id].IntArriv, &flows[id].PktSize,
				    flows[id].IntArrivDistro, flows[id].PktSizeDistro);
				flows[id].l4Proto = L4_PROTO_UDP;
				break;
			case L7_PROTO_DNS:

				dnsParser(&flows[id].IntArriv, &flows[id].PktSize, flows[id].IntArrivDistro, flows[id].PktSizeDistro);
				h++;
				argc--;
				break;
			case LX_PROTO_NONE:
				char temp[sizeof("What is  ?") + sizeof(argv[h])];
				ReportErrorAndExit("General parser", strcat(strcat(strcpy(temp,
						"What is "), argv[h]), " ?"), programName, id);
				break;
			} 
		} 
	} 
#ifdef DEBUG
	printf("Terminate Parser flow %d\n",id);
#endif

#ifdef WIN32
	if ((flows[id].l4Proto == L4_PROTO_ICMP) && (flows[id].DestHost->ai_family == PF_INET6)) {
		printf("Error: traffic ICMP with protocol IPv6 is not supported \n");
		memClean();
	exit(1);
	}
#endif
	
	if (seed == 0.0) {
#ifdef WIN32
		_ftime(&tstruct);
		seed = 0.49 * sin(tstruct.millitm) + 0.50;	
#endif
#ifdef LINUX_OS
		struct timeval tv;	
		gettimeofday(&tv, NULL);
		seed = 0.49 * sin(tv.tv_usec) + 0.50;	
#endif
	}

	
	flows[id].IntArriv->Set(seed);
	flows[id].PktSize->Set(seed);


	
	if (createNewPipe(flows[id].parserPipe) < 0) {
		printf("Error in flowParser() trying to create a new pipe. [flow %d]\n", id);
		exitThread();
	}

	
	
	if (Delay) {
#ifdef LINUX_OS
		timeout.tv_sec = Delay / 1000;
		timeout.tv_usec = (Delay % 1000) * 1000;
		long int result;
		do
			result = (long int) (select(0, NULL, NULL, NULL, &timeout));
		while (result == -1L && errno == EINTR);
#endif
#ifdef WIN32
		Sleep(Delay);
#endif
	}

	
	
	
 	
	int rit = identifySignalManager(id, &chanId, flows[id].DestHost);
	if (rit == -1) {
		printf("Error into function identifySignalManager() n");
		exitThread();
	}

	if ((namelogReceiver == 1) || (logServer == 1)) {
		if (signalChannels[chanId].errorLog == true){
			printf("Error log file specified is already open \n");
  			isChannelClosable(chanId);
			if (multiFlows)
	   			exitThread();
			else return 0;
		}
	}


	
	msg.code = MSG_SM_NEWFLOW;
	msg.flowId = id;
	if (sendPipeMsg(signalChannels[chanId].pipe, &msg) < 0) {
		perror("flowParser sending msg");
		exitThread();
	}

	
	if (recvPipeMsg(flows[id].parserPipe, &msg) < 0) {
		perror("flowParser receiving msg");
		exitThread();
	}

#ifdef DEBUG
	printf("msg received from signal manager %d\n",msg.code);
#endif

	switch (msg.code) {
	case MSG_FP_END:
		break;
	case MSG_FP_ERR1:
		printf("Error at Receiver side \n");
		break;
	case MSG_FP_ERR2:
		printf("Error - FlowSender interrupted by an error\n");
		break;
	default:
		printf("Error undefined message received from signal manager\n");
		break;
	}

	

	if (managerMode) {
		
		int length = strlen(ManagerMsg);
		memmove(ManagerMsg + 2 * sizeof(int), ManagerMsg, length);
		((int *) ManagerMsg)[0] = MNG_FLOWEND;	
		((int *) ManagerMsg)[1] = length;	
		sendto(managerSock, ManagerMsg, length + sizeof(int) * 2, 0, (struct sockaddr *) &ManagerIP,
		    ManagerIPslen);
#ifdef DEBUG
		printf("Notify ITGManager about the end of the generation \n");
#endif

	}

	
   	closePipe(flows[id].parserPipe);


    

	if (multiFlows)
	   exitThread();
    return 0;
}

void *signalManager(void *id)
{
	int	chanId, sock, size;
	BYTE	type;
	unsigned int	flowId;
	char	buffer[4];
	struct pipeMsg msg;
#ifdef LINUX_OS
	int fd, maxfd;
	fd_set	rset;
#endif
#ifdef WIN32
	HANDLE fd, namedPipe;
	HANDLE	events[2];
	DWORD available = 0;
	DWORD waited;
	unsigned long pending;
#endif

#ifdef DEBUG
	printf("signalManager() started\n");
#endif

	
	chanId = *(int *)id;
	sock = signalChannels[chanId].socket;
	fd = signalChannels[chanId].pipe[0];
#ifdef WIN32
	events[0] = WSACreateEvent();
	WSAEventSelect(sock, events[0], FD_READ);
	events[1] = signalChannels[chanId].pipe[1];
	namedPipe = signalChannels[chanId].pipe[2];
#endif

#ifdef LINUX_OS
	maxfd = max(fd, sock) + 1;
	FD_ZERO(&rset);
#endif
    
	
	for (;;) {
		
#ifdef LINUX_OS
		FD_SET(sock, &rset);
		FD_SET(fd, &rset);
		if (select(maxfd, &rset, NULL, NULL, NULL) == -1) {
			if (errno == EINTR)
				continue;
			printf("error during select in signalManager %d\n", chanId);
			exitThread();
		}
		
		if (FD_ISSET(sock, &rset)) {
#endif

#ifdef WIN32
#ifdef DEBUG
		printf("before waitformultiple...\n");
#endif
		waited = WaitForMultipleObjects(2, (const HANDLE *)events, FALSE, INFINITE);
#ifdef DEBUG
		printf("out of waitformultiple...\n");
#endif
		
		
		ResetEvent(events[0]);
		
		pending = 0;
		ioctlsocket(sock, FIONREAD, &pending);
#ifdef DEBUG
		printf("pending: %d\n", pending);
#endif
		while (pending > 0) {
#endif
			

			
			size = recv(sock, (char *) &type, sizeof(type), 0);
#ifdef DEBUG
			printf("received type %d on socket\n", type);
#endif
			switch (type) {
			case TSP_ACK_CLOSED_FLOW:

				
				recv(sock, (char *) buffer, sizeof(buffer), 0);
				flowId = *(unsigned int *) buffer;
#ifdef DEBUG
				printf("received ack closed flow %d\n", flowId);
#endif
				

				
				if ( isChannelClosable(chanId))  {
					
					msg.code = MSG_FP_END;
					msg.flowId = flowId;
					if (sendPipeMsg(flows[flowId].parserPipe, &msg) < 0) {
						perror("signalManager sending msg");
						exitThread();
					}
					exitThread();
				} else {
					
					msg.code = MSG_FP_END;
					msg.flowId = flowId;
					if (sendPipeMsg(flows[flowId].parserPipe, &msg) < 0) {
						perror("signalManager sending msg");
						exitThread();
					}
				}
				break;
			case TSP_ACK_SEND_FLOW:
				
				recv(sock, (char *) buffer, sizeof(buffer), 0);
				flowId = *(unsigned int *) buffer;
				
				CREATE_THREAD(&(flows[flowId]), flowSender, NULL, flows[flowId].handle);
#ifdef WIN32
				if (setPriority == true){
					if (SetThreadPriority(flows[flowId].handle, THREAD_PRIORITY_TIME_CRITICAL) == 0)
					printf("Error - Impossible set priority for thread - %d \n", GetLastError());
 				}
#endif
				break;
			case TSP_DISCOVERY:
				sendType(sock, TSP_ACK_DISCOVERY);
				break;
			case TSP_ERR_MSG_2:
				recv(sock, (char *) buffer, sizeof(buffer), 0);
				flowId = *(unsigned int *) buffer;
				printf("Error - Busy port on receiver side\n");
				
				if ( isChannelClosable(chanId))  {
					
					msg.code = MSG_FP_ERR1;
					msg.flowId = flowId;
					if ( sendPipeMsg(flows[flowId].parserPipe, &msg) < 0) {
						perror("signalManager sending msg");
						exitThread();
					}
			 		exitThread();
				} else {
					msg.code = MSG_FP_ERR1;
					msg.flowId = flowId;
					if ( sendPipeMsg(flows[flowId].parserPipe, &msg) < 0) {
						perror("signalManager sending msg");
						exitThread();
				 	}
				}
				break;
			case TSP_ERR_MSG_3:
				recv(sock, (char *) buffer, sizeof(buffer), 0);
				flowId = *(unsigned int *) buffer;
				printf("** To generate ICMP traffic sender and receiver must be root\n");
				
				if (isChannelClosable(chanId))  {
					
					msg.code = MSG_FP_ERR1;
				 	msg.flowId = flowId;
				 	if (sendPipeMsg(flows[flowId].parserPipe, &msg) < 0) {
						perror("signalManager sending msg");
						exitThread();
				 	}
			 		exitThread();
				}else {
					
				 	msg.code = MSG_FP_ERR1;
				 	msg.flowId = flowId;
				 	if (sendPipeMsg(flows[flowId].parserPipe, &msg) < 0) {
						perror("signalManager sending msg");
						exitThread();
				 	}
				}
    				break;
			default:
				printf("Error - Got unknown message from receiver: %d\n",(int) type);
				break;
			} 
#ifdef WIN32
			ioctlsocket(sock, FIONREAD, &pending);
#endif
		} 

#ifdef LINUX_OS
		
		if (FD_ISSET(fd, &rset)) {
#endif
#ifdef WIN32
		
		if (PeekNamedPipe(namedPipe, NULL , 0 , NULL , &available , NULL) == 0) {
			printf("Error in peek named pipe\n");
			exitThread();
		}
#ifdef DEBUG
		printf("available: %d\n", available);
#endif

		while(available > 0) {
#endif
			
			if (recvPipeMsg(signalChannels[chanId].pipe, &msg) < 0) {
				perror("signalManager receiving msg");
				exitThread();
			}
#ifdef DEBUG
			printf("signal manager received msg code: %d\n", msg.code);
#endif
			switch(msg.code) {
			case MSG_SM_NEWFLOW:
				flows[msg.flowId].sigChanId = chanId;
			       	requestToSend(msg.flowId, sock);
				break;
			case MSG_SM_ENDFLOW:
				
#ifdef DEBUG
				printf("send request to close flow %d\n", msg.flowId);
#endif
				closedFlow(msg.flowId, sock);
				break;
			case MSG_SM_ERRFLOW:
				
				msg.code = MSG_FP_ERR2;
				if (sendPipeMsg(flows[msg.flowId].parserPipe, &msg) < 0) {
					perror("signalManager sending msg");
					exitThread();
				}
				closedFlowErr(msg.flowId, sock);
				
				if ( isChannelClosable(chanId))
					exitThread();
				break;
			default:
				printf("Got unknown message from queue\n");
				break;
			}
#ifdef WIN32
			
			if (PeekNamedPipe(fd, NULL , 0 , NULL , &available , NULL) == 0) {
				printf("Error in peek named pipe\n");
				exitThread();
			}
#endif
		} 

	} 
}


int isChannelClosable(int id)
{
	MUTEX_THREAD_LOCK(mutex);
	signalChannels[id].flows--;
	if (signalChannels[id].flows == 0) {
		sendRelease(signalChannels[id].socket);

		if (closeSock(signalChannels[id].socket) < 0)
			printf("error closing socket\n");
		signalChannels[id].socket = -1;
		signalChannels[id].errorLog = false;

		closePipe(signalChannels[id].pipe);

  		MUTEX_THREAD_UNLOCK(mutex);
#ifdef DEBUG
		printf("closing signalling channel\n");
#endif
		return(1);
	}
	MUTEX_THREAD_UNLOCK(mutex);
	return(0);
}


int identifySignalManager(int flowId, int *chanId, struct addrinfo *DestHost)
{
	int signalSock;
	char type =0;
	MUTEX_THREAD_LOCK(mutex);

	
	if (checkDestHostIP(chanId, DestHost) == false) {
		
		createTransportChan(signalSock, DestHost);	
		createSignalChan(signalSock);			

		
		if ((namelogReceiver == 1) && (logServer == 0)){
     		if (sendNameLog(signalSock, logFileReceiver,sizeof(logFileReceiver))<0) {
				printf("sendNameLog() error \n");
				return(-1);
			}
			recv(signalSock, (char *) &type, sizeof(type), 0);
		}
		if (logServer == 1){
			if (sendLog(signalSock, serverLogReceiver, protoTx_ServerLogReceiver, logFileReceiver)<0){
				printf("sendLog() error \n");
				return(-1);
			}
			recv(signalSock, (char  *) &type, sizeof(type), 0);
		}

		
		
		*chanId = 0;
		while (signalChannels[*chanId].socket != -1)
			(*chanId)++;
		
		if (createNewPipe(signalChannels[*chanId].pipe) < 0) {
			printf("signalManager() could not open pipe for flowId %d\n", flowId);
			return(-1);
		}
		
		signalChannels[*chanId].DestAddr = DestHost;
		signalChannels[*chanId].flows = 1;
		signalChannels[*chanId].socket = signalSock;

		if ((logServer ==1 ) || (namelogReceiver ==1)){
			if (type == TSP_ERR_MSG_4){
				printf("signalManager() TSP_ERR_MSG_4\n");
				signalChannels[*chanId].errorLog = true;
			}
		}
		if (signalChannels[*chanId].errorLog == false){
			
			CREATE_THREAD(chanId, signalManager, NULL, signalChannels[*chanId].handle);

			
			signalChanCount++;
		}
		MUTEX_THREAD_UNLOCK(mutex);
		return(1);

	} else {
		MUTEX_THREAD_UNLOCK(mutex);
		return(0);
	}
}







void *flowSender(void *para)
{
	flowDescriptor *param = (flowDescriptor *)para;
	int id = param->id;
   	struct addrinfo *SrcHost =	flows[id].SrcHost;
	struct addrinfo *DestHost =	flows[id].DestHost;
	BYTE meter =	    		flows[id].meter;
	BYTE l4Proto = 		    	flows[id].l4Proto;
	BYTE l7Proto = 		    	flows[id].l7Proto;
	int icmptype = 			flows[id].icmptype;
	int DSByte =			flows[id].DSByte;
	unsigned long Duration = 	flows[id].Duration;
	int TTL = 			flows[id].TTL;
	SumRandom * IntArriv = 		flows[id].IntArriv;
	SumRandom * PktSize = 		flows[id].PktSize;
	int sigChanId =            	flows[id].sigChanId;
	bool Nagle =                	flows[id].Nagle;
	struct info *infos = 		(struct info *) malloc(DIM * sizeof(info));
	bool SrcPortSpecify =       	flows[id].srcPortSpecify;
	unsigned char payload[MAX_PAYLOAD_SIZE];
	unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
	unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
	unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
	unsigned char *ptrSize = NULL;

	fd_set read_set, active_set;
	int size, size_r = 0;
	long int time, time1, time2;
	struct TTicker Ticker;
	struct timeval start_time, end_time, RcvTime, timeout;

	int socktype;
	int prototype = 0;
	unsigned int seqNum = 1;
	Real wait;
	int count = 0;
	int sockchk = 0;
	struct pipeMsg msg;

	char HelpSrcAddress[INET6_ADDRSTRLEN];
	char HelpDstAddress[INET6_ADDRSTRLEN];
	int tmpPort_SrcPort = 0;
	int tmpPort_DstPort = 0;
#ifdef WIN32
	LARGE_INTEGER _tstart, _tend, _tprec;
	unsigned long secondi = 0, microsecondi = 0;
	int first = 1;
	int first_update = 1;
#endif


#ifdef DEBUG
	printf("flowSender() started\n");
#endif

	
	UniformRV = new Uniform;
	UniformRV->Set(0.5);
	for (int i=0; i<MAX_PAYLOAD_SIZE;i++)
		payload[i]=(unsigned char)(255*UniformRV->Next());

	
	msg.flowId = id;

 	
 	if (SrcPortSpecify == true)
 	    GET_PORT(flows[id].SrcHost, tmpPort_SrcPort);

  	
	SrcHost->ai_family = DestHost->ai_family;
	SrcHost->ai_addrlen = DestHost->ai_addrlen;
	SrcHost->ai_addr = (struct sockaddr *) malloc(SrcHost->ai_addrlen);

	
	switch (l4Proto) {
	case L4_PROTO_UDP:
		socktype = SOCK_DGRAM;
		break;
	case L4_PROTO_ICMP:
		socktype = SOCK_RAW;
		if (meter == METER_OWDM)
			prototype = (DestHost->ai_family == AF_INET) ? IPPROTO_ICMP : IPPROTO_ICMPV6;
		else if (meter == METER_RTTM)
			prototype = IPPROTO_RAW;
		break;
	default:
		socktype = SOCK_STREAM;
		break;
	}

    	
	int sock = socket(DestHost->ai_family, socktype, prototype);
	if (sock < 0) {
		perror("flowSender");
		printf("Could not create a new socket. Flow ID: %d\n", id);
		msg.code = MSG_SM_ERRFLOW;
		
		if (sendPipeMsg(signalChannels[sigChanId].pipe, &msg) < 0) {
			perror("flowSender sending msg");
			exitThread();
		}
		exitThread();
	}

	
#ifdef LINUX_OS
	int reuse = 1;
	int optlen = sizeof(reuse);
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char*)&reuse, optlen)<0){
		printf("flowSender sending msg");
	}
#endif

	
	if (SrcPortSpecify == true){
#ifdef DEBUG
	printf("Set Port on Sender Side \n");
#endif

#ifdef LINUX_OS
	
	if ( getaddrinfo("::", NULL, NULL, &SrcHost) < 0 )  {
		
		if (SrcHost) freeaddrinfo(SrcHost);
		if ( getaddrinfo("0.0.0.0", NULL, NULL, &SrcHost) <0)
		perror("flowSender");
		printf("Error into getaddrinfo Flow ID: %d\n", id);
		msg.code = MSG_SM_ERRFLOW;
		
		if (sendPipeMsg(signalChannels[sigChanId].pipe, &msg) < 0) {
			perror("flowSender sending msg");
			exitThread();
		}
		exitThread();
	}
#endif

#ifdef WIN32
#ifdef IPv6RECV
      if (getaddrinfo("::", NULL, NULL, &SrcHost) <0){
#else
      if (getaddrinfo("0.0.0.0", NULL, NULL, &SrcHost)<0){
#endif
	perror("flowSender");
	printf("Error into getaddrinfo Flow ID: %d\n", id);
	msg.code = MSG_SM_ERRFLOW;
	
	if (sendPipeMsg(signalChannels[sigChanId].pipe, &msg) < 0) {
		perror("flowSender sending msg");
		exitThread();
	}
	exitThread();
	}
#endif

    SET_PORT(SrcHost, tmpPort_SrcPort);
    if (bind(sock, SrcHost->ai_addr, SrcHost->ai_addrlen)!=0){
	        perror("flowSender");
		printf("Could not bind a new socket. Flow ID: %d\n", id);
		msg.code = MSG_SM_ERRFLOW;
		
		if (sendPipeMsg(signalChannels[sigChanId].pipe, &msg) < 0) {
			perror("flowSender sending msg");
			exitThread();
		}
		exitThread();
	}
	} 


	
	if ((!(l7Proto == L7_PROTO_TELNET) && (!(l7Proto == L7_PROTO_DNS))) && (socktype == SOCK_STREAM)
        && (Nagle == false)) {
		printf("Nagle algorithm disabled\n");
#ifdef LINUX_OS
		int no_delay = 1;
		if (setsockopt(sock, getprotobyname("TCP")->p_proto, TCP_NODELAY, &no_delay,
			sizeof(no_delay)) < 0)
#endif
#ifdef WIN32
		char *no_delayWin;
		no_delayWin = "1";
		if (setsockopt(sock, getprotobyname("TCP")->p_proto, TCP_NODELAY, no_delayWin,
			sizeof(no_delayWin)) < 0)
#endif
			printf("** WARNING ** Flow %d. Cannot disable Nagle Algorithm\n", id);
	}

	
 	MUTEX_THREAD_LOCK(mutexLog);
	if (((logging) && (isFirstThread == 1)) || ((meter == METER_RTTM) && (isFirstThreadRttm == 1))) {
#ifdef  DEBUG
	printf("Log!  \n");
#endif
		isFirstThread = 0;
		isFirstThreadRttm = 0;
		if (!logremoto) {
			out.open(logFile, ios::out | ios::binary | ios::trunc);
			if (!out) {
				printf("** WARNING ** Flow %d. Cannot create local logfile\n", id);
				logging = 0;
			}
		}
		else
			createRemoteLogFile(logHost, protoTxLog);
	}
	MUTEX_THREAD_UNLOCK(mutexLog);

	
	if (connect(sock, DestHost->ai_addr, DestHost->ai_addrlen) < 0) {
		perror("flowSender");
		printf("Error in connect(). Flow ID: %d\n", id);
		
		msg.code = MSG_SM_ERRFLOW;
		if (sendPipeMsg(signalChannels[sigChanId].pipe, &msg) < 0) {
			perror("flowSender sending msg");
			exitThread();
		}
		exitThread();
	}

#ifdef DEBUG
    	printf("DS byte %d\n",DSByte);
#endif
	if (DSByte && setsockopt(sock, IPPROTO_IP, IP_TOS, (char *) &DSByte, sizeof(DSByte)) < 0)
		printf("** WARNING ** Flow %d. Could not set DS byte to: %d\n", id, DSByte);


#ifdef DEBUG
	printf("TTL %d\n", TTL);
#endif
	if (TTL >0 && (setsockopt(sock, IPPROTO_IP, IP_TTL, (char *) &TTL, sizeof(TTL)) < 0))
		printf("** WARNING ** Flow %d. Could not set TTL to: %d\n", id, TTL);


#ifdef LINUX_OS
	getsockname(sock, SrcHost->ai_addr, &SrcHost->ai_addrlen);
#endif
#ifdef WIN32
	getsockname(sock, SrcHost->ai_addr, (int *) &SrcHost->ai_addrlen);
#endif

   	
	getInfo(SrcHost, tmpPort_SrcPort, HelpSrcAddress);
	
	getInfo(DestHost, tmpPort_DstPort, HelpDstAddress);

   	if (l4Proto == L4_PROTO_TCP)
			ptrSize = ptrTimeUsec + sizeof(int);

	printf("Starting sending packets of flow ID: %d\n", id);

	Ticker.count = 0.0;
	memcpy(payload, &id, sizeof(unsigned int));


	TSTART(_tstart, secondi, microsecondi, first, meter, 0);

	GET_TIME_OF_DAY(&start_time, _tend, _tstart, secondi, microsecondi, meter, 0);



	
	end_time.tv_sec = start_time.tv_sec + Duration / 1000 + (end_time.tv_usec =
	    start_time.tv_usec + (Duration % 1000) * 1000) / 1000000;
	end_time.tv_usec %= 1000000;

	GET_TIME_OF_DAY(&Ticker.lastTime, _tend, _tstart, secondi, microsecondi, meter, 0);

	
	if (meter == METER_RTTM) {
	
		start_time.tv_sec = 0;
		start_time.tv_usec = 0;
	
		FD_ZERO(&active_set);
		FD_SET(sock, &active_set);
	}

#ifdef WIN32
	if (flows[id].serial != INVALID_HANDLE_VALUE){
		RTS_Enable(flows[id].serial);
		RTS_Disable(flows[id].serial);
		DTR_Enable(flows[id].serial);
	}
#endif

#ifdef LINUX_OS
	if (flows[id].serial != INVALID_HANDLE_VALUE){
		RTS_Disable(flows[id].serial);
	}
#endif

	
	do {
		if (l4Proto == L4_PROTO_TCP)
			((size = (int) PktSize->Next()) >= MAX_PAYLOAD_SIZE) ? size =

			    MAX_PAYLOAD_SIZE : (size < (MinPayloadSize + (int) sizeof(int))) ? size =
			    (MinPayloadSize + (int) sizeof(int)) : 1;
		else
			((size = (int) PktSize->Next()) >= MAX_PAYLOAD_SIZE) ? size =
			    MAX_PAYLOAD_SIZE : (size < MinPayloadSize) ? size = MinPayloadSize : 1;

		time = Ticker.lastTime.tv_sec % 86400L;

		
		memcpy(ptrSeqNum, &seqNum, sizeof(unsigned int));
		memcpy(ptrTimeSec, &(time), sizeof(long int));
		memcpy(ptrTimeUsec, &(Ticker.lastTime.tv_usec), sizeof(long int));
		if (l4Proto == L4_PROTO_TCP)
				memcpy(ptrSize, &size, sizeof(int));

		if ((l4Proto == L4_PROTO_ICMP) && (meter == METER_OWDM)) {
				if (DestHost->ai_family == AF_INET) {
					icmppkt pkt;					
					pkt.icmp_buf.icmp_type = icmptype;
					pkt.icmp_buf.icmp_code = 0;
					pkt.icmp_buf.icmp_cksum = 0;
					memcpy(&pkt.packet, payload, size);
					pkt.icmp_buf.icmp_cksum =
			    		checksum((unsigned short *) &pkt, size + sizeof(icmp));
					sockchk =
			    			sendto(sock, (char *) &pkt, size + sizeof(icmp), 0,  DestHost->ai_addr,
			    				DestHost->ai_addrlen);
				} else 	if (DestHost->ai_family == AF_INET6) {
#ifdef LINUX_OS
					icmppktv6 pkt;					
					pkt.icmp_buf.icmp_type = icmptype;
					pkt.icmp_buf.icmp_code = 0;
					pkt.icmp_buf.icmp_cksum = 0;
					memcpy(&pkt.packet, payload, size);					
					pkt.icmp_buf.icmp_cksum =
				    		checksum((unsigned short *) &pkt, size + sizeof(icmpv6));
					struct sockaddr_in6 from;
					from.sin6_family=AF_INET6;
					from.sin6_port=0;
					from.sin6_addr=((struct sockaddr_in6*)(DestHost->ai_addr))->sin6_addr;		
					sockchk =
			    			sendto(sock, (char *) &pkt, size + sizeof(icmpv6), 0,  (sockaddr *)&from,
			    		sizeof(from));
#endif
			    } 
		} else {
			sockchk = send(sock, (char *) payload, size, 0);
		}

		if (flows[id].serial != INVALID_HANDLE_VALUE){
	         DTR_Disable(flows[id].serial);
                 DTR_Enable(flows[id].serial);
		}

        if (sockchk < 0)
			printf("** WARNING ** flow: %d Packet: %d not sent\n", id, seqNum);
		else {

			
			if (meter == METER_RTTM) {
				read_set = active_set;
				if (select(FD_SETSIZE, &read_set, NULL, NULL, &start_time) < 0) {
					perror("flowSender");
					printf("invalid fd or operation interrupted by signal\n");
					
					msg.code = MSG_SM_ERRFLOW;
					if (sendPipeMsg(signalChannels[sigChanId].pipe, &msg) < 0) {
						perror("flowSender sending msg");
						exitThread();
					}
					exitThread();
				} 

				if (FD_ISSET(sock, &read_set)) {
					GET_TIME_OF_DAY(&RcvTime, _tend, _tstart, secondi, microsecondi, meter, 0);
					if (l4Proto == L4_PROTO_TCP)
                        		
                        			size_r=TCPrecvPacket((unsigned char*)payload,sock);
                    			else
						size_r = recv(sock, (char *) payload, MAX_PAYLOAD_SIZE, 0);
					time1 = (*(long int *) ptrTimeSec);
					time2 = RcvTime.tv_sec % 86400L;

					
					if (((logging) && (size_r > 0)) || (meter == METER_RTTM)) {
				        	writeInBuffer(&infos[count],*(unsigned int *) payload,*(unsigned int *) ptrSeqNum,
     			           		 	HelpSrcAddress, HelpDstAddress, tmpPort_SrcPort, tmpPort_DstPort, time1,time2,*(long int 	*)
							ptrTimeUsec,RcvTime.tv_usec,size);
						count++;
						
						if (count == DIM) {
					    		flushBuffer(infos, count);
					        	count = 0;
						} 
					} 
		        	} 
			} 

			
			if ((logging) && (meter == METER_OWDM)) {
				if (l7Proto == L7_PROTO_TELNET)
					size = size - 20;
			   	writeInBuffer(&infos[count],*(unsigned int *) payload,*(unsigned int *) ptrSeqNum,
			        HelpSrcAddress, HelpDstAddress, tmpPort_SrcPort, tmpPort_DstPort, time, time, Ticker.lastTime.tv_usec, Ticker.lastTime.tv_usec,size);
				count++;
				
				if (count == DIM) {
					flushBuffer(infos, count);
					count = 0;
				}
			}
		}

		
		wait = IntArriv->Next();	
		UPDATE_TICKER(&Ticker, _tend, _tprec, _tstart, first_update);
		if (wait <= Ticker.count)
			Ticker.count -= wait;
		else {
			while (wait > Ticker.count) {
				wait -= Ticker.count;
				Ticker.count = 0.0;
				timeout.tv_sec = (long) wait / 1000;
				timeout.tv_usec = (long) (wait - (timeout.tv_sec * 1000)) * 1000;
				select(1, NULL, NULL, NULL, &timeout);
				UPDATE_TICKER(&Ticker, _tend, _tprec, _tstart, first_update);
			}
			Ticker.count -= wait;
		}

#ifdef WIN32
		GET_TIME_OF_DAY(&Ticker.lastTime, _tend, _tstart, secondi, microsecondi, meter, 0);
#endif
		seqNum++;
	} while (Ticker.lastTime.tv_sec < end_time.tv_sec
	    || (Ticker.lastTime.tv_sec == end_time.tv_sec && Ticker.lastTime.tv_usec < end_time.tv_usec));

	if (flows[id].serial != INVALID_HANDLE_VALUE)
		RTS_Enable(flows[id].serial);

	

	if (meter == METER_RTTM) {
	        bool flag = true;
		while (flag) {
			start_time.tv_sec = rttmDelay;
			read_set = active_set;
			if (select(FD_SETSIZE, &read_set, NULL, NULL, &start_time) < 0) {
				perror("send_packrttm");
				flag = true;
			} else {
				
				if (FD_ISSET(sock, &read_set)) {
					GET_TIME_OF_DAY(&RcvTime, _tend, _tstart, secondi, microsecondi,
					    meter,0);

					if (l4Proto == L4_PROTO_TCP)
                        			TCPrecvPacket((unsigned char*)payload,sock);
  					 else
						size_r = recv(sock, (char *) payload, MAX_PAYLOAD_SIZE, 0);

					time1 = *(long int *) ptrTimeSec;
					time2 = RcvTime.tv_sec % 86400L;

					
					   if (((logging) && (size_r > 0)) || (meter == METER_RTTM)) {
			               		writeInBuffer(&infos[count],*(unsigned int *) payload,*(unsigned int *) ptrSeqNum,
                                HelpSrcAddress, HelpDstAddress,  tmpPort_SrcPort, tmpPort_DstPort, time1,time2,
						  *(long int*)ptrTimeSec,RcvTime.tv_usec,size);
						count++;

      					
      					if (count == DIM) {
							flushBuffer(infos, count);
							count = 0;
   						}
					} 
				} else {
					
					flag = false;
				} 
			} 
		} 
	}

	
	printf("Finished sending packets of flow ID: %d\n", id);

	
	if ((logging) || (meter == METER_RTTM)) {
		flushBuffer(infos, count);
		count = 0;
	}
	free(infos);

	closeSock(sock);

	
	msg.code = MSG_SM_ENDFLOW;
	if (sendPipeMsg(signalChannels[sigChanId].pipe, &msg) < 0) {
		perror("flowSender sending msg");
		exitThread();
	}
}




void Terminate(int sig)
{
	
	if (logremoto) {
		signaling signaling_log;
		signaling_log.stop = true;
		sendto(logSockSignaling, (char *) &signaling_log, sizeof(signaling_log), 0,
		    logHost->ai_addr, logHost->ai_addrlen);
		if (closeSock(logSock) < 0)
			printf("Error into close  log sock\n");
		if (closeSock(logSockSignaling) < 0)
			printf("Error into close log sock signaling\n");
	} else if (logging) {
		out.close();
	}

	
	memClean();
#ifdef LINUX_OS
	exit(1);
#endif
#ifdef WIN32
	WSACleanup();
	ExitProcess(0);
#endif
}

void printHelp()
{
	cout << " Name " << endl;
	cout << "	 ITGSend - Sender componet of D-ITG platform" << endl << endl;
	cout << " Synopsis" << endl<<endl;
	cout << "   - In case of using a script file to generate multiple flows:" << endl;
	cout << "   ./ITGSend <script_file> [-l [<logfile>]] [-L [<log_server_addr>]" <<endl;
	cout << "             [<protocol_type>]][-X [<log_server_addr>] [<protocol_type>]]" <<endl;
	cout << "             [-x [<receiver_logfile>]] "<<endl<<endl;
	cout << "   - If you want to remotely control the sender, launch it in daemon mode:" <<
	    endl;
	cout << "   ./ITGSend -Q [-l [<logfile>]] [-L [<log_server_addr>] [<protocol_type>]]" <<endl;
	cout <<
	    "	   [-x [<receiver_logfile>]] [-X [<log_server_addr>] [<protocol_type>]]"
	    << endl << endl;
	cout << "   - Otherwise:" << endl;
	cout << "   ./ITGSend [-m <msr_type>][-a <destination_address>][-rp <destination_port>]" <<endl;
	cout << "	   [-sk <sender_serial_iface>]  [-rk <receiver_serial_iface>]" << endl;
	cout << "	   [-b <DS byte>] [-l [<logfile>]] [-L [<log_server_addr>]" <<
	    endl;
	cout << "	   [<protocol _type>]] [-X [<log_server_addr>] [<protocol_type>]]" << endl;
	cout << "	   [-x [<logfile_receiver>]] [-t <duration>] [-d <gen_delay>]" << endl;
	cout << " 	   [-T <protocol_type>] [-s <seed>] [-D] [-f <TTL>] ";
#ifdef WIN32
    cout << " [-P] ";
#endif
    cout << endl;
	cout << "	    [-sp <source_port>]" << endl;
	cout << "	   [[ -C <pkts_per_s> | -U <min_pkts_per_s max_pkts_per_s> | " <<
	    endl;
	cout << "	   -E <average_pkts_per_s> | -V <shape> <scale> | -Y <shap> <scale> |" <<
	    endl;
	cout << "	   -N <mean> <std_dev> | -O <average_pkts_per_s> | -G <shape scale>] " <<
	    endl;
	cout << "	   [ -u <min_pkt_size> <max_pkt_size> | -e <average_pkt_size> |" << endl;
	cout << "	   -v <shape> <scale> | -y <shape> <scale> | -n <mean> <std_dev> |  " << endl;
	cout << "	   -o <average_pkt_size> | -g <shape> <scale> | -c <pkt_size> ]] | " << endl;
	cout << "	   [[Telnet] [DNS] [[VoIP] [-x <codec_type>] [-h <protocol_type>] " << endl;
	cout << "	   [-VAD]]]" << endl;
	cout << endl << " Options" << endl << endl;
	cout <<
	    "  -m  <msr_type>\t\t\tSet the type of meter.\n\t\t\t\t\tValues: owdm (one way delay meter)\n\t\t\t\t\trttm (round trip time meter)\n\t\t\t\t\t(Default: owdm)"
	    << endl;
	cout << "  -a  <destination_address>\t\tSet the destination address\n\t\t\t\t\t\(Default: " << DefaultDestIP << ")" << endl;
	cout << "  -rp <destination_port>\t\tSet the destination port \n\t\t\t\t\t\(Default: " << DEFAULT_PORT << ") " << endl;
	cout << "  -sp <source_port>\t\t\tSet the source port \n\t\t\t\t\t\(Default: Set by O.S.)" << endl;
	cout << "  -sk <sender_serial_iface>\t\tSender serial interface"<<endl;
	cout << "  -rk <receiver_serial_iface>\t\tReceiver serial interface"<<endl;
	cout << "  -s  <seed>\t\t\t\tSet the seed \n\t\t\t\t\t\(Default: Random)" << endl;
	cout << "  -t  <duration>\t\t\tSet the generation duration\n\t\t\t\t\t(Default: " <<
	    DefaultDuration << " msecs)" << endl;
	cout << "  -d <generation_delay>\t\t\tSet the generation delay\n\t\t\t\t\t\(Default: " << DefaultDelay << " msecs)" << endl;
	cout << "  -D \t\t\t\t\tNagle Algorithm Disabled" << endl;
#ifdef WIN32
	cout << "  -P \t\t\t\t\tEnable thread high priority  " << endl;
#endif

    cout << "  -l <logfile>\t\t\t\tGenerate log file\n\t\t\t\t\t(Default: " << DefaultLogFile <<
	    ")" << endl;;
	cout << "  -x  <receiver_logfile>\t\tGenerate log file at the receiver side \n\t\t\t\t\t(Default: " << DefaultRecvLogFile<<
	    ")" << endl;;
	cout << "  -L <log_server_address> \t\tRemote log file \n\t<protocol_type> \t\t(Default: <" <<
	    DEFAULT_LOG_IP << "> <" << invFindL4Proto(DEFAULT_PROTOCOL_TX_LOG) << ">)"<< endl;;
	cout << "  -Z <log_server_address>  \t\tReceiver remote log file\n\t<protocol_type>\t\t\t(Default: <"
	    << DEFAULT_LOG_IP << "> <" <<invFindL4Proto(DEFAULT_PROTOCOL_TX_LOG) << ">)" << endl;

	cout << "  -T <protocol_type>\t\t\t(Default: " << invFindL4Proto(L4_PROTO_UDP) <<
	    ") NOTE: Protocol\n\t\t\t\t\tTypes are: UDP,TCP, ICMP" << endl;

	cout << "  -b <DS_byte>\t\t\t\tSet the DS byte for QoS tests\n\t\t\t\t\t(Default: " << DefaultDSByte << ")" << endl;
	cout << "  -f <TTL byte>\t\t\t\tSet the time to live (TTL) \n\t\t\t\t\t(Default:  64)" << endl;
	cout <<
	    "  -C <pkts_per_s>\t\t\t[DEFAULT] constant inter-arrival\n\t\t\t\t\t(Default: " <<
	    DefaultPktPerSec << " pkts/s)" << endl;
	cout <<
	    "  -U <min_pkts_per_s> <max_pkts_per_s>\tuniformly distributed\n\t\t\t\t\tinter-arrival"
	    << endl;
	cout <<
	    "  -E <average_pkts_per_s>\t\texponentially distributed\n\t\t\t\t\tinter-arrival"
	    << endl;
	cout << "  -V <shape> <scale>\t\t\tpareto distributed\n\t\t\t\t\tinter-arrival" << endl;
	cout << "  -Y <shape> <scale>\t\t\tcauchy distributed\n\t\t\t\t\tinter-arrival" << endl;
	cout << "  -N <mean> <std_dev>\t\t\tnormal distributed\n\t\t\t\t\tinter-arrival" <<
	    endl;
	cout << "  -O <mean>\t\t\t\tpoisson distributed\n\t\t\t\t\tinter-arrival" << endl;
	cout << "  -G <shape> <scale>\t\t\tgamma distributed\n\t\t\t\t\tinter-arrival" << endl;

	cout << "  -c <pkt_size>\t\t\t\t[DEFAULT] constant payload size\n\t\t\t\t\t(Default: "
	    << DefaultPktSize << " bytes)" << endl;
	cout <<
	    "  -u <min_pkt_size> <max_pkt_size>\tuniformly distributed\n\t\t\t\t\tpayload size"
	    << endl;
	cout << "  -e <average_pkt_size>\t\t\texponentially distributed\n\t\t\t\t\tpayload size"
	    << endl;
	cout << "  -v <shape> <scale>\t\t\tpareto distributed\n\t\t\t\t\tpayload size" << endl;
	cout << "  -y <shape> <scale>\t\t\tcauchy distributed\n\t\t\t\t\tpayload size" << endl;
	cout << "  -n <mean> <std_dev>\t\t\tnormal distributed\n\t\t\t\t\tpayload size" << endl;
	cout << "  -o <mean>\t\t\t\tpoisson distributed\n\t\t\t\t\tpayload size" << endl;
	cout << "  -g <shape> <scale>\t\t\tgamma distributed\n\t\t\t\t\tpayload size" << endl;
	cout << " Upper Protocol Options: \n" << endl;
	cout << "  Telnet (without any other option)" << endl;
	cout << "  DNS (without any other option)" << endl;
	cout << "  VoIP (with option: )\t-x <codec_type>\tCodec:  G.711.<1 or 2> (samples per pkt)"
	    << endl;
	cout << " \t\t\t\t\t\tG.729.<2 or 3> (samples per pkt)" << endl;
	cout << " \t\t\t\t\t\tG.723.1" << endl;
	cout << " \t\t\t\t\t\t(Default: G.711.1)" << endl;
	cout << "  \t\t\t-h <protocol_type>\t(Default: RTP)" << endl;
	cout << "  \t\t\t-VAD \t\t\t Voice_Activity_Detection>" << endl;
	cout << endl;
	cout << " For more information consult " "help" " file in the same directory" << endl;

	exit(1);
}

void ReportErrorAndExit(char *function, char *msg, char *pname, int fid)
{
	printf(" ** ERROR **  Flow %d aborted:  %s : %s \n ",fid, function, msg);
	printf("Type %s for help \n", pname);
	memClean();
	exit(1);
}


void createTransportChan(int &signalSock, struct addrinfo *DestHost)
{
	signalSock = socket(DestHost->ai_family, SOCK_STREAM, 0);
	struct sockaddr *locale = (struct sockaddr *) malloc(DestHost->ai_addrlen);
	memcpy(locale, DestHost->ai_addr, DestHost->ai_addrlen);
	if (DestHost->ai_family == PF_INET)
		((struct sockaddr_in *) locale)->sin_port = htons(DEFAULT_PORT_SIGNALING);
	else if (DestHost->ai_family == PF_INET6)
		((struct sockaddr_in6 *) locale)->sin6_port = htons(DEFAULT_PORT_SIGNALING);

	if (connect(signalSock, locale, DestHost->ai_addrlen) < 0) {
		perror("Connect error in createTransportChan()");
		memClean();
		exit(1);
	}
}


void sendType(int signalSock, BYTE type)
{
	char msg[1];

	putValue(&msg, (void *) &type, sizeof(type));
	send(signalSock, (char *) &msg, sizeof(msg), 0);
}


void createSignalChan(int signalSock)
{
	timeval timeout;
	int numSend = 0;
	fd_set active_set;
	int exit = 0;
	do {
		
		sendType(signalSock, TSP_CONNECT);

		
		FD_ZERO(&active_set);
		FD_SET(signalSock, &active_set);
		timeout.tv_sec = TIME_OUT;
		timeout.tv_usec = 0;
		if (select(FD_SETSIZE, &active_set, NULL, NULL, &timeout) < 0) {
			printf("Error ** : Invalid file descriptor\n");
		}
		if (FD_ISSET(signalSock, &active_set)) {
			recvAck(signalSock);
			exit = 1;
		}
	} while ((exit != 1) && (numSend < 2));

	if (numSend == 2)
		printf("** ERROR ** Receiver is down !\n");
}


void sendRelease(int signalSock)
{
	timeval timeout;
	int numSend = 0;
	fd_set active_set;
	int exit = 0;
	do {
		sendType(signalSock, TSP_RELEASE);
#ifdef DEBUG
		printf("sent TSP_RELEASE\n");
#endif
		FD_ZERO(&active_set);
		FD_SET(signalSock, &active_set);
		timeout.tv_sec = TIME_OUT;
		timeout.tv_usec = 0;
		if (select(FD_SETSIZE, &active_set, NULL, NULL, &timeout) < 0) {
			printf("Error ** : Invalid file descriptor\n");
		}
		if (FD_ISSET(signalSock, &active_set)) {
			recvAck(signalSock);
#ifdef DEBUG
			printf("received ack to release signal channel\n");
#endif
			exit = 1;
		}
	} while ((exit != 1) && (numSend < 2));
	if (numSend == 2)
		printf("** ERROR ** Receiver is down !\n");
}


int sendNameLog(int signalSock, char *FileName, int sizeFileName)
{
	char Messaggio[DIM_LOG_FILE + sizeof(BYTE)];
	char *next;
	BYTE type = TSP_SEND_NAME_LOG;
	int ret = 0;
	int sizeMessag;
	next = putValue(&Messaggio, (void *) &type, sizeof(type));
	next = putValue(next, (void *) FileName, sizeFileName);
	sizeMessag = sizeof(type) + sizeFileName;
	ret  = send(signalSock, (char *) &Messaggio, sizeMessag, 0);
	return (ret);
}




int sendLog(int signalSock, struct addrinfo *logHost, BYTE logProtocol, char *FileName)
{
	char Messaggio[DIM_LOG_FILE + 20];
	char *next;
	BYTE type = TSP_SEND_FLOW_LOG;
	int ret, sizeMessag;
	next = putValue(&Messaggio, (void *) &type, sizeof(type));
	next = putValue(next, (void *) &(logHost->ai_family), sizeof(int));
	if (logHost->ai_family == PF_INET) {
		next =
		    putValue(next,
		    (void *) &(((struct sockaddr_in *) logHost->ai_addr)->sin_addr.s_addr),
		    sizeof(in_addr_t));
		next =
		    putValue(next, (void *) &(((struct sockaddr_in *) logHost->ai_addr)->sin_port),
		    sizeof(in_port_t));
	} else if (logHost->ai_family == PF_INET6) {
		next =
		    putValue(next,
		    (void *) (((struct sockaddr_in6 *) logHost->ai_addr)->sin6_addr.s6_addr32),
		    4 * sizeof(in_addr_t));
		next =
		    putValue(next,
		    (void *) &((
		    (struct sockaddr_in6 *) logHost->ai_addr)->sin6_port),
		    sizeof(in_port_t));
	}
	next = putValue(next, (void *) &logProtocol, sizeof(logProtocol));
	next = putValue(next, (void *) FileName, DIM_LOG_FILE);

	sizeMessag = sizeof(type) + sizeof(int) + sizeof(in_port_t) + sizeof(BYTE) + DIM_LOG_FILE;
	if (logHost->ai_family == PF_INET)
		sizeMessag += sizeof(in_addr_t);
	else if (logHost->ai_family == PF_INET6)
		sizeMessag += 4 * sizeof(in_addr_t);

	ret = send(signalSock, (char *) &Messaggio, sizeMessag, 0);
	return (ret);
}


void recvAck(int signalSock)
{
	int i;
	char buffer;
	i = recv(signalSock, (char *) &buffer, sizeof(BYTE), 0);
}


void closedFlowErr(int flowId, int signalSock)
{
	char *next;
	BYTE type = TSP_CLOSED_ERR;
	int sizeMessag = sizeof(int) + sizeof(type);
	char Messaggio[sizeMessag];

	next = putValue(&Messaggio, (void *) &type, sizeof(type));
	next = putValue(next, (void *) &flowId, sizeof(int));
	int size;
	size = send(signalSock, (char *) &Messaggio, sizeMessag, 0);
	if (size < 0) {
		printf("error into send\n");
		memClean();
		exit(1);
	}
}


int closedFlow(int flowId, int signalSock)
{
	char *next;
	BYTE type = 4;
	int sizeMessag = sizeof(int) + sizeof(type);
	char Messaggio[sizeMessag];

	next = putValue(&Messaggio, (void *) &type, sizeof(type));
	next = putValue(next, (void *) &flowId, sizeof(int));

	if (send(signalSock, (char *) &Messaggio, sizeMessag, 0) < 0) {
		printf("Error in request to close\n");
		return(-1);
	}

	return (0);
}


int requestToSend(int flowId, int signalSock)
{
	char Messaggio[100];
	char *next;
	BYTE type = 3;
	int sizeMessag;

   	struct addrinfo *DestHost = flows[flowId].DestHost;
	BYTE l4Proto = flows[flowId].l4Proto;
	BYTE l7Proto = flows[flowId].l7Proto;
	BYTE meter = flows[flowId].meter;


 	
	
	
	

	next = putValue(&Messaggio, (void *) &type, sizeof(type));
	next = putValue(next, (void *) &l4Proto, sizeof(type));
	next = putValue(next, (void *) &l7Proto, sizeof(type));
	next = putValue(next, (void *) &meter, sizeof(type));
	next = putValue(next, (void *) &(DestHost->ai_family), sizeof(int));
	next = putValue(next, (void *) &flowId, sizeof(int));
 	next = putValue(next, (void *) &flows[flowId].serialReceiver, DIM_NAME_SERIAL_INTERFACE);
 	
	if (DestHost->ai_family == PF_INET) {
		next =
		    putValue(next, (void *) &(((struct sockaddr_in *) DestHost->ai_addr)->sin_port),
		    sizeof(in_port_t));
		
		next =
		    putValue(next,
		    (void *) &(((struct sockaddr_in *) DestHost->ai_addr)->sin_addr.s_addr),
		    sizeof(in_addr_t));
	} else if (DestHost->ai_family == PF_INET6) {
		
		next =
		    putValue(next,
		    (void *) &(((struct sockaddr_in6 *) DestHost->ai_addr)->sin6_port),
		    sizeof(in_port_t));
		next =
		    putValue(next,
		    (void *) (((struct sockaddr_in6 *) DestHost->ai_addr)->sin6_addr.s6_addr32),
		    4 * sizeof(in_addr_t));
	}

	sizeMessag = 4 * sizeof(type) + 2 * sizeof(int) + sizeof(in_port_t) + DIM_NAME_SERIAL_INTERFACE;
	if (DestHost->ai_family == PF_INET)
		sizeMessag += sizeof(in_addr_t);
	else if (DestHost->ai_family == PF_INET6)
		sizeMessag += 4 * sizeof(in_addr_t);

	if (send(signalSock, (char *) &Messaggio, sizeMessag, 0) < 0) {
		printf("Error in request to send\n");
		return(-1);
	}

	return(0);
}


bool checkDestHostIP(int * chanId, struct addrinfo * DestHost)
{
	int i = 0;

	while (i < MAX_NUM_THREAD) {
		

		if ((signalChannels[i].socket != -1)
		  && (ARE_INET_ADDR_EQUAL(DestHost, signalChannels[i].DestAddr))) {
		      signalChannels[i].flows++;
		      *chanId = i;
		      return true;
        }
		i++;
	}
	return false;
}

void argvToString(char *argv[], int argc, char line[200])
{
	int i = 0;

	strcpy(line, " ");
	while (argc > 0) {
		strcat(line, argv[i]);
		strcat(line, " ");
		argc--;
		i++;
	}
	strcat(line, "\n");
}


void flushBuffer(info *infos, int count)
{
	if (logremoto) {
		if(sendto(logSock, (char *) infos, count * sizeof(struct info), 0, logHost->ai_addr,
		    logHost->ai_addrlen) < 0)
			printf("ERROR Sending infos to logger....\n");
	} else {
		MUTEX_THREAD_LOCK(mutexLog);
		out.write((const char *) infos, count * sizeof(struct info));
		MUTEX_THREAD_UNLOCK(mutexLog);
	}
}


void memClean()
{
}




void createRemoteLogFile(struct addrinfo *logHost, BYTE protocolLog)
{
	
	int sizeMsg = sizeof(int);
	
	char buffer[sizeMsg];

	

	createSignalingLogChannel(protocolLog);

	

	switch(protocolLog) {
		case L4_PROTO_UDP :
		
			logSock = socket(logHost->ai_family, SOCK_DGRAM, 0);
			if (logSock < 0)
				ReportErrorAndExit("createRemoteLogFile","socket DATAGRAM - Cannot create socket logSock", programName, 0);
			break;
		case L4_PROTO_TCP :
            
			logSock = socket(logHost->ai_family, SOCK_STREAM, 0);
			if (logSock < 0)
				ReportErrorAndExit("createRemoteLogFile","socket STREAM - Cannot create socket logSock", programName, 0);
			break;
		default :
			break;
	}
	
	if ( recv(logSockSignaling, (char *) buffer, sizeof(buffer), 0) < 0)
		ReportErrorAndExit("createRemoteLogFile","Cannot receive on signaling socket", programName, 0);
#ifdef DEBUG
	printf("Port received for log : %d\n",*(unsigned int *) buffer);
#endif
	
	SET_PORT(logHost, htons(*(unsigned int *) buffer));
	sleep(1);
    
	if (connect(logSock, logHost->ai_addr, logHost->ai_addrlen) < 0)
		ReportErrorAndExit("createRemoteLogFile","Error into connect with logsender!", programName, 0);
}



void createSignalingLogChannel(BYTE protocolLog)
{
	
	signaling signal;
	
	char buffer[1];

	

	logSockSignaling = socket(logHost->ai_family, SOCK_STREAM, 0);
	if (logSockSignaling < 0)
		ReportErrorAndExit("createSignalingLogChannel","Cannot create socket logSockSignaling!", programName, 0);
	
	SET_PORT(logHost, htons(DEFAULT_LOG_PORT_SIGNALING));
	
	signal.protocol = protocolLog;
	
	strcpy(signal.logFile, logFile);
	
	if (connect(logSockSignaling, logHost->ai_addr, logHost->ai_addrlen) < 0)
		ReportErrorAndExit("createSignalingLogChannel","Error into connect !", programName, 0);
	
	do {
		if (recv(logSockSignaling, (char *) &buffer, sizeof(BYTE), 0) < 0)
		ReportErrorAndExit("createSignalingLogChannel","Error into receive!", programName, 0);
	
  	} while (*(BYTE *) buffer != LOG_CONNECT);
#ifdef DEBUG
	printf("Log Signal Manager : Received LOG_CONNECT Message\n");
#endif
	
	if (send(logSockSignaling, (char *) &signal, sizeof(signal), 0) < 0)
		ReportErrorAndExit("createSignalingLogChannel","Cannot send infos to LogServer !", programName, 0);

#ifdef DEBUG
	printf("Log Signal Manager : Sent to LogServer infos for creating signaling channel\n");
#endif
}

