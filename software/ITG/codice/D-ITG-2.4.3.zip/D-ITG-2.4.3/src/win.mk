export DEVDIR=C:/Dev-Cpp
export OS = WIN32
export RM = del
export CP = copy
export SUFFIX = ".exe"
export CXXFLAGS = -O2 -Wall -DWIN32 -Wno-deprecated -I$(DEVDIR)/Include/G++ -I$(DEVDIR)/Include/c++ -I$(DEVDIR)/Include/c++/mingw32 -I$(DEVDIR)/Include/c++/backward -I$(DEVDIR)/Include -L$(DEVDIR)/Lib
export LDFLAGS = $(DEVDIR)/Lib/libws2_32.a 
export BASEDIR = $(shell cd)
export BIN = "$(BASEDIR)\..\bin\"
export COMMON = "$(BASEDIR)\common\"
export NRCLEAN = "$(BASEDIR)\ITGSend\newran\"

