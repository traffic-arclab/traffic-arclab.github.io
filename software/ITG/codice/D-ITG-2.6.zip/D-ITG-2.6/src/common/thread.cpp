/*
 *	Component of the D-ITG v2.6 platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright    : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                      Walter de Donato, Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and 
 *                                      CommunicationS) Group, Dipartimento di Informatica
 *                                      e Sistemistica of the University of Napoli "Federico II".
 *      email        : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                     walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is open-source and completely free for Universities, Schools,
 *      Research Institutes, and Individuals; it is also free for Companies that 
 *      use D-ITG for their research; you can redistribute it and/or modify it 
 *      under the terms of the D-ITG NON-COMMERCIAL LICENSE as reported in the 
 *      LICENSE file of this ditribution; either version 1 of the License, or
 *      (at your option) any later version.
 *
 *      For commercial use please refer to D-ITG Professional.
 */


#ifdef WIN32
    int num = 0;
#endif

#include "thread.h"
#include "debug.h"




int createThread(void *argument, void *(nameFunction) (void *), void *attrib, pthread_t &idThread)
{
	
	int ret = 0;
#ifdef WIN32	
	
	void *pid;
	
	idThread =
	    CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) nameFunction, argument, (DWORD) NULL,
	    (unsigned long *) &pid);
    PRINTD(1,"Return value CreateThread (WIN32) %d\n",(int)idThread);
	if (idThread == NULL) ret = -1;
	PRINTD(1,"Return value createThread : %d\n",ret);
#endif

#ifdef LINUX_OS
	
	 
	ret = pthread_create(&idThread, NULL, nameFunction, argument);
	if (ret != 0) ret = -1;
    PRINTD(1,"Return value pthread_create (LINUX) %d\n",(int)idThread);
    PRINTD(1,"Return value createThread : %d\n",ret);
#endif
	return ret;
};


int terminateThread(pthread_t idThread)
{
	
	int ret = 0;
#ifdef WIN32
	
	ret = TerminateThread((HANDLE) idThread, 0);
	if (ret == 0) ret = -1;
	else ret = 0;
#endif
#ifdef LINUX_OS
	
	ret = pthread_cancel(idThread);
	if (ret != 0) ret = -1;
#endif
    PRINTD(1,"Return value terminateThread : %d\n",ret);
	return ret;
}; 


void exitThread()
{
#ifdef WIN32
	
	ExitThread(0);
#endif
#ifdef LINUX_OS
	
	pthread_exit(0);
#endif
};


int joinThread(int numFlow, pthread_t hThr[])
{
	int ret = 0;
#ifdef WIN32
	DWORD temp = 0;
	
	temp = WaitForMultipleObjects(numFlow, (const HANDLE *) hThr, TRUE, INFINITE);
    PRINTD(1,"Return value WaitForMultipleObjects(WIN32) : %d\n",(int)temp);
	if (temp == WAIT_FAILED) ret = -1;
#endif
#ifdef LINUX_OS
	
	int ret2 = 0;
	for(int i = 0; i < numFlow; i++) {
		ret2 = pthread_join(hThr[i], NULL);
		if (ret2 != 0)
			ret = -1;
	}
#endif
    PRINTD(1,"Return value joinThread : %d\n",ret);
    return ret;
};



#ifdef WIN32

int mutexThreadInit(HANDLE &mutex)
{
	int ret = 0;
	
	 char stringa[30];
	 char nameMutex[30]="";
	 num++;

	  
	  strcat(nameMutex, nameProgram);
      sprintf(stringa, "%d", num);
	  strcat(nameMutex, stringa);
	 
	 
	 mutex = CreateMutex(NULL, FALSE, nameMutex);

	 PRINTD(1,"Return value CreateMutex (WIN32) : %d \n",(int)mutex);
     PRINTD(1,"Name mutex %s \n", nameMutex);

	 if (mutex == NULL) ret = -1;
     PRINTD(1,"Return value mutexThreadInit : %d \n",ret);
	return ret;
}
#endif

#ifdef LINUX_OS

int mutexThreadInit(void* mutex)
{
	int ret = 0;
	
	ret = pthread_mutex_init((pthread_mutex_t *)mutex, NULL);
	PRINTD(1,"Return value pthread_mutex_init (LINUX) : %d \n", (int) mutex);
	PRINTD(1,"Return value mutexThreadInit : %d \n",ret);
	return ret;
}
#endif
	

int mutexThreadLock(void *mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_lock((pthread_mutex_t *) mutex);
	if (ret != 0 ) ret = -1;
#endif
#ifdef WIN32
	DWORD temp = 0;
	
	temp = WaitForSingleObject((HANDLE)mutex,INFINITE);
    PRINTD(1,"Return value WaitForSingleObject(WIN32) : %d\n",(int)temp);
	if (temp == WAIT_FAILED) ret = -1;
#endif
    PRINTD(1,"Return value mutexThreadLock : %d\n",ret);
	return ret;
};


int mutexThreadUnlock(void *mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_unlock((pthread_mutex_t *) mutex);
	if (ret != 0 ) ret = -1;
#endif
#ifdef WIN32
	BOOL flag = 0;
	
	flag = ReleaseMutex((HANDLE)mutex);
    PRINTD(1,"Return value ReleaseMutex(WIN32) in mutexThreadUnlock : %d\n",flag);
	if (flag == 0) ret = -1;
#endif
    PRINTD(1,"Return value mutexThreadUnlock : %d\n",ret);
	return ret;
};



int mutexThreadRelease(void* mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_destroy((pthread_mutex_t *)mutex);
	if (ret != 0) ret = -1;
#endif
#ifdef WIN32
		BOOL flag = 0;
		
		flag = CloseHandle((HANDLE)mutex);
		if (flag == 0) ret = -1;
#endif
    PRINTD(1,"Return value mutexThreadRelease : %d\n",ret);
	return ret;
}





int closeSock(int socket)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = close(socket);
#endif
#ifdef WIN32
	
	ret = closesocket(socket);
	if (ret == SOCKET_ERROR) ret = -1;
#endif
    PRINTD(1,"Return value closeSock : %d\n",ret);
	return ret;
};
