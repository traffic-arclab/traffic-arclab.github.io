/*
 *	Component of the D-ITG v2.6 platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright    : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                      Walter de Donato, Antonio Pescape' (PI)
 *                                      of the COMICS (COMputer for Interaction and 
 *                                      CommunicationS) Group, Dipartimento di Informatica
 *                                      e Sistemistica of the University of Napoli "Federico II".
 *      email        : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                     walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is open-source and completely free for Universities, Schools,
 *      Research Institutes, and Individuals; it is also free for Companies that 
 *      use D-ITG for their research; you can redistribute it and/or modify it 
 *      under the terms of the D-ITG NON-COMMERCIAL LICENSE as reported in the 
 *      LICENSE file of this ditribution; either version 1 of the License, or
 *      (at your option) any later version.
 *
 *      For commercial use please refer to D-ITG Professional.
 */


#include "../libITG/ITGapi.h"
#include <stdio.h>
#include <string.h>

int main()
{
	char *sender, *msg;
	int i;
	char command[] = "-C 10 -c 1001 -sp 9005 -rp 9006 -t 5000 -a 127.0.0.1";
	DITGsend("localhost", command);

	do {
		if ((i = catchManagerMsg(&sender, &msg)) != MNG_NOMSG)
			printf("Received msg type %d   %s   %s\n", i, sender, msg);
 } while (1);
}
