/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */


#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <stdio.h>

#ifdef DEBUG
	#define PRINTD(level, ...)		if (DEBUG >= level) { printf(__VA_ARGS__); fflush(stdout); }
#else
	#define PRINTD(level, ...)
#endif

#ifdef DEBUG
	#ifdef LINUX_OS
		#define PRINTDS(level, ...)	    if (DEBUG >= level) { usleep(1000); printf(__VA_ARGS__); fflush(stdout); }
	#endif
	#ifdef WIN32
		#define PRINTDS(level, ...)	    if (DEBUG >= level) { Sleep(1000); printf(__VA_ARGS__); fflush(stdout); }
	#endif
#else
	#define PRINTDS(level, ...)
#endif

#endif

