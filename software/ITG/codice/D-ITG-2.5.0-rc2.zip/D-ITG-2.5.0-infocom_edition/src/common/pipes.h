/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */


#define PIPE_BUFSIZE 1000
#define PIPE_TIMEOUT 100000
extern char nameProgram[];

struct pipeMsg {
	int flowId;
	int code;
};

#ifdef WIN32
extern HANDLE mutex_numPipes;
extern int numPipes;
#endif

#ifdef LINUX_OS
int createNewPipe(int fd[2]);
int sendPipeMsg(int fd[2], pipeMsg *msg);
int recvPipeMsg(int fd[2], pipeMsg *msg);
int closePipe(int fd[2]);
#endif
#ifdef WIN32
int createNewPipe(HANDLE pipe[3]);
int sendPipeMsg(HANDLE pipe[3], pipeMsg *msg);
int recvPipeMsg(HANDLE pipe[3], pipeMsg *msg);
int closePipe(HANDLE fd[3]);
#endif

