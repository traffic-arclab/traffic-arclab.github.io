/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */


#include "../libITG/ITGapi.h"
#include <stdio.h>
#include <string.h>

int main()
{
	char *sender, *msg;
	int i;
	char command[] = "-C 10 -c 1001 -sp 9005 -rp 9006 -t 5000 -a 127.0.0.1";
	DITGsend("localhost", command);

	do {
		if ((i = catchManagerMsg(&sender, &msg)) != MNG_NOMSG)
			printf("Received msg type %d   %s   %s\n", i, sender, msg);
 } while (1);
}
