/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Walter de Donato, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , walter.dedonato@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */






#define OFFSET_LOG_PORT 1000


#define SEED_LOG_PORT 9003


struct paramLogThread {
	int socket;					
};






extern ofstream out;


extern int flagTerm;


extern signaling signalingLog;


extern struct sockaddr_in senderLog;


extern int signalSocket;


#ifdef LINUX_OS
extern const char DEFAULT_LOG_FILE[];


#endif

#ifdef WIN32
extern const char DEFAULT_LOG_FILE[];

extern HANDLE mutexLog;

#endif




void printHelpAndExit();


void closeFileLog(ofstream *out);


void recvInfo(int signalingChannel,BYTE &protocol,char logFile[DIM_LOG_FILE]);


int findPortFree(int logSock);


char* allowedLogFile(char logFile[DIM_LOG_FILE]);


void *channelManager(void *param);



void terminate(int sign);



void reportErrorAndExit(char *function, char *program, char *msg);


void createSignalingChannel();



void logInit();



void parserLog(int argc , char *argv[]);

