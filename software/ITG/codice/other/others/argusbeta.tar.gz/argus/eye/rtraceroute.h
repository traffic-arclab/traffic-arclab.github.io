int rtraceroute(int argc, char **argv, char *answer, int nAnswer);
