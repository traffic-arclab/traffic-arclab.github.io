#include <stdlib.h>
#include <stdio.h>
#include "rtraceroute.h"

int main(int argc, char **argv)
{
  char answer[10240];

#ifdef HAVE_SETLINEBUF
	setlinebuf (stdout);
#else
	setvbuf(stdout, NULL, _IOLBF, 0);
#endif

  rtraceroute(argc, argv, answer, 10240);
  printf("%s", answer);
}
