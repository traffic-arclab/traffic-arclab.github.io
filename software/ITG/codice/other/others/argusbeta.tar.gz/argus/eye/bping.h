int bping(int argc, char **argv, char *answer, int nAnswer);
