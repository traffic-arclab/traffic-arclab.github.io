//#define MYDEBUG
#define ERRTAG "!!"

#define Printf(s) snprintf(g_answer, g_nAnswer, "%s" s, g_answer)
#define Printf1(s, arg0) \
     snprintf(g_answer, g_nAnswer, "%s" s, g_answer, \
	      arg0)
#define Printf2(s, arg0, arg1) \
     snprintf(g_answer, g_nAnswer, "%s" s, g_answer, \
	      arg0, arg1)
#define Printf3(s, arg0, arg1, arg2) \
     snprintf(g_answer, g_nAnswer, "%s" s, g_answer, \
	      arg0, arg1, arg2)
#define Printf4(s, arg0, arg1, arg2, arg3) \
     snprintf(g_answer, g_nAnswer, "%s" s, g_answer, \
	      arg0, arg1, arg2)

#define PrintError(err) Printf(ERRTAG err)
#define PrintError1(err, arg0) Printf1(ERRTAG err, arg0)
#define PrintError2(err, arg0, arg1) Printf2(ERRTAG err, arg0, arg1)
#define PrintError3(err, arg0, arg1, arg2) \
     Printf3(ERRTAG err, arg0, arg1, arg2)
#define PrintError4(err, arg0, arg1, arg2, arg3) \
     Printf4(ERRTAG err, arg0, arg1, arg2, arg3)
#define PError(err) Printf2("%s%s", err, strerror(errno))

// my own debugging routines
#ifdef MYDEBUG
#define MyPrintf(str) printf(str)
#define MyPrintf1(str, arg1) printf(str, arg1)
#define MyPrintf2(str, arg1, arg2) printf(str, arg1, arg2)
#define MyPrintf3(str, arg1, arg2, arg3) printf(str, arg1, arg2, arg3)
#define MyPrintf4(str, arg1, arg2, arg3, arg4) printf(str, arg1, arg2, arg3, arg4)
#else
#define MyPrintf(str)
#define MyPrintf1(str, arg1)
#define MyPrintf2(str, arg1, arg2)
#define MyPrintf3(str, arg1, arg2, arg3)
#define MyPrintf4(str, arg1, arg2, arg3, arg4)
#endif

#define EMPTY_IN_ADDR(inaddr) (!(*((int *) (inaddr))))


/* Host name and address list */
struct hostinfo {
	char *name;
	int n;
	u_int32_t *addrs;
};

extern char *g_answer;
extern int g_nAnswer;
extern char *g_prog;

char * pr_type( register int t );

int pr_pack( char *buf, int cc, struct sockaddr_in *from );

u_short in_cksum(u_short *addr, int len);

void tvsub( register struct timeval *out, register struct timeval *in );

char *inetname(struct in_addr in);

void setsin(struct sockaddr_in *, u_int32_t);

int	str2val(const char *, const char *, int, int);

void	getaddr(u_int32_t *, char *);

struct	hostinfo *gethostinfo(char *);

double	deltaT(struct timeval *, struct timeval *);

void	freehostinfo(struct hostinfo *);
