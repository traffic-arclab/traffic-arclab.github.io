#!/usr/local/bin/perl
use Socket;
use strict;

sub call_socket {
    my ($hostname, $port) = @_;
    my ($iaddr, $paddr, $proto);
#    local (*SOCKET);

    $iaddr = inet_aton($hostname);
    $paddr = sockaddr_in($port, $iaddr);

    $proto = getprotobyname('tcp');
    socket(SOCKET, PF_INET, SOCK_STREAM, $proto) or die "socket: $!";
    connect(SOCKET, $paddr) or die "connect: $!";

#    return *SOCKET;
}

sub send_sock {
    my ($text) = @_;
#    send SOCKET, (pack 'N', length $text), 0;
    send SOCKET, $text, 0;
}

my $eyepassword = "brainrq";

my ($n, $size, $line);
my ($request);
my $httpheader = "POST $eyepassword HTTP/1.0\n";
my $mimetype = "Content-Type: multipart/mixed\n";
my $mimebound = "boundary=BrainMsgBound\n";
my $mimeboundary = "--BrainMsgBound\n";
my $mimeterminate = "--BrainMsgBound--\n";
#local (*SOCK);

&call_socket("sim1.cs.cornell.edu", 53333);
while ($request = <STDIN>) {

# add http stuff
    print $request;
# really got to encapsulate the following...
    &send_sock($httpheader);
    &send_sock("\n");
    &send_sock($mimetype);
    &send_sock($mimebound);
    &send_sock("\n");
    &send_sock($mimeboundary);
 

    &send_sock($request);

    &send_sock("\n");
    &send_sock($mimeterminate);

    if ($request =~ /quit/) {
	last;
    }
    print "Request sent, waiting for response\n";
    while ($line = <SOCKET>) {
	print $line;
	if ($line =~/--EyeMsgBound--/) {
	    last;
	}
    }
    print "Next command:\n";
}

close(SOCK);
