int ftraceroute(int argc, char **argv, char *answer, int nAnswer);
