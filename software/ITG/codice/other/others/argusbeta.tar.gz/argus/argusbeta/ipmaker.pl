
sub ipmaker_rand {
    my($my_addrs, $iprange, $num) = @_;
    my $rand_number;
    my $i;
    for ($i = 0; $i < $num; $i++) {
	$_ = $iprange;
	while (/.*\*.*/) {
	    $rand_number = int(rand 255) + 1;
	    s/\*/$rand_number/;
	}
	add_addr($_,$my_addrs);
    }
}

sub ipmaker_all {
    my($my_addrs, $iprange, $num) = @_;
    my $i;

    if ($num eq '') {
	$num = 1;
    }
    
    $_ = $iprange;
    if (/\[(\d*)-(\d*)\]/) {
	my $low = $1;
	my $high = $2;
	for ($i = $low; $i <= $high; $i++) {
	    $_ = $iprange;
	    s/\[\d*-\d*\]/$i/;
	    &ipmaker_all($my_addrs, $_, $num);
	}
    } elsif (/\*/) {
	for ($i = 1; $i < 256; $i++) {
	    $_ = $iprange;
	    s/\*/$i/;
	    &ipmaker_all($my_addrs, $_, $num);
	}
    } elsif (/\?/) {
	for ($i = 0; $i < $num; $i++) {
	    $_ = $iprange;
	    $rand_number = int(rand 255) + 1;
	    while (/.*\?.*/) {
		$rand_number = int(rand 255) + 1;
		s/\?/$rand_number/;
	    }
	    push(@$my_addrs, $_);
	}
    } else {
	push(@$my_addrs, $iprange);
    }
    
}

return 1;

# my $addrs;

# @$addrs = '';
# ipmaker_rand($addrs, "128.253.*.1", 50);
# for (local($j) = 0; $j <= $#$addrs; $j++) {
#     $temp = @$addrs[$j];
# }


