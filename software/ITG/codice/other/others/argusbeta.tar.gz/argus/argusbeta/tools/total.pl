#!/usr/u/cnrg/bin/perl

$total=0;
while ($line=<>){
  if ($line=~/\#\#\#(\d+)/)
    {$total+=$1;}
  print $line;
}
print ">>>>>>Total>>>>>>$total\n";
