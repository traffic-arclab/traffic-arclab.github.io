#!/usr/local/bin/perl

require 'inet.pl';
require 'init.pl';
require 'dns.pl';
require 'ping.pl';
require 'dbinterface.pl';
require 'logging.pl';
require 'tracert.pl';

my ($domain)=$ARGV[0];
&init_single('test');
#&dns_init;
#&ping_init;
my ($names)=&rec_dns($domain);
my ($name);
my %visited=();
foreach $name (@$names)
  {next if ($visited{$name});
   print "$name ";
   foreach $a (&dns_name2addrs($name))
     {print "$a ";}
   print "\n";
   $visited{$name}='1';
 }
