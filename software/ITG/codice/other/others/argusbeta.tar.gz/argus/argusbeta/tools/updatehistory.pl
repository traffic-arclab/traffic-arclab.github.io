#!/usr/local/bin/perl

require 'history.pl';
require 'logging.pl';

$histfile=$ARGV[0];
$ipfile=$ARGV[1];

log_message(4,"History file $histfile IP file $ipfile reading history");

&read_history($histfile);

log_message(4,"Updating history");
$HISTORY_LENGTH=50;

&update_history($histfile,$ipfile);
