#!/usr/local/bin/perl

require 'inet.pl';
require 'init.pl';
require 'dns.pl';
require 'ping.pl';
require 'dbinterface.pl';
require 'logging.pl';
require 'tracert.pl';

my ($domain)=$ARGV[0];
&init_single('test');
#&dns_init;
#&ping_init;
my ($names)=&rec_dns($domain);
my ($name);
my %visited=();
foreach $name (@$names)
  {$i++;
   next if ($visited{$name});
#   print "$name ";
   foreach $a (&dns_name2addrs($name))
     {$xx=&dns_addr2name($a);
      if (!$xx)
	{$void++;}
      elsif ($xx ne $name)
	{print "$name*$xx\n";$bad++}
      else
	{$good++}
    }
#   print "\n";
   $visited{$name}='1';
 }
print "i $i, void $void, bad $bad, good $good\n";
