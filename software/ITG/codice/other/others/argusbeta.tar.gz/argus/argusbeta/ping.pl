#
# Haye, please clean up this file! Pleeeeeeeeeeease!
#

sub ping_init {

  $PINGS_SENT = 0;
  $PINGS_RECEIVED = 0;
  #arbitrary => usually timeout less than 10000 ms.
#  $PING_MAX = 0;
#  $PING_AVG = 0;
#  $PING_MIN = 10000;
#  $PING_TIMEOUT_TEST = 100;
#  $PING_LARGER = 0;

  if ($USE_EYE) {return 1;}
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  if (-x "/tmp/bping64")
    {$BPING="/tmp/bping64";}
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  elsif ( -x "/usr/sbin/bping" ) 
    {$BPING="/usr/sbin/bping";}
  elsif ( -x "/usr/local/sbin/bping" ) 
    {$BPING="/usr/local/sbin/bping";}
  else
    {die "Could not find bping"}

  return 1;
}

sub ping_print_stats {
#    local ($percentile);
    log_message(4 ,"Pings sent $PINGS_SENT, Pings received $PINGS_RECEIVED");
#    print "maximum ping rtt = $PING_MAX ms, minimum rtt = $PING_MIN ms\n";
#    print "average ping rtt = $PING_AVG ms\n";
#    if ($PINGS_RECEIVED)
#    {$percentile = (($PINGS_RECEIVED - $PING_LARGER) / $PINGS_RECEIVED) * 100;}
#    print "timeout $PING_TIMEOUT_TEST ms is the $percentile% percentile\n";
#    print "PING_TIMEOUT=$PING_TIMEOUT BATCHSIZE=$BATCHSIZE\n";
}

sub bping_cmdline 
  {my($addrs, $size, $cnt, $timeout)=@_;

# this will automatically return an error, thus will be
# OK. This is to fix the "freezing" problem on solaris
# when a null address is given and it just stops
   if ($addrs eq '') { return "Invalid Ping"; }

#print "$BPING $addrs $size $cnt $timeout\n";
   return "$BPING $addrs $size $cnt $timeout".($USE_EYE?'':'|');
 }

sub bping_alive {
  local($timeout,@addrs)=@_;
  local(*HOSTFILE, *FOO);
  my (@livehosts) =();
  my (@ttllist) =();
  my (@rttlist) = ();
  my ($ttl);
  local($cnt) = 0;

  if ($timeout<=0)
    {&log_message(1,"Nonpositive timeout $timeout passed to bping");
     $timeout=200;
    }

  $PINGS_SENT+=@addrs;

  unless ($USE_EYE) {
    open(FOO,&bping_cmdline(join(',',@addrs), 8, 1, $timeout));
    while (<FOO>) {
      if (/PRT\s-\s.*/) { 
	last;
      }
    }
    while (<FOO>) {
      if (/^--.*/) {
	break;
      } elsif (/.*:\s(.*),.*=\s(-*\d+).*=\s(\d+).*ms.*/)  {
#	  print "status = $1, hop count = $2, rtt = $3 ms\n";
	if ($1 eq 'alive') {
	  $PINGS_RECEIVED++;
	  push @livehosts, 0;
	} else {
	  push @livehosts, -1;
	}
	push @ttllist, $2;
	push @rttlist, $3;
      }
    }
    close FOO;
    return (\@livehosts,\@ttllist, \@rttlist);
  } else {
    return remoteinvoke ('SOCKET','bping_alive',@_);
  }
}

sub simple_bping_alive {
  local($timeout,@addrs)=@_;
  local(*HOSTFILE, *FOO);
  my (@livehosts) =();
  local($cnt) = 0;

  if ($timeout<=0)
    {&log_message(1,"Nonpositive timeout $timeout passed to bping");
     $timeout=200;
    }
  $PINGS_SENT+=@addrs;
  unless ($USE_EYE) {
    open(FOO,&bping_cmdline(join(',',@addrs), 8, 1, $timeout));

    $cnt=0;
    while (<FOO>) {
      if (/PRT\s-\s.*/) { 
	last;
      }
    }
    while (<FOO>) {
      if (/^--.*/) {
	break;
      } elsif (/.*:\s(.*),.*=\s(-*\d+).*=\s(\d+).*ms.*/) {
	if ($1 eq 'alive') {
	  push @livehosts,$addrs[$cnt];
	}
	$cnt++;
      }
    }
    close FOO;
    return (\@livehosts);
  } else {
   return remoteinvoke ('SOCKET','simple_bping_alive',@_);
  }
 }

sub filter {
    my ($map, $addrs) = @_;
    my (@ret) = ();
    my ($i);

    for ($i=0; $i<@$map; $i++) {
	if ($$map[$i] == 0) {
	    push @ret, $$addrs[$i];
	}
    }
    return @ret;
}

#&ping_init;
#($a,$t)=&bping_alive (700,'www.berkeley.edu','www.stanford.edu','www.yahoo.com','www.utcluj.ro','www.uab.ro','www.polito.it','www.wustl.edu');

#foreach $ad (@$a)
#  {print "$ad - ttl - ".(shift @$t)."\n";}

return 1;
