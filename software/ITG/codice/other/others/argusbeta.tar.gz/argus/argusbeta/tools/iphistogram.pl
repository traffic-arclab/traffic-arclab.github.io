#!/usr/local/bin/perl
while ($line=<STDIN>)
  {if ($line =~ /\{ip ([\d]+.[\d]+.[\d]+).[\d]+,/ )
     {$prefix=$1;
      if(not defined $counter{$prefix})
	{push @prefixes,$prefix;
	 $counter{$prefix}=1;
       }
      else
	{$counter{$prefix}++}
    }
 }
print (((keys %counter)+0)." distinct prefixes displaying all\n");
if ($ARGV[0] eq '-bycount')
  {@prefixes=sort {$counter{$b} <=> $counter{$a}} @prefixes;}
else
  {@prefixes=sort @prefixes;}
foreach $k (@prefixes)
#  {if ($counter{$k}>1)
     {print "$counter{$k}\t$k\n";}
# }
