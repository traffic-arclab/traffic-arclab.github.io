#!/usr/local/bin/perl
$namecnt=($ARGV[0] or 10);
$prefixcnt=($ARGV[1] or 10);
$suffixcnt=($ARGV[2] or 10);
while ($line=<STDIN>)
  {if ($line =~ /name \{([\d\-a-z\.]+)/)
     {$fullname=$1;
      $fullname =~ /^([\-a-z\d]+)/;
      $name=$1;
      if(not defined $counter{$name})
	{push @names,$name;
	 $counter{$name}=1;
       }
      else
	{$counter{$name}++}
      $name =~ /^([\-a-z]+)(\d.*)$/;

      if(not defined $pcounter{$1})
	{push @pnames,$1;
	 $pcounter{$1}=1;
       }
      else
	{$pcounter{$1}++}

      if(not defined $scounter{$2})
	{push @snames,$2;
	 $scounter{$2}=1;
       }
      else
	{$scounter{$2}++}
    }
 }
print (((keys %counter)+0)." distinct names displaying $namecnt\n");
@names=sort {$counter{$b} <=> $counter{$a}} @names;
foreach $k (@names)
  {if ($counter{$k}>1)
     {print "$counter{$k}\t$k\n";}
   last unless (--$namecnt);
 }
print (((keys %pcounter)+0)." distinct prefixes displaying $prefixcnt\n");
@pnames=sort {$pcounter{$b} <=> $pcounter{$a}} @pnames;
foreach $k (@pnames)
  {if ($pcounter{$k}>1)
     {print "$pcounter{$k}\t$k\n";}
   last unless (--$prefixcnt);
 }
print (((keys %scounter)+0)." distinct suffixes displaying $suffixcnt\n");
@snames=sort {$scounter{$b} <=> $scounter{$a}} @snames;
foreach $k (@snames)
  {if ($scounter{$k}>1)
     {print "$scounter{$k}\t$k\n";}
   last unless (--$suffixcnt);
 }
