#!/usr/local/bin/perl

%s=();
%n=();
%w=();
while (<>) {
  my ($addr,$subnet);
  chop;
  ($addr)=split(' ');
  $subnet = $addr;
  unless ($subnet =~ s/^(\d+)(\.\d+)(\.\d+)(\.\d+)$/$1$2$3/) {
      print "Bad IP address  >$addr<\n";
      next;
    }
  $s{$subnet}++;
}

foreach $subnet (keys %s) {
  $n{$s{$subnet}}++;
  $w{$s{$subnet}}+=$s{$subnet};
}
for ($i=1;$i<=255;$i++) {
  print ($n{$i} or "0");
  print "\n";
}
print "---------";
for ($i=1;$i<=255;$i++) {
  print ($w{$i} or "0");
  print "\n";
}

