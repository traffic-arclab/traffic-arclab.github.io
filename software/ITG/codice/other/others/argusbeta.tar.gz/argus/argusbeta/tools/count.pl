#!/usr/local/bin/perl

$field =$ARGV[0];

while ($line=<STDIN>){
  $i=index $line,$field;
  if ($i == -1 )
    {print $line}
  else
    {$o=index $line,"{",$i;
     $c=index $line,"}",$i;
     if ($o >  $c)
       {print $line}
     else
       {print (substr $line,0,$o);
	print ('###');
	if ($c-$o==1)
	  {print "0";}
	else
	  {print 0+(split /,/,(substr $line,$o,$c-$o));}
	print (substr $line,$c);
       }
    }
}
