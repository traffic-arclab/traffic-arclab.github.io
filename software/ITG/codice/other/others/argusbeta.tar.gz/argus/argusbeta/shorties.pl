
#I'm soooo lazy :-)
sub l2d
  {return &long2dotted(@_);}

sub d2l
  {return &dotted2long(@_);}

sub sr
  {return &serialize('Router',@_);}

sub ss
  {return &serialize('Subnet',@_);}

sub si
  {return &serialize('IPdata',@_);}

sub pr
  {my $id=@_;
   return &serialize('Router',$Router[$id]);}

sub ps
  {my $id=@_;
   return &serialize('Subnet',$Subnet[$id]);}


return 1;
