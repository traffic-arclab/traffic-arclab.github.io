#!/usr/u/cnrg/bin/perl

$field=$ARGV[0];

while (<STDIN>) {
    if (/.*$field\s(\d+).*/) {
	print "$1\n";
    }
}
