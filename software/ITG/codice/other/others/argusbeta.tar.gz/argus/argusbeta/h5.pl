# this is the intelligence of heuristic 5. Figures out when and where to
#  add new
# addresses.
sub add_addr {
    my ($new_addr, $addrs_handle) = @_;
    if (!$added_addrs{$new_addr}) {
#	print "adding to list: $new_addr\n";
	push(@$addrs_handle, $new_addr);
	$added_addrs{$new_addr} = 1;
#	log_message 5,"$new_addr";
    }
}

sub add_addrs {
    my($new_addrs, $addrs_handle) = @_;
    my($j);
    for ($j = 0; $j <= $#$new_addrs; $j++) {
	&add_addr(@$new_addrs[$j], $addrs_handle);
    }
}

#the persiatance_factor is normally 2
sub add_correlated_addrs {
  my($new_addr, $addrs_handle) = @_;
  my $temp_addrs_handle;
  my ($j);
#    print "checking $new_addr under heuristic 5\n";
    
# if exists a "*.1" address
  if ($new_addr =~ /\A(\d+)\.(\d+)\.(\d+)\.1\Z/) {
    for ($j = 2; $j <= $persistance_factor + 2; $j++) {
      &add_addr("$1.$2.$3.$j", $addrs_handle);
    }
    &add_addr("$1.$2.$3.129", $addrs_handle);
    &ipmaker_rand($addrs_handle, "$1.$2.$3.*", $persistance_factor * 5);
# if exists a "*.129" address
  } elsif ($new_addr =~ /\A(\d+)\.(\d+)\.(\d+)\.129\Z/) {
    for ($j = 130; $j <= $persistance_factor + 128; $j++) {
      &add_addr("$1.$2.$3.$j", $addrs_handle);
    }
    &add_addr("$1.$2.$3.65", $addrs_handle);
    &add_addr("$1.$2.$3.193", $addrs_handle);
# for any other address
  } elsif ($new_addr =~ /\A(\d+)\.(\d+)\.(\d+)\.(\d+)\Z/) {
    $j=$4-1;
    &add_addr("$1.$2.$3.$j", $addrs_handle);
    for ($j = $4-2*$persitance_factor; $j <= $4+2*$persistance_factor; $j++) {
      if($j<255 and $j>0) {&add_addr("$1.$2.$3.$j", $addrs_handle);}
    }
  } else {
    log_message (2,"Add correlated error: $new_addr is not a valid address");
    return;
  }
  &ipmaker_rand($addrs_handle, "$1.$2.$3.*", $persistance_factor-1);
}

return 1;
