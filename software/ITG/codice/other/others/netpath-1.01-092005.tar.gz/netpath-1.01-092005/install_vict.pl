#!/usr/bin/perl

#
# Copyright (c) 2003-2005 Shilpi Agarwal.
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, subject to the conditions
# listed in the NetPath LICENSE file. These conditions include: you must
# preserve this copyright notice, and you cannot mention the copyright
# holders in advertising related to the Software without their permission.
# The Software is provided WITHOUT ANY WARRANTY, EXPRESS OR IMPLIED. This
# notice is a summary of the NetPath LICENSE file; the license in that file 
# is legally binding.
#

use Getopt::Long;

#check for required perl modules
if ( !eval { require XML::Simple }) {
    die "Error: XML::Simple is not installed \n";
}

if ( !eval { require Math::BaseCalc }) {
    die "Error: Math::BaseCalc is not installed \n";
}

if ( !eval { require Data::Dumper }) {
    die "Error: Data::Dumper is not installed \n";
}

if ( !eval { require Getopt::Long }) {
    die "Error: Getopt::Long is not installed \n";
}

GetOptions('dir=s' => \$dir, 'disable' => \$disable,)
            or exit(1);

#check for click-install
if(system("which click-install")) {
  die "Error: click-install not found \n";
}

#check for click-uninstall
if(system("which click-uninstall")) {
  die "Error: click-uninstall not found \n";
}

#check for clogin
if(!defined $disable) {
  if(system("which clogin")) {
    die "Error: clogin not found \n";
  }
}


#install vict
$TARGET = "/usr/local/bin";
if(defined $dir) {
  $TARGET = $dir;
}

if(! -e $TARGET)
{
  mkdir($TARGET) or die "can not create directory \n";
} 

if(system("install -C -c src/* $TARGET")) {
  die "can not install wailnet\n";
}
