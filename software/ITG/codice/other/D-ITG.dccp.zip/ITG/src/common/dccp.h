/*
 *
 *      Added by Nenad Cuturic 2006.04.06
 *      email		: cnesko (at) gmail dot com      
 *
*/

#ifndef DCCP_SOCKOPT_PACKET_SIZE
#define DCCP_SOCKOPT_PACKET_SIZE 1
#endif

#ifndef DCCP_SOCKOPT_SERVICE
#define DCCP_SOCKOPT_SERVICE 2
#endif

#ifndef SOCK_DCCP
#define SOCK_DCCP 6
#endif

#ifndef TCP_CONGESTION
#define TCP_CONGESTION	13
#endif

#ifndef DCCP_SOCKOPT_CCID_RX_INFO
#define DCCP_SOCKOPT_CCID_RX_INFO 128
#endif

#ifndef DCCP_SOCKOPT_CCID_TX_INFO
#define DCCP_SOCKOPT_CCID_TX_INFO 192
#endif

#ifndef SOL_DCCP
#define SOL_DCCP 269
#endif
