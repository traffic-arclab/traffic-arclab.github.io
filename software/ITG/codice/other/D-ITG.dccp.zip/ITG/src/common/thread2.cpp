 /*	Component of the D-ITG 2.4 Platform
 *
 * 	
 *	copyright	: (C) 2004  	by Stefano Avallone, Alessio Botta, Donato Emma, 
 *					Salvatore Guadagno, Antonio Pescape'
 *					DIS Dipartimento di Informatica e Sistemistica				 
 *					(Computer Science Department)
 *					University of Naples "Federico II"	
 *	email:		: {stavallo, pescape}@unina.it, {abotta, demma, sguadagno}@napoli.consorzio-cini.it
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */
 
 


#include "thread.h"




int createThread(void *argument, void *(nameFunction) (void *), void *attrib, pthread_t &idThread)
{
	
	int ret = 0;

#ifdef LINUX_OS
	
	 
	ret = pthread_create(&idThread, NULL, nameFunction, argument);
	if (ret != 0) ret = -1;
#ifdef DEBUG
    printf("Return value pthread_create (LINUX) %d\n",(int)idThread);
    printf("Return value createThread : %d\n",ret);
#endif
#endif
	return ret;
};


int terminateThread(pthread_t idThread)
{
	
	int ret = 0;

#ifdef LINUX_OS
	
	ret = pthread_cancel(idThread);
	if (ret != 0) ret = -1;
#endif
#ifdef DEBUG
    printf("Return value terminateThread : %d\n",ret);
#endif
	return ret;
}; 


void exitThread()
{

#ifdef LINUX_OS
	
	pthread_exit(0);
#endif
};


int joinThread(int numFlow, pthread_t hThr[])
{
	int ret = 0;

#ifdef LINUX_OS
	
	int ret2 = 0;
	for(int i = 0; i < numFlow; i++) {
		ret2 = pthread_join(hThr[i], NULL);
		if (ret2 != 0)
			ret = -1;
	}
#endif
#ifdef DEBUG
    printf("Return value joinThread : %d\n",ret);
#endif
    return ret;
};

#ifdef LINUX_OS

int mutexThreadInit(void* mutex)
{
	int ret = 0;
	
	ret = pthread_mutex_init((pthread_mutex_t *)mutex, NULL);
#ifdef DEBUG
	printf("Return value pthread_mutex_init (LINUX) : %d \n",mutex);
	printf("Return value mutexThreadInit : %d \n",ret);
#endif
	return ret;
}
#endif
	

int mutexThreadLock(void *mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_lock((pthread_mutex_t *) mutex);
	if (ret != 0 ) ret = -1;
#endif

#ifdef DEBUG
    printf("Return value mutexThreadLock : %d\n",ret);
#endif
	return ret;
};


int mutexThreadUnlock(void *mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_unlock((pthread_mutex_t *) mutex);
	if (ret != 0 ) ret = -1;
#endif

#ifdef DEBUG
    printf("Return value mutexThreadUnlock : %d\n",ret);
#endif
	return ret;
};



int mutexThreadRelease(void* mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_destroy((pthread_mutex_t *)mutex);
	if (ret != 0) ret = -1;
#endif

#ifdef DEBUG
    printf("Return value mutexThreadRelease : %d\n",ret);
#endif
	return ret;
}





int closeSock(int socket)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = close(socket);
#endif

#ifdef DEBUG
    printf("Return value closeSock : %d\n",ret);
#endif
	return ret;
};
