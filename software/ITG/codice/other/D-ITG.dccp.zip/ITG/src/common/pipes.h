 /*	Component of the D-ITG 2.4 Platform
 *
 * 	
 *	copyright	: (C) 2004  	by Stefano Avallone, Alessio Botta, Donato Emma, 
 *					Salvatore Guadagno, Antonio Pescape'
 *					DIS Dipartimento di Informatica e Sistemistica				 
 *					(Computer Science Department)
 *					University of Naples "Federico II"	
 *	email:		: {stavallo, pescape}@unina.it, {abotta, demma, sguadagno}@napoli.consorzio-cini.it
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */

#define PIPE_BUFSIZE 1000
#define PIPE_TIMEOUT 100000
extern char nameProgram[];

struct pipeMsg {
	int flowId;
	int code;
};

#ifdef WIN32
extern HANDLE mutex_numPipes;
extern int numPipes;
#endif

#ifdef LINUX_OS
int createNewPipe(int fd[2]);
int sendPipeMsg(int fd[2], pipeMsg *msg);
int recvPipeMsg(int fd[2], pipeMsg *msg);
int closePipe(int fd[2]);
#endif
#ifdef WIN32
int createNewPipe(HANDLE pipe[3]);
int sendPipeMsg(HANDLE pipe[3], pipeMsg *msg);
int recvPipeMsg(HANDLE pipe[3], pipeMsg *msg);
int closePipe(HANDLE fd[3]);
#endif
