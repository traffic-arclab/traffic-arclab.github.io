
#define MNG_NOMSG     -1
#define MNG_FLOWSTART  1
#define MNG_FLOWEND    2


/* 
   Send a message to a D-ITG sender 
   sender: D-ITG sender IP address 
   message: message sent to the D-ITG sender
   
   return value
   0  - success
   -1 - error 
*/

int DITGsend(char *sender, char *message);



/* 
   Catch messages from D-ITG senders. This function is non-blocking. 
   If no message arrived, returns MNG_NOMSG
   Otherwise returns the type of the message received (MNG_xxx), sender contains
   the IP address of ITGSend and msg the body of the message. There is no need
   to allocate memory for sender and msg 
*/

int catchManagerMsg(char **senderIP, char **msg);
