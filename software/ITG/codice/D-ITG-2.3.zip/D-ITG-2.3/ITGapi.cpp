#include "ITG.h"

static int socket_r=0;

int DITGsend(char *sender, char *message)
{
   #ifdef WIN32
   WSADATA wsaData;
   if (WSAStartup(MAKEWORD(1,1),&wsaData)!=0){
	fprintf(stderr,"WSAStartup() failed");
	exit(1);
   }
   #endif

   struct sockaddr_in Sender;
   struct hostent *host;
   
   if (!socket_r)
   {
	socket_r=socket(PF_INET,SOCK_DGRAM,0);
	/* Add the O_NONBLOCK flag */
#ifdef LINUX_OS
    int flags;
	flags = fcntl(socket_r, F_GETFL, 0);
	fcntl(socket_r, F_SETFL, flags | O_NONBLOCK);
#endif
#ifdef WIN32
    unsigned long i = 1;
    ioctlsocket(socket_r, FIONBIO, &i);
#endif
   }
   
   Sender.sin_family = AF_INET;

   if (!(host=gethostbyname(sender)))
   {  
         cerr << endl << "DITGsend: Invalid destination address" << endl;
         return -1;
   }
   memcpy((char *)&Sender.sin_addr, host->h_addr, host->h_length);

   Sender.sin_port=htons(DefaultPortSenderManager);
   
   if (sendto(socket_r,message,strlen(message),0,(struct sockaddr*)&Sender,sizeof(Sender)) != (int)strlen(message))
         return -1;
   
   return 0;
}

/* This function is non-blocking. If no messages arrived, returns MNG_NOMSG
   Otherwise returns the type of the message received (MNG_xxx), sender contains
   the IP address of ITGSend and msg the body of the message. There is no need
   to allocate memory for sender and msg */
int catchManagerMsg(char **senderIP, char **msg)
{
	const int MaxBufferSize = 300;
	struct sockaddr_in Sender;
	socklen_t SenderSlen=sizeof(Sender);
	int length,msgtype;
	
	if (!socket_r)
		return MNG_NOMSG;

	char* buffer=(char*)malloc(sizeof(char)*MaxBufferSize);
	
	if (recvfrom(socket_r,buffer,MaxBufferSize,0,(struct sockaddr *)&Sender,&SenderSlen)<0)
	{
		free(buffer);
		return MNG_NOMSG;
	}

	*senderIP = (char*)malloc(sizeof(char)*30);
	strcpy(*senderIP,inet_ntoa(Sender.sin_addr));
	
	msgtype = *(int*)buffer;
	length = ((int*)buffer)[1];
	memmove(buffer,((int*)buffer)+2,length);
	buffer[length]='\0';
	*msg=buffer;

	return msgtype;	
}


