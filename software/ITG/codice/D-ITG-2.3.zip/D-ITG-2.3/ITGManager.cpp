#include "ITGapi.h"
#include <stdio.h>
#include <string.h>

int main()
{
	char *sender,*msg;
	int i;
	char command[]="-C 10 -c 200 -t 5000 -a 10.0.0.4";
	DITGsend("localhost",command);
	
	do 
	{
		if ((i=catchManagerMsg(&sender,&msg))!=MNG_NOMSG)
			printf("Received msg type %d   %s   %s\n",i,sender,msg);
	} while (1);
}
