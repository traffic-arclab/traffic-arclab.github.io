#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#ifdef WIN32
#include <io.h>
#endif
#include <string.h>
#include <iostream.h>
#include <fstream.h>
#include <math.h>

struct Info
{
	unsigned int FlowId;
	unsigned int SeqNum;
	char src_addr[15];
	unsigned int src_port;
	char dest_addr[15];
	unsigned int dest_port;
	long int TxTime1;
	long int TxTime2;
	double TxTime3;
	long int RxTime1;
	long int RxTime2;
	double RxTime3;
	int size;
};

int
main (int argc, char *argv[])
{
	typedef char address[16];

	struct Info *infos = (struct Info *) malloc (sizeof (struct Info));
	int check, i, j, hold;
	int elab_type, err, trovato, u;
	int flagpl, flagdelay, dflagall, flagjitter, jflagall, jflagpl,
		flagbitrate, logflag, flagpktloss;
	unsigned long int index, z, indexm1, tot, pktloss, pkterr, bytetot,
		dparziale, jparziale, bparziale, pparziale, dimvect,
		pktparziale;
	double ritm, jitter, jittemp, tempopl, tempoul, sigma;
	double ritparziale, dmsoffset, jitparziale, jmsoffset, bitparziale,
		bmsoffset, pmsoffset, temposec;
	double *vect = NULL;
	unsigned int *indvect = NULL;
	unsigned int z2;
	unsigned int *totflow = NULL;
	unsigned int totflownum;
	double *sigmav = NULL;
	unsigned long int *pktlossvect, *jparzialev, *dparzialev,
		*pktparzialev, *pparzialev, *totvect = NULL;
	double *ritmv = NULL;
	unsigned long int *byterecv = NULL;
	double *firstlnt, *lastlnt, *delmin, *delmax, *jitvect;
	address *srcaddrv;
	double *bitparzialev;
	double *jitparzialev;
	double *ritparzialev;
	unsigned int *srcportv;
	address *dstaddrv;
	unsigned int *dstportv, *seqnumv;
	double rxtime, riti, ritmax, ritmin, dmsiniz, jmsiniz, bmsiniz,
		pmsiniz;
	double msdelay, msjitter, msbitrate, mspktloss;
	ifstream in;
	FILE *fpout;
	FILE *fpdelay;
	FILE *fpjitter;
	FILE *fpbitrate;
	FILE *fppktloss;
	char logname[100];
	char logoutname[100];

	//Inizialitazion of viariables
	vect = (double *) malloc (100 * sizeof (double));
	indvect = (unsigned int *) malloc (100 * sizeof (unsigned int));
	dimvect = 100;
	totflownum = 0;
	riti = 0;
	tot = 0;
	bytetot = 0;
	flagpl = 0;
	pktloss = 0;
	pkterr = 0;
	ritm = 0;
	dmsiniz = 0;
	dmsoffset = 0;
	ritparziale = 0;
	dparziale = 0;
	dflagall = 0;
	flagdelay = 0;
	jmsiniz = 0;
	jmsoffset = 0;
	jitparziale = 0;
	jparziale = 0;
	flagjitter = 0;
	jflagall = 0;
	jflagpl = 1;
	bmsiniz = 0;
	bmsoffset = 0;
	bitparziale = 0;
	bparziale = 0;
	flagbitrate = 0;
	logflag = 0;
	elab_type = 0;
	flagpktloss = 0;
	index = 0;
	pktparziale = 0;

	// parser
	if (argc <= 1)
	{
		printf ("\nMissing filename!!!\nTry ITGDec -h or --help for more informations\n");
		exit (1);
	}
	strcpy (logname, argv[0]);
	argv++;
	argc--;
	while (argc > 0)
	{
		if (argv[0][0] == '-')
		{
			switch (argv[0][1])
			{
			case 'd':
				if ((argc < 2) || (argv[1][0] == '-'))
				{
					printf ("Error 1 on delay time\n");
					argc -= 1;
					argv += 1;
				}
				else
				{
					msdelay = (double) atof (argv[1]);
					//printf("msdelay %Lf\n",msdelay);
					if (msdelay < 0)
					{
						printf ("Error 2 on delay time\n");
						exit (1);
					}
					else
					{
						if (msdelay == 0)
							dflagall = 1;
						flagdelay = 1;
						argv += 2;
						argc -= 2;
					}
				}
				break;
			case 'b':
				if ((argc < 2) || (argv[1][0] == '-'))
				{
					printf ("Error 1 on bitrate time\n");
					argc -= 1;
					argv += 1;
				}
				else
				{
					msbitrate = (double) atof (argv[1]);
					//printf("msbitrate = %Lf",msbitrate);
					if (msbitrate < 0)
					{
						printf ("Error 2 on bitrate time\n");
						exit (1);
					}
					else
					{
						flagbitrate = 1;
						argv += 2;
						argc -= 2;
					}
				}
				break;
			case 'j':
				if ((argc < 2) || (argv[1][0] == '-'))
				{
					printf ("Error 1 on jitter time\n");
					argc -= 1;
					argv += 1;
				}
				else
				{
					msjitter = (double) atof (argv[1]);
					//printf("msjitter = %Lf",msjitter);
					if (msjitter < 0)
					{
						printf ("Error 2 on jitter time\n");
						exit (1);
					}
					else
					{
						if (msjitter == 0)
							jflagall = 1;
						flagjitter = 1;
						argv += 2;
						argc -= 2;
					}
				}
				break;
			case 'p':
				if ((argc < 2) || (argv[1][0] == '-'))
				{
					printf ("Error 1 on packet loss time\n");
					argc -= 1;
					argv += 1;
				}
				else
				{
					mspktloss = (double) atof (argv[1]);
					//printf("msjitter = %Lf",msjitter);
					if (mspktloss < 0)
					{
						printf ("Error 2 on packet loss time\n");
						exit (1);
					}
					else
					{
						//if(mspktloss==0)
						//jflagall=1;
						flagpktloss = 1;
						argv += 2;
						argc -= 2;
					}
				}
				break;
			case 'h':
				printf ("USAGE: decod bin_file param\n");
				printf ("with param = \n");
				printf ("-d DT     -> generate delay file with average delay every DT millisec\n");
				printf ("-j JT     -> generate jitter file with average jitter every JT millisec\n");
				printf ("-b BT     -> generate bitrate file with average bitrate every BT millisec\n");
				printf ("-p PT     -> generate bitrate file with average bitrate every PT packets\n");
				printf ("-v        -> generate total result for visualization\n");
				printf ("-i        -> generate total result for import\n");
				printf ("-l outlog -> generate decoded log file with name 'outlog' \n");
				exit (1);
				break;
			case '-':
				printf ("USAGE: decod bin_file param\n");
				printf ("with param = \n");
				printf ("-d DT     -> generate delay file with average delay every DT millisec\n");
				printf ("-j JT     -> generate jitter file with average jitter every JT millisec\n");
				printf ("-b BT     -> generate bitrate file with average bitrate every BT millisec\n");
				printf ("-p PT     -> generate bitrate file with average bitrate every PT millisec\n");
				printf ("-v        -> generate total result for visualization\n");
				printf ("-i        -> generate total result for import\n");
				printf ("-l outlog -> generate decoded log file with name 'outlog' \n");
				exit (1);
				break;

			case 'v':
				elab_type = 1;
				argv += 1;
				argc -= 1;
				break;

			case 'i':
				elab_type = 2;
				argv += 1;
				argc -= 1;
				break;
			case 'l':
				logflag = 1;
				if ((argc < 2) || (argv[1][0] == '-'))
				{
					printf ("Error on output log file name\n");
					exit (1);
				}
				else
				{
					strcpy (logoutname, argv[1]);
					argc -= 2;
					argv += 2;
				}
				break;
			default:
				elab_type = 1;
				break;
			}
		}
		else
		{
			strcpy (logname, argv[0]);
			argc -= 1;
			argv += 1;
		}
	}
//End parser

	if (!
	    ((flagdelay) || (flagjitter) || (flagbitrate) || (elab_type)
	     || (logflag) || (flagpktloss)))
	{
		elab_type = 1;
	}

	i = 1;
	in.open (logname, ios::in | ios::binary);
	if (!in.is_open ())
	{
		printf ("\n Error opening log file '%s'\n", logname);
		exit (1);
	}
	if (logflag)
		fpout = fopen (logoutname, "w");
	if (fpout < 0)
	{
		printf ("Error opening file '%s' for write", logoutname);
		exit (1);
	}
	if (flagbitrate)
		fpbitrate = fopen ("bitrate.dat", "w");
	if (fpbitrate < 0)
	{
		printf ("Error opening file 'bitrate.dat' for write");
		exit (1);
	}

	if (flagdelay)
		fpdelay = fopen ("delay.dat", "w");
	if (fpdelay < 0)
	{
		printf ("Error opening file 'delay.dat' for write");
		exit (1);
	}

	if (flagjitter)
		fpjitter = fopen ("jitter.dat", "w");
	if (fpjitter < 0)
	{
		printf ("Error opening file 'jitter.dat' for write");
		exit (1);
	}

	if (flagpktloss)
		fppktloss = fopen ("pktloss.dat", "w");
	if (fppktloss < 0)
	{
		printf ("Error opening file 'pktloss.dat' for write");
		exit (1);
	}


	int size = 0;
	while (1)
		//for(i=1;i<6;i++)
	{
		in.read ((char *) infos, sizeof (struct Info));
		//hold=read(fd, infos,sizeof(struct Info));
		size = in.gcount ();
		if (size == 0)
		{
			if (tot > 0)
			{
				if (flagdelay && (dparziale > 0))
				{
					ritparziale = ritparziale / dparziale;
					fprintf (fpdelay, "%lf  ", temposec);
					fprintf (fpdelay, "%lf\n",
						 ritparziale * 1000);
					//fprintf(fpdelay,"Tempo ricezione %lu:%lu:%lf\n",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
					//fprintf(fpdelay,"dparziale %lu ritardo medio parziale %Lf msoffset %Lf \n",dparziale,ritparziale,dmsoffset);
				}
				if (flagjitter && (jparziale > 0))
				{
					jitparziale =
						jitparziale /
						(double) (jparziale -
							  jflagpl);
					fprintf (fpjitter, "%lf  ", temposec);
					fprintf (fpjitter, "%lf",
						 jitparziale * 1000);
					for (z = 1; z <= totflownum; z++)
					{
						if (jparzialev[z] > 0)
						{
							if (jparzialev[z] = 1)
								jitparzialev
									[z] =
									jitparzialev
									[z] /
									(double)
									(jparzialev
									 [z]);
							else
								jitparzialev
									[z] =
									jitparzialev
									[z] /
									(double)
									(jparzialev
									 [z] -
									 1);
							fprintf (fpjitter,
								 " %lf",
								 jitparzialev
								 [z] * 1000);
							jitparzialev[z] = 0;
							jparzialev[z] = 0;
						}
						else
							fprintf (fpjitter,
								 " 0");
					}
					fprintf (fpjitter, "\n");
				}
				if (flagbitrate && (bparziale > 0))
				{
					fprintf (fpbitrate, "%lf ", temposec);
					if (bmsoffset > 0)
					{
						fprintf (fpbitrate, "%lf ",
							 bitparziale /
							 bmsoffset);
						for (z = 1; z <= totflownum;
						     z++)
							fprintf (fpbitrate,
								 "%lf ",
								 bitparzialev
								 [z] /
								 bmsoffset);
						fprintf (fpbitrate, "\n");
						//fprintf(fpbitrate,"Tempo ricezione %lu:%lu:%lf\n",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
						//fprintf(fpbitrate,"bitparziale %lf bmsoffset %lf su %lu campioni\n",bitparziale,bmsoffset,bparziale);
					}
				}
				if (flagpktloss && (pparziale > 0))
				{
					fprintf (fppktloss, "%lf  ",
						 temposec);
					for (z = 1; z <= totflownum; z++)
						pktparziale =
							pktparziale +
							pktparzialev[z];

					fprintf (fppktloss, "%lu",
						 pktparziale);
					for (z = 1; z <= totflownum; z++)
					{
						fprintf (fppktloss, " %lu",
							 pktparzialev[z]);
						pparzialev[z] =
							pparzialev[z] +
							pktparzialev[z];
						pktparzialev[z] = 0;
					}
					fprintf (fppktloss, "\n");

					//fprintf(fpbitrate,"Tempo ricezione %lu:%lu:%lf\n",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
					//fprintf(fpbitrate,"bitparziale %Lf bmsoffset %Lf su %lu campioni\n",bitparziale,bmsoffset,bparziale);
				}
				if (elab_type)
				{
					sigmav = (double *)
						malloc ((totflownum +
							 1) *
							sizeof (double));
					jitter = 0;
					jittemp = 0;
					ritmax = 0;
					ritmin = 9999;
					tempoul = tempoul - tempopl;
					ritm = ritm / tot;
					for (z = 1; z <= totflownum; z++)
					{
						sigmav[z] = 0;
					}
					//printf("totale flussi elaborati %u\n",totflownum);
					for (z = 0; z < tot; z++)
					{
						if (z > 0)
							jittemp =
								vect[z] -
								vect[z - 1];
						if (jittemp < 0)
							jittemp = -jittemp;
						jitter = jitter + jittemp;
						if (vect[z] > ritmax)
							ritmax = vect[z];
						if (vect[z] < ritmin)
							ritmin = vect[z];
						//printf("Jitter = %Lf ",jitter);
						//printf(" %Lf ",ritmvect[indvect[z]]);

					}
					//ritm=ritm/tot;
					for (z = 1; z <= totflownum; z++)
					{
						ritmv[z] =
							ritmv[z] /
							(totvect[z]);
					}
					//printf("Ritardo medio = %Lf ",ritm);
					jitter = jitter / (tot - 1);
					sigma = 0;
					for (z = 0; z < tot; z++)
					{
						sigma = sigma + (vect[z] -
								 ritm) *
							(vect[z] - ritm);
						for (int zz = 1;
						     zz <= totflownum; zz++)
							if (totflow[zz] ==
							    indvect[z])
								index = zz;
						sigmav[index] =
							sigmav[index] +
							(vect[z] -
							 ritmv[index]) *
							(vect[z] -
							 ritmv[index]);
					}
					if (elab_type == 1)
					{
						for (z = 1; z <= totflownum;
						     z++)
						{
							sigmav[z] =
								sigmav[z] /
								(totvect[z]);
							sigmav[z] =
								sqrt (sigmav
								      [z]);
							pktloss =
								pktloss +
								pktlossvect
								[z];
							jitvect[z] =
								jitvect[z] /
								(totvect[z] -
								 1);
							printf ("---------------------------------------------------------------\n");
							printf ("Flow Id : %u\n", totflow[z]);
							printf ("---------------------------------------------------------------\n");
							printf ("From %16s:%hu ", srcaddrv[z], srcportv[z]);
							printf (" ---> To  %16s:%hu\n\n", dstaddrv[z], dstportv[z]);
							printf ("Total time          = %lf sec\n", lastlnt[z] - firstlnt[z]);
							printf ("Total packet        = %lu\n", totvect[z]);
							printf ("Max delay           = %lf msec\n", delmax[z] * 1000);
							printf ("Min delay           = %lf msec\n", delmin[z] * 1000);
							printf ("Average delay       = %lf msec\n", ritmv[z] * 1000);
							printf ("Average jitter      = %lf msec\n", jitvect[z] * 1000);
							printf ("Delay variation     = %lf msec\n", sigmav[z] * 1000);
							printf ("Byte received       = %lu\n", byterecv[z]);
							printf ("Average bitrate     = %lf Kbps\n", (double) byterecv[z] * 8 / (lastlnt[z] - firstlnt[z]) / 1000);
							printf ("Average packet rate = %lf pkt/sec\n", (double) totvect[z] / (lastlnt[z] - firstlnt[z]));
							printf ("packets dropped     = %u\n", pktlossvect[z]);
							printf ("---------------------------------------------------------------\n");
						}
					}
					sigma = sigma / (double) (tot);
					sigma = sqrt (sigma);
					if (elab_type == 1)
					{
						//Print total results on screen for visualization
						printf ("Total results \n");
						printf ("---------------------------------------------------------------\n");
						printf ("Total number of flows  = %lu \n", totflownum);
						printf ("Max delay              = %lf msec\n", ritmax * 1000);
						printf ("Min delay              = %lf msec\n", ritmin * 1000);
						printf ("Average delay          = %lf msec\n", ritm * 1000);
						printf ("Average jitter         = %lf msec\n", jitter * 1000);
						printf ("Delay variation        = %lf msec\n", sigma * 1000);
						printf ("Byte received          = %lu\n", bytetot);
						printf ("Total time             = %lf sec\n", tempoul);
						printf ("Average bitrate        = %lf Kbit/sec\n", bytetot * 8 / tempoul / 1000);
						printf ("Average packets rate   = %lf pkts/sec\n", (double) tot / tempoul);
						printf ("Packets dropped        = %lu \n", pktloss);
						printf ("Packets wrong          = %lu \n", pkterr);
						printf ("Total packets received = %lu\n", tot);
						printf ("---------------------------------------------------------------\n");
					}
					else
					{
						//Print total result on screen for import
						printf ("Max delay*%lf*msec*",
							ritmax * 1000);
						printf ("Min delay*%lf*msec*",
							ritmin * 1000);
						printf ("Average delay*%lf*msec*", ritm * 1000);
						printf ("Average jitter*%lf*msec*", jitter * 1000);
						printf ("Delay vaiation*%lf*msec*", sigma * 1000);
						printf ("Byte received*%lu*",
							bytetot);
						printf ("Total time*%lf*sec*",
							tempoul);
						printf ("Average bitrate*%lf*Kbit/sec*", bytetot * 8 / tempoul / 1000);
						printf ("Average packets rate*%lf*pkts/sec*", (double) tot / tempoul);
						printf ("Packets dropped*%lu*", pktloss);
						printf ("Packets wrong*%lu*",
							pkterr);
						printf ("Total packets received*%lu*\n", tot);
					}
				}
			}
			else
			{
				printf ("\n Empty log file");
			}
			free (vect);
			in.close ();
			if (logflag)
				fclose (fpout);
			if (flagbitrate)
				fclose (fpbitrate);
			if (flagjitter)
				fclose (fpjitter);
			if (flagpktloss)
				fclose (fppktloss);
			if (flagdelay)
				fclose (fpdelay);
			exit (1);
		}
		j = 0;
		if (infos[j].size != 0)
		{
			//
			//printf("totflownum = %u ",totflownum);

			//printf("1 ");
			if (logflag)
			{
				fprintf (fpout, "Flow>%04u ",
					 infos[j].FlowId);
				fprintf (fpout, "Seq>%7u ", infos[j].SeqNum);
				fprintf (fpout, "Src>%16s/%hu  ",
					 infos[j].src_addr,
					 infos[j].src_port);
				fprintf (fpout, "Dest>%16s/%hu  ",
					 infos[j].dest_addr,
					 infos[j].dest_port);
				fprintf (fpout, "TxTime>%u:%u:%lf ",
					 infos[j].TxTime1, infos[j].TxTime2,
					 infos[j].TxTime3);
				fprintf (fpout, "RxTime>%u:%u:%lf ",
					 infos[j].RxTime1, infos[j].RxTime2,
					 infos[j].RxTime3);
				fprintf (fpout, "Size>%5u\n", infos[j].size);
			}

			//Verify times correctness
			err = 0;
			if ((infos[j].TxTime1 > 24) || (infos[j].TxTime1 < 0))
				err = 1;
			if ((infos[j].TxTime2 > 59) || (infos[j].TxTime2 < 0))
				err = 2;
			if ((infos[j].TxTime3 > (double) (59.999999))
			    || (infos[j].TxTime3 < 0))
				err = 3;
			if ((infos[j].RxTime1 > 24) || (infos[j].RxTime1 < 0))
				err = 4;
			if ((infos[j].RxTime2 > 59) || (infos[j].RxTime2 < 0))
				err = 5;
			if ((infos[j].RxTime3 > (double) (59.999999))
			    || (infos[j].RxTime3 < 0))
				err = 6;

			if (err > 0)
			{	//Errori in linea corrente
				//printf("2err1 \n");
				//riti=0;
				pkterr++;
				//printf("packet error tot = %lu , err = % u\n",tot,err);
			}
			else
			{	//Linea corrente corretta

				if (totflownum == 0)
				{
					//Inizializza parametri per primo flusso
					totflownum = 1;
					totflow =
						(unsigned int *) malloc (2 *
									 sizeof
									 (unsigned
									  int));
					totflow[1] = infos[j].FlowId;
					byterecv =
						(unsigned long int *)
						malloc (2 *
							sizeof (unsigned long
								int));
					byterecv[1] = 0;
					totvect =
						(unsigned long int *)
						malloc (2 *
							sizeof (unsigned long
								int));
					totvect[1] = 0;
					ritmv = (double *) malloc (2 *
								   sizeof
								   (double));
					ritmv[1] = 0;
					firstlnt =
						(double *) malloc (2 *
								   sizeof
								   (double));
					firstlnt[1] = 100000;
					lastlnt =
						(double *) malloc (2 *
								   sizeof
								   (double));
					lastlnt[1] = 0;
					delmax = (double *) malloc (2 *
								    sizeof
								    (double));
					delmax[1] = 0;
					delmin = (double *) malloc (2 *
								    sizeof
								    (double));
					delmin[1] = 100000;
					srcaddrv =
						(address *) malloc (2 *
								    sizeof
								    (address));
					strncpy (srcaddrv[1],
						 infos[j].src_addr, 16);
					srcportv =
						(unsigned int *) malloc (2 *
									 sizeof
									 (unsigned
									  int));
					srcportv[1] = infos[j].src_port;
					dstaddrv =
						(address *) malloc (2 *
								    sizeof
								    (address));
					strncpy (dstaddrv[1],
						 infos[j].dest_addr, 16);
					dstportv =
						(unsigned int *) malloc (2 *
									 sizeof
									 (unsigned
									  int));
					dstportv[1] = infos[j].dest_port;
					jitvect =
						(double *) malloc (2 *
								   sizeof
								   (double));
					jitvect[1] = 0;
					pktlossvect =
						(unsigned long int *)
						malloc (2 *
							sizeof (unsigned long
								int));
					pktlossvect[1] = 0;
					seqnumv =
						(unsigned int *) malloc (2 *
									 sizeof
									 (unsigned
									  int));
					seqnumv[1] = 0;
					bitparzialev =
						(double *) malloc (2 *
								   sizeof
								   (double));
					bitparzialev[1] = 0;
					jitparzialev =
						(double *) malloc (2 *
								   sizeof
								   (double));
					jitparzialev[1] = 0;
					jparzialev =
						(unsigned long int *)
						malloc (2 *
							sizeof (unsigned long
								int));
					jparzialev[1] = 0;
					ritparzialev =
						(double *) malloc (2 *
								   sizeof
								   (double));
					ritparzialev[1] = 0;
					dparzialev =
						(unsigned long int *)
						malloc (2 *
							sizeof (unsigned long
								int));
					dparzialev[1] = 0;
					pktparzialev =
						(unsigned long int *)
						malloc (2 *
							sizeof (unsigned long
								int));
					pktparzialev[1] = 0;
					pparzialev =
						(unsigned long int *)
						malloc (2 *
							sizeof (unsigned long
								int));
					pparzialev[1] = 0;
					//printf("%u %u \n",tot_flow[1],infos[j].FlowId);
					//printf("primo flusso\n");
				}
				else
				{
					//Verifica se flusso gi� esistente
					trovato = 0;
					for (u = 1; u <= totflownum; u++)
					{
						//printf("ciclo for ");
						//printf("tot flow di %u = %u , flowid = %u ",u,totflow[u],infos[j].FlowId);
						if (totflow[u] ==
						    infos[j].FlowId)
						{
							//printf("trovato ");
							trovato = 1;
						}
					}
					if (!trovato)
					{

						//Inizializza parametri per altri flussi
						totflownum = totflownum + 1;
						totflow =
							(unsigned int *)
							realloc (totflow,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  int));
						totflow[totflownum] =
							infos[j].FlowId;
						byterecv =
							(unsigned long int *)
							realloc (byterecv,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  long int));
						byterecv[totflownum] = 0;
						totvect =
							(unsigned long int *)
							realloc (totvect,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  long int));
						totvect[totflownum] = 0;
						ritmv = (double *)
							realloc (ritmv,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						ritmv[totflownum] = 0;
						firstlnt =
							(double *)
							realloc (firstlnt,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						firstlnt[totflownum] = 100000;
						lastlnt =
							(double *)
							realloc (lastlnt,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						lastlnt[totflownum] = 0;
						delmax = (double *)
							realloc (delmax,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						delmax[totflownum] = 0;
						delmin = (double *)
							realloc (delmin,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						delmin[totflownum] = 100000;
						srcaddrv =
							(address *)
							realloc (srcaddrv,
								 (totflownum +
								  1) *
								 sizeof
								 (address));
						strncpy (srcaddrv[totflownum],
							 infos[j].src_addr,
							 16);
						srcportv =
							(unsigned int *)
							realloc (srcportv,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  int));
						srcportv[totflownum] =
							infos[j].src_port;
						dstaddrv =
							(address *)
							realloc (dstaddrv,
								 (totflownum +
								  1) *
								 sizeof
								 (address));
						strncpy (dstaddrv[totflownum],
							 infos[j].dest_addr,
							 16);
						dstportv =
							(unsigned int *)
							realloc (dstportv,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  int));
						dstportv[totflownum] =
							infos[j].dest_port;
						jitvect =
							(double *)
							realloc (jitvect,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						jitvect[totflownum] = 0;
						pktlossvect =
							(unsigned long int *)
							realloc (pktlossvect,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  long int));
						pktlossvect[totflownum] = 0;
						seqnumv =
							(unsigned int *)
							realloc (seqnumv,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  int));
						seqnumv[totflownum] = 0;
						bitparzialev =
							(double *)
							realloc (bitparzialev,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						bitparzialev[totflownum] = 0;
						jitparzialev =
							(double *)
							realloc (jitparzialev,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						jitparzialev[totflownum] = 0;
						jparzialev =
							(unsigned long int *)
							realloc (jparzialev,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  long int));
						jparzialev[totflownum] = 0;
						ritparzialev =
							(double *)
							realloc (ritparzialev,
								 (totflownum +
								  1) *
								 sizeof
								 (double));
						ritparzialev[totflownum] = 0;
						dparzialev =
							(unsigned long int *)
							realloc (dparzialev,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  long int));
						dparzialev[totflownum] = 0;
						pktparzialev =
							(unsigned long int *)
							realloc (pktparzialev,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  long int));
						pktparzialev[totflownum] = 0;
						pparzialev =
							(unsigned long int *)
							realloc (pparzialev,
								 (totflownum +
								  1) *
								 sizeof
								 (unsigned
								  long int));
						pparzialev[totflownum] = 0;
						//printf("altro flusso \n");
					}
					//printf("0 ");
				}
				indexm1 = index;
				//Trova indice per flusso corrente
				for (z = 1; z <= totflownum; z++)
				{
					if (totflow[z] == infos[j].FlowId)
						index = z;
				}

				tot++;
				dparziale++;
				jparziale++;
				bparziale++;
				pparziale++;
				totvect[index]++;
				jparzialev[index]++;
				dparzialev[index]++;
				rxtime = (infos[j].RxTime1 * 3600 +
					  infos[j].RxTime2 * 60 +
					  infos[j].RxTime3);
				if (firstlnt[index] > rxtime)
					firstlnt[index] = rxtime;
				if (lastlnt[index] < rxtime)
					lastlnt[index] = rxtime;

				jittemp = riti;
				riti = ((infos[j].RxTime1 * 3600 +
					 infos[j].RxTime2 * 60 +
					 infos[j].RxTime3) -
					(infos[j].TxTime1 * 3600 +
					 infos[j].TxTime2 * 60 +
					 infos[j].TxTime3));
				ritparziale = ritparziale + riti;
				ritparzialev[index] =
					ritparzialev[index] + riti;
				tempoul =
					infos[j].RxTime1 * 3600 +
					infos[j].RxTime2 * 60 +
					infos[j].RxTime3;

				jittemp = riti - jittemp;
				if (jittemp < 0)
					jittemp = -jittemp;
				jitvect[index] = jitvect[index] + jittemp;
				if (flagpl)
				{
					jitparziale = jitparziale + jittemp;
					if (indexm1 == index)
						jitparzialev[index] =
							jitparzialev[index] +
							jittemp;
					bitparziale =
						bitparziale +
						((double) (infos[j].size) *
						 8);
					bitparzialev[index] =
						bitparzialev[index] +
						((double) (infos[j].size) *
						 8);
				}
				if (!flagpl)
				{
					tempopl =
						infos[j].RxTime1 * 3600 +
						infos[j].RxTime2 * 60 +
						infos[j].RxTime3;
					dmsiniz = tempopl * 1000;
					jmsiniz = tempopl * 1000;
					bmsiniz = tempopl * 1000;
					pmsiniz = tempopl * 1000;
					flagpl = 1;
				}

				if (infos[j].SeqNum !=
				    (totvect[index] + pparzialev[index]))
					pktparzialev[index] =
						infos[j].SeqNum -
						totvect[index];

				temposec =
					-(tempopl) +
					((infos[j].RxTime1 * 3600) +
					 (infos[j].RxTime2 * 60) +
					 infos[j].RxTime3);

				if (flagdelay)
				{
					dmsoffset =
						(double) (infos[j].RxTime1 *
							  3600 +
							  infos[j].RxTime2 *
							  60 +
							  infos[j].RxTime3) *
						1000 - dmsiniz;
					//fprintf(fpdelay,"dmsoffset %Lf ,msdelay %Lf\n",dmsoffset,msdelay);
					if ((dmsoffset >= msdelay)
					    || (dflagall))
					{
						ritparziale =
							ritparziale /
							dparziale;
						fprintf (fpdelay, "%lf  ",
							 temposec);
						fprintf (fpdelay, "%lf",
							 ritparziale * 1000);
						for (z = 1; z <= totflownum;
						     z++)
						{
							if (dparzialev[z] > 0)
							{
								ritparzialev
									[z] =
									ritparzialev
									[z] /
									(double)
									dparzialev
									[z];
								fprintf (fpdelay, " %lf", ritparzialev[z] * 1000);
								ritparzialev
									[z] =
									0;
								dparzialev[z]
									= 0;
							}
							else
								fprintf (fpdelay, " 0");
						}
						fprintf (fpdelay, "\n");
						//fprintf(fpdelay,"Tempo ricezione %lu:%lu:%lf\n",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
						//printf("parziale %lu ritardo medio parziale %Lf msoffset %Lf \n",parziale,ritparziale,msoffset);
						dmsiniz =
							(infos[j].RxTime1 *
							 3600 +
							 infos[j].RxTime2 *
							 60 +
							 infos[j].RxTime3) *
							1000;
						dparziale = 0;
						ritparziale = 0;
					}
				}
				if (flagjitter)
				{
					jmsoffset =
						(double) (infos[j].RxTime1 *
							  3600 +
							  infos[j].RxTime2 *
							  60 +
							  infos[j].RxTime3) *
						1000 - jmsiniz;
					if ((jmsoffset >= msjitter)
					    || (jflagall))
					{
						if (!
						    ((jflagpl) && (jflagall)))
						{
							jitparziale =
								jitparziale /
								(double)
								(jparziale -
								 jflagpl);
							fprintf (fpjitter,
								 "%lf  ",
								 temposec);
							fprintf (fpjitter,
								 "%lf",
								 jitparziale *
								 1000);
							for (z = 1;
							     z <= totflownum;
							     z++)
							{
								if (jparzialev
								    [z] > 0)
								{
									if (jparzialev[z] > 1)
										jitparzialev
											[z]
											=
											jitparzialev
											[z]
											/
											(double)
											(jparzialev
											 [z]);
									fprintf (fpjitter, " %lf", jitparzialev[z] * 1000);
									jitparzialev
										[z]
										=
										0;
									jparzialev
										[z]
										=
										0;
								}
								else
									fprintf (fpjitter, " 0");
							}
							fprintf (fpjitter,
								 "\n");
						}
						jflagpl = 0;
						//fprintf(fpjitter,"Tempo ricezione %lu:%lu:%lf\n",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
						jmsiniz =
							(infos[j].RxTime1 *
							 3600 +
							 infos[j].RxTime2 *
							 60 +
							 infos[j].RxTime3) *
							1000;
						jparziale = 0;
						jitparziale = 0;
					}
				}
				if (flagbitrate)
				{
					bmsoffset =
						(double) (infos[j].RxTime1 *
							  3600 +
							  infos[j].RxTime2 *
							  60 +
							  infos[j].RxTime3) *
						1000 - bmsiniz;
					//fprintf(fpdelay,"dmsoffset %Lf ,msdelay %Lf\n",dmsoffset,msdelay);
					if ((bmsoffset >= msbitrate))
					{
						if (bmsoffset > 0)
						{
							fprintf (fpbitrate,
								 "%lf  ",
								 temposec);
							fprintf (fpbitrate,
								 "%lf ",
								 bitparziale /
								 bmsoffset);
							for (z = 1;
							     z <= totflownum;
							     z++)
							{
								fprintf (fpbitrate, "%lf ", bitparzialev[z] / bmsoffset);
								bitparzialev
									[z] =
									0;
							}
							fprintf (fpbitrate,
								 "\n");
							//fprintf(fpbitrate,"Tempo ricezione %lu:%lu:%lf\n",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
							//fprintf(fpbitrate,"bitparziale %Lf bmsoffset %Lf su %lu campioni\n",bitparziale,bmsoffset,bparziale);
							bmsiniz =
								(infos[j].
								 RxTime1 *
								 3600 +
								 infos[j].
								 RxTime2 *
								 60 +
								 infos[j].
								 RxTime3) *
								1000;
							bparziale = 0;
							bitparziale = 0;
						}
					}
				}
				if (flagpktloss)
				{
					pmsoffset =
						(double) (infos[j].RxTime1 *
							  3600 +
							  infos[j].RxTime2 *
							  60 +
							  infos[j].RxTime3) *
						1000 - pmsiniz;
					if ((pmsoffset >= mspktloss))
					{
						for (z = 1; z <= totflownum;
						     z++)
							pktparziale =
								pktparziale +
								pktparzialev
								[z];

						fprintf (fppktloss, "%lf  ",
							 temposec);
						fprintf (fppktloss, "%lu",
							 pktparziale);
						for (z = 1; z <= totflownum;
						     z++)
						{
							fprintf (fppktloss,
								 " %lu",
								 pktparzialev
								 [z]);
							pparzialev[z] =
								pparzialev[z]
								+
								pktparzialev
								[z];
							pktparzialev[z] = 0;
						}
						fprintf (fppktloss, "\n");
						pmsiniz =
							(infos[j].RxTime1 *
							 3600 +
							 infos[j].RxTime2 *
							 60 +
							 infos[j].RxTime3) *
							1000;
						pktparziale = 0;
					}
				}
				if (elab_type)
				{
					//printf("4a tot %lu\n",tot);

					ritm = ritm + riti;
					ritmv[index] = ritmv[index] + riti;
					if (tot > dimvect)
					{
						//printf("4b tot %lu dimvect %lu\n",tot,dimvect);
						dimvect = 2 * dimvect;
						//printf("4b00 %u \n",totflownum);
						vect = (double *)
							realloc (vect,
								 dimvect *
								 sizeof
								 (double));
						//printf("4b0 \n");
						indvect =
							(unsigned int *)
							realloc (indvect,
								 dimvect *
								 sizeof
								 (unsigned
								  int));
						//printf("4b1 tot %lu dimvect %lu\n",tot,dimvect);

					}
					seqnumv[index] = infos[j].SeqNum;
					vect[tot - 1] = riti;
					indvect[tot - 1] = infos[j].FlowId;

					//if(infos[j].SeqNum!=tot+pktloss)
					//pktloss=infos[j].SeqNum-tot;

					if (infos[j].SeqNum !=
					    totvect[index] +
					    pktlossvect[index])
						pktlossvect[index] =
							infos[j].SeqNum -
							totvect[index];

					//printf("tfn%u ",totflownum);
					if (delmax[index] < riti)
						delmax[index] = riti;
					if (delmin[index] > riti)
						delmin[index] = riti;
					byterecv[index] =
						byterecv[index] +
						infos[j].size;
					bytetot = bytetot + infos[j].size;
					//printf("Tempo send %d = %u:%u:%lf \n",i-1,infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
					//printf("Tempo recv %d = %u:%u:%lf \n",i-1,infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
					//printf("Ritardo %d esimo = %lf sec\n",i-1,vect[i-1]);
				}
			}
		}
		i++;
	}
	free (vect);
	in.close ();
	if (logflag)
		fclose (fpout);
	if (flagbitrate)
		fclose (fpbitrate);
	if (flagjitter)
		fclose (fpjitter);
	if (flagpktloss)
		fclose (fppktloss);
	if (flagdelay)
		fclose (fpdelay);
	exit (1);
}
