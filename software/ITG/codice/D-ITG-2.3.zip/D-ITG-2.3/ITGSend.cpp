 /******************************************************************************
 			ITGSend.cpp - Sender Component of the D-ITG Platform

			copyright	: (C) 2004 by Stefano Avallone, Donato Emma,
							Antonio Pescape'
			email:		: stavallo@unina.it, demma@napoli.consorzio-cini.it
							pescape@unina.it
*******************************************************************************/
 /******************************************************************************
 *   	                                                                       *
 *   This program is free software; you can redistribute it and/or modify  	   *
 *   it under the terms of the GNU General Public License as published by      *
 *   the Free Software Foundation; either version 2 of the License, or         *
 *   (at your option) any later version.                                       *
 *																			   *
 *                                                                             *
 ******************************************************************************/
#define TimeOut 60
#ifdef LINUX_OS
 #include <errno.h>
 #include <netdb.h>
 #include "ITG.h"
 #include "newran.h"   	   // to include after iostream.h
 #include <sys/wait.h>
 #include <math.h>
 #include <netinet/tcp.h> // for NO_DELAY TCP option
 #include <netinet/ip.h>
 #include <sys/timeb.h>
 #include <sys/shm.h>
 #include <pthread.h>
 #include <sys/msg.h>
 #include <sys/ipc.h>
//#include <openssl/rsa.h> // per l'autenticazione
// #include <openssl/pem.h> // per l'autenticazione
#endif



#ifdef WIN32
 #include <errno.h>
 #include "ITG.h"
 #include "newran/newran.h"   // to include after iostream.h
 #include <math.h>
 #include <sys/timeb.h>
 #include <time.h>
 static LARGE_INTEGER freq;
 #include <signal.h>
#endif

//Type enum declarations
typedef enum TDistro {pdConstant,pdUniform,pdExponential,pdPareto,pdCauchy,
	pdNormal,pdPoisson,pdGamma,pdTelnet};
typedef enum TAppProto {apNone,apTelnet,apVoIP,apDNS};
//Const declarations
const char* DistroStrings[] = {"Constant","Uniform","Exponential","Pareto",
	"Cauchy","Normal","Poisson","Gamma","Telnet"};
// the last element of AppProto must be " "
const char* AppProto[] = {"", "Telnet", "VoIP", "DNS", " "};
#ifdef LINUX_OS
const char DefaultLogFile[] = "/tmp/ITGSend.log";
#endif
#ifdef WIN32
char DefaultLogFile[] = "ITGSend.log";
#endif

const char DefaultDestIP[] = "127.0.0.1";
const unsigned int DefaultDSByte = 0;
const unsigned int DefaultPktPerSec = 1000;
const unsigned int DefaultPktSize = 512;
const unsigned long DefaultDuration = 10000;
const unsigned long DefaultDelay = 0;
const int MinPayloadSize = 2 * ( sizeof(unsigned int) + sizeof(long int) );
const int DimDefault=40;
// parametri da passare al thread i-esimo
struct parametriThread {
	int NumFlows;
	char line[MaxNumThread];
	Info *indirizzoinfos;
	int count;
	bool tcpNoDelay;
};

struct TTicker {
    Real count;
    struct timeval lastTime;
};

// pacchetto ICMP
struct icmppkt{
  	struct icmp icmp_buf;
	char packet[MaxPayloadSize];
};


// tale struttura dati ha memoria per ogni canale di signaling del numero di thread
// che lo condividono
struct gestioneCanaleSign{
	int socket;
	int numThreadSu;
	struct sockaddr_in DestAddr;
};
gestioneCanaleSign canSign[MaxNumThread];
// tale struttura realizza la corrispondenza tra
// il thread-gestore e il corrispondente canale di signalig

struct hThrGes {
    #ifdef WIN32
    HANDLE hand;
    #endif
    #ifdef LINUX_OS
    pthread_t hand;
    #endif
    int signaling;
};

hThrGes hThrGestore[MaxNumThread];
// tale struttura dati permette di associare un evento ad ogni thread:
// in tal modo si realizza un meccanismo di inter-process communication
#ifdef WIN32
HANDLE hEvent[MaxNumThread];
#endif

#ifdef LINUX_OS
int id_msg;
struct msg{
  long tipo;
  char testo[1];
} area_msg;
#endif




struct sig{
	int FlowId;
	int signaling;
};

// realizza la corrispondenza tra la chiave, il numero di flusso e  il canale di signaling
sig parasignaling[MaxNumThread];
// parametri da passare al thread-gestore dell'iesimo canale di signaling
sig HELPpara[MaxNumThread];
//Global variables
int sock;
char LogFile[DimLogFileChr];		  	 //nome del file di Log
int logvar=0;				 //logvar=1 voglio creare il logfile!
int ScriptMode=0;			 //modalita' di script
int logout=0;
int logsock;
int logremoto=0;
struct sockaddr_in LogHost;
struct sockaddr_in DestHostIP;
struct sockaddr_in ManagerIP;
socklen_t ManagerIPslen = sizeof(ManagerIP);
char *ProtoTx_Log=DefaultProtoTx_Log;
char *ProtoTx_ServerLogReceiver=DefaultProtoTx_LogOpZ;

//char NameMsr[30];
int logsocksignaling;
int logfile;
ofstream out;				    //file per il log!
Info *indirizzoinfos;
int countinfos;
static int primoThread=1;
int numcanalisignaling=0;
int l=1;
struct sockaddr_in serverLogReceiver;
char LogFileServerLogReceiver[DimLogFileChr];
int LogServer=0;
#ifdef LINUX_OS
uid_t user_id;
#endif

// Random Variables
Constant *ConstantRV;
Uniform *UniformRV;
Exponential *ExponentialRV;
Pareto *ParetoRV;
Cauchy *CauchyRV;        //new
Normal *NormalRV;        //new
Poisson *PoissonRV;      //new
Gamma *GammaRV;          //new

// inizializzazione della variabile mutex
#ifdef LINUX_OS
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_closed = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_log = PTHREAD_MUTEX_INITIALIZER;

#endif
#ifdef WIN32
HANDLE hMutex;
HANDLE hMutex_closed;
HANDLE mutex_log;
#endif

//-----------
int ServerSender;
struct sockaddr_in LocalHost;
int socketServer;
int SrcAddress;


// Prototypes
void telnetParser(SumRandom **pIntArriv,SumRandom **pPktSize,
					TDistro &IntArrivDistro,TDistro &PktSizeDistro);
void dnsParser(SumRandom **pIntArriv,SumRandom **pPktSize,
					TDistro &IntArrivDistro,TDistro &PktSizeDistro);
void voIPParser(int h,char *argv[], int &argc, unsigned int FlowId,
					SumRandom **pIntArriv,SumRandom **pPktSize,
					TDistro &IntArrivDistro,TDistro &PktSizeDistro);
void parserScriptMode(char *argv[],int argc);
void printHelpAndExit();
void ReportErrorAndExit(char *function, char *msg, char *pname, int fid);
 int findProto(char *s);
char * ricercaNameMsr(char line[200]);
void Terminate(int sig);
#ifdef LINUX_OS
void TerminatePulito(int sig);
#endif
void saveBufferBeforeClose(Info* infos,int count);
void argvToString(char *argv[],int argc,char line[200]);
void sendFlowId(int FlowId,int signaling, struct sockaddr_in DestHost,char *protocolName,char *upProtocol,int FlowIdStop,char NameMsr[30]);
void sendLog(int signaling,unsigned short logPort,unsigned int logIP,BYTE logProtocol,char FileName[30]);

void createCanalTrasport(int &signaling,struct sockaddr_in DestHost);
void createCanalSignaling(int signaling,struct sockaddr_in DestHost);
void recvAckConnect(int signaling);
void recvAck(int signaling);
 int recvAckFlow(int FlowId,int signaling);

void sendRelase(int signaling);
//void recvAckRelase(int signaling);
void closedFlow(int FlowId,int signaling);
void closedFlowErr(int FlowId,int signaling);
void Sendtype(int signaling,BYTE typeMessag);
char *putValue(void* startpos,void* data,int size);


bool checkClosedCanal(int &signaling,struct sockaddr_in DestHost);
bool checkDestHostIP(int &signaling,struct sockaddr_in DestHost);
void createRemotLogFile(struct sockaddr_in &LogHost,char *Prototx_Log);
void fillPacket(struct icmppkt &pkt, int size, int icmptype, struct sockaddr_in DestHost, struct sockaddr_in SrcHost);

void send_packowdm(int &ScriptMode, unsigned int DSByte, unsigned long &Duration, uid_t user_id,
 int icmptype, TAppProto AppProtocol, int logvar, int FlowId,char *LogFile,
 struct timeval timeout, struct sockaddr_in DestHost, int &logremoto,
 char* ProtoTx_Log,char upProtocol[30],char protocolName[30],int TTL,char NameMsr[30],
 SumRandom *IntArriv,SumRandom *PktSize,TDistro IntArrivDistro,TDistro PktSizeDistro);
void send_packrttm(int &ScriptMode, unsigned int &DSByte, unsigned long &Duration, uid_t user_id,
 int icmptype, TAppProto AppProtocol, int logvar, int FlowId,char *LogFile,
 struct timeval timeout, struct sockaddr_in DestHost, int &logremoto,
 char* ProtoTx_Log,char upProtocol[30],char protocolName[30],int TTL,char NameMsr[30],
 SumRandom *IntArriv,SumRandom *PktSize,TDistro IntArrivDistro,TDistro PktSizeDistro,parametriThread*para);

#ifdef LINUX_OS
 void* Gestore_Flusso(void* param);
 void UpdateTicker(struct TTicker *Ticker);
#endif

#ifdef WIN32
 DWORD WINAPI Gestore_Flusso(parametriThread* para);
 void UpdateTicker(struct TTicker * Ticker,LARGE_INTEGER &_tend,LARGE_INTEGER &_tprec,LARGE_INTEGER &_tstart,int &first);
 void tstart(LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi,int &first,char NameMsr[30]);
 void gettimeofday(struct timeval* thisTime,LARGE_INTEGER &_tend,LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi,char NameMsr[30]);
#endif


#ifdef LINUX_OS
	void pulisceMem(){
	//cout<<"ho cancellato la coda!"<<endl;
	if (msgctl(id_msg,IPC_RMID,NULL)<0)
		cout<<"Error into close queue"<<endl;
}
#endif
	



#ifdef WIN32
int InitializeWinsock(WORD wVersionRequested)
{
WSADATA wsaData;
int err;

	err = WSAStartup(wVersionRequested, &wsaData);

	// ritorna errore se, ad esempio, l'applicazione supporta al massimo
	// la versione 1.1 e la DLL supporta da 2.0 in su (le versioni non si sovrappongono)
	if (err!=0) return 0; // Tell the user that we couldn't find a usable winsock.dll

	// WSAStartup returns in wHighVersion (struct wsaData) the highest version it supports
	//  and in wVersion the minimum of its high version and wVersionRequested.
	//  wVersion is the The version of the Windows Sockets specification
	//  that the Windows Sockets DLL expects the caller to use.

	// Se WSAStartup ritorna un risultato accettabile, l'applicazione deve ancora
	//  verificare che il risultato sia compatibile con la sua richiesta. Ad esempio,
	//  con wVersionRequested=1.1 e DLL version 1.0, wVersion=1.0. Se l'applicazione
	//  vuole assolutamente usare la DLL 1.1, deve ancora verificare di non trovarsi
	//  in questo caso

	// Tell the user that we couldn't find a usable winsock.dll.
	if (LOBYTE(wsaData.wVersion )!=1 || HIBYTE(wsaData.wVersion)!=1) return 0;

	//Everything is fine: proceed
	return 1;
}

#endif
/*******************************************************************************
********************************** MAIN ****************************************
*******************************************************************************/
int main(int argc, char *argv[]) {
  char temp[MaxNumThread];
  char line[MaxNumThread];
  int numflusso=0;
  parametriThread para[MaxNumThread];	//array di parametri
  //strcpy(NameMsr,DefaultMsr);

  #ifdef WIN32
  HANDLE hThr[MaxNumThread];
  hMutex = CreateMutex(NULL, FALSE, "MYMUTEX");
  mutex_log = CreateMutex(NULL, FALSE, "MYMUTEX");
  int pid;
  //SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
  #endif

  #ifdef LINUX_OS
  pthread_t hThr[MaxNumThread];
  user_id=getuid();
  id_msg=msgget(IPC_PRIVATE,IPC_CREAT|0666);
  struct msqid_ds coda;
  coda.msg_qbytes=16384*2;
  msgctl(id_msg,IPC_SET,&coda);
  if (id_msg==-1) printf(" ** ERROR into messag queue \n");
  #endif

   #ifdef WIN32
   if (!InitializeWinsock (MAKEWORD(1,1) ) ){
	   	cerr<<"** ERROR ** WSAStartup() failed "<<endl;
		exit(1);
	}
   #endif

  #ifdef LINUX_OS
  pthread_attr_t attrib;
  if (user_id==0){
   struct sched_param param;
   pthread_attr_init(&attrib);
   pthread_attr_setinheritsched(&attrib, PTHREAD_EXPLICIT_SCHED);
   pthread_attr_setschedpolicy(&attrib,SCHED_RR);
   param.sched_priority=99;
   pthread_attr_setschedparam(&attrib,&param);
  }
  #endif

// Store the program name and inc argv
  strcpy(programName, argv[0]);
  argv++;
  argc--;
  if (!argc){
       cout<<endl<<"Missing argument!!!\nTry ITGSend -h or --help for more informations\n";
       exit(1);
  }
  else if (((argv[0][0] == '-') && (argv[0][1]=='h')) || ((argv[0][0] == '-') && (argv[0][1]=='-') && (argv[0][2]=='h')))
   	printHelpAndExit();

  for (int i=0; i<MaxNumThread; i++){
	canSign[i].socket=-1;
	canSign[i].numThreadSu=0;
    parasignaling[i].signaling=-1;
    parasignaling[i].FlowId=-1;
  }

 //opzione server manager
 if ((argc>0) && (argv[0][0] == '-') && (argv[0][1]=='Q')) {
   signal(SIGINT,Terminate);
   cout<<"Press Ctrl-C to terminate"<<endl;
   ServerSender = 1;			// modalita' sender remoto
   ScriptMode=1;
  // socklen_t sin_len=sizeof(SrcAddress);
   int size_r;
   char buffer[80];

  argv++;
  argc--;
  parserScriptMode(argv,argc);

  LocalHost.sin_family=AF_INET;
  //porto di default su cui mi ascolto il signaling!
  LocalHost.sin_port = htons(DefaultPortSenderManager);
  socketServer = socket(PF_INET, SOCK_DGRAM, 0);
  if (socketServer < 0) {
      cerr << endl << "** ERROR **  : Cannot create a socket on port "  << endl;
      #ifdef LINUX_OS
      	pulisceMem();
      #endif
      exit(1);
  }

 #ifdef LINUX_OS
 LocalHost.sin_addr.s_addr=htonl(INADDR_ANY);
 #endif
 #ifdef WIN32
 LocalHost.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
 #endif
 if (bind(socketServer, (struct sockaddr *) &LocalHost, sizeof(LocalHost))<0) {
      cerr << endl << "** ERROR **  : Cannot bind a socket on port - for signaling" << endl;
      #ifdef LINUX_OS
      	pulisceMem();
      #endif
      exit(1);
  }
  
 do {
    size_r = recvfrom(socketServer, buffer, sizeof(buffer),0,(struct sockaddr *)&ManagerIP, &ManagerIPslen);
    buffer[size_r]='\n';
    buffer[size_r+1]='\0';
    strcpy(para[numflusso].line,buffer);		//linea da passare al thread i-esimo
    para[numflusso].NumFlows=numflusso+1;		//identificativo del flusso che sar�generato

    /* send an ack back to ITGManager */
    memmove(buffer+2*sizeof(int),buffer,size_r);
    ((int*)buffer)[0]=MNG_FLOWSTART;      /* msg type */
   ((int*)buffer)[1]=size_r;             /* length */

    sendto(socketServer, buffer, size_r+2*sizeof(int), 0, (struct sockaddr *)&ManagerIP, ManagerIPslen);

    #ifdef WIN32
    int pid;
    hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) Gestore_Flusso, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
    //SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);
    #endif
    #ifdef LINUX_OS
    if (user_id==0) pthread_create(&hThr[numflusso],NULL, Gestore_Flusso, &para[numflusso]);
	   else pthread_create(&hThr[numflusso],NULL, Gestore_Flusso, &para[numflusso]);
    #endif
    if (hThr[numflusso] < 0) {
     		cerr << "Cannot create a process to handle flow " << numflusso+1 << endl;
    }
    numflusso++;
 } while (1);//endwhile
 }

 // Is script mode ?
 else if ( argc>0 && argv[0][0] != '-' && !findProto(argv[0]) ) {
	//Script Mode
	ScriptMode = 1;
	FILE *batch;
 	if ((batch = fopen(argv[0], "r")) == NULL) {
		// unable to open script file
      	#ifdef LINUX_OS
			perror("ITGServer Main: ");
      		pulisceMem();
      	#endif
		cerr << "Cannot open '" << argv[0] << "' for reading" << endl;
      	exit(1);
  }
  argv++;
  argc--;
  parserScriptMode(argv,argc);
  // gets the first line of the script file
  if (fgets(line,sizeof(line)-1,batch)==NULL) {
		cerr<<"errore"<<endl;
	    #ifdef LINUX_OS
      	pulisceMem();
      	#endif
		exit(1);
  }  	
  //start a thread for each flow that must be generated
  strcpy(temp,line);
  do {
	  strcpy(para[numflusso].line,temp);//flow configuration
 	  para[numflusso].NumFlows=numflusso+1;	//flow id
	  para[numflusso].tcpNoDelay = true;
#ifdef WIN32
	  hThr[numflusso]=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) Gestore_Flusso, &para[numflusso], (DWORD)NULL,(unsigned long*)&pid);
      	  //SetThreadPriority(&hThr[numflusso],THREAD_PRIORITY_TIME_CRITICAL);
#endif
#ifdef LINUX_OS
	  // create the new thread
	  if (user_id==0) pthread_create(&hThr[numflusso],NULL,
		  Gestore_Flusso, &para[numflusso]);
	  else pthread_create(&hThr[numflusso],NULL,
		  Gestore_Flusso, &para[numflusso]);
#endif
          if (hThr[numflusso] < 0) {
			perror("ITGSend Main: ");
       		cerr << "Cannot create a process to handle flow " 
			  << numflusso+1 << endl;
      	  }
	  numflusso++;
  } while (fgets(temp, sizeof(temp)-1, batch));
  fclose(batch);
#ifdef LINUX_OS
	signal(SIGINT,TerminatePulito);
	// cout<<"Press Ctrl-C to terminate "<<endl;
#endif
  // Wait for flows
#ifdef WIN32
	WaitForMultipleObjects(numflusso,hThr,TRUE,INFINITE); //aspetta la terminazione di tutti i figli
#endif
#ifdef LINUX_OS
	for (int i=0;i<numflusso;i++) pthread_join(hThr[i],NULL);
#endif
  #ifdef WIN32
  for (int i=0; i<numflusso;i++) CloseHandle(hThr[i]);
  #endif
 } else { // No script Mode
        para[0].NumFlows=1;				//numero del flusso
        argvToString(argv,argc,para[0].line);
        strcpy(temp,para[0].line);
        /*strcpy(NameMsr,ricercaNameMsr(temp));
        if (strcmp(NameMsr,"rttm")==0){
            signal(SIGINT,Terminate);
            cout<<"Press Ctrl-C to terminate "<<endl;
		} //end if rttm mode
		#ifdef LINUX_OS
			else {
            signal(SIGINT,TerminatePulito);
            //cout<<"Press Ctrl-C to terminate "<<endl;

			}
		#endif*/
	Gestore_Flusso(&para[0]);
 } // end else

 #ifdef LINUX_OS
 if (msgctl(id_msg,IPC_RMID,NULL)<0)
  cout<<" ** Error into message queue"<<endl;
 #endif

  if (logremoto && ScriptMode==1) 		 //se il log deve essere creato ma e' script
    	 {
    Signaling signaling_log;		 //per la gestione del canale di signaling con il log remoto
    signaling_log.stop=true;
    sendto(logsocksignaling, (char*)&signaling_log, sizeof(signaling_log),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
    // cout<<"ho inviato il messaggio di stop!"<<endl;
    #ifdef WIN32
    closesocket(logsock);
    closesocket(logsocksignaling);
    #endif
    #ifdef LINUX_OS
    if (close(logsock)<0) cout<<"error into close "<<endl;
    if (close(logsocksignaling)<0) cout<<"error into close "<<endl;
    #endif
 }
 else {
	out.close();
 }

 #ifdef WIN32
 WSACleanup();
 ExitProcess(0);
 return 0;
 #endif
}//END Main




void parserScriptMode(char *argv[],int argc){
   DestHostIP.sin_family=AF_INET;
   #ifdef WIN32
   DestHostIP.sin_addr.S_un.S_addr=inet_addr(DefaultDestIP);  //per windows
   #endif
   #ifdef LINUX_OS
   inet_aton(DefaultDestIP,&DestHostIP.sin_addr);  //per windows
   #endif

   DestHostIP.sin_port=htons(DefaultPort);
   while (argc>0) {
    if (argv[0][0] == '-') {
      struct hostent *host;
      switch (argv[0][1]) {
         case 'h':
           printHelpAndExit();
          break;
         case 'L':
	   logremoto=1;
           logout = 1;
           logvar = 1;
   	   if ((argc < 3) || !(host=gethostbyname(argv[1])) )
    	    ReportErrorAndExit("General parser"," Invalid log-server address or port", programName,0);
          memcpy((char *)&LogHost.sin_addr, host->h_addr, host->h_length);
	       //LogHost.sin_port=htons(atoi(argv[2]));
		     strcpy(ProtoTx_Log,argv[2]);
			 argv+=3;
	       argc-=3;
	     break;
         case 'Z':
   	      if ((argc < 2) || !(host=gethostbyname(argv[1])) )
    	  	ReportErrorAndExit("General parser"," Invalid log-server address or port", programName,0);
              memcpy((char *)&serverLogReceiver.sin_addr, host->h_addr, host->h_length);
	      //serverLogReceiver.sin_port=htons(atoi(argv[2]));
	      strcpy(ProtoTx_ServerLogReceiver,argv[2]);
	      strcpy(LogFileServerLogReceiver,argv[3]);
	      argv+=4;
	      argc-=4;
	      LogServer=1;
	     break;
/*    	 case 'm':
    	  if ((strcasecmp(argv[1],"rttm")) && (strcasecmp(argv[1],"owdm")))
	         ReportErrorAndExit("General parser", "Invalid misure type", programName, 0);
			strcpy(NameMsr,argv[1]);
          argv+=2;
      	  argc-=2;
	     break;*/
       	 case 'l':
          logvar = 1;
          if ((argc < 2) || (argv[1][0] == '-') || findProto(argv[1]) ) {
            strcpy(LogFile, DefaultLogFile);
          argc-=1;
	      argv+=1;
          }
          else {
            strcpy(LogFile, argv[1]);
            argc-=2;
	        argv+=2;
          }
	    break;
     } //end switch
   } //end if (argc[][]==
  } //end while
}



#ifdef WIN32
DWORD WINAPI Gestore_Flusso(parametriThread* para){
  struct _timeb tstruct;
#endif
#ifdef LINUX_OS
 void* Gestore_Flusso(void* param){
 parametriThread* para;
 para=(parametriThread*)param;
#endif

 struct sockaddr_in DestHost;
 char protocolName[30];
 char NameMsr[30]="owdm";
 char upProtocol[30]="none";
 char *argv[200];
 int argc;
 int FlowId=para->NumFlows;
 char *token;
 SumRandom *IntArriv;
 SumRandom *PktSize;
 TDistro IntArrivDistro;
 TDistro PktSizeDistro;
 if (para->line[strlen(para->line)-1]=='\n'){
		para->line[strlen(para->line)-1]='\0';
 } else {
		cerr<<" No newline at the end of file" <<endl;
    	      #ifdef LINUX_OS
	      	pulisceMem();
      		#endif

	exit(1);
 }

 char *ManagerMsg;
 if (ServerSender)
 {
    ManagerMsg = (char*)malloc(sizeof(char)*strlen(para->line)+sizeof(int)*2);
    strcpy(ManagerMsg,para->line);
 }

//Set default variables
  unsigned int DSByte = DefaultDSByte;
  unsigned long Duration = DefaultDuration;
  unsigned long Delay = DefaultDelay;
  int icmptype=8;
  int TTL=0;
  strcpy(protocolName,DefaultProto); //default UDP
  double seed = 0.0;

  TAppProto AppProtocol;
  AppProtocol = apNone;
  timeval timeout;

// Set the default IP dest addr
  DestHost.sin_family=AF_INET;
  #ifdef WIN32
  DestHost.sin_addr.S_un.S_addr=inet_addr(DefaultDestIP);  //per windows
  #endif
  #ifdef LINUX_OS
  inet_aton(DefaultDestIP,&DestHost.sin_addr);  //per linux
  #endif

  DestHost.sin_port=htons(DefaultPort);

   LogHost.sin_family=AF_INET;
// Set the default IP log addr
  if (!ScriptMode){
   strcpy(LogFile,DefaultLogFile);
   #ifdef WIN32
   LogHost.sin_addr.S_un.S_addr=inet_addr(DefaultDestIP);
   #endif
   #ifdef LINUX_OS
   inet_aton(DefaultDestIP,& LogHost.sin_addr);  //per linux
   #endif
   LogHost.sin_port=htons(DefaultLogPort);
  }
// Set the default inter-arrival time (msecs)
  IntArrivDistro = pdConstant;
  ConstantRV = new Constant(1);
  IntArriv = new SumRandom(1000.0 / DefaultPktPerSec * (*ConstantRV));

// Set the default packet size (bytes)
  PktSizeDistro = pdConstant;
  ConstantRV = new Constant(1);
  PktSize = new SumRandom(DefaultPktSize * (*ConstantRV));

// Decodifica la stringa di input.
  token = strtok( para->line," ");
  int j=0;
  while( token != NULL )
  {
	  argv[j]=token;
	  j++;
      token = strtok( NULL," ");
    }
  argc=j;
  int h=0;
  while (argc>0) {
    if (argv[h][0] == '-') {
      struct hostent *host;
      char *tail;
      long int temp;
      Real a,b;
  	 switch (argv[h][1]) {
    	 case 'm':
    	  if ((strcasecmp(argv[h+1],"rttm")) && (strcasecmp(argv[h+1],"owdm")))
	         ReportErrorAndExit("General parser", "Invalid misure type", programName, 0);
			strcpy(NameMsr,argv[h+1]);
          h+=2;
      	  argc-=2;
	     break;

	/*case 'm':
           if (ScriptMode)
             ReportErrorAndExit("General parser", "-m option not allowed in script file", programName, FlowId);
    	   if ((strcasecmp(argv[h+1],"rttm")) && (strcasecmp(argv[h+1],"owdm")))
	         ReportErrorAndExit("General parser", "Invalid misure type", programName, FlowId);
		    strcpy(NameMsr,argv[h+1]);
           h+=2;
      	   argc-=2;
	  break;*/
	case 'a':
           if ( (argc < 2) || !(host=gethostbyname(argv[h+1])))
         	ReportErrorAndExit("General parser", "Invalid destination address", programName, FlowId);
		   memcpy((char *)&DestHost.sin_addr, host->h_addr, host->h_length);
	       h+=2;
           argc-=2;
          break;
	case 'p':
          if (argc < 2)
            ReportErrorAndExit("General parser", "Invalid port number", programName, FlowId);
          DestHost.sin_port = htons(atoi(argv[h+1]));
          h+=2;
          argc-=2;
          break;
        case 'f':
          if (argc < 2)
            ReportErrorAndExit("General parser", "Invalid TTL", programName, FlowId);
          temp = strtol(argv[h+1],&tail,0);
          if ( (tail == argv[h+1]) || (temp < 0) || (temp > 255) )
            ReportErrorAndExit("General parser", "Invalid TTL", programName, FlowId);
          TTL = temp;
          h+=2;
          argc-=2;
          break;

		case 't':
          if ( (argc < 2) || ((temp = strtol(argv[h+1],NULL,10)) <= 0) )
            ReportErrorAndExit("General parser", "Invalid Duration", programName, FlowId);
          Duration = temp;
 		  h+=2;
          argc-=2;
          break;
        case 'd':
          if (argc < 2)
            ReportErrorAndExit("General parser", "Invalid Delay", programName, FlowId);
          temp = strtol(argv[h+1],&tail,10);
          if ( (tail == argv[h+1]) || (temp < 0) )
            ReportErrorAndExit("General parser", "Invalid Delay", programName, FlowId);
          Delay = temp;
		  h+=2;
          argc-=2;
          break;
        case 'b':
          if (argc < 2)
            ReportErrorAndExit("General parser", "Invalid DS Byte", programName, FlowId);
          temp = strtol(argv[h+1],&tail,0);
          if ( (tail == argv[h+1]) || (temp < 0) || (temp > 255) )
            ReportErrorAndExit("General parser", "Invalid DS Byte", programName, FlowId);
          DSByte = temp;
          h+=2;
          argc-=2;
          break;
        case 'L':
           if (ScriptMode)
             ReportErrorAndExit("General parser", "-L option not allowed in script mode", programName, FlowId);
          	 logout = 1;
          	 logvar = 1;
		 logremoto = 1;
   	  	   if ((argc < 2) || !(host=gethostbyname(argv[h+1])) )
    	 	ReportErrorAndExit("General parser"," Invalid log-server address or port", programName,FlowId);
           memcpy((char *)&LogHost.sin_addr, host->h_addr, host->h_length);
	       //LogHost.sin_port=htons(atoi(argv[h+2]));
	       strcpy(ProtoTx_Log,argv[h+2]);
		   h+=3;
	       argc-=3;
	       break;
        case 'Z':
   	       if ((argc < 2) || !(host=gethostbyname(argv[h+1])) )
    	   	ReportErrorAndExit("General parser"," Invalid log-server address or port", programName,FlowId);
           memcpy((char *)&serverLogReceiver.sin_addr, host->h_addr, host->h_length);
	       //serverLogReceiver.sin_port=htons(atoi(argv[h+2]));
           strcpy(ProtoTx_ServerLogReceiver,argv[h+2]);
	       strcpy(LogFileServerLogReceiver,argv[h+3]);
	       h+=4;
	       argc-=4;
	       LogServer=1;
	       break;
  	    case 'T':
          if (argc<2)
            ReportErrorAndExit("General parser", "Invalid Protocol Type", programName, FlowId);
          if ( (strcmp(argv[h+1],"UDP")==0) && (strcmp(argv[h+1],"TCP")==0) && (strcmp(argv[h+1],"ICMP")==0))
            ReportErrorAndExit("General parser", "Invalid Protocol Type", programName, FlowId);
          strcpy(protocolName,argv[h+1]);
          if (strcmp(protocolName,"ICMP")==0){
            if ((argc > 2) && (argv[h+2][0]!='-')){
              icmptype=atoi(argv[h+2]);
              h+=1;
              argc--;
            }
          }
          h+=2;
	      argc-=2;
          break;
        case 's':
          if ( (argc < 2) || ((seed = strtod(argv[h+1], NULL)) >= 1.0) || (seed <= 0.0) )
            ReportErrorAndExit("General parser", "Invalid seed (0 < seed < 1)", programName, FlowId);
          h+=2;
	      argc-=2;
          break;
          break;
      	case 'l':
          if (ScriptMode)
            ReportErrorAndExit("General parser", "-l option not allowed in script mode", programName, FlowId);
          logvar = 1;
          if ((argc < 2) || (argv[h+1][0] == '-') || findProto(argv[h+1]) ) {
            strcpy(LogFile, DefaultLogFile);
          argc-=1;
	      h+=2;
          }
          else {
            strcpy(LogFile, argv[h+1]);
            argc-=2;
	        h+=2;
          }
          break;
         case 'C':					//se cambia qui deve cambiare d'ovunque!!
          if ( (argc < 2) || (atoi(argv[h+1]) < 1) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId);
          IntArrivDistro = pdConstant;
		  delete IntArriv;
		  ConstantRV = new Constant(1);
          IntArriv = new SumRandom( 1000.0 / atoi(argv[h+1]) * (*ConstantRV) );
		  h+=2;
          argc-=2;
          break;
        case 'U':
          if ( (argc < 3) || (atoi(argv[h+1]) < 1) || (atoi(argv[h+2]) <= atoi(argv[h+1])) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId);
          delete IntArriv;
		  IntArrivDistro = pdUniform;
          b = 1000.0 / atoi(argv[h+2]);
          a = 1000.0 / atoi(argv[h+1]) - b;
		  UniformRV = new Uniform;
          IntArriv = new SumRandom(  a * (*UniformRV) + b );
          h+=3;
          argc-=3;
          break;
        case 'E':
          if ( (argc < 2) || (atoi(argv[h+1]) < 1) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId);
		  delete IntArriv;
          IntArrivDistro = pdExponential;
		  ExponentialRV = new Exponential;
          IntArriv = new SumRandom( 1000.0 / atoi(argv[h+1]) * (*ExponentialRV) );
          h+=2;
		  argc-=2;
          break;
        case 'V':
          if ( (argc < 3) || (strtod(argv[h+1],NULL) <= 0) || (strtod(argv[h+2],NULL) <= 0) )
             ReportErrorAndExit("Protocol Parser", "Invalid Pareto Distribution parameter values", programName, FlowId);
          a = (Real) strtod(argv[h+1],NULL);
          b = (Real) strtod(argv[h+2],NULL);
          ParetoRV = new Pareto(a);
		  delete IntArriv;
          IntArrivDistro = pdPareto;
          IntArriv = new SumRandom( b * (*ParetoRV) );
          h+=3;
		  argc-=3;
          break;
        case 'Y':
          if ((argc < 3) || (atoi(argv[h+2]) <= 0))//a>0, b real
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId);
          IntArrivDistro = pdCauchy;
          b = (Real) 1000.0 /atoi(argv[h+1]);//shape
          a = (Real) 1000.0 /atoi(argv[h+2]);//scale
		  delete IntArriv;
		  CauchyRV = new Cauchy;
          IntArriv = new SumRandom( a * (*CauchyRV) + b );
          h+=3;
		  argc-=3;
          break;
        case 'N':
          if ((argc < 3) || (argv[h+2]<=0))//standard deviation >0
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId);
          IntArrivDistro = pdNormal;
          b = (Real) 1000.0 /atoi(argv[h+1]);//mean
          a = (Real) 1000.0 /atoi(argv[h+2]);//standard deviation
		  delete IntArriv;
		  NormalRV = new Normal;
          IntArriv = new SumRandom( a * (*NormalRV) + b );
          h+=3;
		  argc-=3;
          break;
        case 'O':
          if ( (argc < 2) || (atoi(argv[h+1]) < 0) )//mean >0
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId);
          a = (Real) atoi(argv[h+1]);
		  delete IntArriv;
          PoissonRV = new Poisson(a);   // the constructor takes the mean as argument
          IntArrivDistro = pdPoisson;
          IntArriv = new SumRandom( 1000.0/(*PoissonRV) );
		  h+=2;
	      argc-=2;
          break;
        case 'G':
          if ( (argc < 3) || (strtod(argv[h+1],NULL) <= 0) || (strtod(argv[h+2],NULL) <= 0) ) // shape, scale >0
             ReportErrorAndExit("Protocol Parser", "Invalid Gamma Distribution parameter values", programName, FlowId);
          a = (Real) strtod(argv[h+1],NULL);
          b = (Real) strtod(argv[h+2],NULL);
	      delete IntArriv;
          GammaRV = new Gamma(a);    //the constructor takes the shape parameter as argument
          IntArrivDistro = pdGamma;
          IntArriv = new SumRandom( b * (*GammaRV) );
	      h+=3;
          argc-=3;
          break;
        case 'c':
          if ( (argc < 2) || (atoi(argv[h+1]) < 1) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId);
          delete PktSize;
		  PktSizeDistro = pdConstant;
		  ConstantRV = new Constant(1);
          PktSize = new SumRandom( atoi(argv[h+1]) * (*ConstantRV) );
		  h+=2;
          argc-=2;
          break;
        case 'u':
          if ( (argc < 3) || (atoi(argv[h+1]) < 1) || (atoi(argv[h+2]) <= atoi(argv[h+1])) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId);
          delete PktSize;
          PktSizeDistro = pdUniform;
          b = atoi(argv[h+1]);
          a = atoi(argv[h+2]) - b;
		  UniformRV = new Uniform;
          PktSize = new SumRandom( a * (*UniformRV) + b );
          argc-=3;
		  h+=3;
          break;
        case 'e':
          if ( (argc < 2) || (atoi(argv[h+1]) < 1) )
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId);
          delete PktSize;
          PktSizeDistro = pdExponential;
		  ExponentialRV = new Exponential;
          PktSize = new SumRandom( atoi(argv[h+1]) * (*ExponentialRV) );
		  h+=2;
          argc-=2;
          break;
        case 'v':
          if ( (argc < 3) || (strtod(argv[h+2],NULL) <= 0) )//a>o, b to be real
             ReportErrorAndExit("Protocol Parser", "Invalid Pareto Distribution parameter values", programName, FlowId);
          a = (Real) strtod(argv[h+1],NULL);
          b = (Real) strtod(argv[h+2],NULL);
          delete PktSize;
          ParetoRV = new Pareto(a);
          PktSizeDistro = pdPareto;
          PktSize = new SumRandom( b * (*ParetoRV) );
          argc-=3;
		  h+=3;
          break;
        case 'y':
          if ((argc < 3) || (atoi(argv[h+2]) <= 0))//a>0, b real
            ReportErrorAndExit("Protocol Parser", "Invalid pkts per sec", programName, FlowId);
          delete PktSize;
          PktSizeDistro = pdCauchy;
          b = (Real) atoi(argv[h+1]);//shape
          a = (Real) atoi(argv[h+2]);//scale
		  CauchyRV = new Cauchy;
          PktSize = new SumRandom( a * (*CauchyRV) + b );
          h+=3;
          argc-=3;
          break;
        case 'n':
          if ((argc < 3) || (argv[h+2]<=0))//standard deviation >0
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId);
          delete PktSize;
          PktSizeDistro = pdNormal;
          b = (Real) atoi(argv[h+1]);//mean
          a = (Real) atoi(argv[h+2]);//standard deviation
		  NormalRV = new Normal;
          PktSize = new SumRandom( a * (*NormalRV) + b );
          h+=3;
		  argc-=3;
          break;
        case 'o':
          if ( (argc < 2) || (atoi(argv[h+1]) < 0) ) //mean >0
            ReportErrorAndExit("Protocol Parser", "Invalid pkt size", programName, FlowId);
          a = atoi(argv[h+1]);
          delete PktSize;
          PoissonRV = new Poisson(a);   // the constructor takes the mean as argument
          PktSizeDistro = pdPoisson;
          PktSize = new SumRandom( 1 * (*PoissonRV) );
          h+=2;
          argc-=2;
          break;
        case 'g':
          if ( (argc < 3) || (strtod(argv[h+2],NULL) <= 0) )
             ReportErrorAndExit("Protocol Parser", "Invalid Gamma Distribution parameter values", programName, FlowId);
          delete PktSize;
          a = (Real) strtod(argv[h+1],NULL);
          b = (Real) strtod(argv[h+2],NULL);
          GammaRV = new Gamma(a); //the constructor takes the shape parameter as argument
          PktSizeDistro = pdGamma;
          PktSize = new SumRandom( b * (*GammaRV) );
		  h+=3;
          argc-=3;
          break;
		case 'D':
				cout << "Abilità l'algoritmo di Nagle \n";
			break;
       default:
	  char temp[sizeof("What is  ?")+sizeof(argv[h])];
	  ReportErrorAndExit("General parser", strcat(strcat(strcpy(temp, "What is "), argv[h]), " ?"), programName, FlowId);
	  break;
      } //end switch
   } //end if
   else  {

			AppProtocol = (TAppProto)findProto(argv[h]);
			switch (AppProtocol) {
       			case apTelnet:
				  strcpy(NameMsr,"owdm");
	           	  telnetParser(&IntArriv,&PktSize,IntArrivDistro,PktSizeDistro);
				  strcpy(upProtocol,"Telnet");
				  strcpy(protocolName,"TCP");
				  h++;
       	          argc--;
	  	 	break;
			case apVoIP:
        		  strcpy(NameMsr,"owdm");
           	 	  voIPParser(h,argv,argc,FlowId,&IntArriv,&PktSize,IntArrivDistro,PktSizeDistro);
				  strcpy(upProtocol,"VoIP");
				  strcpy(protocolName,"UDP");
	  		break;
        		case apDNS:
          		  strcpy(NameMsr,"owdm");
	           	  dnsParser(&IntArriv,&PktSize,IntArrivDistro,PktSizeDistro);
				  strcpy(upProtocol,"DNS");
				  strcpy(protocolName,"UDP");
				  h++;
				  argc--;
			break;
		        case apNone:
          			  char temp[sizeof("What is  ?")+sizeof(argv[h])];
	          		  ReportErrorAndExit("General parser", strcat(strcat(strcpy(temp, "What is "), argv[h]), " ?"), programName, FlowId);
			break;
  			} //end switch
        } //end else
  }// End While

 if (seed == 0.0) {
 #ifdef WIN32              // not specified by user
 _ftime( &tstruct );
 seed = 0.49 * sin(tstruct.millitm ) + 0.50;    //  0.01 <= seed <= 0.99
 #endif

 #ifdef LINUX_OS
 struct timeval tv;             // not specified by user
 gettimeofday(&tv,NULL);
 seed = 0.49 * sin(tv.tv_usec) + 0.50;    //  0.01 <= seed <= 0.99
 #endif
 }

// Initialize random generators
  IntArriv->Set(seed);
  PktSize->Set(seed);

// Wait Delay msecs
  if (Delay) {
#ifdef LINUX_OS
    timeout.tv_sec = Delay / 1000;
    timeout.tv_usec = ( Delay % 1000 ) * 1000;
    long int result;
    do result = (long int) ( select(0, NULL, NULL, NULL, &timeout) );
    while (result == -1L && errno == EINTR);
#endif
#ifdef WIN32
	Sleep(Delay);
#endif
  }

  #ifdef LINUX_OS
  int user_id=getuid();
  #endif
  #ifdef WIN32
  int user_id=0;
  #endif
  if (strcmp(NameMsr,"owdm")==0)
   send_packowdm(ScriptMode,DSByte,Duration,user_id,icmptype,AppProtocol,logvar,para->NumFlows,LogFile,
 timeout,DestHost,logremoto,ProtoTx_Log,upProtocol,protocolName,TTL,NameMsr,IntArriv,PktSize,IntArrivDistro,PktSizeDistro);
  else {
      send_packrttm(ScriptMode,DSByte,Duration,user_id,icmptype,AppProtocol,logvar,para->NumFlows,LogFile,
    		   timeout,DestHost,logremoto,ProtoTx_Log,upProtocol,protocolName,TTL,NameMsr,IntArriv,PktSize,IntArrivDistro,PktSizeDistro,para);
  }

 if (ServerSender)
    {
       /* Notify ITGManager about the end of the generation */
       int length=strlen(ManagerMsg);
       memmove(ManagerMsg+2*sizeof(int),ManagerMsg,length);
       ((int*)ManagerMsg)[0]=MNG_FLOWEND;      /* msg type */
       ((int*)ManagerMsg)[1]=length;           /* msg length */
       cout << endl << "Sending bytes " << sendto(socketServer,ManagerMsg,length+sizeof(int)*2,0,(struct sockaddr *)&ManagerIP,ManagerIPslen) << endl;
    }

	if (logout && ScriptMode==0) {		 //se il log deve essere creato ma e' un solo flusso

	Signaling signaling_log;		 //per la gestione del canale di signaling con il log remoto
    	signaling_log.stop=true;
    	sendto(logsocksignaling, (char*)&signaling_log, sizeof(signaling_log),0,
			(struct sockaddr *)&LogHost, sizeof(LogHost));
#ifdef WIN32
 		closesocket(logsock);
		closesocket(logsocksignaling);
 		//if (closesocket(logsock)<0) cout<<"error into close "<<endl;
		//if (closesocket(logsocksignaling)<0) cout<<"error into close "<<endl;
#endif
#ifdef LINUX_OS
		//cout<<"Sto uscendo!"<<endl;
		close(logsock);
		close(logsocksignaling);
		//if (close(logsock)<0) cout<<"error into close "<<endl;
   		//if (close(logsocksignaling)<0) cout<<"error into close "<<endl;
#endif
	} else if (ScriptMode==0) {
		out.close();
 	}
 	if (ScriptMode==1)
 #ifdef WIN32
 		ExitThread(0);
 #endif
 #ifdef LINUX_OS
 		pthread_exit(0);
 #endif
	return 0;
}



int searchPosition(int signaling,int FlowId){
	int i=0;

	while ((parasignaling[i].signaling!=signaling) || (parasignaling[i].FlowId!=FlowId))
		i++;
	return i;
}


#ifdef WIN32
DWORD WINAPI createThreadGestore(sig* idcanale){
#endif
#ifdef LINUX_OS
void* createThreadGestore(void* idcanaleparam){
 sig* idcanale;
 idcanale=(sig*)idcanaleparam;
#endif
 int size;
 BYTE type;
 while(1){
    size=recv(idcanale->signaling,(char*)&type,sizeof(type),0);
    if ((type==5) || (type==6)) {
	    char buffer[4];
	    char *ptrFlowId = buffer;
	    size=recv(idcanale->signaling,(char*)buffer,sizeof(buffer),0);
		#ifdef WIN32
		SetEvent(hEvent[searchPosition(idcanale->signaling,*(unsigned int*)ptrFlowId)]);
		#endif
		#ifdef LINUX_OS
		area_msg.tipo=(*(unsigned int*)ptrFlowId);
		msgsnd(id_msg,&area_msg,sizeof(unsigned int),0);
		#endif
  }
  else if (type==8) {
  	Sendtype(idcanale->signaling,9);
  }
  else if ((type==15) || (type==16)) {  //messaggio di errore per il flusso i-esimo
			if (type==16) {  // type=16 il receiver non � root!
			char buffer[4];
	    		char *ptrFlowId = buffer;
	    		size=recv(idcanale->signaling,(char*)buffer,sizeof(buffer),0);
   			cout<< " ** To generate ICMP traffic sender e receiver must be root"<<endl;
			closedFlowErr((*(unsigned int*)ptrFlowId),idcanale->signaling);
			}
			if (type==15) {  // il porto specificato dal flusso � occupato
			char buffer[4];
	    		char *ptrFlowId = buffer;
    			size=recv(idcanale->signaling,(char*)buffer,sizeof(buffer),0);
   			cout<< " ** Porto occupato"<<endl;
			closedFlowErr((*(unsigned int*)ptrFlowId),idcanale->signaling);

            }
			#ifdef LINUX_OS
      		//pulisceMem();
		    #endif
			exit(1);
			#ifdef WIN32
			//TerminateThread(hThr[k],0);    //uccide il thread con handle hThr[k]
			#endif
			#ifdef LINUX_OS
			//pthread_cancel(hThr[k]);
			#endif
   }
 }//end-while
}



int ricercaThrHandle(int signaling){
	int i=0;
	while ((hThrGestore[i].signaling!=signaling) && (i<MaxNumThread))
		i++;
	return i;
}

/*#ifdef LINUX_OS
void generate_key(){
	RSA *RSAreceiver;
	FILE *keyReceiver1;
	FILE *keyReceiver2;
	keyReceiver1=fopen("KeyReceiverPubblica","w");
	keyReceiver2=fopen("KeyReceiverPrivata","w");
	RSAreceiver=RSA_generate_key(1024,17,0,0);
	//printf("sizeof key %d \n", RSA_size(RSAreceiver));
	PEM_write_RSAPublicKey(keyReceiver1,RSAreceiver);
	PEM_write_RSAPrivateKey(keyReceiver2,RSAreceiver,0,0,0,0,0);
	fclose(keyReceiver1);
	fclose(keyReceiver2);

	RSA *RSAsender;
	FILE *KeySender1;
	FILE *KeySender2;
	KeySender1=fopen("KeySenderPubblica","w");
	KeySender2=fopen("KeySenderPrivata","w");
	RSAsender=RSA_generate_key(1024,17,0,0);
	//printf("sizeof key %d \n", RSA_size(RSAsender));
	PEM_write_RSAPublicKey(KeySender1,RSAsender);
	PEM_write_RSAPrivateKey(KeySender2,RSAsender,0,0,0,0,0);
	//cout<<"fine generazione"<<endl;
	fclose(KeySender1);
	fclose(KeySender2);
}

int autenticazione(int signaling){
	char * next;
	int size;
	BYTE type=10;
	unsigned char Messaggio[256];
	unsigned char MessaggioCodificato[256];
	unsigned char MessaggioCodificato2[256];
	unsigned char MessaggioOriginale[]="fantozzi alla riscossa";
	unsigned char MessaggioOriginale2[256];
	unsigned char buffer[3000];
	generate_key();
	int plen=sizeof(MessaggioOriginale)-1;
	RSA*RSAreceiver;
	FILE *keyReceiver;
	keyReceiver=fopen("KeyReceiverPubblica","r");
	PEM_read_RSAPublicKey(keyReceiver,&RSAreceiver,0,0);
	fclose(keyReceiver);

	//printf("Messaggio Originale: %s \n",MessaggioOriginale);
	size=RSA_public_encrypt( plen, MessaggioOriginale, MessaggioCodificato, RSAreceiver,RSA_PKCS1_PADDING);  		//decodifica con la chiave privata!
	cout<<"Esito della RSA_pubblic_encrypt :"<<size<<endl;

	//printf("Messaggio Codificato: %s \n",MessaggioCodificato);
	next=putValue(&Messaggio,(void*)&type,sizeof(type));
  	next=putValue(next,(void*)&MessaggioCodificato,sizeof(MessaggioCodificato));
	size=send(signaling,(char*)&Messaggio,129,0);


	size=recv(signaling,(char*)&type,sizeof(type),0);
	size=recv(signaling,(char*)&MessaggioCodificato2,sizeof(MessaggioCodificato2),0);
	//printf("Messaggio Ritornato: %s \n",MessaggioCodificato2);

	RSA*RSAsender;
	FILE *keysender;
	keysender=fopen("KeySenderPrivata","r");
	PEM_read_RSAPrivateKey(keysender,&RSAsender,0,0);
	fclose(keysender);
	size=RSA_private_decrypt( size, MessaggioCodificato2, MessaggioOriginale2, RSAsender,  RSA_PKCS1_PADDING);
	cout<<"Esito della RSA_private decrypt :"<<size<<endl;

	//decodifica con la chiave privata!
	//printf("Messaggio Decodificato: %s \n",MessaggioOriginale2);
	if (strcmp((const char*)MessaggioOriginale,(const char*)MessaggioOriginale2)==0)
	 	return 0;
		else return 1;
}

#endif
*/
/*******************************************************************************
*********************************Packets sender function owdn*******************
*******************************************************************************/
void send_packowdm(int &ScriptMode, unsigned int DSByte,
	unsigned long &Duration, uid_t user_id,int icmptype, TAppProto AppProtocol,
	int logvar, int FlowId,char *LogFile, struct timeval timeout,
	struct sockaddr_in DestHost, int &logremoto,char* ProtoTx_Log,
	char *upProtocol,char protocolName[30],int TTL, char NameMsr[30],SumRandom *IntArriv,
	SumRandom *PktSize,TDistro IntArrivDistro,TDistro PktSizeDistro){
  int signaling;
  unsigned char payload[MaxPayloadSize];
  int count;
  //struct sockaddr_in SockAddress;
  struct sockaddr_in SrcHost;
  int socktype;
  int prototype=0;
  unsigned int SeqNum = 1;
  struct TTicker Ticker;
  struct timeval start_time, end_time;
  struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
  Real wait;
  int size;
  long int time;
  unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
  unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
  unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
  unsigned char *ptrSize;
  icmppkt pkt;


  #ifdef WIN32
  LARGE_INTEGER _tstart,_tend,_tprec;
  unsigned long secondi=0,microsecondi=0;
  int first=1;
  int first_update=1;
  int pid;

   #endif

  if (!(strcasecmp(protocolName,"UDP"))){
    socktype=SOCK_DGRAM;
  }
  else if (!(strcasecmp(protocolName,"ICMP"))){
    socktype=SOCK_RAW;
    prototype=IPPROTO_ICMP;
    }
  else socktype=SOCK_STREAM;

  // Create the socket
  int sock = socket(PF_INET, socktype , prototype);
  if (sock < 0) {
    cerr << endl << "** ERROR **  Flow " << FlowId << " aborted : Cannot create a socket" << endl;
          #ifdef LINUX_OS
      	pulisceMem();
      #endif

    exit(1);
  }

  // Set DS byte if nonzero
  #ifdef LINUX_OS
  if ( DSByte && setsockopt(sock, SOL_IP, IP_TOS, &DSByte, sizeof(DSByte)) < 0 )
		cerr << "** WARNING **  Flow " << FlowId << " : Cannot set DS byte to " << DSByte << endl;
  #endif
  





  // blocca la memoria condivisa
  #ifdef LINUX_OS
 /* if ((mlockall(MCL_CURRENT|MCL_FUTURE)<0) && (user_id==0))
        cout<<"Memory lock failed"<<endl;*/
  #endif

  #ifdef LINUX_OS
  if ( TTL>0 && setsockopt(sock, SOL_IP, IP_TTL, &TTL, sizeof(TTL)) < 0 )
		cerr << "** WARNING **  Flow " << FlowId << " : Cannot set TTL to " << TTL << endl;
  #endif
  
  #ifdef WIN32
  if ( TTL>0 && setsockopt(sock, IPPROTO_IP, IP_TTL, (char*)&TTL, sizeof(TTL)) < 0 )
		cerr << "** WARNING **  Flow " << FlowId << " : Cannot set TTL to " << TTL << endl;
  #endif
   
  // Disabilita l'algoritmo di Nagle
  if ((!(AppProtocol==apTelnet)&&(!(AppProtocol==apDNS)))&&(socktype==SOCK_STREAM))
  {
	//printf("Nagle algorithm disabled\n");
	#ifdef LINUX_OS
	int no_delay=1;
	if (setsockopt(sock, getprotobyname("TCP")->p_proto, TCP_NODELAY, &no_delay, sizeof(no_delay))<0)
		cerr << "** WARNING **  : Cannot disable Nagle Algorithm" << endl;
	#endif

	#ifdef WIN32
	char *no_delayWin;
	no_delayWin="1";
	if (setsockopt(sock, getprotobyname("TCP")->p_proto, TCP_NODELAY, no_delayWin, sizeof(no_delayWin))<0)
		cerr << "** WARNING **  : Cannot disable Nagle Algorithm" << endl;
	#endif
  }


  #ifdef LINUX_OS
  pthread_mutex_lock (&mutex);		// blocca sul semaforo
  #endif
  #ifdef WIN32
  WaitForSingleObject(hMutex, INFINITE);
  #endif

 //aggiorna la struttura parasignaling che ha memoria dei flussi creati
  while ((parasignaling[l].FlowId!=-1) && (l<MaxNumThread)) {
	 l++;
  }

  #ifdef WIN32
  hEvent[l]=CreateEvent(NULL,FALSE,FALSE,NULL);
  #endif
 
  
   //crea log locale o remoto
  if ((logvar) && (primoThread==1)){
	  primoThread=0;
	  if (!logremoto){
		  out.open(LogFile,ios::out |ios::binary|ios::trunc);
		  if (!out){
		  cerr << "** WARNING **  Cannot create '" << LogFile << "' for writing" << endl;
		  logvar = 0;
		  } //end if logfile<0
		} //end ! logout
		else createRemotLogFile(LogHost,ProtoTx_Log);
  }

  
  // crea canale per fare signaling con il ricevitore;
  //se il canale di signaling non esiste ..
  if (checkDestHostIP(signaling,DestHost)==false){
	  createCanalTrasport(signaling,DestHost);
	  createCanalSignaling(signaling,DestHost);  //fa una connect (livello 7)
       /* #ifdef LINUX_OS
	  if (autenticazione(signaling)==1){    //autenticazione non andata a buon fine
		Sendtype(signaling,14);
		#ifdef LINUX_OS
      		pulisceMem();
      		#endif
		exit(1);
	  }
	  #endif*/

	  if (LogServer==1)
          #ifdef WIN32
	  sendLog(signaling,serverLogReceiver.sin_port,
	  	serverLogReceiver.sin_addr.S_un.S_addr,
	  	INVconverti(ProtoTx_ServerLogReceiver),
	  	LogFileServerLogReceiver);
	  #endif
      	  #ifdef LINUX_OS
	  sendLog(signaling,serverLogReceiver.sin_port,serverLogReceiver.sin_addr.s_addr,
	  	INVconverti(ProtoTx_ServerLogReceiver),
	  	LogFileServerLogReceiver);
	  #endif

	  int i=0;
	  //aggiorna la struttura che realizza la corrispondenza numeroflusslo-Idflusso-signaling
	  parasignaling[l].signaling=signaling;
 	  parasignaling[l].FlowId=FlowId;

	  //aggiorna la struttura canSig che ha memoria dei canali di signaling creati
	  while (canSign[i].socket!=-1){
		 i++;
	  }
	  canSign[i].DestAddr.sin_addr.s_addr=DestHost.sin_addr.s_addr;
	  canSign[i].numThreadSu=1;
	  canSign[i].socket=signaling;

	  //printf("canale di signaling appena creato %d \n",signaling);
          HELPpara[numcanalisignaling+1].signaling=signaling;
	  #ifdef LINUX_OS
	  pthread_create(&hThrGestore[numcanalisignaling].hand,NULL,createThreadGestore,&HELPpara[numcanalisignaling+1]);
	  #endif
	  #ifdef WIN32
	  hThrGestore[numcanalisignaling].hand=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)createThreadGestore,&HELPpara[numcanalisignaling+1],(DWORD)NULL,(unsigned long*)&pid);
          #endif
	  hThrGestore[numcanalisignaling].signaling=signaling;
	  numcanalisignaling++; //incrementa il numero di canali di signaling
  }
  else {
  	 parasignaling[l].signaling=signaling;
 	 parasignaling[l].FlowId=FlowId;
  }

  #ifdef LINUX_OS
  pthread_mutex_unlock (&mutex);	// sblocca il semaforo
  #endif
  #ifdef WIN32
  ReleaseMutex(hMutex);
  #endif

  // Invia sul canale di signaling le informazioni relative al flusso che si vuole trasmettere
  sendFlowId(FlowId,signaling,DestHost,protocolName,upProtocol,0,NameMsr);
   

  if (connect(sock, (struct sockaddr *)&DestHost, sizeof(DestHost))<0) {
	  perror("");
	  cerr << "** WARNING **  Error into connect "<< endl;
  }

  #ifdef WIN32
  if ( DSByte && setsockopt(sock, IPPROTO_IP, IP_TOS, (char*)&DSByte, sizeof(DSByte)) < 0 )
		cerr << "** WARNING **  Flow " << FlowId << " : Cannot set DS byte to " << DSByte << endl;
  #endif

  size_t sizeAddr=sizeof(SrcHost);
  #ifdef LINUX_OS
  getsockname(sock, (struct sockaddr *)&SrcHost, &sizeAddr);
  #endif
  #ifdef WIN32
  getsockname(sock, (struct sockaddr *)&SrcHost, (int*)&sizeAddr);
  #endif

  if (!(strcasecmp(protocolName,"TCP")))
    	ptrSize = ptrTimeUsec + sizeof(int);

  count=0;
  int sockchk=0;
  cout << "Sending packets of flow " << FlowId << "..." << endl;
  Ticker.count = 0.0;
  memcpy(payload, &FlowId, sizeof(unsigned int) );

  //Get starting time
  #ifdef WIN32
  tstart(_tstart,secondi,microsecondi,first,NameMsr);
  gettimeofday(&start_time,_tend,_tstart,secondi,microsecondi,NameMsr);
  #endif

  #ifdef LINUX_OS
  gettimeofday(&start_time,NULL);
  #endif

  //Calculate ending time
  end_time.tv_sec = start_time.tv_sec + Duration / 1000 + (end_time.tv_usec = start_time.tv_usec + (Duration % 1000) * 1000) / 1000000;
  end_time.tv_usec %= 1000000;

  #ifdef WIN32
  gettimeofday(&Ticker.lastTime,_tend,_tstart,secondi,microsecondi,NameMsr);
  #endif

  #ifdef LINUX_OS
  gettimeofday(&Ticker.lastTime,NULL);
  #endif
  do {
  	  // send packet
     if (!(strcasecmp(protocolName,"TCP")))
      	((size=(int) PktSize->Next()) >= MaxPayloadSize) ? size=MaxPayloadSize : (size < (MinPayloadSize + sizeof(int))) ? size=(MinPayloadSize + sizeof(int)) : 1;
      else
	((size=(int) PktSize->Next()) >= MaxPayloadSize) ? size=MaxPayloadSize : (size < MinPayloadSize) ? size=MinPayloadSize : 1;
      time=Ticker.lastTime.tv_sec%86400L;
      memcpy( ptrSeqNum, &SeqNum, sizeof(unsigned int) );
      memcpy( ptrTimeSec, &(time), sizeof(long int) );
      memcpy( ptrTimeUsec, &(Ticker.lastTime.tv_usec), sizeof(long int) );

      if (!(strcasecmp(protocolName,"TCP")))
      	memcpy( ptrSize, &size, sizeof(int) );
      if (strcmp(protocolName,"ICMP")==0){
          pkt.icmp_buf.icmp_type=icmptype;
	  pkt.icmp_buf.icmp_code=0;
	  pkt.icmp_buf.icmp_cksum=0;
	  memcpy(&pkt.packet,payload,size);
	  pkt.icmp_buf.icmp_cksum=checksum((unsigned short *)&pkt,size+sizeof(icmp));
	  #ifdef LINUX_OS
	  sockchk=sendto(sock,&pkt,size+sizeof(icmp),0,(struct sockaddr*)&DestHost,sizeof(DestHost));
	  #endif
          #ifdef WIN32
	  sockchk=sendto(sock,(char*)&pkt,size+sizeof(icmp),0,(struct sockaddr*)&DestHost,sizeof(DestHost));
	  #endif
	  }
      else sockchk=send(sock, (char*)payload, size, 0);
      if (sockchk < 0)
        cerr << "** WARNING  **  Flow " << FlowId << " : Packet " << SeqNum << " not sent" << endl;
      else {
        if (logvar) {
  	      //Logging informations using an array of structs as memory buffer
      			infos[count].FlowId=*(unsigned int *)payload;
		        infos[count].SeqNum=*(unsigned int *)ptrSeqNum;
        		strcpy(infos[count].src_addr,inet_ntoa(SrcHost.sin_addr));
        		infos[count].src_port=ntohs(SrcHost.sin_port);
        		strcpy(infos[count].dest_addr,inet_ntoa(DestHost.sin_addr));
        		infos[count].dest_port=htons(DestHost.sin_port);
        		infos[count].TxTime1=time/3600;
        		infos[count].TxTime2=(time%3600)/60;
        		infos[count].TxTime3=time%60+Ticker.lastTime.tv_usec/1000000.0;
        		infos[count].RxTime1=time/3600;
        		infos[count].RxTime2=(time%3600)/60;
        		infos[count].RxTime3=time%60+Ticker.lastTime.tv_usec/1000000.0;
        		if (AppProtocol==apTelnet)
          			infos[count].size=size-20;
        		else
          		infos[count].size=size;

				/*int j=count;
				printf("%d\n",infos[j].FlowId);
				printf("%d\n",infos[j].SeqNum);
				printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
				printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
				printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
				printf("rxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
				printf("Size>%5u\n",infos[j].size);*/
				count++;

    			if (count==Dim) {
        		 if (!logremoto){
	 				#ifdef LINUX_OS
  					pthread_mutex_lock(&mutex_log);		// blocca sul semaforo
  					#endif
					#ifdef WIN32
  					WaitForSingleObject(mutex_log, INFINITE);
					#endif
					out.write((const char*)infos, Dim*sizeof(struct Info));
					#ifdef WIN32
					ReleaseMutex(mutex_log);
					#endif
					#ifdef LINUX_OS
 					pthread_mutex_unlock(&mutex_log);		// blocca sul semaforo
  					#endif
					count=0;
		         }
        	   	else {
         		 if (sendto(logsock,(char *) infos, Dim*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
           		 cerr << "** WARNING **  Flow " << FlowId << " : Packet " << SeqNum << " not sent" << endl;
         		 count=0;
			} //end if (logout)
		} //end count=Dim
	  } //end logvar
	} //end else


     // wait inter-arrive
     wait = IntArriv->Next();   // wait is expressed in msecs
     #ifdef LINUX_OS
     UpdateTicker(&Ticker);
     #endif
     #ifdef WIN32
     UpdateTicker(&Ticker,_tend,_tprec,_tstart,first_update);
     #endif
     if (wait <= Ticker.count)
        Ticker.count -= wait;
      else {
        while(wait > Ticker.count) {
          wait -= Ticker.count;
          Ticker.count = 0.0;
          timeout.tv_sec = (long) wait/1000;
          timeout.tv_usec = (long) (wait - (timeout.tv_sec*1000))*1000;
          select(1, NULL, NULL, NULL, &timeout);
	  #ifdef LINUX_OS
	  UpdateTicker(&Ticker);
	  #endif
	  #ifdef WIN32
	  UpdateTicker(&Ticker,_tend,_tprec,_tstart,first_update);
	  #endif
        }
        Ticker.count -= wait;
      }
     SeqNum++;
     #ifdef WIN32
     gettimeofday(&Ticker.lastTime,_tend,_tstart,secondi,microsecondi,NameMsr);
      #endif
  }while (Ticker.lastTime.tv_sec < end_time.tv_sec || (Ticker.lastTime.tv_sec == end_time.tv_sec && Ticker.lastTime.tv_usec < end_time.tv_usec));
  cout<<"Flow " << FlowId << ": Done!" << endl;
 #ifdef LINUX_OS
 pthread_mutex_lock(&mutex_closed);// blocca sul semaforo
 #endif
 #ifdef WIN32
 WaitForSingleObject(hMutex_closed, INFINITE);
 #endif

 // Invia sul canale di signaling l'informazione che il flusso con Id FlowId �terminato
 #ifdef LINUX_OS
 close(sock);
 #endif
 #ifdef WIN32
 closesocket(sock);
 #endif

 closedFlow(FlowId,signaling);

 // Swap to file elements that may remain into the buffer
 if (logvar) {
   if (count!=0)
	if (!logremoto){
 		#ifdef LINUX_OS
  			pthread_mutex_lock(&mutex_log);		// blocca sul semaforo
  			#endif
			#ifdef WIN32
  			WaitForSingleObject(mutex_log, INFINITE);
			#endif
			out.write((const char*)infos, count*sizeof(struct Info));
			#ifdef WIN32
			ReleaseMutex(mutex_log);
			#endif
			#ifdef LINUX_OS
 			pthread_mutex_unlock(&mutex_log);		// blocca sul semaforo
  			#endif
	}
 	else
   	  if (sendto(logsock,(char *) infos, count*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
		cout<<"Error into sendto"<<endl;
   }

 //controlla se e' possibie chiudere il canale di signaling verso il ricevitore

 if (checkClosedCanal(signaling,DestHost)==true){
	#ifdef LINUX_OS
        munlockall();
 	#endif
	cout<<"Finish! "<<endl;
	#ifdef WIN32
	TerminateThread(hThrGestore[ricercaThrHandle(signaling)].hand,0);
	#endif
	#ifdef LINUX_OS
	pthread_cancel(hThrGestore[ricercaThrHandle(signaling)].hand);
	#endif

	sendRelase(signaling);

	#ifdef LINUX_OS
	if (close(signaling)<0) cout<<"Error into close socket "<<endl;
  	#endif
	#ifdef WIN32
	if (closesocket(signaling)<0) cout<<"Error into close socket " <<endl;
	#endif
  }
  #ifdef LINUX_OS
  pthread_mutex_unlock (&mutex_closed);	// sblocca il semaforo
  #endif
  #ifdef WIN32
  ReleaseMutex(hMutex_closed);
  #endif

 // libera la memoria allocata
 free (infos);
 //sleep(1);
}// end send_packowdm




/*******************************************************************************
**************************Packets sender function rttm**************************
*******************************************************************************/
void send_packrttm(int &ScriptMode, unsigned int &DSByte,
	unsigned long &Duration, uid_t user_id, int icmptype, TAppProto AppProtocol,
	int logvar, int FlowId,char *LogFile, struct timeval timeout,
	struct sockaddr_in DestHost, int &logremoto,char* ProtoTx_Log,
	char upProtocol[30],char protocolName[30],int TTL, char NameMsr[30],
	SumRandom *IntArriv,SumRandom *PktSize, TDistro IntArrivDistro,
	TDistro PktSizeDistro, parametriThread* para){

	int signaling;

	struct sockaddr_in SrcHost;
	size_t sizeAddr = sizeof(SrcHost);
	int socktype;
	int prototype=0;
	unsigned int SeqNum = 1;
	struct TTicker Ticker;
	struct timeval start_time, end_time,RcvTime;
	struct Info *infos = (struct Info *) malloc (Dim * sizeof(Info));
	//salva l'indirizzo della struttura dove memorizza i dati

	indirizzoinfos=infos;
	countinfos=0;
	para->indirizzoinfos=infos;
	para->count=0;

	unsigned char buffer[MaxPayloadSize];
	unsigned char payload[MaxPayloadSize];
	unsigned char rpayload[MaxPayloadSize];
	fd_set read_set,active_set;
	Real wait;
	long int time;
	int size, terminate=0;
	int first_time=1;
	size_t offSeqNum = sizeof(unsigned int);
	size_t offTimeSec = offSeqNum + sizeof(unsigned int);
	size_t offTimeUsec = offTimeSec + sizeof(long int);
	size_t offSize;
	
	int size_r,size_p;
	long int time1,time2;
	
	#ifdef WIN32
	int pid;
	LARGE_INTEGER _tstart,_tend,_tprec;
	unsigned long secondi=0,microsecondi=0;
	int  first=1;
	int first_update=1;
	#endif
	

	if (!(strcasecmp(protocolName,"UDP"))){
		socktype=SOCK_DGRAM;
	} else if (!(strcasecmp(protocolName,"ICMP"))){
		socktype=SOCK_RAW;
		prototype=IPPROTO_RAW;
	} else socktype=SOCK_STREAM;
	
	// Create the socket
	int sock = socket(PF_INET, socktype , prototype);
	if (sock < 0) {
		cerr << endl << "** ERROR **  Flow " << FlowId 
			<< " aborted : Cannot create a socket" << endl;
#ifdef LINUX_OS
		pulisceMem();
#endif
		exit(1);
	}

	// Set DS byte if nonzero
#ifdef LINUX_OS
	if (DSByte && setsockopt(sock, SOL_IP, IP_TOS, &DSByte, sizeof(DSByte)) < 0)
		cerr << "** WARNING **  Flow " << FlowId
			<< " : Cannot set DS byte to " << DSByte << endl;
#endif

#ifdef LINUX_OS
	if ( TTL>0 && setsockopt(sock, SOL_IP, IP_TTL, &TTL, sizeof(TTL)) < 0 )
		cerr << "** WARNING **  Flow " << FlowId << " : Cannot set TTL to "
		<< TTL << endl;
#endif

  #ifdef WIN32
  if ( TTL>0 && setsockopt(sock, IPPROTO_IP, IP_TTL, (char*)&TTL, sizeof(TTL)) < 0 )
		cerr << "** WARNING **  Flow " << FlowId << " : Cannot set TTL to " << TTL << endl;
  #endif

#ifdef LINUX_OS
	/*if (mlockall(MCL_CURRENT|MCL_FUTURE)<0)
		 ReportErrorAndExit("General parser", "Memory lock failed",
							programName, FlowId);*/
#endif


#ifdef LINUX_OS
	pthread_mutex_lock (&mutex);		// blocca sul semaforo
#endif
#ifdef WIN32
	WaitForSingleObject(hMutex, INFINITE);
#endif
	
	//aggiorna la struttura parasignaling che ha memoria dei flussi creati
	while (parasignaling[l].FlowId!=-1){
		l++;
	}
	//ritorna la prima posizione libera

	
#ifdef WIN32
	hEvent[l]=CreateEvent(NULL,FALSE,FALSE,NULL);
#endif

	// log process setting
	if (!logvar)
		strcpy(LogFile,DefaultLogFile);
	logvar=1;
	if (primoThread==1) {
		primoThread=0;
		if (!logremoto){ //log locale
			out.open(LogFile,ios::out |ios::binary|ios::trunc);

			if (!out){
				cerr << "** WARNING **  Cannot create '" << LogFile
					<< "' for writing" << endl;
				logvar = 0;
			} //end if logfile<0
		 } else {
		 	createRemotLogFile(LogHost,ProtoTx_Log);
			}
	}

	// setup TSP signaling channel (if it does not already exists)
	if (checkDestHostIP(signaling,DestHost)==false){
		// TSP signaling setup
		createCanalTrasport(signaling,DestHost);
		createCanalSignaling(signaling,DestHost);
		/*#ifdef LINUX_OS
		if (autenticazione(signaling)==1){    //autenticazione non andata a buon fine
			Sendtype(signaling,16);
#ifdef LINUX_OS
			pulisceMem();
#endif
			exit(1);
	  	}
#endif */
		 if (LogServer==1)
          	#ifdef WIN32
	  	sendLog(signaling,serverLogReceiver.sin_port,
	  	serverLogReceiver.sin_addr.S_un.S_addr,
	  	INVconverti(ProtoTx_ServerLogReceiver),
	  	LogFileServerLogReceiver);
	  	#endif
      	  	#ifdef LINUX_OS
		  sendLog(signaling,serverLogReceiver.sin_port,serverLogReceiver.sin_addr.s_addr,
	  	INVconverti(ProtoTx_ServerLogReceiver),
	  	LogFileServerLogReceiver);
		  #endif

		int i=0;
		// update parasignaling struct
		// aggiorna la struttura che realizza la corrispondenza numeroflusslo-Idflusso-signaling
		parasignaling[l].signaling=signaling;
		parasignaling[l].FlowId=FlowId;

		// update canSign struct
		while (canSign[i].socket!=-1){
			i++;
		}
		canSign[i].DestAddr.sin_addr.s_addr=DestHost.sin_addr.s_addr;
		canSign[i].numThreadSu=1;
		canSign[i].socket=signaling;

		HELPpara[numcanalisignaling+1].signaling=signaling;
#ifdef LINUX_OS
		pthread_create(&hThrGestore[numcanalisignaling].hand,NULL,createThreadGestore,&HELPpara[numcanalisignaling+1]);
#endif
#ifdef WIN32
		hThrGestore[numcanalisignaling].hand=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)createThreadGestore,&HELPpara[numcanalisignaling+1],(DWORD)NULL,(unsigned long*)&pid);
#endif
		hThrGestore[numcanalisignaling].signaling=signaling;
		numcanalisignaling++; //incrementa il numero di canali di signaling
	} else {
		parasignaling[l].signaling=signaling;
		parasignaling[l].FlowId=FlowId;
	}

#ifdef LINUX_OS
	pthread_mutex_unlock (&mutex);	// sblocca il semaforo
#endif
#ifdef WIN32
	ReleaseMutex(hMutex);
#endif

	// Send on the signaling channel the generating flow description
	sendFlowId(FlowId,signaling,DestHost,protocolName,upProtocol,0,NameMsr);

	// Attende ACK da parte del ricevitore.. il ricevitore ha ricevuto il messaggio
	//recvAck(FlowId,signaling);

	if (connect(sock, (struct sockaddr *)&DestHost, sizeof(DestHost))<0)
		cerr << "** WARNING **  Error into connect "<< endl;

	#ifdef WIN32
  if ( DSByte && setsockopt(sock, IPPROTO_IP, IP_TOS, (char*)&DSByte, sizeof(DSByte)) < 0 )
		cerr << "** WARNING **  Flow " << FlowId << " : Cannot set DS byte to " << DSByte << endl;
  #endif

#ifdef LINUX_OS
	getsockname(sock, (struct sockaddr *)&SrcHost, &sizeAddr);
#endif

#ifdef WIN32
	getsockname(sock, (struct sockaddr *)&SrcHost, (int*)&sizeAddr);
#endif
	char DestAddr[30];
	strcpy(DestAddr, inet_ntoa(DestHost.sin_addr));
	connect(sock, (struct sockaddr *)&DestHost, sizeof(DestHost));
	if (!(strcasecmp(protocolName,"TCP")))
		offSize = offTimeUsec + sizeof(int);

	memcpy(payload, &FlowId, sizeof(unsigned int));

	cout << "Sending packets of flow " << FlowId << "..." << endl;
	Ticker.count = 0.0;

	// Get starting time
#ifdef WIN32
	tstart(_tstart,secondi,microsecondi,first,NameMsr);
	gettimeofday(&start_time,_tend,_tstart,secondi,microsecondi,NameMsr);
#endif

#ifdef LINUX_OS
	gettimeofday(&start_time,NULL);
#endif

	// Calculate ending time
	end_time.tv_sec = start_time.tv_sec + Duration / 1000 + (end_time.tv_usec = start_time.tv_usec + (Duration % 1000) * 1000) / 1000000;
	end_time.tv_usec %= 1000000;

#ifdef WIN32
	gettimeofday(&Ticker.lastTime,_tend,_tstart,secondi,microsecondi,NameMsr);
#endif

#ifdef LINUX_OS
	gettimeofday(&Ticker.lastTime,NULL);
#endif

	start_time.tv_sec=0;
	start_time.tv_usec=0;

	FD_ZERO(&active_set);
	FD_SET(sock,&active_set);
	// send packet
	while (!terminate) {
		if (!(strcasecmp(protocolName,"TCP")))
			((size=(unsigned int) PktSize->Next()) >= MaxPayloadSize) ?
			size=MaxPayloadSize :
			(size < (MinPayloadSize + sizeof(int))) ?
			size=(MinPayloadSize + sizeof(int)) : 1;
		else
			((size=(unsigned int) PktSize->Next()) >= MaxPayloadSize) ?
			size=MaxPayloadSize : (size < MinPayloadSize) ?
			size=MinPayloadSize : 1;
		memcpy( payload+offSeqNum, &SeqNum, sizeof(unsigned int) );
		time=(Ticker.lastTime.tv_sec%86400L);
		memcpy( payload+offTimeSec, &(time), sizeof(long int) );
		memcpy( payload+offTimeUsec, &(Ticker.lastTime.tv_usec),
		sizeof(long int) );
		if (!(strcasecmp(protocolName,"TCP")))
			memcpy( payload+offSize, &size, sizeof(int) );
		if (send(sock, (char*)payload, size, 0) < 0)
			cerr << "** WARNING **  Flow " << FlowId << " : Packet "<< SeqNum << " not sent" << endl;
		read_set=active_set;
		if (select(FD_SETSIZE,&read_set,NULL,NULL,&start_time)<0) {
	   		cerr<<endl<<"** ERROR ** : Invalid file descriptor or operation interruped by a signal"<<endl;
#ifdef LINUX_OS
			pulisceMem();
#endif
	   		exit(1);
		}
		if (FD_ISSET(sock, &read_set)) {
#ifdef WIN32
			gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi,NameMsr);
#endif
#ifdef LINUX_OS
			gettimeofday(&RcvTime,NULL);

#endif
			if (!(strcasecmp(protocolName,"TCP"))){
				size_r = recv(sock, (char*)rpayload, 20, 0);
				if (size_r < 20){
			   		recv(sock, (char*)buffer, 20 - size_r, 0);
			   		memcpy( payload, &buffer, sizeof(buffer) );
			 	}
				size = *(int *)(rpayload + offSize);
				size_p = recv(sock, (char*)buffer, (size - 20), 0);
				if (size_p < (size - 20) )
			 		recv(sock,(char*)buffer, ((size - 20) - size_p), 0);
	  		} else size_r = recv(sock, (char*)rpayload, MaxPayloadSize, 0);
	  		time1 = (*(long int *)(rpayload+offTimeSec));
	  		time2 = RcvTime.tv_sec%86400L;
			//Logging informations using an array of structs as memory buffer
			if (size_r>0 && logvar) {
				if (para->count<Dim) {
					infos[para->count].FlowId = *(unsigned int *)rpayload;
					infos[para->count].SeqNum = *(unsigned int *)(rpayload+offSeqNum);
					strcpy(infos[para->count].src_addr,inet_ntoa(SrcHost.sin_addr));
					infos[para->count].src_port=ntohs(SrcHost.sin_port);
					strcpy(infos[para->count].dest_addr,inet_ntoa(DestHost.sin_addr));
					infos[para->count].dest_port=htons(DestHost.sin_port);
					infos[para->count].TxTime1=time1/3600;
					infos[para->count].TxTime2=(time1%3600)/60;
					infos[para->count].TxTime3=time1%60+(*(long int *)(rpayload+offTimeUsec))/1000000.0;
					infos[para->count].RxTime1=time2/3600;
					infos[para->count].RxTime2=(time2%3600)/60;
					infos[para->count].RxTime3=time2%60+RcvTime.tv_usec/1000000.0;
					infos[para->count].size=size;

	/*	int j=para->count;
		printf("%d\n",infos[j].FlowId);
		printf("%d\n",infos[j].SeqNum);
		printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
		printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
		printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
		printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
		printf("Size>%5u\n",infos[j].size);*/

					para->count++;
					countinfos++;
				}
	 			if (para->count==Dim) {
					if (!logremoto){
#ifdef LINUX_OS
						pthread_mutex_lock(&mutex_log); // blocca sul semaforo
#endif
#ifdef WIN32
						WaitForSingleObject(mutex_log, INFINITE);
#endif
						out.write((const char*)infos, Dim*sizeof(struct Info));
#ifdef WIN32
						ReleaseMutex(mutex_log);
#endif
#ifdef LINUX_OS
						pthread_mutex_unlock(&mutex_log); // blocca sul semaforo
#endif
						para->count=0;
						countinfos=0;
					} else {
		 				if (sendto(logsock,(char *) infos,
							Dim*sizeof(struct Info),0,
							(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)

							cerr << "** WARNING **  Flow " << FlowId <<
								" : Packet " << SeqNum << " not sent" << endl;

						para->count=0;
		 			}
	 			}
			}
	}
		wait = IntArriv->Next();   // wait is expressed in msecs
#ifdef LINUX_OS
		UpdateTicker(&Ticker);
#endif
#ifdef WIN32
		UpdateTicker(&Ticker,_tend,_tprec,_tstart,first_update);
#endif
		if (wait <= Ticker.count) {
			Ticker.count -= wait;
		} else {
			while(wait > Ticker.count) {
				wait -= Ticker.count;
				Ticker.count = 0.0;
				timeout.tv_sec = (long) wait/1000;
				timeout.tv_usec = (long) (wait - (timeout.tv_sec*1000))*1000;
				select(1, NULL, NULL, NULL, &timeout);
#ifdef LINUX_OS
				UpdateTicker(&Ticker);
#endif
#ifdef WIN32
				UpdateTicker(&Ticker,_tend,_tprec,_tstart,first_update);
#endif
			}
			Ticker.count -= wait;
		} //end else
#ifdef WIN32
		gettimeofday(&Ticker.lastTime,_tend,_tstart,secondi,microsecondi,NameMsr);
#endif
	SeqNum++;
	terminate = (Ticker.lastTime.tv_sec > end_time.tv_sec ||
				(Ticker.lastTime.tv_sec == end_time.tv_sec &&
					Ticker.lastTime.tv_usec >= end_time.tv_usec));;
	} //end while
			bool flag = true;
			while(flag) {
				start_time.tv_sec = 15;
				read_set=active_set;
				//cout << "packet \n";
				if (select(FD_SETSIZE,&read_set,NULL,NULL,&start_time)<0){
					perror("send_packorttm");
					flag = true;
				} else {
					if (FD_ISSET(sock, &read_set)) {
#ifdef WIN32
					gettimeofday(&RcvTime,_tend,_tstart,secondi,microsecondi,NameMsr);
#endif
#ifdef LINUX_OS
					gettimeofday(&RcvTime,NULL);


#endif

					if (!(strcasecmp(protocolName,"TCP"))){
							size_r = recv(sock, (char*)rpayload, 20, 0);
							if (size_r < 20){
			   					recv(sock, (char*)buffer, 20 - size_r, 0);
			   					memcpy( payload, &buffer, sizeof(buffer) );
			 				}
							size = *(int *)(rpayload + offSize);
							size_p = recv(sock, (char*)buffer, (size - 20), 0);
							if (size_p < (size - 20) )
			 					recv(sock,(char*)buffer, ((size - 20) - size_p), 0);
							} else size_r = recv(sock, (char*)rpayload,
								MaxPayloadSize, 0);
							time1 = (*(long int *)(rpayload+offTimeSec));
							time2 = RcvTime.tv_sec%86400L;
							//Logging informations using an array of structs as memory buffer
							if (size_r>0 && logvar) {
								if (para->count<Dim) {
									infos[para->count].FlowId = *(unsigned int *)rpayload;
									infos[para->count].SeqNum = *(unsigned int *)(rpayload+offSeqNum);
									strcpy(infos[para->count].src_addr,inet_ntoa(SrcHost.sin_addr));
									infos[para->count].src_port=ntohs(SrcHost.sin_port);
									strcpy(infos[para->count].dest_addr,inet_ntoa(DestHost.sin_addr));
									infos[para->count].dest_port=htons(DestHost.sin_port);
									infos[para->count].TxTime1=time1/3600;
									infos[para->count].TxTime2=(time1%3600)/60;
									infos[para->count].TxTime3=time1%60+(*(long int *)(rpayload+offTimeUsec))/1000000.0;
									infos[para->count].RxTime1=time2/3600;
									infos[para->count].RxTime2=(time2%3600)/60;
									infos[para->count].RxTime3=time2%60+RcvTime.tv_usec/1000000.0;
									infos[para->count].size=size;

	/*	int j=para->count;
		printf("%d\n",infos[j].FlowId);
		printf("%d\n",infos[j].SeqNum);
		printf("Src>%16s/%hu  ",infos[j].src_addr,infos[j].src_port);
		printf("Dest>%16s/%hu  ",infos[j].dest_addr,infos[j].dest_port);
		printf("TxTime>%u:%u:%lf ",infos[j].TxTime1,infos[j].TxTime2,infos[j].TxTime3);
		printf("RxTime>%u:%u:%lf ",infos[j].RxTime1,infos[j].RxTime2,infos[j].RxTime3);
		printf("Size>%5u\n",infos[j].size);*/


									para->count++;
									countinfos++;
								}
								if (para->count==Dim) {
									if (!logremoto){
#ifdef LINUX_OS
										pthread_mutex_lock(&mutex_log); // blocca sul semaforo
#endif
#ifdef WIN32
										WaitForSingleObject(mutex_log, INFINITE);
#endif
										out.write((const char*)infos, Dim*sizeof(struct Info));
#ifdef WIN32
										ReleaseMutex(mutex_log);
#endif
#ifdef LINUX_OS
										pthread_mutex_unlock(&mutex_log); // blocca sul semaforo
#endif
										para->count=0;
										countinfos=0;
									} else {
										if (sendto(logsock,(char *) infos, 
											Dim*sizeof(struct Info),0,
											(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
											
											cerr << "** WARNING **  Flow " << FlowId <<
												" : Packet " << SeqNum << " not sent" << endl;

										para->count=0;
									}
								}
							}
						} else {
							flag = false;
						}
					}
				}
				close(sock);
				cout<<"Flow"<<FlowId<<": Done!"<<endl;
				closedFlow(FlowId,signaling);

 // Swap to file elements that may remain into the buffer
 if (logvar) {
   if (para->count!=0)
	if (!logremoto){
 		#ifdef LINUX_OS
  			pthread_mutex_lock(&mutex_log);		// blocca sul semaforo
  			#endif
			#ifdef WIN32
  			WaitForSingleObject(mutex_log, INFINITE);
			#endif
			out.write((const char*)infos, para->count*sizeof(struct Info));
			#ifdef WIN32
			ReleaseMutex(mutex_log);
			#endif
			#ifdef LINUX_OS
 			pthread_mutex_unlock(&mutex_log);		// blocca sul semaforo
  			#endif
	}
 	else
   	  if (sendto(logsock,(char *) infos, para->count*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
		cout<<"Error into sendto"<<endl;
   }

#ifdef LINUX_OS
			munlockall();
			//msgctl(id_msg,IPC_RMID,0);
#endif
	
			//recvAck(FlowId,signaling);
			first_time=0;
			if (checkClosedCanal(signaling,DestHost)==true){
				cout<<"Finish! "<<endl;
#ifdef WIN32
				TerminateThread(hThrGestore[ricercaThrHandle(signaling)].hand,0);
#endif
#ifdef LINUX_OS
				pthread_cancel(hThrGestore[ricercaThrHandle(signaling)].hand);
#endif
				sendRelase(signaling);
				//recvAckRelase(signaling);
				close(signaling);
		}

}// end send_packrttm

#ifdef LINUX_OS
void TerminatePulito(int sig) {
	pulisceMem();
	exit(1);
}
#endif
	
// gestione dell'interruzione legata alla pressione dei tasti CNTRL+C
void Terminate(int sig) {
 if (ServerSender==0) saveBufferBeforeClose(indirizzoinfos, countinfos);
 //saveBufferBeforeClose(indirizzoinfos, countinfos);
 if (logremoto){
    Signaling signaling_log;		 //per la gestione del canale di signaling con il log remoto
    signaling_log.stop=true;
    sendto(logsocksignaling, (char*)&signaling_log, sizeof(signaling_log),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
    #ifdef WIN32
    if (closesocket(logsock)<0) cout<<"error into close "<<endl;
    if (closesocket(logsocksignaling)<0) cout<<"error into close "<<endl;
    #endif
    #ifdef LINUX_OS
    if (close(logsock)<0) cout<<"error into close "<<endl;
    if (close(logsocksignaling)<0) cout<<"error into close "<<endl;
    #endif
 }
 else {
  out.close();
 }
 exit(1);
 #ifdef WIN32
 WSACleanup();
 ExitProcess(0);
 #endif
}


// Telnet_parser
void telnetParser(SumRandom **pIntArriv,SumRandom **pPktSize,TDistro &IntArrivDistro,TDistro &PktSizeDistro)
{
  int numval=15;
  Real prob[] = {0.65,0.13,0.07,0.05,0.03,0.01,0.01,0.01,0.01,0.005,0.005,0.005,0.005,0.005,0.005};
  // Set inter-arrival time (msecs)
  ParetoRV = new Pareto(0.95);
  IntArrivDistro = pdPareto;
  delete (*pIntArriv);
  *pIntArriv = new SumRandom( 1.1 * (*ParetoRV) );
  // Set the default packet size (bytes)
  PktSizeDistro = pdTelnet;
  delete (*pPktSize);
  static DiscreteGen D(numval,prob);
  *pPktSize = new SumRandom(D+21);
} // End Telnet_parser


// VoIP_parser
void voIPParser(int h,char *argv[], int &argc, unsigned int FlowId,SumRandom **pIntArriv,SumRandom **pPktSize,TDistro &IntArrivDistro,TDistro &PktSizeDistro){
  char codec[10];
  //Default definition
  strcpy(codec,"G.711.1");
  Real samples=1.0;
  Real framesize=80.0;
  Real VAD=1.0;
  Real header=8.0;
  Real pkts=100.0;
  argv++;
  argc--;
  while (argc>0) {
    if (argv[h][0] == '-') {
      char *tail;
      switch (argv[h][1]) {
        case 'x':
          if (argc<2)
            ReportErrorAndExit("VoIP parser", "Invalid Codec Type", programName, FlowId);
          if (strcmp(argv[h+1],"G.711.1")==0){
              strcpy(codec,"G.711");
              framesize=80.0;
              samples=1.0;
              pkts=100.0;
          }
          else if (strcmp(argv[h+1],"G.711.2")==0){
              strcpy(codec,"G.711");
              framesize=80.0;
              samples=2.0;
              pkts=50.0;
          }
          else if (strcmp(argv[h+1],"G.729.2")==0){
              strcpy(codec,"G.729");
              framesize=10.0;
              samples=2.0;
              pkts=50.0;
              }
          else if (strcmp(argv[h+1],"G.729.3")==0){
              strcpy(codec,"G.729");
              framesize=10.0;
              samples=3.0;
              pkts=33.0;
              }
          else if (strcmp(argv[h+1],"G.723.1")==0){
              strcpy(codec,argv[h+1]);
              framesize=30.0;
              samples=1.0;
              pkts=26.0;
              }
	   else
	   	ReportErrorAndExit("VoIP parser", "Invalid Codec Type", programName, FlowId);
          //argv+=2;
		  h+=2;
          argc-=2;
          break;
        case 'h':
          if (argc<2)
            ReportErrorAndExit("VoIP parser", "Invalid Protocol Type", programName, FlowId);
          if (strcmp(argv[h+1],"RTP")==0)
              header=8.0;
          else if (strcmp(argv[h+1],"CRTP")==0)
              header=2;
	  else
	  	ReportErrorAndExit("VoIP parser", "Invalid Protocol Type (RTP or CRTP)", programName,FlowId);
          h+=2;
          argc-=2;
          break;
        case 'i':
          if (argc<2)
            ReportErrorAndExit("VoIP parser", "Invalid Option (VAD)", programName, FlowId);
          if (strcmp(argv[h+1],"VAD")==0)
              VAD=0.65;
	  else
	  	ReportErrorAndExit("VoIP parser", "Invalid Option (VAD)", programName, FlowId );
          h+=2;
          argc-=2;
          break;
        default:
         tail = (char *)malloc(sizeof("Unknown option ")+sizeof(argv[0]));
         ReportErrorAndExit("VoIP parser",
			strcat(strcpy(tail, "Unknown option "), argv[0]), 
			programName, FlowId);
         break;
          }
        }
    else {
        char temp[sizeof("What is  ?")+sizeof(argv[h])];
        ReportErrorAndExit("VoIP parser", 
			strcat(strcat(strcpy(temp, "What is "), argv[0]), " ?"),
			programName, FlowId);
    }
   }
   delete (*pPktSize);
   PktSizeDistro = pdConstant;
   ConstantRV = new Constant(1);
   *pPktSize = new SumRandom( (VAD * framesize * samples) * (*ConstantRV) + header);
   delete (*pIntArriv);
   IntArrivDistro = pdConstant;
   ConstantRV = new Constant(1);
   *pIntArriv = new SumRandom( 1000.0 / pkts * (*ConstantRV) );
   printf("Voice Codec: %s\t\nFramesize: %4.2f\t\nSamples: %4.0f\t\nPackets per sec.: %4.0f\t\n",codec,framesize,samples,pkts);
   if (VAD==1)
     printf("VAD: No\n");
   else
     printf("VAD: Si\n");
} // End VoIP_parser


// DNS Parser
void dnsParser(SumRandom **pIntArriv,SumRandom **pPktSize,TDistro &IntArrivDistro,TDistro &PktSizeDistro)
{
 // Set inter-arrival time (msecs)
  delete (*pIntArriv);
  IntArrivDistro = pdConstant;
  ConstantRV = new Constant(1);
  *pIntArriv = new SumRandom( 1000.0 / 0.56  * (*ConstantRV) );

  //Set packet size (bytes)
  delete (*pPktSize);
  PktSizeDistro = pdUniform;
  UniformRV = new Uniform;
  *pPktSize = new SumRandom( 220.0 * (*UniformRV) + 100.0 );
}



void printHelpAndExit() {
  cout << " Name " << endl;
  cout << "	 ITGSend -  sender componet of D-ITG platform" << endl << endl;
  cout << " Synopsis"<<endl;
  cout << "   - In case of using a script file:" << endl;
  cout << "   ./ITGSend <script_file> [[-l <logfile>] | [-l <logfile> -L <log_server_addr>"<<endl;
  cout << "	   <protocol_type>]] [-Z <log_server_addr> <protocol_type> <receiver_logfile>]"<<endl <<endl;
  cout << "   - If you want to remotely control the sender, launch it in daemon mode:" <<endl;
  cout << "   ./ITGSend -Q [[-l <logfile>] | [ -l <logfile> -L <log_server_addr> "<<endl;
  cout << "    <protocol_type>]] [-Z <log_server_addr> <protocol_type> <receiver_logfile>]" <<endl<<endl;
  cout << "   - Otherwise:" << endl;
  cout << "   ./ITGSend [-m <msr_type>] [-a <destination_address>] [-p <destination_port>]"<<endl;
  cout << "	   [-b <DS byte>] [[-l <logfile>] | [-l <logfile> -L <log_server_addr>" <<endl;
  cout << "	   <protocol _type>]] [-Z <log_server_addr> <protocol_type> "<<endl;
  cout << "	   <receiver_logfile>] [-t <duration>] [-T <protocol_type>] [-s <seed>]"<<endl;
  cout << "	   [-f <TTL>] [-d <gen_delay>] "<<endl;
  cout << "	   [[ -C <pkts_per_sec> | -U <min_pkts_per_sec max_pkts_per_sec> | "<<endl;
  cout << "	   -E <average_pkts_per_sec> | -V <shape scale> | -Y <shape scale> |"<<endl;
  cout << "	   -N <mean std_dev> | -O <average_pkts_per_sec> | -G <shape scale>] "<<endl;
  cout << "	   [ -u <min_pkt_size max_pkt_size> | -e <average_pkt_size> |"<<endl;
  cout << "	   -v <shape scale> | -y <shape scale> | -n <mean std_dev> |  "<<endl;
  cout << "	   -o <average_pkt_size> | -g <shape scale> | -c <pkt_size> ]] | "<<endl;
  cout << "	   [[Telnet]|[DNS]|[[VoIP] [-x <codec_type>] [-h <protocol_type> "<<endl;
  cout << "	   -i <Voice_Activity_Detection>]]]"<<endl;
  cout <<endl<< " Options" << endl << endl;
  cout << "  -m <msr_type>\t\t\t\ttype of meter.\n\t\t\t\t\tValues: owdm (one way delay meter)\n\t\t\t\t\t\trttm (round trip time meter)\n\t\t\t\t\t\t(Default: owdm)" << endl;
  cout << "  -a <destination_address>\t\t\t(Default: " << DefaultDestIP << ")" << endl;
  cout << "  -p <destination_port>\t\t\t\t(Default: " << DefaultPort << ") " << endl;
  cout << "  -s <seed>\t\t\t\t\tseed (Default: Random)" << endl;
  cout << "  -t <duration>\t\t\t\t\tgeneration duration\n\t\t\t\t\t\t(Default: " << DefaultDuration << " msecs)" << endl;
  cout << "  -d <generation_delay>\t\t\t\t(Default: " << DefaultDelay << " msecs)" << endl;
  cout << "  -l <logfile>\t\t\t\t\tGenerate log file\n\t\t\t\t\t(Default: " << DefaultLogFile << " only for rttm)\n" << endl;
  cout << "  -L <log_server_address> <protocol_type> \tRemote Log \n\t\t\t\t\t(Default: <" <<DefaultLogIP<<"> <"<<DefaultLogPort<<"> <"<<DefaultProtoTx_Log<<">"<< "\n\t\t\t" << endl;;
  cout << "  -Z <log_server_address> <protocol_type> <receiver_logfile>Receiver Remote Log \n\t\t\t\t\t(Default: <" <<DefaultLogIP<<"> <"<<DefaultLogPort<<"> <"<<DefaultProtoTx_Log<<">"<< "\n\t\t\t" << endl;;
  cout << "  -T <protocol_type>\t\t\t\t(Default: "<< DefaultProto << ") NOTE: Protocol\n\t\t\t\t\t\tTypes are: UDP,TCP, ICMP" << endl;
  cout << "  -b <DS_byte>\t\t\t\t\t(Default: " << DefaultDSByte << ")" << endl;
  cout << "  -f <TTL byte>\t\t\t\t\t(Default:  64 )" << endl;
  cout << "  -C <pkts_per_sec>\t\t\t\t[DEFAULT] constant inter-arrival\n\t\t\t\t\t\t(Default: " << DefaultPktPerSec << " pkts/sec)" << endl;
  cout << "  -U <min_pkts_per_sec> <max_pkts_per_sec>\tuniformly distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -E <average_pkts_per_sec>\t\t\texponentially distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -V <shape> <scale>\t\t\t\tpareto distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -Y <shape> <scale>\t\t\t\tcauchy distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -N <mean> <std_dev>\t\t\t\tnormal distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -O <mean>\t\t\t\t\tpoisson distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -G <shape> <scale>\t\t\t\tgamma distributed\n\t\t\t\t\t\tinter-arrival" << endl;
  cout << "  -c <pkt_size>\t\t\t\t\t[DEFAULT] constant payload size\n\t\t\t\t\t\t(Default: " << DefaultPktSize << " bytes)" << endl;
  cout << "  -u <min_pkt_size> <max_pkt_size>\t\tuniformly distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -e <average_pkt_size>\t\t\t\texponentially distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -v <shape> <scale>\t\t\t\tpareto distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -y <shape> <scale>\t\t\t\tcauchy distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -n <mean> <std_dev>\t\t\t\tnormal distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -o <mean>\t\t\t\t\tpoisson distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << "  -g <shape> <scale>\t\t\t\tgamma distributed\n\t\t\t\t\t\tpayload size" << endl;
  cout << " Upper Protocol Options: \n" << endl;
  cout << "  Telnet (without any other option)" << endl;
  cout << "  DNS (without any other option)" << endl;
  cout << "  VoIP (with option: )\t-x <codec_type>\tCodec:  G.711.<1 or 2> (samples per pkt)" << endl;
  cout << " \t\t\t\t\t\tG.729.<2 or 3> (samples per pkt)" << endl;
  cout << " \t\t\t\t\t\tG.723.1" << endl;
  cout << " \t\t\t\t\t\t(Default: G.711.1)" << endl;
  cout << "  \t\t-h <protocol_type>\t\t(Default: RTP)" << endl;
  cout << "  \t\t-i <Voice_Activity_Detection>\t(Default: VAD)" << endl;
  cout << endl;
  cout << " For more information consult ""help"" file in the same directory"<<  endl;
  #ifdef LINUX_OS
  pulisceMem();
  #endif
  exit(1);
}


void ReportErrorAndExit(char *function, char *msg, char *pname, int fid) {
  cerr << endl << "** ERROR **  Flow " << fid << " aborted : " << function << ": " << msg << endl;
  cerr << "Type '" << pname << "' for help" << endl << endl;
#ifdef LINUX_OS
      	pulisceMem();
      #endif

  exit(1);
}

int findProto(char *s)
{
	int i=1;

	while (strcmp(AppProto[i]," "))
		if (!strcasecmp(s,(char*)AppProto[i]))
			return i;
		else
			i++;
	return 0;
}


//Crea il canale TCP su cui "costruire" il canale di signaling
void createCanalTrasport(int &signaling,struct sockaddr_in DestHost){
   struct sockaddr_in locale;
   signaling=0;   
   signaling=socket(PF_INET,SOCK_STREAM,0);
   locale.sin_family = AF_INET;
   #ifdef LINUX_OS
   locale.sin_addr.s_addr=DestHost.sin_addr.s_addr; //indirizzo del canale di signaling
   #endif
   #ifdef WIN32
   locale.sin_addr.S_un.S_addr=DestHost.sin_addr.S_un.S_addr; //indirizzo del canale di signaling
   #endif
   locale.sin_port=htons(DefaultPortSignaling);
   if (connect(signaling, (struct sockaddr *)&locale, sizeof(locale))<0){
	   cout<<"Error into connect"<<endl;
	   perror("createCanalTrasport: ");
        #ifdef LINUX_OS
      	pulisceMem();
      #endif

	   exit(1);
	 }
}


char *putValue(void* startpos,void* data,int size){
	char *endpos;
	memcpy(startpos,data,size);
	endpos=(char*)startpos+size;
	return endpos;
}


//Invia sul canale di signaling un messaggio contenente il solo campo type
void Sendtype(int signaling,BYTE typeMessag){
  char Messaggio[1];
  putValue(&Messaggio,(void*)&typeMessag,sizeof(typeMessag));
  send(signaling,(char*)&Messaggio,sizeof(Messaggio),0);
}


//Invia sul canale di signaling il messaggio connect() 
void createCanalSignaling(int signaling,struct sockaddr_in DestHost){
  timeval timeout;
  int numSend=0;
  fd_set active_set;
  int exit=0;
  do {
     Sendtype(signaling,1);
     FD_ZERO(&active_set);
	 FD_SET(signaling,&active_set);
	 timeout.tv_sec=TimeOut;
	 timeout.tv_usec=0;
     if (select(FD_SETSIZE,&active_set,NULL,NULL,&timeout)<0) {
		cerr<<endl<<" Error ** : Invalid file descriptor "<<endl;
	 }
	 if (FD_ISSET(signaling,&active_set)) {
		 recvAck(signaling);
		 exit=1;
	 }
  } while ((exit!=1) && (numSend<2));
  if (numSend==2) cout<<"** ERROR ** Receiver is down ! "<<endl;
}


//Invia sul canale di signaling il messaggio send_release()
void sendRelase(int signaling){
  timeval timeout;
  int numSend=0;
  fd_set active_set;
  int exit=0;
  do {
     Sendtype(signaling,11);
     FD_ZERO(&active_set);
	 FD_SET(signaling,&active_set);
	 timeout.tv_sec=TimeOut;
	 timeout.tv_usec=0;
     if (select(FD_SETSIZE,&active_set,NULL,NULL,&timeout)<0) {
		cerr<<endl<<" Error ** : Invalid file descriptor "<<endl;
	 }
	 if (FD_ISSET(signaling,&active_set)) {
		 recvAck(signaling);
		 exit=1;
	 }
  } while ((exit!=1) && (numSend<2));
  if (numSend==2) cout<<"** ERROR ** Receiver is down ! "<<endl;
}

//spedisce sul canale di signaling il messaggio sendflowlog()
void sendLog(int signaling,unsigned short logPort,unsigned int logIP,BYTE logProtocol,char *FileName){
  
  char Messaggio[DimLogFileChr+20];
  char * next;
  BYTE type=12;
  int numSend=0;
  int sizeMessag;
  next=putValue(&Messaggio,(void*)&type,sizeof(type));
  next=putValue(next,(void*)&logPort,sizeof(logPort));
  next=putValue(next,(void*)&logIP,sizeof(logIP));
  next=putValue(next,(void*)&logProtocol,sizeof(logProtocol));
  next=putValue(next,(void*)FileName,DimLogFileChr);
  fd_set read_set,active_set;
  FD_ZERO(&active_set);
  FD_SET(signaling,&active_set);
  timeval timeout;
  timeout.tv_sec=600;
  timeout.tv_usec=0;
  sizeMessag=sizeof(type)+sizeof(logPort)+sizeof(logIP)+sizeof(logProtocol)+DimLogFileChr;
  int exit=0;
  do {
	 send(signaling,(char*)&Messaggio,sizeMessag,0);
     FD_ZERO(&active_set);
	 FD_SET(signaling,&active_set);
	 timeout.tv_sec=TimeOut;
	 timeout.tv_usec=0;
     if (select(FD_SETSIZE,&active_set,NULL,NULL,&timeout)<0) {
		cerr<<endl<<" Error ** : Invalid file descriptor "<<endl;
	 }
	 if (FD_ISSET(signaling,&active_set)) {
		 recvAck(signaling);
		 exit=1;
	 }
  } while ((exit!=1) && (numSend<2));
  if (numSend==2) cout<<"** ERROR ** Receiver is down ! "<<endl;
}

//Si mette in attesa si un ack sul canale di signaling
void recvAck(int signaling){
  int i;
  char buffer[1];
  i=recv(signaling,(char*)&buffer,sizeof(BYTE),0);
}

//spedisce sul canale di signaling il messaggio closedflowErr()
void closedFlowErr(int FlowId,int signaling)
{

  char Messaggio[5];
  char * next;
  BYTE type=17;

  next=putValue(&Messaggio,(void*)&type,sizeof(type));
  next=putValue(next,(void*)&FlowId,sizeof(int));
  int sizeMessag=sizeof(int)+sizeof(type);
  int size;
  size=send(signaling,(char*)&Messaggio,sizeMessag, 0);
  if (size<0) {
	   cout<<" *** Error into send "<<endl;
           #ifdef LINUX_OS
      	   pulisceMem();
           #endif
	   exit(1);
	 }

}

//spedisce sul canale di signaling il messaggio closedflow()
void closedFlow(int FlowId,int signaling)
{
  char Messaggio[5];
  char * next;
  BYTE type=4;
  next=putValue(&Messaggio,(void*)&type,sizeof(type));
  next=putValue(next,(void*)&FlowId,sizeof(int));
  int sizeMessag=sizeof(int)+sizeof(type);
  int numSend=0;
  int size;
  do {
  size=send(signaling,(char*)&Messaggio,sizeMessag, 0);
  if (size<0) {
	   cout<<" *** Error into send "<<endl;
           #ifdef LINUX_OS
      	   pulisceMem();
           #endif
	   exit(1);
	 }
  numSend++;
  } while ((recvAckFlow(FlowId,signaling)!=1) && (numSend<2));
  if (numSend==2) cout<<"E' caduto il ricevitore!"<<endl;
}



//spedisce sul canale di signaling il messaggio sendflow()
void sendFlowId(int FlowId,int signaling, struct sockaddr_in DestHost,char *protocolName,char *upProtocol,int FlowIdStop,char NameMsr[30]){
  char Messaggio[100];
  char * next;
  BYTE type=3;
  int sizeMessag;
  BYTE Meter;
  BYTE AppProtocolName;
  BYTE protocol;
  int numSend=0;
  int size;

  AppProtocolName=INVconverti_app(upProtocol);
  protocol=INVconverti(protocolName);
  Meter=INVconvertiMeter(NameMsr);

  next=putValue(&Messaggio,(void*)&type,sizeof(type));
  next=putValue(next,(void*)&protocol,sizeof(type));
  next=putValue(next,(void*)&AppProtocolName,sizeof(type));
  next=putValue(next,(void*)&Meter,sizeof(type));

  #ifdef WIN32
  next=putValue(next,(void*)&DestHost.sin_addr.S_un.S_addr,sizeof(unsigned int));
  #endif
  #ifdef LINUX_OS
  next=putValue(next,(void*)&DestHost.sin_addr,sizeof(unsigned int));
  #endif
  next=putValue(next,(void*)&DestHost.sin_port,sizeof(unsigned short));
  next=putValue(next,(void*)&FlowId,sizeof(int));
  sizeMessag=4*sizeof(type)+sizeof(unsigned int)+sizeof(unsigned short)+sizeof(int);

  do {
  size=send(signaling,(char*)&Messaggio,sizeMessag, 0);
  numSend++;
  if (size<0) {
	   cout<<" *** Error into send "<<endl;
           #ifdef LINUX_OS
  	   pulisceMem();
      	   #endif
	   exit(1);
	 }
  // Attende ACK da parte del ricevitore..
  } while ((recvAckFlow(FlowId,signaling)!=1) && (numSend<2));
  if (numSend==2) cout<<"E' caduto il ricevitore!"<<endl;
}

// Si mette in attesa del messaggio di ack!
int recvAckFlow(int FlowId,int signaling) {
  #ifdef WIN32 //attesa passiva del thread
  WaitForSingleObject(hEvent[searchPosition(signaling,FlowId)],6000000);
    if (WAIT_TIMEOUT==1) {
	  cout<<"TimeOut is elasped!"<<endl;
	  return 0;
  }
  else return 1;
  #endif
  #ifdef LINUX_OS
  struct msqid_ds coda;
  msgrcv(id_msg,&area_msg, sizeof(unsigned int), FlowId, 0);
  return 1;
  #endif
}



//Controlla che il canale di signaling verso la macchina con IP DestHost.sin_addr
//non sia gia' presente
bool checkDestHostIP(int &signaling,struct sockaddr_in DestHost){
    int i=0;
    while ((DestHost.sin_addr.s_addr!=canSign[i].DestAddr.sin_addr.s_addr) && (canSign[i].socket!=-1)){
			i++;
		}
   if (DestHost.sin_addr.s_addr==canSign[i].DestAddr.sin_addr.s_addr){
	   canSign[i].numThreadSu++;
	   signaling=canSign[i].socket;
	   return true;
	}
	else return false;
}

//Controlla se �possibile chiudere il canale di signalign;
bool checkClosedCanal(int &signaling,struct sockaddr_in DestHost){
  int i=0;
  //cout<<"sono nella closed"<<endl;
   while (DestHost.sin_addr.s_addr!=canSign[i].DestAddr.sin_addr.s_addr){
	i++;
  }
  canSign[i].numThreadSu--;
  //cout<<"numero di thread ancora .. "<<canSign[i].numThreadSu<<endl;
  if (canSign[i].numThreadSu==0){
	signaling=canSign[i].socket;
	canSign[i].socket=-1;
	canSign[i].DestAddr.sin_addr.s_addr=0;
   	//cout<<"sono alla uscita closed"<<endl;
	return true;


  }
 else{
  //cout<<"sono alla usctita closed"<<endl;
  return false;

 }
}


void argvToString(char *argv[],int argc,char line[200]){
 int i=0;
 strcpy(line," ");
 while (argc>0)  {
  strcat(line,argv[i]);
  strcat(line," ");
  argc--;
  i++;
}
strcat(line,"\n");
}

//Salva il buffer su disco
void saveBufferBeforeClose(Info* infos,int count){
   if (logvar){
      // Swap to file elements that may remain into the buffer
      if (!logremoto){
		#ifdef LINUX_OS
  		pthread_mutex_lock(&mutex_log);		// blocca sul semaforo
  		#endif
		#ifdef WIN32
  		WaitForSingleObject(mutex_log, INFINITE);
		#endif
		out.write((const char*)infos, count*sizeof(struct Info));
		#ifdef WIN32
		ReleaseMutex(mutex_log);
		#endif
		#ifdef LINUX_OS
		pthread_mutex_unlock(&mutex_log);		// blocca sul semaforo
		#endif
		count=0;
		}
	else {
	       sendto(logsock,(char *)infos, count*sizeof(struct Info),0,(struct sockaddr *)&LogHost, sizeof(LogHost));
		}
   } //end if logcheck..
 }



#ifdef WIN32
void tstart(LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi,int &first,char NameMsr[30])
{
    SYSTEMTIME lpSystemTime;
	if (first) {
		QueryPerformanceFrequency(&freq);
		first=0;
	}
	QueryPerformanceCounter(&_tstart);
	GetSystemTime(&lpSystemTime);
	secondi=lpSystemTime.wHour*3600+lpSystemTime.wMinute*60+lpSystemTime.wSecond;
	if (strcmp(NameMsr,"owdm")==0)
		microsecondi=lpSystemTime.wMilliseconds;
	else microsecondi=lpSystemTime.wMilliseconds*1000;
}
                                                                                                                                                                               
void gettimeofday(struct timeval* thisTime,LARGE_INTEGER &_tend,LARGE_INTEGER &_tstart,unsigned long &secondi,unsigned long &microsecondi,char NameMsr[30])
{
   double secondieusecond;
   double tempsecondi=0,tempmicrosecondi=0;
   long micro;
   QueryPerformanceCounter(&_tend);
   secondieusecond=((((double)_tend.QuadPart-(double)_tstart.QuadPart))/(double)freq.QuadPart);
   thisTime->tv_sec=((unsigned long)secondieusecond)+secondi;
   if (strcmp(NameMsr,"owdm")==0) {
	   micro=floor(((secondieusecond-(unsigned long)secondieusecond)*1e6)/1000);
	   if ((thisTime->tv_usec=(micro+microsecondi))>=1e3) {
		thisTime->tv_sec++;
		thisTime->tv_usec=((double)(thisTime->tv_usec*1e-3)-1)*1e3;
		}
	   thisTime->tv_usec=thisTime->tv_usec*1e3;
	}
   else {
            micro=((secondieusecond-(unsigned long)secondieusecond)*1e6);
	    if ((thisTime->tv_usec=(micro+microsecondi))>=1e6) {
		thisTime->tv_sec++;
		thisTime->tv_usec=((double)(thisTime->tv_usec*1e-6)-1)*1e6;
	    }
        }
}

void UpdateTicker(struct TTicker * Ticker,LARGE_INTEGER &_tend,LARGE_INTEGER &_tprec,LARGE_INTEGER &_tstart,int &first)
{
  if (first) {
	_tprec=_tstart;
	first=0;
  }
  QueryPerformanceCounter(&_tend);
  Ticker->count=(((((double)_tend.QuadPart-(double)_tprec.QuadPart))/(double)freq.QuadPart)*1e3);
  _tprec=_tend;
}
#endif


#ifdef LINUX_OS
void UpdateTicker(struct TTicker *Ticker) {
  struct timeval thisTime, *lastTime = &Ticker->lastTime;

  gettimeofday(&thisTime, NULL);
  Ticker->count += ((double)(thisTime.tv_sec - lastTime->tv_sec))*1000.0 +
                   ((double)(thisTime.tv_usec - lastTime->tv_usec))/1000.0;
  *lastTime = thisTime;

}
#endif

//Crea il canale di signaling con il log remoto
void createRemotLogFile(struct sockaddr_in &LogHost,char *Prototx_Log){	  // protocollo di trasporto di default per il log remoto
    Signaling signal;			  //per la gestione del canale di signaling con il log remoto
    char buffer[1];
    int help;
    int logsocksignaling;
    logsocksignaling = socket(PF_INET, SOCK_STREAM , 0); // ..canale per fare signaling!
    help=LogHost.sin_port;
    LogHost.sin_family=AF_INET;
    LogHost.sin_port=htons(DefaultLogPortSignaling);
    signal.PortoLog=ntohs(help);
    strcpy(signal.protocol,Prototx_Log);
    strcpy(signal.LogFile,LogFile);
    connect(logsocksignaling, (struct sockaddr *)&LogHost, sizeof(LogHost));
    recv(logsocksignaling,(char*)buffer,sizeof(buffer),0);

    if (sendto(logsocksignaling, (char*)&signal, sizeof(signal),0,(struct sockaddr *)&LogHost, sizeof(LogHost)) < 0)
    		cerr << "** WARNING **  Error into sendto "<< endl;

    LogHost.sin_port=help;
    //canale TX - LOG Remoto
    if (strcmp(Prototx_Log,"UDP")==0) {
	    logsock = socket(PF_INET, SOCK_DGRAM , 0);    // canale UDP TX - Log
    }
    else {
        logsock=socket(AF_INET,SOCK_STREAM,0);      // canale TCP TX - Log..
    }
    char buffer2[100];
    int size;
    size=recv(logsocksignaling,(char*)buffer2,sizeof(buffer2),0);
    sleep(1);
    LogHost.sin_port=htons(*(unsigned int *)buffer2);
    connect(logsock,(struct sockaddr *)&LogHost, sizeof(LogHost));
}


char * ricercaNameMsr(char line[200]){
	char *token;
	token=strtok(line," ");
	while ((strcmp(token,"-m")!=0) && (strcmp(token,"\n")!=0)) {
		token=strtok(NULL," ");
	}
	if (strcmp(token,"\n")==0)
	  return DefaultMsr;
	else {
		token=strtok(NULL," ");
		return token;
	}
}
