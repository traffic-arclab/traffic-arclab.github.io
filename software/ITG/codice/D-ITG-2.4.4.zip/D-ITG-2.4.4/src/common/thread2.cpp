/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */



#include "thread.h"




int createThread(void *argument, void *(nameFunction) (void *), void *attrib, pthread_t &idThread)
{
	
	int ret = 0;
#ifdef WIN32	
	
	void *pid;
	
	(HANDLE)idThread =
	    CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) nameFunction, argument, (DWORD) NULL,
	    (unsigned long *) &pid);
#ifdef DEBUG
    printf("Return value CreateThread (WIN32) %d\n",(int)idThread);
#endif
	if (idThread == NULL) ret = -1;
#ifdef DEBUG
	printf("Return value createThread : %d\n",ret);
#endif
#endif

#ifdef LINUX_OS
	
	 
	ret = pthread_create(&idThread, NULL, nameFunction, argument);
	if (ret != 0) ret = -1;
#ifdef DEBUG
    printf("Return value pthread_create (LINUX) %d\n",(int)idThread);
    printf("Return value createThread : %d\n",ret);
#endif
#endif
	return ret;
};


int terminateThread(pthread_t idThread)
{
	
	int ret = 0;
#ifdef WIN32
	
	ret = TerminateThread((HANDLE) idThread, 0);
	if (ret == 0) ret = -1;
	else ret = 0;
#endif
#ifdef LINUX_OS
	
	ret = pthread_cancel(idThread);
	if (ret != 0) ret = -1;
#endif
#ifdef DEBUG
    printf("Return value terminateThread : %d\n",ret);
#endif
	return ret;
}; 


void exitThread()
{
#ifdef WIN32
	
	ExitThread(0);
#endif
#ifdef LINUX_OS
	
	pthread_exit(0);
#endif
};


int joinThread(int numFlow, pthread_t hThr[])
{
	int ret = 0;
#ifdef WIN32
	DWORD temp = 0;
	
	temp = WaitForMultipleObjects(numFlow, (const HANDLE *) hThr, TRUE, INFINITE);
#ifdef DEBUG
    printf("Return value WaitForMultipleObjects(WIN32) : %d\n",(int)temp);
#endif
	if (temp == WAIT_FAILED) ret = -1;
#endif
#ifdef LINUX_OS
	
	int ret2 = 0;
	for(int i = 0; i < numFlow; i++) {
		ret2 = pthread_join(hThr[i], NULL);
		if (ret2 != 0)
			ret = -1;
	}
#endif
#ifdef DEBUG
    printf("Return value joinThread : %d\n",ret);
#endif
    return ret;
};



#ifdef WIN32

int mutexThreadInit(HANDLE &mutex)
{
	int ret = 0;
	
	mutex = CreateSemaphore(NULL,2,2,"MYMUTEX");
#ifdef DEBUG
	printf("Return value CreateSemaphore (WIN32) : %d \n",(int)mutex);
#endif
	if (mutex == NULL) ret = -1;
#ifdef DEBUG
	printf("Return value mutexThreadInit : %d \n",ret);
#endif
	return ret;
}
#endif

#ifdef LINUX_OS

int mutexThreadInit(void* mutex)
{
	int ret = 0;
	
	ret = pthread_mutex_init((pthread_mutex_t *)mutex, NULL);
#ifdef DEBUG
	printf("Return value pthread_mutex_init (LINUX) : %d \n",mutex);
	printf("Return value mutexThreadInit : %d \n",ret);
#endif
	return ret;
}
#endif
	

int mutexThreadLock(void *mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_lock((pthread_mutex_t *) mutex);
	if (ret != 0 ) ret = -1;
#endif
#ifdef WIN32
	DWORD temp = 0;
	
#ifdef DEBUG
	printf("Try to lock mutex : %d\n",(int)mutex);
#endif
	temp = WaitForSingleObject((HANDLE)mutex,INFINITE);
#ifdef DEBUG
    printf("Return value WaitForSingleObject(WIN32) : %d\n",(int)temp);
#endif
	if (temp == WAIT_FAILED) ret = -1;
#endif
#ifdef DEBUG
    printf("Return value mutexThreadLock : %d\n",ret);
#endif
	return ret;
};


int mutexThreadUnlock(void *mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_unlock((pthread_mutex_t *) mutex);
	if (ret != 0 ) ret = -1;
#endif
#ifdef WIN32
	BOOL flag = 0;
	LONG cPreviousCount;

#ifdef DEBUG
	printf("Try to unlock mutex : %d\n",(int)mutex);
#endif
	flag = ReleaseSemaphore((HANDLE)mutex,1,&cPreviousCount);
#ifdef DEBUG
	printf("Previous Count value : %d\n",cPreviousCount);
    printf("Return value ReleaseSemaphore(WIN32) in mutexThreadUnlock : %d\n",flag);
#endif
	if (flag == 0) ret = -1;
#endif
#ifdef DEBUG
    printf("Return value mutexThreadUnlock : %d\n",ret);
#endif
	return ret;
};



int mutexThreadRelease(void* mutex)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = pthread_mutex_destroy((pthread_mutex_t *)mutex);
	if (ret != 0) ret = -1;
#endif
#ifdef WIN32
		BOOL flag = 0;
		
		flag = CloseHandle((HANDLE)mutex);
		if (flag == 0) ret = -1;
#endif
#ifdef DEBUG
    printf("Return value mutexThreadRelease : %d\n",ret);
#endif
	return ret;
}





int closeSock(int socket)
{
	int ret = 0;
#ifdef LINUX_OS
	
	ret = close(socket);
#endif
#ifdef WIN32
	
	ret = closesocket(socket);
	if (ret == SOCKET_ERROR) ret = -1;
#endif
#ifdef DEBUG
    printf("Return value closeSock : %d\n",ret);
#endif
	return ret;
};
