/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */



#ifdef WIN32
#include <windows.h>
#endif
#ifdef LINUX_OS
typedef int HANDLE;
#endif

HANDLE serialUp(char *nameSerial);
void DTR_Enable(HANDLE hComm);
void DTR_Disable(HANDLE hComm);
void RTS_Enable(HANDLE hComm);
void RTS_Disable(HANDLE hComm);

