/*
 *	Component of the D-ITG platform (http://www.grid.unina.it/software/ITG)
 *
 *      Copyright       : (C) 2004-2007 by Stefano Avallone, Alessio Botta, Alberto Dainotti
 *                                         Donato Emma, Antonio Pescape'
 *      email:          : stavallo@unina.it , a.botta@unina.it , alberto@unina.it
 *                        doemma@unina.it , pescape@unina.it
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 */



#include "../common/ITG.h"
#include "../common/serial.h"
#include "../common/pipes.h"
#include "../common/thread.h"
#include "../common/timestamp.h"
#include "ITGRecv.h"
#include "data.h"

#ifdef LINUX_OS
#include <netinet/ip.h>
#endif


inline void flushBuffer(ofstream *pointerLog, struct info *infos , int count)
{
	
	if ( MUTEX_THREAD_LOCK(mutexLog) < 0)
			reportErrorAndExit("flushBuffer","MUTEX_THREAD_LOCK","Cannot lock mutex");

	
	(*pointerLog).write((const char *) infos,count * sizeof(struct info));

	
	if ( MUTEX_THREAD_UNLOCK(mutexLog) < 0)
			reportErrorAndExit("flusBuffer","MUTEX_THREAD_UNLOCK","Cannot unlock mutex");
}




void *icmpSock(void *param)
{
#ifdef WIN32
	
	int first = 1;
#endif
   	
	int dimheader = 0;
	
	     
   	HANDLE hComm;

	
	paramThread *paraThread;
	
	paraThread = (paramThread *) param;
	
	int sock = 0;
	
	unsigned char buffer[MAX_PAYLOAD_SIZE + 32];
	
	unsigned char payload[MAX_PAYLOAD_SIZE];
	
	struct info *infos = (struct info *) malloc(DIM * sizeof(info));
	
	struct addrinfo SrcAddress;

	
	int size_r = 0;
	
	struct timeval RcvTime;
	#ifdef WIN32
	
	struct addrinfo* sockAddress;

	

	
	LARGE_INTEGER _tstart, _tend;
	

	
	unsigned long secs = 0, msecs = 0;
#endif

#ifdef DEBUG
	
	int numRecvdPkt = 0;
#endif

	
	char *ptrSeqNum = (char *) payload + sizeof(unsigned int);
	
	char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
	
	char *ptrTimeUsec = ptrTimeSec + sizeof(long int);

	
	paraThread->addressInfos = infos;
	
	paraThread->count = 0;

	if (strcmp(paraThread->serial,"noSerial")!=0) {
		hComm = serialUp(paraThread->serial);
        if (hComm == INVALID_HANDLE_VALUE)
             printf("Error opening interface %s \n", paraThread->serial);
    }

	
	sock = socket(paraThread->destHost.ai_family, SOCK_RAW,
		(paraThread->destHost.ai_family == AF_INET) ? IPPROTO_ICMP : IPPROTO_ICMPV6);
	if (sock < 0) {
		
		struct pipeMsg msg;
		printf("icmpSock - error into create socket");

		msg.code = MSG_FT_ERR2;
		msg.flowId = paraThread->flowId;
		if (sendPipeMsg(paraThread->rPipe, &msg) < 0) {
			printf(" sending msg error");
		}
		sleep(INFINITE);
	}

#ifdef WIN32

#ifdef IPv6RECV
	if ( getaddrinfo("::", NULL, NULL, &sockAddress) != 0)
		reportErrorAndExit("icmpSock","getaddrinfo IPv6","Cannot set the default IP log address");

#else
	if ( getaddrinfo("0.0.0.0", NULL, NULL, &sockAddress) != 0)
		reportErrorAndExit("icmpSock","getaddrinfo IPv4","Cannot set the default IP log address");
#endif
	
	if ( bind(sock, sockAddress->ai_addr, sockAddress->ai_addrlen))
		reportErrorAndExit("icmpSock","bind","Cannot bind a socket on port");
#endif


	
	
	struct pipeMsg msg;
	msg.code = MSG_FT_OK;
	msg.flowId = paraThread->flowId;
	if (sendPipeMsg(paraThread->rPipe, &msg) < 0) {
		printf("error into sending msg to signal manager");
	}

	printf("Listening ICMP traffic \n");
	
	paraThread->socketClose = sock;
	
	SrcAddress.ai_family = paraThread->destHost.ai_family;
	
	if (SrcAddress.ai_family == PF_INET) {
		
		SrcAddress.ai_addr = (struct sockaddr *) malloc(sizeof(struct sockaddr_in));
		
		SrcAddress.ai_addrlen = sizeof(struct sockaddr_in);
		
		dimheader = sizeof(icmp) + sizeof(iphdr);

	
	} else if (SrcAddress.ai_family == PF_INET6) {
		
		SrcAddress.ai_addr = (struct sockaddr *) malloc(sizeof(struct sockaddr_in6));
		
		SrcAddress.ai_addrlen = sizeof(struct sockaddr_in6);
		
		dimheader = sizeof(icmpv6);
	}
	
	int firstpacket = 1;
	char HelpSrcAddress[INET6_ADDRSTRLEN];
	char HelpDstAddress[INET6_ADDRSTRLEN];
	int tmpPort_SrcPort;
	int tmpPort_DstPort;
	
	TSTART(_tstart, secs, msecs, first, 0, RECEIVER);
	
	while (1) {
		
		size_r =
		    recvfrom(sock, (char *) buffer, MAX_PAYLOAD_SIZE + dimheader, 0,
		    SrcAddress.ai_addr, (socklen_t *) & SrcAddress.ai_addrlen);

			printf("ICMP Pkt Receiver : Received RAW Packet :%d\n", size_r);

#ifdef DEBUG
			printf("ICMP Pkt Receiver : Received RAW Packet :%d\n", size_r);
#endif
		if (size_r < 0)
			reportErrorAndExit("icmpSock","recvfrom","Cannot receive RAW packets");
		
		char *ptr = (char *) buffer;		
		
		
		ptr = ptr + dimheader;
		
		
		size_r = size_r - dimheader;
		
		
		memcpy(&payload, ptr, size_r);

	        if (hComm != INVALID_HANDLE_VALUE){
        	      DTR_Disable(hComm);
              	      DTR_Enable(hComm);
        	}

		
		GET_TIME_OF_DAY(&RcvTime, _tend, _tstart, secs, msecs, 0, RECEIVER);

		

		
		if ((logCheck != 0) || (logRemote != 0)) {
			if (firstpacket == 1) {
				getInfo(&SrcAddress, tmpPort_SrcPort, HelpSrcAddress);
				getInfo(&paraThread->destHost, tmpPort_DstPort, HelpDstAddress);
				firstpacket = 0;
			}
			writeInBuffer(&infos[paraThread->count],*(unsigned int *) payload,*(unsigned int *) ptrSeqNum,
                               HelpSrcAddress, HelpDstAddress, tmpPort_SrcPort, tmpPort_DstPort, *(long int *) ptrTimeSec, RcvTime.tv_sec % 86400L,
                               *(long int *) ptrTimeUsec, RcvTime.tv_usec, size_r);
#ifdef DEBUG
numRecvdPkt++;
#endif
			
			paraThread->count++;
			
			if (paraThread->count == DIM) {
			

			if (logCheck ==!0)
				flushBuffer((ofstream *) paraThread->fileLog, infos , DIM);
			
			else  if (logRemote != 0) {
					if ( sendto(paraThread->logSock, (char *) infos,
							DIM * sizeof(struct info), 0, paraThread->logHost->ai_addr,
							paraThread->logHost->ai_addrlen) < 0)
						reportErrorAndExit("icmpSock","sendto","Cannot send log infos to LogServer");
#ifdef DEBUG
					printf("ICMP Pkt Receiver : Sent Infos to LogServer\n");
#endif
				}
				
				paraThread->count = 0;
			}	
		}	
	}	
}	





void *udpSock(void *param)
{
#ifdef WIN32
	
	int first = 1;
#endif
	
	HANDLE hComm;

	
	paramThread *paraThread;

	
	paraThread = (paramThread *) param;
	
	int sock = 0;
	
	unsigned char payload[MAX_PAYLOAD_SIZE];
	
	struct info *infos = (struct info *) malloc(DIM * sizeof(info));
	
	struct addrinfo SrcAddress;
	
	in_port_t tmpPort = 0;
	
	int size_r = 0;
	
	unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
	
	unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
	
	unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
	
	struct timeval RcvTime;
#ifdef WIN32
	

	
	LARGE_INTEGER _tstart, _tend;
	

	
	unsigned long secs = 0, msecs = 0;
#endif

#ifdef DEBUG
	
	int numRecvdPkt = 0;
#endif
	
	paraThread->addressInfos = infos;
	
	paraThread->count = 0;

	if (strcmp(paraThread->serial,"noSerial")!=0) {
		hComm = serialUp(paraThread->serial);
        if (hComm == INVALID_HANDLE_VALUE)
             printf("Error opening interface %s \n", paraThread->serial);
 	}

	
	sock = socket(paraThread->destHost.ai_family, SOCK_DGRAM, 0);
	if (sock < 0)
		reportErrorAndExit("udpSock","socket","Cannot create a DATAGRAM socket on port");


       if (bind(sock, paraThread->destHost.ai_addr, paraThread->destHost.ai_addrlen) < 0) {
	      
	 	printf("Error into bind function!\n");
		struct pipeMsg msg;
		msg.code = MSG_FT_ERR1;
		msg.flowId = paraThread->flowId;
		if (sendPipeMsg(paraThread->rPipe, &msg) < 0) {
			printf(" sending msg error");
		}
		sleep(INFINITE);
 	} else {
			
			GET_PORT((&(paraThread->destHost)), tmpPort);
			printf("Listening on port : %d\n",ntohs(tmpPort));

			
			struct pipeMsg msg;
			msg.code = MSG_FT_OK;
			msg.flowId = paraThread->flowId;
			if (sendPipeMsg(paraThread->rPipe, &msg) < 0) {
				printf("error sending msg to signal manager");
			}
		}

	
	paraThread->socketClose = sock;
	
	SrcAddress.ai_family = paraThread->destHost.ai_family;
	
	if (SrcAddress.ai_family == PF_INET) {
		
		SrcAddress.ai_addr = (struct sockaddr *) malloc(sizeof(struct sockaddr_in));
		
		SrcAddress.ai_addrlen = sizeof(struct sockaddr_in);
	
	} else if (SrcAddress.ai_family == PF_INET6) {
		
		SrcAddress.ai_addr = (struct sockaddr *) malloc(sizeof(struct sockaddr_in6));
		
		SrcAddress.ai_addrlen = sizeof(struct sockaddr_in6);
	}

	int firstpacket = 1;
	char HelpSrcAddress[INET6_ADDRSTRLEN];
	char HelpDstAddress[INET6_ADDRSTRLEN];
	int tmpPort_SrcPort;
	int tmpPort_DstPort;

	

	

	
	TSTART(_tstart, secs, msecs, first, 0, RECEIVER);


	
	
	while (1){
		
		size_r =
		    recvfrom(sock, (char *) payload, MAX_PAYLOAD_SIZE, 0, SrcAddress.ai_addr,
		    (socklen_t *) & SrcAddress.ai_addrlen);
#ifdef DEBUG
		printf("UDP Pkt Receiver : Received DATAGRAM packet\n");
#endif

		if (size_r < 0)
			reportErrorAndExit("udpSock","recvfrom","Cannot receive UDP packets");


		if (hComm != INVALID_HANDLE_VALUE){
			DTR_Disable(hComm);
			DTR_Enable(hComm);
       		}

		
		GET_TIME_OF_DAY(&RcvTime, _tend, _tstart, secs, msecs, 0, RECEIVER);
		

		
		if ((logCheck!=0) || (logRemote != 0)){  
			if (firstpacket == 1) {
				getInfo(&SrcAddress, tmpPort_SrcPort, HelpSrcAddress);
				getInfo(&paraThread->destHost, tmpPort_DstPort, HelpDstAddress);
				firstpacket = 0;
			}
			writeInBuffer(&infos[paraThread->count],*(unsigned int *) payload,*(unsigned int *) ptrSeqNum,
                               HelpSrcAddress, HelpDstAddress, tmpPort_SrcPort, tmpPort_DstPort, *(long int *) ptrTimeSec, RcvTime.tv_sec % 86400L,
                               *(long int *) ptrTimeUsec, RcvTime.tv_usec, size_r);
			
			paraThread->count++;

			
			if (paraThread->count == DIM) {
				
				if (logCheck !=0 )
					flushBuffer((ofstream *) paraThread->fileLog, infos , DIM);
					
				else if (logRemote != 0) {
					if ( sendto(paraThread->logSock, (char *) infos,
						DIM * sizeof(struct info), 0, paraThread->logHost->ai_addr,
						paraThread->logHost->ai_addrlen) < 0)
						reportErrorAndExit("udpSock","sendto","Cannot send log infos to LogServer");
#ifdef DEBUG
					printf("UDP Pkt Receiver : Sent Infos to LogServer\n");
#endif
			}
			
			paraThread->count = 0;
			}	
		}	
		
		if (paraThread->meter == METER_RTTM) {
			if ( sendto(sock, (char *) payload, size_r, 0, SrcAddress.ai_addr,
					SrcAddress.ai_addrlen) < 0)
						reportErrorAndExit("udpSock","sendto",
							"Cannot send back payload for rttm");
#ifdef DEBUG
			printf("UDP Pkt Receiver : Sent RTTM message\n");
#endif
			 }	
		}	
}	







void *tcpSock(void *param)
{
#ifdef WIN32
	
	int first = 1;
#endif
    
    HANDLE hComm;

	
	paramThread *paraThread;
	
	paraThread = (paramThread *) param;


	
	int sock = 0;

	
	unsigned char payload[MAX_PAYLOAD_SIZE];
	
	struct info *infos = (struct info *) malloc(DIM * sizeof(info));
	
	struct addrinfo SrcAddress;
	
	in_port_t tmpPort = 0;
	
	int newSock = 0;
    
	int size = 0;
	
	unsigned char *ptrSeqNum = payload + sizeof(unsigned int);
	
	unsigned char *ptrTimeSec = ptrSeqNum + sizeof(unsigned int);
	
	unsigned char *ptrTimeUsec = ptrTimeSec + sizeof(long int);
	
	struct timeval RcvTime;
#ifdef WIN32
    

    
	LARGE_INTEGER _tstart, _tend;
	

	
	unsigned long secs = 0, msecs = 0;
#endif
#ifdef DEBUG
	
	int numRecvdPkt = 0;
#endif

	
	paraThread->addressInfos = infos;
	
	paraThread->count = 0;

	if (strcmp(paraThread->serial,"noSerial")!=0) {
		hComm = serialUp(paraThread->serial);
        	if (hComm == INVALID_HANDLE_VALUE)
			printf("Error opening interface %s \n", paraThread->serial);
	}
    
	
	sock = socket(paraThread->destHost.ai_family, SOCK_STREAM, 0);
	if (sock < 0)
		reportErrorAndExit("tcpSock","socket","Cannot create a STREAM socket on port");
	
	if (bind(sock, paraThread->destHost.ai_addr, paraThread->destHost.ai_addrlen) < 0) {
		
		struct pipeMsg msg;

		msg.code = MSG_FT_ERR1;
		msg.flowId = paraThread->flowId;
		if (sendPipeMsg(paraThread->rPipe, &msg) < 0) {
			printf(" sending msg error");
		}
		sleep(INFINITE); 
	}

	
	if (listen(sock, SOMAXCONN) < 0)
			reportErrorAndExit("tcpSock","listen","Cannot listen on a port");
	else {
		
		GET_PORT((&(paraThread->destHost)), tmpPort);
		printf("Listening on port : %d\n",ntohs(tmpPort));

		
		struct pipeMsg msg;
		msg.code = MSG_FT_OK;
		msg.flowId = paraThread->flowId;
		if (sendPipeMsg(paraThread->rPipe, &msg) < 0) {
			printf("error into sending msg to signal manager");
		}
	}

	
	SrcAddress.ai_family = paraThread->destHost.ai_family;
	
	if (SrcAddress.ai_family == PF_INET) {
		
		SrcAddress.ai_addr = (struct sockaddr *) malloc(sizeof(struct sockaddr_in));
		
		SrcAddress.ai_addrlen = sizeof(struct sockaddr_in);
	
	} else if (SrcAddress.ai_family == PF_INET6) {
		
		SrcAddress.ai_addr = (struct sockaddr *) malloc(sizeof(struct sockaddr_in6));
		
		SrcAddress.ai_addrlen = sizeof(struct sockaddr_in6);
	}

	

	if ((newSock =
		accept(sock, SrcAddress.ai_addr, (socklen_t *) & SrcAddress.ai_addrlen)) < 0)
			reportErrorAndExit("tcpSock","accept","Cannot accept connection");
	
	if ( closeSock(sock) == -1)
		reportErrorAndExit("tcpSock","closeSock","Cannot close socket sock");

	
	paraThread->socketClose = newSock;

    int firstpacket =1;
	char HelpSrcAddress[INET6_ADDRSTRLEN];
	char HelpDstAddress[INET6_ADDRSTRLEN];
    int tmpPort_SrcPort;
    int tmpPort_DstPort;

	
	TSTART(_tstart, secs, msecs, first, 0, RECEIVER);
	
	while (1) {
		
		size=TCPrecvPacket((unsigned char*)payload,newSock);

		if (hComm != INVALID_HANDLE_VALUE) {
			DTR_Disable(hComm);
			DTR_Enable(hComm);
		}

	        
		GET_TIME_OF_DAY(&RcvTime, _tend, _tstart, secs, msecs, 0, RECEIVER);

		
		
		if ((logCheck!=0) || (logRemote != 0)){  
		

	         if (firstpacket == 1) {
				getInfo(&SrcAddress, tmpPort_SrcPort, HelpSrcAddress);

				getInfo(&paraThread->destHost, tmpPort_DstPort, HelpDstAddress);

				firstpacket = 0;
		}
			
		if (paraThread->l7Proto == L7_PROTO_TELNET)
					size = size - 20; 

                  writeInBuffer(&infos[paraThread->count],*(unsigned int *) payload,*(unsigned int *) ptrSeqNum,
                               HelpSrcAddress, HelpDstAddress, tmpPort_SrcPort, tmpPort_DstPort,
                               *(long int *)ptrTimeSec, RcvTime.tv_sec % 86400L,*(long int *) ptrTimeUsec, RcvTime.tv_usec, size);
                
                paraThread->count++;
                
                if (paraThread->count == DIM) {
                                                
						if (logCheck !=0 )
				                               flushBuffer((ofstream *) paraThread->fileLog, infos , DIM);
				                                
                                                else
						if (logRemote !=0 )
						{
                                                 if ( sendto(paraThread->logSock, (char *) infos,
                                                            DIM * sizeof(struct info), 0, paraThread->logHost->ai_addr,
                                          				    paraThread->logHost->ai_addrlen) < 0)
                                          				    reportErrorAndExit("tcpSock","sendto","Cannot send log infos to LogServer");
#ifdef DEBUG
						                         printf("TCP Pkt Receiver : Sent infos to LogServer\n");
#endif
                                                }
                                                
                                                paraThread->count = 0;
			}	
		}	
		
		if (paraThread->meter == METER_RTTM) {
			if (sendto(newSock, (char *) payload, size, 0, SrcAddress.ai_addr,
			    SrcAddress.ai_addrlen) < 0)
					reportErrorAndExit("tcpSock","sendto","Cannot send payload back for rttm");
#ifdef DEBUG
			printf("TCP Pkt Receiver : Sent RTTM infos\n");
#endif
			}	
	}	
}	
