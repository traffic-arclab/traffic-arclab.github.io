export DEVDIR=$(ProgramFiles)/Dev-Cpp
export OS = WIN32
# Uncomment following line to enable IPv6
#export IPV6= "-DIPv6RECV"
export RM = del
export CP = copy
export SUFFIX = ".exe"
export CXXFLAGS = -O2 -Wall $(IPV6) -DWIN32 -Wno-deprecated -I$(DEVDIR)/Include/G++ -I$(DEVDIR)/Include/c++ -I$(DEVDIR)/Include/c++/mingw32 -I$(DEVDIR)/Include/c++/backward -I$(DEVDIR)/Include -L$(DEVDIR)/Lib
export LDFLAGS = $(DEVDIR)/Lib/libws2_32.a 
export BASEDIR = $(shell cd)
export BIN = "$(BASEDIR)\..\bin\"
export COMMON = "$(BASEDIR)\common\"
export NRCLEAN = "$(BASEDIR)\ITGSend\newran\"

CXX = g++
export THOBJS = common/thread.o
export OBJS = common/ITG.o common/timestamp.o common/serial.o
SUBDIRS = ITGSend ITGRecv ITGLog ITGDec libITG ITGManager

.PHONY: $(SUBDIRS)
all: $(SUBDIRS)

ITGSend ITGRecv ITGLog ITGDec libITG: $(THOBJS) $(OBJS)
	@ (cd $@ && $(MAKE))

ITGManager: 
	@ (cd $@ && $(MAKE))

clean: 
	$(RM) $(COMMON)*.o
	(cd ITGSend && make clean) 
	(cd ITGRecv && make clean) 
	(cd ITGLog && make clean) 
	(cd ITGDec && make clean) 
	(cd libITG && make clean) 
	(cd ITGManager && make clean) 

