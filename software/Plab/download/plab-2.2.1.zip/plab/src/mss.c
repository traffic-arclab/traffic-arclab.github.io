/*
 *  $Id:$
 *
 *  mss.c - Packet Lab: hash tables routines
 *
 *  Copyright (c) 2004 Alberto Dainotti, Antonio Pescap�, Alessio Botta
 *  Email: alberto@unina.it , pescape@unina.it , a.botta@unina.it
 *  DIS - Dipartimento di Informatica e Sistemistica (Computer Science Department)
 *  University of Naples Federico II
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include "plab.h"
#include "mss.h"
#include "pkt_macros.h"

/*
 * This function takes an hash table and a pointer to a function as arguments.
 * It would walk through the hash table calling func(mss_entry *entry) for each
 * table entry found.
 */
int mss_walk_through(struct mss_entry **ht, int (* func)(struct mss_entry *))
{
	int i;
	struct mss_entry *entry;

	for(i = 0; i < MSS_TABLE_SIZE; i++) {
		entry = ht[i];
		while (entry) {
			func(entry);
			entry = entry->next;
		}
	}

	return(0);
}

/*
 * Initialize the hash table.
 * The hash table is an array of MSS_TABLE_SIZE pointers.
 * Where mapped key goes from 0 to MSS_TABLE_SIZE - 1
 * and each pointer points to an hash table entry
 */
void mss_init_table(struct mss_entry **table)
{
	int c;

	for (c = 0; c < MSS_TABLE_SIZE; c++) {
		table[c] = NULL;
	}
}


/*
 * Hashing function.
 * Map the packet key (source + dest address) in to the table.
 * Return the table location
 */
u_long ip_hash(u_char * packet)
{
	int i;
	u_long j;

	for (i = 26, j = 0; i != 30; i++) {
		j = (j * 13) + packet[i];
	}

	PRINTDD("ip_hash: generated hash: %ld\n", j % MSS_TABLE_SIZE);
	return (j % MSS_TABLE_SIZE);
}

u_long ip_hash_dst(u_char * packet)
{
	int i;
	u_long j;

	for (i = 30, j = 0; i != 34; i++) {
		j = (j * 13) + packet[i];
	}

	PRINTDD("ip_hash_dst: generated hash: %ld\n", j % MSS_TABLE_SIZE);
	return (j % MSS_TABLE_SIZE);
}

/*
 * Verify if packet belongs to an existing mss_entry in loc (mapped key).
 * If so, return the mss_entry pointer.
 * Otherwise return NULL. In this case we have a collision or loc was unused.
 */
struct mss_entry *mss_dup_check(u_char *packet, struct mss_entry **table, int loc)
{
	struct mss_entry *p;

	for (p = table[loc]; p; p = p->next) {
		if (p->key[0] == packet[26] && p->key[1] == packet[27] &&
		    p->key[2] == packet[28] && p->key[3] == packet[29]) {
			/* this key is already in our table */
			return (p);
		}
	}
	/* this key has collided with other entries in our table or ht[loc] was NULL */
	return (NULL);
}

struct mss_entry *mss_dup_check_dst(u_char *packet, struct mss_entry **table, int loc)
{
	struct mss_entry *p;

	for (p = table[loc]; p; p = p->next) {
		if (p->key[0] == packet[30] && p->key[1] == packet[31] &&
		    p->key[2] == packet[32] && p->key[3] == packet[33]) {
			/* this key is already in our table */
			return (p);
		}
	}
	/* this key has collided with other entries in our table or ht[loc] was NULL */
	return (NULL);
}


/*
 * Add a new mss_entry to the table in position loc
 * Return the pointer to the new mss_entry
 */
struct mss_entry *mss_add_entry(u_char * packet, struct mss_entry **table, int loc)
{
	struct mss_entry *p;

	if (table[loc] == NULL) {
		/* this is the first entry in this location in the table */
		table[loc] = malloc(sizeof(struct mss_entry));
		if (table[loc] == NULL) {
			perror("mss_add_entry");
			return (NULL);
		}

		p = table[loc];
	} else {
		/* this is a chain, find the end of it */
		for (p = table[loc]; p->next; p = p->next);
		p->next = malloc(sizeof(struct mss_entry));
		if (p->next == NULL) {
			perror("mss_add_entry");
			return (NULL);
		}

		p = p->next;
	}

	/*
	 * Initialize mss_entry
	 */
	p->key[0] = packet[26];
	p->key[1] = packet[27];
	p->key[2] = packet[28];
	p->key[3] = packet[29];

	p->id = stats.mss_entries++;
	PRINTDD("MSS, generated a new ip entry: %d.%d.%d.%d\n", packet[26], packet[27], packet[28], packet[29]);
	p->next = NULL;
	p->mss = 0;

	return (p);
}


/*
 * Given a packet, get a pointer to the corresponding mss_entry.
 * If necessary allocate and initialize a new entry.
 * On error return NULL.
 */
struct mss_entry *mss_get_entry(u_char * packet, struct mss_entry **table)
{
	u_long n;
	struct mss_entry *entry;

	/* calculate the hash corresponding to the packet (map the key in to a table location) */
	n = ip_hash(packet);

	/* check to see if we have to add a new entry */
	entry = mss_dup_check(packet, table, n);
	if (entry == NULL) {
		entry = mss_add_entry(packet, table, n);
	}

	return (entry);
}


struct mss_entry *mss_lookup_entry_src(u_char * packet, struct mss_entry **table)
{
	u_long loc;

	/* calculate the hash corresponding to the packet (map the key in to a table location) */
	loc = ip_hash(packet);
	/* check to see if we have to add a new entry */
	return(mss_dup_check(packet, table, loc));
}

struct mss_entry *mss_lookup_entry_dst(u_char * packet, struct mss_entry **table)
{
	u_long loc;

	/* calculate the hash corresponding to the packet (map the key in to a table location) */
	loc = ip_hash_dst(packet);
	/* check to see if we have to add a new entry */
	return(mss_dup_check_dst(packet, table, loc));
}
