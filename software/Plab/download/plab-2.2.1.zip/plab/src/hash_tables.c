/*
 *  $Id:$
 *
 *  hash_tables.c - Packet Lab: hash tables routines
 *
 *  Copyright (c) 2004 Alberto Dainotti, Antonio Pescap�, Alessio Botta
 *  Email: alberto@unina.it , pescape@unina.it , a.botta@unina.it
 *  DIS - Dipartimento di Informatica e Sistemistica (Computer Science Department)
 *  University of Naples Federico II
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include "plab.h"
#include "hash_tables.h"
#include "distros.h"
#include "output.h"

/*
 * This function takes an hash table and a pointer to a function as arguments.
 * It would walk through the hash table calling func(table_entry *entry) for each
 * table entry found.
 */
int ht_walk_through(struct table_entry **ht, int (* func)(struct table_entry *))
{
	int i;
	struct table_entry *entry;

	for(i = 0; i < HASH_TABLE_SIZE; i++) {
		entry = ht[i];
		while (entry) {
			func(entry);
			entry = entry->next;
		}
	}

	return(0);
}


/*
 * Similar to ht_walk_through but works with all sessions instead of entries.
 * This function takes an hash table and a pointer to a function as arguments.
 * It walks through the hash table calling func(session *s) for each
 * session of each table entry found.
 */
int ht_walk_through_s(struct table_entry **ht, int (* func)(struct session *))
{
	int i;
	struct table_entry *entry;
	struct session *s;

	for(i = 0; i < HASH_TABLE_SIZE; i++) {
		entry = ht[i];
		while (entry) {
			s = entry->last_session;
			while (s) {
				func(s);
				s = s->prev;
			}
			entry = entry->next;
		}
	}

	return(0);
}

/*
 * This is like ht_walk_through_s but allows the called function to delete
 * the passed session. For this reason the called function needs to be passed
 * the address of the session pointer.
 * Warning: the called function must return a value different from zero if 
 * deletes the session.
 */
int ht_walk_through_s_p(struct table_entry **ht, int (* func)(struct session **))
{
	int i;
	struct table_entry *entry;
	struct session **s;

	for(i = 0; i < HASH_TABLE_SIZE; i++) {
		entry = ht[i];
		while (entry) {
			s = &(entry->last_session);
			while (*s) {
				 /* If func() returns != 0 it means it has deleted the session */
				if (func(s) != 0)
					entry->num_sessions--;
				else
					s = &((*s)->prev);
			}
			entry = entry->next;
		}
	}

	return(0);
}



int session_walk_through(struct session *s, int (* func)(struct session *))
{
	while (s) {
		func(s);
		s = s->prev;
	}

	return(0);
}


int session_is_invalid(struct session *s)
{
	if (s->up_pkts < VALID_UP_PKTS) {
		return(1);
	}

	if (s->dw_pkts < VALID_DW_PKTS) {
		return(1);
	}

	return(0);
}


/*
 * Check if session is expired
 */
int session_expired(struct session *s, struct timeval ts)
{
	if (s) {
		if ((ts.tv_sec - s->ts_last.tv_sec) > pv.session_timeout) {
			PRINTDD("session expired\n");
			return (1);
		} else {
			PRINTDD("session NOT expired\n");
			return (0);
		}
	} else {
		return(0);
	}
}


int delete_session(struct session **s)
{
	struct session *ptr;

	if (*s) {
		/* session detach: link to previous session */
		ptr = *s;
		*s = ptr->prev;

		/* free session memory */
		free(ptr);

		stats.sessions--;
	}

	return(0);
}


/*
 * Initialize the hash table.
 * The hash table is an array of HASH_TABLE_SIZE pointers.
 * Where mapped key goes from 0 to HASH_TABLE_SIZE - 1
 * and each pointer points to an hash table entry
 */
void ht_init_table(struct table_entry **hash_table)
{
	int c;

	for (c = 0; c < HASH_TABLE_SIZE; c++) {
		hash_table[c] = NULL;
	}
}


/*
 * Hashing function.
 * Map the packet key (source + dest address) in to the table.
 * Return the table location
 */
u_long ht_hash(u_char * packet)
{
	int i;
	u_long j,k;

	/*
	for (i = 26, j = 0; i != 34; i++) {
		j = (j * 13) + packet[i];
	}
	*/

	/*
	 * Hash generation routine must give the same result for the same
	 * peers even if source and dest are swapped.
	 */

	/* XXX a rigore, per non assegnare alla stessa session due diverse
	 * sessioni quando entrambi i peer hanno server web ed entrambi
	 * navigano l'uno sull'altro (rarissimo, quasi impossibile) bisognerebbe
	 * fare cosi':
	 * - individuare prima quale dei due peer ha la porta 80, lo chiamiamo server, e poi fare
	 * un hash di server + client ordinati ed in modo che in ordine swappato diano
	 * un hash diverso.
	 * - oppure: mantenere il fatto che ordini diversi non danno problemi..(come
	 * nel codice qui scirtto)  pero'
	 * individuare quale dei due ha la porta 80 e farne l'hash di ip + porta , mentre
	 * per l'altro fare solo l'hash dell'ip.
	 */

	/* source ip
	for (i = 26, j = 0; i != 30; i++) {
		j += packet[i];
	}
	j = j * 13;
	dest ip
	for (i = 30, k = 0; i != 34; i++) {
		k += packet[i];
	}
	k = k * 13;
	*/
	/* source ip */
	for (i = 26, j = 0; i != 30; i++) {
		j = (j * 13) + packet[i];
	}
	/* dest ip */
	for (i = 30, k = 0; i != 34; i++) {
		k = (k * 13) + packet[i];
	}

	PRINTDD("ht_hash: generated hash: %ld\n", (j + k) % HASH_TABLE_SIZE);
	return ((j + k) % HASH_TABLE_SIZE);
}


/*
 * Verify if packet belongs to an existing table_entry in loc (mapped key).
 * If so, return the table_entry pointer.
 * Otherwise return NULL. In this case we have a collision or loc was unused.
 */
struct table_entry *ht_dup_check(u_char *packet, struct table_entry **hash_table, int loc)
{
	struct table_entry *p;

	for (p = hash_table[loc]; p; p = p->next) {
		if ((p->key[0] == packet[26] && p->key[1] == packet[27] &&
		    p->key[2] == packet[28] && p->key[3] == packet[29] &&
		    p->key[4] == packet[30] && p->key[5] == packet[31] &&
		    p->key[6] == packet[32] && p->key[7] == packet[33]) ||
		   (p->key[4] == packet[26] && p->key[5] == packet[27] &&
		    p->key[6] == packet[28] && p->key[7] == packet[29] &&
		    p->key[0] == packet[30] && p->key[1] == packet[31] &&
		    p->key[2] == packet[32] && p->key[3] == packet[33])) {
			/* this key is already in our table */
			return (p);
		}
	}
	/* this key has collided with another entry in our table or ht[loc] was NULL */
	return (NULL);
}


/*
 * Add a new table_entry to the table in position loc
 * Return the pointer to the new table_entry
 */
struct table_entry *ht_add_entry(u_char * packet, struct table_entry **hash_table, int loc)
{
	struct table_entry *p;

	if (hash_table[loc] == NULL) {
		/* this is the first entry in this location in the table */
		hash_table[loc] = malloc(sizeof(struct table_entry));
		if (hash_table[loc] == NULL) {
			perror("ht_add_entry");
			return (NULL);
		}

		p = hash_table[loc];
	} else {
		/* this is a chain, find the end of it */
		for (p = hash_table[loc]; p->next; p = p->next);
		p->next = malloc(sizeof(struct table_entry));
		if (p->next == NULL) {
			perror("ht_add_entry");
			return (NULL);
		}

		p = p->next;
	}

	/*
	 * Initialize table_entry
	 */
	p->key[0] = packet[26];
	p->key[1] = packet[27];
	p->key[2] = packet[28];
	p->key[3] = packet[29];
	p->key[4] = packet[30];
	p->key[5] = packet[31];
	p->key[6] = packet[32];
	p->key[7] = packet[33];

	p->id = stats.ht_entries++;
	PRINTDD("Generated a new entry: %s\n", iprintf(p->key)); 
	p->next = NULL;
	p->last_session = NULL;
	p->num_sessions = 0;

	return (p);
}


/*
 * Given a packet, get a pointer to the corresponding table_entry.
 * If necessary allocate and initialize a new entry.
 * On error return NULL.
 */
struct table_entry *ht_get_entry(u_char * packet, struct table_entry **hash_table)
{
	u_long n;
	struct table_entry *entry;

	/* calculate the hash corresponding to the packet (map the key in to a table location) */
	n = ht_hash(packet);

	/* check to see if we have to add a new entry */
	entry = ht_dup_check(packet, hash_table, n);
	if (entry == NULL) {
		entry = ht_add_entry(packet, hash_table, n);
	}

	return (entry);
}

