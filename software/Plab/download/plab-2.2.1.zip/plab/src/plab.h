/*
 *  $Id:$
 *
 *  plab.h
 *
 *  Copyright (c) 2004 Alberto Dainotti, Antonio Pescap�, Alessio Botta
 *  Email: alberto@unina.it , pescape@unina.it , a.botta@unina.it
 *  DIS - Dipartimento di Informatica e Sistemistica (Computer Science Department)
 *  University of Naples Federico II
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <string.h>
#include <pcap.h>
#include <signal.h>
#include <time.h>

#define _FILE_OFFSET_BITS 64
#define DEBUG
#define PROMISC         	1
#define DEFAULT_SNAPLEN		1514
#define TIMEOUT         	5
#define MAX_PAYLOAD    		1550		/* 1550 */

#define PRINT_STATUS		100000		/* Print status information each PRINT_STATUS pkts processed */

#ifdef DEBUG
#define PRINTD(...);		printf(__VA_ARGS__);
#else
#define PRINTD(...);
#endif
#define PRINTDD(...);			/* to make inactive a debugging command just add a second "D" :-) */

#define MIN(a,b)		(((a) < (b)) ? (a) : (b))
#define TICK(ts, sec)		(ts - (ts % sec))	/* find the nearest previous tick, with a resolution of sec */
#define TV_TO_QUAD(a)		(((u_quad_t)(a.tv_sec) * 1000000) + (u_quad_t)a.tv_usec) /* convert a timeval to an int */
#define TV_SUB_TO_QUAD(a,b)	(u_quad_t)(TV_TO_QUAD(a) - TV_TO_QUAD(b))	/* subtract 2 timevals and convert to int */

extern char *optarg;			/* for getopt */
extern int   optind;			/* for getopt */

struct program_variables {
	int readmode;			/* read pkts from a tcpdump file rathern than from network interface */
	char *sourcefile[50];		/* tcpdump format source files name */
	int writemode;			/* dump pkts in to a tcpdump file */
	char *destfile;			/* tcpdump format destination file name */
	char *basedestfile;			
	char *destfile_mid;			
	char *destfile_end;			
	int filter_disable;		/* disable pkt filtering (and subsequently pkt processing) */
	int mss;			/* Enable MSS detection */
	int split;			
	int splitter;			
	int process_disable;		/* disable pkt processing */
	int filter_tcp;			/* discard tcp pkts with 0 payload */
	char *device;			/* network interface to use */
	int snaplen;			/* capture only # bytes from each pkt */
	int mode;			/* light/heavy */
	u_long start_pkts;		/* start after # pkts */
	u_long stop_pkts;		/* stop after # pkts */
	long int session_timeout;	/* expressed in seconds */
	int resolution;			/* scale down interarrival timestamps by this factor: 1,10,100,1000 */
	char *directory;		/* directory where to store exported data */
	char *filter_file;		/* file from which to read pcap filter commands */
	int time_range;			/* capture only pkts with timestamp in specified time range */
	int day_of_week;		/* capture only pkts with timestamp in specified day of week */
	int tr_hmin;			/* time range min hour */
	int tr_mmin;			/* time range min minute */
	int tr_hmax;			/* time range max hour */
	int tr_mmax;			/* time range max minute */
	int quiet;			/* print less info */
	int rate;			/* dump stats each "rate" seconds */
	int idt_enabled;		/* compute interarrivals */
	int dump_headers;		/* when writing to a file, truncate pkts to TCP header end + dump_headers */
	int zero;			/* zero out ip addresses in dump */
	int pl_inspect;			/* payload inspection */
	int tz;				/* timezone + daylight saving imposed by user */
	int log_ip;			/* log ip addresses of client and server */
};
extern struct program_variables pv;

struct rate_s {
	u_quad_t up_pkts;
	u_quad_t dw_pkts;
	u_quad_t up_bytes;
	u_quad_t dw_bytes;
	u_quad_t sessions;
	u_quad_t up_tcppkts;
	u_quad_t dw_tcppkts;
	time_t tick;
	FILE *file;
};

struct statistics {
	u_quad_t pkts;
	u_quad_t discarded;
	u_quad_t frags;
	u_quad_t truncated;
	u_quad_t err_payload;
	u_quad_t ip_options;
	u_quad_t tcp_options;
	u_quad_t pure_tcp_pkts;
	u_quad_t skipped_sessions;
	u_quad_t skipped_pkts;
	u_long ht_entries;
	u_long mss_entries;
	u_long sessions;
	u_long up_pl_distro[MAX_PAYLOAD];		/* upstream payload distribution */
	u_long dw_pl_distro[MAX_PAYLOAD];		/* downstream payload distribution */
	FILE	*fs_idt_up;
	FILE	*fs_idt_dw;
	struct timeval tv_start;
	struct timeval tv_end;
	time_t cpu_start;		/* date & time when program was started */
	time_t cpu_end;			/* date & time when program finished processing data */
	int	interrupted;		/* program was interrupted by user (CTRL-C) */
	struct rate_s rate;		/* Rate statistics */
	FILE	*fs_pl_inspect;		/* File stream to dump payload inspection data */
	FILE	*fs_log_ip;		/* File stream to dump IPs */
	int	tzoff;			/* Time zone offset */
	FILE	*fs_session_iat;	/* File stream to dump session inter arrival times */
	struct timeval tv_last_session;	/* Timestamp of latest session arrival */
};
extern struct statistics stats;

struct table_entry;

/*
 * Function prototypes
 */
void parse_command_line(int, char **);
int process_packet(u_char *, const struct pcap_pkthdr, struct table_entry **hash_table);
extern void cleanup(int);
extern int catch_sig(int, void (*)());
extern char *copy_argv(char **);
void parse_command_line(int, char **);
int filter_packet(u_char *, const struct pcap_pkthdr);
int ip_cksum(u_short *, int);
int string_to_time_range(char *, int *, int *, int *, int *);
int rate(const struct pcap_pkthdr, int);
void rate_init();
int detect_mss(u_char *, const struct pcap_pkthdr);
char * read_infile(char *);
void next_file_name(struct pcap_pkthdr *);
int splitter(pcap_t *);
void hup(int);
struct tm *tztime(const time_t *);

/* EOF */
