/*
 *  $Id:$
 *
 *  mss.h - Packet Lab
 *
 *  Copyright (c) 2004 Alberto Dainotti, Antonio Pescap�, Alessio Botta
 *  Email: alberto@unina.it , pescape@unina.it , a.botta@unina.it
 *  DIS - Dipartimento di Informatica e Sistemistica (Computer Science Department)
 *  University of Naples Federico II
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#define MSS_TABLE_SIZE		24593	/* needs to be a prime number */

struct mss_entry {
	u_char	key[4];			/* key of this entry (src_ip) */
	int	id;
	u_long	mss;			/* */
	struct	mss_entry *next;	/* pointer to the next entry w/ different key but same mapping */
};


extern void mss_init_table(struct mss_entry **);
extern u_long ip_hash(u_char *);
extern u_long ip_hash_dst(u_char *);
extern struct mss_entry *mss_dup_check(u_char *, struct mss_entry **, int);
extern struct mss_entry *mss_dup_check_dst(u_char *, struct mss_entry **, int);
extern struct mss_entry *mss_add_entry(u_char *, struct mss_entry **, int);
extern struct mss_entry *mss_get_entry(u_char *, struct mss_entry **);
extern int mss_walk_through(struct mss_entry **ht, int (* func)(struct mss_entry *));
extern struct mss_entry *mss_lookup_entry_src(u_char *, struct mss_entry **);
extern struct mss_entry *mss_lookup_entry_dst(u_char *, struct mss_entry **);
