/*
 *  $Id:$
 *
 *  hash_tables.h - Packet Lab
 *
 *  Copyright (c) 2004 Alberto Dainotti, Antonio Pescap�, Alessio Botta
 *  Email: alberto@unina.it , pescape@unina.it, a.botta@unina.it*
 *  DIS - Dipartimento di Informatica e Sistemistica (Computer Science Department)
 *  University of Naples Federico II
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#define HASH_TABLE_SIZE 	1572869	/* needs to be a prime number */
#define VALID_UP_PKTS		4	/* minimum number of upstream pkts to make session valid */
#define VALID_DW_PKTS		2	/* minimum number of downstream pkts to make session valid */

struct session {
	int id;
	int entry_id;
	struct timeval ts_last;			/* timestamp of last pkt */
	struct timeval ts_start;		/* timestamp of first pkt */
	u_long up_pkts;				/* number of upstream pkts */
	u_long up_bytes;			/* number of upstream bytes */
	struct timeval up_ts_last;		/* timestamp of last upstream pkt */
	u_long dw_pkts;				/* number of downstream pkts */
	u_long dw_bytes;			/* number of downstream bytes */
	int mss;
	/*
	int mss_upstream;
	int mss_dwstream;
	*/
	struct timeval dw_ts_last;		/* timestamp of last downstream pkt */
	u_long peers;				/* number of peers */
	struct session *prev;			/* previous session (pointer to next linked list entry) */
	u_quad_t iat;				/* interarrival time wrt the previous session */
	int skip_session;			/* 1 if session must be skipped */
};

struct table_entry {
	u_char	key[8];			/* key of this entry (src_ip + dst_ip) */
	int	id;
	u_long	num_sessions;		/* number of sessions with this key */
	struct session	*last_session;	/* pointer to linked list of sessions */
	struct table_entry *next;	/* pointer to the next entry w/ different key but same mapping */
};


extern void ht_init_table(struct table_entry **);
extern u_long ht_hash(u_char *);
extern struct table_entry *ht_dup_check(u_char *, struct table_entry **, int);
extern struct table_entry *ht_add_entry(u_char *, struct table_entry **, int);
extern struct table_entry *ht_get_entry(u_char *, struct table_entry **);
extern int ht_walk_through(struct table_entry **ht, int (* func)(struct table_entry *));
extern int ht_walk_through_s(struct table_entry **ht, int (* func)(struct session *));
extern int session_walk_through(struct session *s, int (* func)(struct session *));
extern int purge_session(struct session **);
extern int ht_walk_through_s_p(struct table_entry **ht, int (* func)(struct session **));
int delete_session(struct session **);
int session_is_invalid(struct session *);
int session_expired(struct session *, struct timeval);


