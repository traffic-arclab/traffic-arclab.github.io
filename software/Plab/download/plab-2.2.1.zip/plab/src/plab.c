/*
 *  $Id:$
 *
 *  plab.c - Packet Lab
 *
 *  Copyright (c) 2004 Alberto Dainotti, Antonio Pescap�, Alessio Botta
 *  Email: alberto@unina.it , pescape@unina.it , a.botta@unina.it* *
 *  DIS - Dipartimento di Informatica e Sistemistica (Computer Science Department)
 *  University of Naples Federico II
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include "plab.h"
#include "pkt_macros.h"
#include "hash_tables.h"
#include "mss.h"
#include "distros.h"
#include "output.h"
#include "time.h"

/* These defines and include are necessary to have visibility of the pcap_t structure */
#define HAVE_SNPRINTF
#define HAVE_VSNPRINTF
#define HAVE_STRLCPY
#include "pcap-int.h"

struct program_variables pv;
struct statistics stats;
struct mss_entry *mss_table[MSS_TABLE_SIZE];
int loop = 1;
pcap_dumper_t *dumpd = NULL;

/*
 * Initialize program optional parameters and set them by parsing command line arguments.
 */
void parse_command_line(int argc, char **argv)
{
	int c;

	/* Inits */
	pv.device = NULL;
	pv.snaplen = DEFAULT_SNAPLEN;
	pv.readmode = 0;
	pv.writemode = 0;
	pv.destfile = NULL;
	pv.destfile_mid = NULL;
	pv.destfile_end = NULL;
	pv.basedestfile = NULL;
	pv.filter_disable = 0;
	pv.mss = 0;
	pv.process_disable = 0;
	pv.filter_tcp = 0;
	pv.start_pkts = 0;
	pv.stop_pkts = 0;
	pv.session_timeout = 0;
	pv.time_range = 0;
	pv.resolution = 1;
	pv.directory = NULL;
	pv.quiet = 0;
	pv.split = 0;
	pv.splitter = 0;
	pv.rate = 0;
	pv.idt_enabled = 1;
	pv.dump_headers = -1;
	pv.filter_file = NULL;
	pv.zero = 0;
	pv.pl_inspect = 0;
	pv.day_of_week = -1;
	pv.tz = -1;
	pv.log_ip = 0;

	while ((c = getopt(argc, argv, "0C:c:D:d:F:fIi:kmPpqR:r:S:s:T:t:u:W:w:XxZ:")) != EOF) {
		switch (c) {
		case '0':
			pv.zero = 1;
			break;
		case 'C':
			pv.start_pkts = atoi(optarg);
			break;
		case 'c':
			pv.stop_pkts = atoi(optarg);
			break;
		case 'D':
			pv.day_of_week = atoi(optarg);		/* 0-6 = Sun/Mon/Tue/Wed/Thu/Fri/Sat */
			break;
		case 'd':
			pv.directory = optarg;
			break;
		case 'f':
			pv.filter_disable = 1;
			break;
		case 'F':
			pv.filter_file = optarg;
			break;
		case 'i':
			pv.device = optarg;
			break;
		case 'I':
			pv.idt_enabled = 0;
			break;
		case 'k':
			pv.log_ip = 1;
			break;
		case 'm':
			pv.mss = 1;
			break;
		case 'P':
			pv.pl_inspect = 1;
			break;
		case 'p':
			pv.process_disable = 1;
			break;
		case 'q':
			pv.quiet++;
			break;
		case 'R':
			pv.rate = atoi(optarg);
			break;
		case 'r':
			pv.sourcefile[pv.readmode] = optarg;
			PRINTDD("sourcefile: %s\n", pv.sourcefile[pv.readmode]);
			pv.readmode++;
			break;
		case 's':
			pv.snaplen = atoi(optarg);
			break;
		case 'S':
			pv.split = atoi(optarg);
			break;
		case 't':
			pv.session_timeout = atoi(optarg);
			break;
		case 'T':
			pv.time_range = 1; 
			if (string_to_time_range(optarg, &pv.tr_hmin, &pv.tr_mmin, &pv.tr_hmax, &pv.tr_mmax)
			    < 0) {
				printf("Error in selected timerange syntax\n");
				exit(EXIT_FAILURE);
			}
			break;
		case 'u':
			switch(atoi(optarg)) {
				case 0:
					pv.resolution = 1;
					printf("logging interarrivals in microseconds\n");
					break;
				case 1:
					pv.resolution = 10;
					printf("logging interarrivals in tens of microseconds\n");
					break;
				case 2:
					pv.resolution = 100;
					printf("logging interarrivals in hundreds of microseconds\n");
					break;
				case 3:
					printf("logging interarrivals in milliseconds\n");
					pv.resolution = 1000;
					break;
				default:
					printf("invalid resolution factor\n");
					exit(EXIT_FAILURE);
			}
			break;
		case 'W':
			pv.dump_headers = atoi(optarg);
			break;
		case 'w':
			pv.basedestfile = optarg;
			pv.writemode = 1;
			break;
		case 'x':
			pv.filter_tcp = 1;
			printf("Discarding pure TCP packets.\n");
			break;
		case 'X':
			pv.splitter = 1;
			printf("Working as a splitter\n");
			break;
		case 'Z':
			pv.tz = atoi(optarg);				/* seconds ! (es. 3600) */
			printf("User requested timezone: %d\n", pv.tz);
			break;
		default:
			/* XXX print_help(); */
			printf("Unknown command line option.\n");
			exit(EXIT_FAILURE);
		}
	}
}


/*****************************************************************************************************/
int splitter(pcap_t *p)
{
	u_char *packet;
	struct pcap_pkthdr h;
	/* struct stat buf; */

	loop = 1;
	while (loop) {
		/*
		 *  pcap_next() gives us the next packet from pcap's internal packet buffer.
		 */
		packet = (u_char *) pcap_next(p, &h); 
		if (packet == NULL) {
			/*
			 *  We have to be careful here as pcap_next() can return NULL
			 *  if the timer expires with no data in the packet buffer or
			 *  in some special circumstances with linux.
			 */
			if (!pv.readmode) {
				continue;
			} else {
				loop = 0;
				continue;
			}
		}

		/*
		 * Increment counters
		 * XXX Check for overflows !
		 */
		stats.pkts++;

		/*
		 * Start to process only after # packets, if specified by user
		if (pv.start_pkts != 0) {
			if (stats.pkts < pv.start_pkts) {
				continue;
			}
		}
		 */

		/*
		 * Stop processing after # packets, if specified by user
		if (pv.stop_pkts != 0) {
			if (stats.pkts > pv.stop_pkts) {
				loop = 0;
				stats.pkts--;
				continue;
			}
		}
		*/

		
		/*
		 * Print some information each PRINT_STATUS pkts sniffed
		if (stats.pkts % PRINT_STATUS == 0) {
			printf("pkts: %u ", stats.pkts);
			printf("c-s: %u ", stats.ht_entries);
			printf("sessions: %u ", stats.sessions);
			printf("%s", ctime(&(h.ts.tv_sec)));
		}
		*/

		/*
		 * Dump pkt on a file in tcpdump format
		 */
			/*
			 * Do we want to split dump in several files ?
			 */
			if (stats.pkts % 20000000 == 0) {
				/* Check if current size is larger than pv.split
				if (stat(pv.destfile, &buf) < 0) {
					perror("stat");
					exit(1);
				}
				if (buf.st_size > pv.split) {
				*/
					/* Close current file */
					pcap_dump_close(dumpd);
					/* Calculate new file name */
					next_file_name(&h);
					/* Open new file */
					dumpd = pcap_dump_open(p, pv.destfile);
					if (dumpd == NULL) {
						printf("error opening output file: %s\n", pcap_geterr(p));
						pcap_close(p);
						exit(EXIT_FAILURE);
					}
					printf("Writing to file %s\n", pv.destfile);
				/*
				}
				*/
			}
			/* 
			 * Truncate packet before dump.
			 * Stop at the end of TCP header + pv.dump_headers
			if (pv.dump_headers != -1) {
				h.caplen = MIN(h.caplen, 14 + PKT_IP_HLEN_B(packet) +
				    PKT_TCP_HLEN_B(packet) + pv.dump_headers);
			}
			*/
			pcap_dump((u_char *)dumpd, &h, packet);

	} /* main loop */

	return(0);
}

/*****************************************************************************************************/

/*
 * Packet capture loop
 */
int main_loop(pcap_t *p, struct table_entry **hash_table)
{
	u_char *packet;
	struct pcap_pkthdr h;
	struct stat buf;

	loop = 1;
	while (loop) {
		/*
		 *  pcap_next() gives us the next packet from pcap's internal packet buffer.
		 */
		packet = (u_char *) pcap_next(p, &h); 
		if (packet == NULL) {
			/*
			 *  We have to be careful here as pcap_next() can return NULL
			 *  if the timer expires with no data in the packet buffer or
			 *  in some special circumstances with linux.
			 */
			if (!pv.readmode) {
				continue;
			} else {
				loop = 0;
				continue;
			}
		}

		/*
		 * Increment counters
		 * XXX Check for overflows !
		 */
		stats.pkts++;

		/*
		 * Update first and last packet timestamps.
		 * Also, some inits must be done when the first packet is seen.
		 */
		if (stats.pkts == 1) {
			stats.tv_start = h.ts;
			if (pv.rate) {
				/* Set first tick */
				stats.rate.tick = TICK(h.ts.tv_sec, pv.rate);
			}
			stats.tv_last_session = h.ts;
		}
		stats.tv_end = h.ts;

		/*
		 * Start to process only after # packets, if specified by user
		 */
		if (pv.start_pkts != 0) {
			if (stats.pkts < pv.start_pkts) {
				continue;
			}
		}

		/*
		 * Stop processing after # packets, if specified by user
		 */
		if (pv.stop_pkts != 0) {
			if (stats.pkts > pv.stop_pkts) {
				loop = 0;
				stats.pkts--;
				continue;
			}
		}

		PRINTDD("cap: %d wire: %d iptlen: %d\n", h.caplen, h.len, PKT_IP_TLEN_B(packet));

		/* 
		 * Check if rate counters need to be dumped and reset
		 */
		if (pv.rate) {
			rate(h, pv.rate);
		}
		
		/*
		 * Print some information each PRINT_STATUS pkts sniffed
		 */
		if (stats.pkts % PRINT_STATUS == 0) {
			printf("pkts: %qu ", stats.pkts);
			printf("c-s: %lu ", stats.ht_entries);
			printf("sessions: %lu ", stats.sessions);
			printf("%s", asctime(tztime(&(h.ts.tv_sec))));
			/* system("ps axuw | grep \"./plab\" | grep -v grep"); */
		}

		/*
		 * If we disable filtering we cannot process packets because packet processor
		 * doesn't know how to work with some kind of packets.
		 * But we could disable packet processing and keep filtering. 
		 */
		if (!pv.filter_disable) {
			/* Filter packet */
			if (filter_packet(packet, h)) {
				stats.discarded++;
				continue;
			} else {
				if (!pv.process_disable)
					/* Process packet */
					process_packet(packet, h, hash_table);
			}
		}

		/*
		 * Dump pkt on a file in tcpdump format
		 */
		if (pv.writemode) {
			/*
			 * Do we want to split the dump in several files ?
			 * Based on file size.
			 */
			if ((pv.split) && (stats.pkts % 100000 == 0)) {
				/* Check if current file size is larger than pv.split */
				if (stat(pv.destfile, &buf) < 0) {
					perror("stat");
					exit(1);
				}
				if (buf.st_size > pv.split) {
					/* Close current file */
					pcap_dump_close(dumpd);
					/* Calculate new file name */
					next_file_name(&h);
					/* Open new file */
					dumpd = pcap_dump_open(p, pv.destfile);
					if (dumpd == NULL) {
						printf("error opening output file: %s\n", pcap_geterr(p));
						pcap_close(p);
						exit(EXIT_FAILURE);
					}
					printf("Writing to file %s\n", pv.destfile);
				}
			}
			/* 
			 * Truncate packet before dump.
			 */
			if (pv.dump_headers != -1) {
			 	/* Stop at the end of TCP header + pv.dump_headers */
				h.caplen = MIN(h.caplen, 14 + PKT_IP_HLEN_B(packet) +
				    PKT_TCP_HLEN_B(packet) + pv.dump_headers);
			} else {
			 	/* Stop at user-supplied snaplen (it makes sense when reading from file) */
				h.caplen = MIN(h.caplen, pv.snaplen);
			}
			/*
			 * If requested zero out ip addresses to preserve privacy.
			 * Warning: checksums become wrong !
			 */
	 		if (pv.zero) {
				memset(&packet[26], 0, 8);
			}	
			pcap_dump((u_char *)dumpd, &h, packet);
		}

	} /* main loop */

	return(0);
}


int main(int argc, char **argv)
{
	pcap_t *p;		/* pcap descriptor */
	struct pcap_stat ps;
	char errbuf[PCAP_ERRBUF_SIZE];
	struct bpf_program filter_code;
	bpf_u_int32 local_net, netmask;
	bpf_u_int32 defaultnet = 0x00000000;	/* 0xFFFFFF00 */
	char path[200];
	char	*pcap_cmd;
	struct table_entry *hash_table[HASH_TABLE_SIZE];
	int loops = 0;

	/*
	 * Inits
	 */
	stats.pkts = 0;
	stats.discarded = 0;
	stats.frags = 0;
	stats.err_payload = 0;
	stats.truncated = 0;
	stats.tcp_options = 0;
	stats.ip_options = 0;
	stats.ht_entries = 0;
	stats.mss_entries = 0;
	stats.sessions = 0;
	stats.pure_tcp_pkts = 0;
	stats.interrupted = 0;
	stats.skipped_sessions = 0;
	stats.skipped_pkts = 0;
	distro_pl_init(stats.up_pl_distro);
	distro_pl_init(stats.dw_pl_distro);
	ht_init_table(hash_table);
	mss_init_table(mss_table);

	printf("Plab 1.0 [Packet level flow analyzer]\n");
	printf("<ctrl-c> (SIGINT) to quit\n");

	/*
	 * Read options from command line
	 */
	parse_command_line(argc, argv);

	/*************** XXX START OF INIT FUNCTION **********/
	/*
	 * Open dump files
	 */
	if (pv.directory) {
		mkdir(pv.directory, 0755);
	} else {
		pv.directory = malloc(1);
		sprintf(pv.directory, ".");
	}

	if (!pv.process_disable) {
		if (pv.idt_enabled) {
			sprintf(path, "%s/%s", pv.directory, "up.micro");
			stats.fs_idt_up = fopen(path, "w");
			if (stats.fs_idt_up == NULL) {
				perror("error opening idt up file");
				exit(EXIT_FAILURE);
			}
			sprintf(path, "%s/%s", pv.directory, "dw.micro");
			stats.fs_idt_dw = fopen(path, "w");
			if (stats.fs_idt_dw == NULL) {
				perror("error opening idt dw file");
				exit(EXIT_FAILURE);
			}
		}

		/* Initialize rate subsystem */
		if (pv.rate) {
			/* Open dump file */
			sprintf(path, "%s/%s", pv.directory, "rate");
			stats.rate.file = fopen(path, "w");
			if (stats.rate.file == NULL) {
				perror("error opening rate file");
				exit(EXIT_FAILURE);
			}
			rate_init();
		}

		/* Open payload inspection dump file */
		if (pv.pl_inspect) {
			sprintf(path, "%s/%s", pv.directory, "payloads");
			stats.fs_pl_inspect = fopen(path, "w");
			if (stats.fs_pl_inspect == NULL) {
				perror("error opening rate file");
				exit(EXIT_FAILURE);
			}
		}

		/* Open payload inspection dump file */
		if (pv.log_ip) {
			sprintf(path, "%s/%s", pv.directory, "IPs");
			stats.fs_log_ip = fopen(path, "w");
			if (stats.fs_log_ip == NULL) {
				perror("error opening rate file");
				exit(EXIT_FAILURE);
			}
		}

		/* Open session inter-arrival times dump file */
		sprintf(path, "%s/%s", pv.directory, "session_iat");
		stats.fs_session_iat = fopen(path, "w");
		if (stats.fs_session_iat == NULL) {
			perror("error opening session_iat file");
			exit(EXIT_FAILURE);
		}
	}

	/*
	 *  We want to catch the interrupt signal so we can inform the user
	 *  how many packets we captured before we exit.
	 *  XXX We should probably clean up memory and free up the hashtable
	 *  before we go.
	 */
	if (catch_sig(SIGINT, cleanup) == -1) {
		fprintf(stderr, "can't catch SIGINT signal.\n");
		exit(EXIT_FAILURE);
	}
	/*
	 * Catch SIGHUP to null so we can detach from shell
	 */
	if (catch_sig(SIGHUP, hup) == -1) {
		fprintf(stderr, "can't catch SIGHUP signal.\n");
		exit(EXIT_FAILURE);
	}

	/*
	 *  If device is NULL, that means the user did not specify one and is
	 *  leaving it up libpcap to find one.
	 */
	if ( (pv.device == NULL) && (!pv.readmode)) {
		pv.device = pcap_lookupdev(errbuf);
		if (pv.device == NULL) {
			fprintf(stderr, "pcap_lookupdev() failed: %s\n", errbuf);
			exit(EXIT_FAILURE);
		}
	}
	
	/* Initialize the timezone environment */
	tzset();
	if (pv.tz >= 0) {
		timezone = - pv.tz;
	}

	/* Record start of packet processing date/time */
	stats.cpu_start = time(NULL);
	/*************** XXX END OF INIT FUNCTION **********/

	/* 
	 * Repeat packet capturing loop for each source file.
	 * Do it just once for network sniffing.
	 */
	do {
		/*
		 *  Open the packet capturing device
		 */
		if (!pv.readmode) {
			printf("reading from device %s with snaplen %d\n", pv.device, pv.snaplen);
			p = pcap_open_live(pv.device, pv.snaplen, PROMISC, TIMEOUT, errbuf);
			p->tzoff = - timezone;
			printf("Capturing with TimeZone offset: %d\n", p->tzoff);
		} else {
			printf("reading from file %s\n", pv.sourcefile[loops]);
			p = pcap_open_offline(pv.sourcefile[loops], errbuf);
			printf("File has TimeZone offset: %d\n", p->tzoff);
		}
		if (p == NULL) {
			fprintf(stderr, "pcap_open_xxxx() failed: %s\n", errbuf);
			exit(EXIT_FAILURE);
		}

		/* Set the timezone offset used by program */
		if (- timezone != p->tzoff) {
			/* It can happen only in readmode */
			printf("Warning: current timezone (%ld) differs from pcap file header timezone (%d)\n",
			    - timezone, p->tzoff);
			/* XXX case (option) */
			printf("Using current timezone (%ld) to store timestamps\n", - timezone);
			stats.tzoff = - timezone;
		} else {
			/* Live or offline */
			stats.tzoff = - timezone;
		}

		/*
		 *  Set the BPF filter.
		 */
		if (pv.filter_file) {
			pcap_cmd = read_infile(pv.filter_file);
		} else {
			pcap_cmd = copy_argv(&argv[optind]);
		}
		printf("pcap command: %s\n", pcap_cmd);
		if (pcap_lookupnet(pv.device, &local_net, &netmask, errbuf) == -1) {
			printf("pcap_lookupnet() failed: %s\n", errbuf);
			netmask = htonl(defaultnet);
		}
		if (pcap_compile(p, &filter_code, pcap_cmd, 1, netmask) == -1) {
			fprintf(stderr, "pcap_compile() failed: %s\n", pcap_geterr(p));
			pcap_close(p);
			exit(EXIT_FAILURE);
		}
		if (pcap_setfilter(p, &filter_code) == -1) {
			fprintf(stderr, "pcap_setfilter() failed: %s\n", pcap_geterr(p));
			pcap_close(p);
			exit(EXIT_FAILURE);
		}

		/* Print info on source data link (defines are in libpcap/bpf/net/bpf.h) */
		printf("Datalink type: %d (1 = Ethernet)\n", pcap_datalink(p));

		/*
		 * Open output dump file.
		 * Warning: If we read from multiple
		 * input files then they MUST have the same timezone and snaplen, otherwise behaviour
		 * is not consistent anymore. This happens because we copy some data from the first input
		 * file header to the output file header (look at pcap_dump() code in libpcap for more).
		 */
		if ((dumpd == NULL) && pv.basedestfile) {
			if ((pv.split) || (pv.splitter)) {
				pv.destfile = malloc(strlen(pv.basedestfile) + 30 + 14);
				if (pv.destfile == NULL) {
					perror("destfile+30");
					exit(1);
				}
				strcpy(pv.destfile, pv.basedestfile);
				pv.destfile_mid = pv.destfile + strlen (pv.basedestfile);
				pv.destfile_end = pv.destfile_mid + 3;
				memset(pv.destfile_mid, 0, 30 + 14);
				pv.destfile_mid[0] = '.';
				pv.destfile_mid++;
				pv.destfile_mid[0] = 'a';
				pv.destfile_mid[1] = 'a' - 1;
				next_file_name(NULL);
			} else {
				pv.destfile = pv.basedestfile;
			}
			dumpd = pcap_dump_open(p, pv.destfile);
			if (dumpd == NULL) {
				printf("error opening output file: %s\n", pcap_geterr(p));
				pcap_close(p);
				exit(EXIT_FAILURE);
			}
			printf("Writing to file %s\n", pv.destfile);
		}

		if (pv.splitter)
			splitter(p);
		else
		/*
		 * Packet capture loop: get packets and analyze them.
		 */
		main_loop(p, hash_table);

		/*
		 *  Finished to examine packets. It's time to dump statistics.
		 */
		if (pcap_stats(p, &ps) == -1) {
			if (!pv.readmode)
				fprintf(stderr, "pcap_stats() failed: %s\n", pcap_geterr(p));
		} else {
			/*
			 *  Remember that the ps statistics change slightly depending on
			 *  the underlying architecture.  We gloss over that here.
			 */
			printf("\nPackets received by libpcap:\t%6d\n"
			    "Packets dropped by libpcap:\t%6d\n", ps.ps_recv, ps.ps_drop);
		}

		pcap_close(p);
		loops++;

	} while (loops < pv.readmode);

	/* XXX Everything from here should probably go in cleanup() .. */
	/* Record date when program finished packet processing */
	stats.cpu_end = time(NULL);
	
	if (!pv.process_disable) {
		/* Close output dump file */
		if (dumpd != NULL)
			pcap_dump_close(dumpd);
		/* Close interarrivals dump files */
		if (pv.idt_enabled) {
			fclose(stats.fs_idt_up);
			fclose(stats.fs_idt_dw);
		}
		/* Close rate dump file */
		if (pv.rate)
			fclose(stats.rate.file);
		/* Close payload inspection dump file */
		if (pv.pl_inspect)
			fclose(stats.fs_pl_inspect);
		/* Close IPs dump file */
		if (pv.log_ip)
			fclose(stats.fs_log_ip);
		/* Close session inter-arrival times dump file */
		fclose(stats.fs_session_iat);

		/* Dump sessions data: pkts, bytes, durations */
		dump_sessions_data(hash_table, "sessions_data");
		/* Dump payloads PDFs */
		dump_pl_distro(stats.up_pl_distro, "upstream_pl");
		dump_pl_distro(stats.dw_pl_distro, "downstream_pl");
		/* Dump summary text */
		dump_report(argc, argv, "report.txt");
	}	
	display_stats();

	return (EXIT_SUCCESS);
}

u_char *pkt_payload(u_char *packet, const struct pcap_pkthdr head)
{
	char *string;
	int size, i;

	/* Size can be negative if TCP header has not been captured totally */
	size = head.caplen - PKT_IP_HLEN_B(packet) - PKT_TCP_HLEN_B(packet) - 14;

	if (size > 0) {
		string = malloc(size + 1);
		snprintf(string, size + 1, "%s", &packet[PKT_IP_HLEN_B(packet) + PKT_TCP_HLEN_B(packet) + 14]);

		/* Substitute all '\n' in string except the last one */
		for (i = 0; i <= strlen(string); i++) {
			if (string[i] == '\n')
				string[i] = '@';
		}
	} else {
		string = malloc(2);
		string[0] = '@';
		string[1] = '\0';
	}

	return(string);
}

int pkt_payload_is_alpha(u_char *packet, const struct pcap_pkthdr head)
{
	int size, alpha;

	/* Size can be negative if TCP header has not been captured totally */
	size = head.caplen - PKT_IP_HLEN_B(packet) - PKT_TCP_HLEN_B(packet) - 14;

	if (size > 0) {
		if (
		    ( (packet[PKT_IP_HLEN_B(packet) + PKT_TCP_HLEN_B(packet) + 14] > 64) &&
		      (packet[PKT_IP_HLEN_B(packet) + PKT_TCP_HLEN_B(packet) + 14] < 91) ) ||
		    ( (packet[PKT_IP_HLEN_B(packet) + PKT_TCP_HLEN_B(packet) + 14] > 96) &&
		      (packet[PKT_IP_HLEN_B(packet) + PKT_TCP_HLEN_B(packet) + 14] < 123) ) 
		   )
			alpha = 1;
		else
			alpha = 0;
	} else {
		alpha = 0;
	}

	return(alpha);
}


struct tm *tztime(const time_t *time) {
	time_t tmp_time_t;

	tmp_time_t = *time + stats.tzoff;
	return(gmtime(&tmp_time_t));
}

int process_packet(u_char *packet, const struct pcap_pkthdr head, struct table_entry **hash_table)
{
	struct table_entry *entry;
	struct session *tmp;
	struct session *s;
	u_int pl;

	/* get the corresponding table entry for the given packet */
	entry = ht_get_entry(packet, hash_table);
	if (entry == NULL) {
		printf("process_packet: error getting corresponding table entry\n");
		return(-1);
	}

	/*
	 * If there are no stored sessions OR last session expired then START A NEW SESSION.
	 */
	/*
	if ((entry->last_session == NULL) || (session_expired(entry->last_session, head.ts))) {
	*/
	if (
	    (entry->last_session == NULL) || 
	    (
	     PKT_IS_HTTP_UPSTREAM(packet) && 
	     (entry->last_session->up_pkts > 0) &&
	     ((head.ts.tv_sec - entry->last_session->up_ts_last.tv_sec) > pv.session_timeout)
	    ) ||
	    (
	     PKT_IS_HTTP_DOWNSTREAM(packet) &&
	     (entry->last_session->dw_pkts > 0) &&
	     ((head.ts.tv_sec - entry->last_session->dw_ts_last.tv_sec) > pv.session_timeout)
	    )
	   ) {
		/***************************************/
		/* sgrudu */
		/* The old session expired. Save the session's T_OFF 
		if (entry->last_session)
			entry->last_session->t_off = head.ts.tv_sec - entry->last_session->ts_last.tv_sec;
		*/
		/***************************************/

		/* create a new session XXX should become a function */
		tmp = entry->last_session;
		entry->last_session = malloc(sizeof(struct session));
		if (entry->last_session == NULL) {
			perror("process_packet");
			return(-1);
		}
		/* initialize session data */
		/* XXX Fixed. But please recheck
		entry->last_session->id = entry->num_sessions++;
		*/
		/* Count sessions belonging to this entry */
		entry->num_sessions++; 
		entry->last_session->id = stats.sessions++;
		entry->last_session->entry_id = entry->id;
		entry->last_session->prev = tmp;
		entry->last_session->ts_start = head.ts;
		/* entry->last_session->t_off = 0; */
		entry->last_session->up_pkts = 0;
		entry->last_session->up_bytes = 0;
		entry->last_session->dw_pkts = 0;
		entry->last_session->dw_bytes = 0;
		entry->last_session->peers = 0;

		PRINTDD("started a new session [%d][%d]\n", entry->id, entry->last_session->id);

		/*
		 * Assign an MSS to the session
		 * XXX Should become a function
		 */
		if (pv.mss) {
			struct mss_entry *m_entry;
			int mss_src, mss_dst;
			m_entry = mss_lookup_entry_src(packet, mss_table);
			if (m_entry) {
				PRINTDD("SRC MSS HIT\n");
				mss_src = m_entry->mss;
			} else {
				PRINTDD("SRC MSS MISS\n");
				mss_src = 536;
			}
			m_entry = mss_lookup_entry_dst(packet, mss_table);
			if (m_entry) {
				PRINTDD("DEST MSS HIT\n");
				mss_dst = m_entry->mss;
			} else {
				PRINTDD("DEST MSS MISS\n");
				mss_dst = 536;
			}

			entry->last_session->mss = MIN(mss_src, mss_dst);
			/*
			if PKT_IS_HTTP_UPSTREAM(packet) {
				source is the client
				PRINTDD("LOOKUP UPSTREAM\n");
				entry->last_session->mss_upstream = mss_src;
				entry->last_session->mss_dwstream = mss_dst;
				PRINTDD("%d\t\t\t%d\n", mss_src, mss_dst); 
			} else {
				PRINTDD("LOOKUP DWSTREAM\n");
				source is the server
				entry->last_session->mss_upstream = mss_dst;
				entry->last_session->mss_dwstream = mss_src;
				PRINTDD("%d\t\t\t%d\n", mss_src, mss_dst); 
			}
			PRINTDD("client: %d server: %d\n", entry->last_session->mss_upstream, entry->last_session->mss_dwstream);
			*/
		} else {
			entry->last_session->mss = 0;
		}

		/* XXX MOVED XXX update total session count
		stats.sessions++;
		PRINTDD("started a new session [%d][%d]\n", entry->id, entry->last_session->id);
		*/

		if (pv.rate) {
			stats.rate.sessions++;
		}

		/*
		 * Dump payload contents
		 * Choose if session must be skipped
		 */
		if (pv.pl_inspect) {
			if (PKT_IS_HTTP_UPSTREAM(packet)) {
				fprintf(stats.fs_pl_inspect, "%d U %s\n", entry->last_session->id,
				    pkt_payload(packet, head));
				/* If the first payload byte is not an alpha then skip the session */
				entry->last_session->skip_session = !pkt_payload_is_alpha(packet, head);
			} else if (PKT_IS_HTTP_DOWNSTREAM(packet)) {
				fprintf(stats.fs_pl_inspect, "%d D %s\n", entry->last_session->id,
				    pkt_payload(packet, head));
				/* If the session start with a downstream pkt then skip the session */
				entry->last_session->skip_session = 1;
			}
		} else {
			entry->last_session->skip_session = 0;
		}

		if (! entry->last_session->skip_session) {
			/* 
			 * Calculate and dump session interarrival time
			 */
			fprintf(stats.fs_session_iat, "%d%.2d%.2d-%.2d:%.2d.%.2d %qu\n",
			    tztime(&(head.ts.tv_sec))->tm_year + 1900,
			    tztime(&(head.ts.tv_sec))->tm_mon + 1,
			    tztime(&(head.ts.tv_sec))->tm_mday,
			    tztime(&(head.ts.tv_sec))->tm_hour,
			    tztime(&(head.ts.tv_sec))->tm_min,
			    tztime(&(head.ts.tv_sec))->tm_sec,
			    TV_SUB_TO_QUAD(head.ts, stats.tv_last_session));
			entry->last_session->iat = TV_SUB_TO_QUAD(head.ts, stats.tv_last_session);
			stats.tv_last_session = head.ts;
	
			/*
			 * Dump client-server IP address pair
			 */
			if (pv.log_ip) {
				if (PKT_IS_HTTP_UPSTREAM(packet)) {
					fprintf(stats.fs_log_ip, "%d %d.%d.%d.%d %d.%d.%d.%d\n",
						entry->last_session->id,
					       	packet[26], packet[27], packet[28], packet[29],
						packet[30], packet[31], packet[32], packet[33]); 
				} else if (PKT_IS_HTTP_DOWNSTREAM(packet)) {
					fprintf(stats.fs_log_ip, "%d %d.%d.%d.%d %d.%d.%d.%d\n",
						entry->last_session->id,
						packet[30], packet[31], packet[32], packet[33],
					       	packet[26], packet[27], packet[28], packet[29]);
				}
			}
		} else {
			/* accidenti conta pacchetti skippati */
			stats.skipped_sessions++;
		}
	} /* End of new session setup */

	/* just for ease: copy session pointer */
	s = entry->last_session;

	/* If session must be skipped do not process the packet and do not update counters */
	if (s->skip_session) {
		/* accidenti conta pacchetti skippati */
		stats.skipped_pkts++;
		return(1);
	}

	/*
	 * Update session data
	 */
	pl = PKT_TCP_PAYLOAD_B(packet);			/* To spare processing power */
	if (PKT_IS_HTTP_UPSTREAM(packet)) {
		if (pv.idt_enabled) {
			/* Update upstream IPT/PL/MSS distros */
			if (s->up_pkts > 0) {
				fprintf(stats.fs_idt_up, "%d %qu %d %d\n", s->id, TV_SUB_TO_QUAD(head.ts, s->up_ts_last), pl, s->mss);
			} else {
				fprintf(stats.fs_idt_up, "%d -1 %d %d\n", s->id, pl, s->mss);
			}
		}
		/* Update upstream payload compressed distro */
		stats.up_pl_distro[pl]++;

		s->up_ts_last = head.ts;
		s->up_pkts++;
		s->up_bytes += pl;

		if (pv.rate) {
			stats.rate.up_bytes += pl;
			stats.rate.up_pkts++;
		}
	} else if (PKT_IS_HTTP_DOWNSTREAM(packet)) {
		if (pv.idt_enabled) {
			/* Update downstream IPT/PL/MSS distros */
			if (s->dw_pkts > 0) {
				fprintf(stats.fs_idt_dw, "%d %qu %d %d\n", s->id, TV_SUB_TO_QUAD(head.ts, s->dw_ts_last), pl, s->mss);
			} else {
				fprintf(stats.fs_idt_dw, "%d -1 %d %d\n", s->id, pl, s->mss);
			}
		}
		/* Update downstream payload compressed distro */
		stats.dw_pl_distro[pl]++;

		s->dw_ts_last = head.ts;
		s->dw_pkts++;
		s->dw_bytes += pl;

		if (pv.rate) {
			stats.rate.dw_bytes += pl;
			stats.rate.dw_pkts++;
		}
	}
	s->ts_last = head.ts;

#ifdef TODO
	/* for statistics and analysis count number of peers of each session */
	if (/* XXX check if it is a new peer */) {
		/* add it to the current list (key.current_session_peer_hash_table) */
		s->peers++;
	}
#endif
	return(1);
}


void cleanup(int signo)
{
	loop = 0;
	stats.interrupted = 1;
	printf("INTerrupt signal caught...\n");
}


void hup(int signo)
{
	printf("HUP signal caught...\n");
}


int catch_sig(int signo, void (*handler) ())
{
	struct sigaction action;

	action.sa_handler = handler;
	sigemptyset(&action.sa_mask);
	action.sa_flags = 0;

	if (sigaction(signo, &action, NULL) == -1) {
		return (-1);
	} else {
		return (1);
	}
}


/*
 *
 * Purpose: Copies a 2D array (like argv) into a flat string.  Stolen from
 *          TCPDump.
 *
 * Arguments: argv => 2D array to flatten
 *
 * Returns: Pointer to the flat string
 *
 */
char *copy_argv(char **argv)
{
	char **p;
	u_int len = 0;
	char *buf;
	char *src, *dst;
	void ftlerr(char *,...);

	p = argv;
	if(*p == 0)
	    return 0;

	while(*p)
	    len += strlen(*p++) + 1;

	buf = (char *) malloc(len);

	if(buf == NULL) {
		printf("copy_argv: malloc() failed: %s\n", strerror(errno));
		exit(1);
	}
	p = argv;
	dst = buf;

	while((src = *p++) != NULL) {
	    while((*dst++ = *src++) != '\0');
	    dst[-1] = ' ';
	}

	dst[-1] = '\0';

	return buf;
}

char * read_infile(char *fname)
{
	register int fd, cc;
	register char *cp;
	struct stat buf;

	fd = open(fname, O_RDONLY);
	if (fd < 0) {
		printf("can't open %s: %s", fname, pcap_strerror(errno));
		exit(1);
	}

	if (fstat(fd, &buf) < 0) {
		printf("can't stat %s: %s", fname, pcap_strerror(errno));
		exit(1);
	}

	cp = malloc((u_int)buf.st_size + 1);
	if (cp == NULL) {
		printf("malloc(%d) for %s: %s", (u_int)buf.st_size + 1,
			fname, pcap_strerror(errno));
		exit(1);
	}
	cc = read(fd, cp, (u_int)buf.st_size);
	if (cc < 0) {
		printf("read %s: %s", fname, pcap_strerror(errno));
		exit(1);
	}
	if (cc != buf.st_size) {
		printf("short read %s (%d != %d)", fname, cc, (int)buf.st_size);
		exit(1);
	}
	cp[(int)buf.st_size] = '\0';

	return (cp);
}

/*
 * IP header checksum.
 * Taken from Libnet.
 */
int ip_cksum(u_short *addr, int len)
{
	int sum;
	int nleft;
	u_short ans;
	u_short *w;

	sum = 0;
	ans = 0;
	nleft = len;
	w = addr;

	while (nleft > 1) {
		sum += *w++;
		nleft -= 2;
	}
	
	if (nleft == 1) {
		*(u_char *)(&ans) = *(u_char *)w;
		sum += ans;
	}
	
	return(sum = (sum >> 16) + (sum & 0xffff), (~(sum + (sum >> 16)) & 0xffff));
}


int string_to_time_range(char *opt, int *hmin, int *mmin, int *hmax, int *mmax)
{
	char tmp[3] = "00\0";

	/* At least check for separators */
	if ((opt[2] != ':') || (opt[5] != '-') || (opt[8] != ':')) {
		return(-1);
	}

	tmp[0] = opt[0];
	tmp[1] = opt[1];
	*hmin = atoi(tmp);
	
	tmp[0] = opt[3];
	tmp[1] = opt[4];
	*mmin = atoi(tmp);
	
	tmp[0] = opt[6];
	tmp[1] = opt[7];
	*hmax = atoi(tmp);
	
	tmp[0] = opt[9];
	tmp[1] = opt[10];
	*mmax = atoi(tmp);

	PRINTDD("%d %d %d %d\n", pv.tr_hmin, pv.tr_mmin, pv.tr_hmax, pv.tr_mmax);

	return(0);
}

/*
 * Convert a string in the form "hh:mm:ss:MM:yyyy"
 * struct tm {
 *                     int     tm_sec;         * seconds *
 *                     int     tm_min;         * minutes *
 *                     int     tm_hour;        * hours *
 *                     int     tm_mday;        * day of the month *
 *                     int     tm_mon;         * month *
 *                     int     tm_year;        * year *
 *                     int     tm_wday;        * day of the week *
 *                     int     tm_yday;        * day in the year *
 *                     int     tm_isdst;       * daylight saving time *
 * };
 */
/*
time_t string_to_time(char *date)
*/
void prova()
{
	struct tm *tm;
	/*
	struct timeval tv;
	struct timezone tz;
	*/
	time_t tt;
	
	/* get current tm */
	/*
	tt = time(NULL);
	tm = localtime(tt);
	*/


	tt = time(NULL);
	tm = localtime(&tt);
	printf("pirla: %d:%d\n", tm->tm_hour, tm->tm_min);
	/* change some tm fields */

	/* translate tm in to a time_t (seconds since 1 Jan 1970) */
	/*
	return(mktime(tm));
	*/
}


/* 
 * Dump statistics of some variables with rate = sec
 * XXX: add timezone reading from pcap dump file
 * XXX: ^^^ when sniffing from network: check if the given time is without tz, if so: get tz from system
 */
int rate(const struct pcap_pkthdr head, int sec)
{
	time_t tick;

	/* Calculate the nearest tick preceding current packet */
	tick = TICK(head.ts.tv_sec, sec);

	/* printf("%ld\n", timezone); sgrudu */
	/* New tick ? */
	if (tick > stats.rate.tick) {
			/*
			 * Dump rate statistics for current tick
			 */
			fprintf(stats.rate.file, "%lu %qu %qu %qu %qu %qu %qu %qu\n", stats.rate.tick + stats.tzoff,
			    stats.rate.up_pkts, stats.rate.dw_pkts, stats.rate.up_bytes, stats.rate.dw_bytes,
			    stats.rate.sessions, stats.rate.up_tcppkts, stats.rate.dw_tcppkts);
			stats.rate.up_pkts = 0;
			stats.rate.dw_pkts = 0;
			stats.rate.up_bytes = 0;
			stats.rate.dw_bytes = 0;
			stats.rate.sessions = 0;
			stats.rate.up_tcppkts = 0;
			stats.rate.dw_tcppkts = 0;

			/*
			 * Check if we skipped some ticks because of no packets.
			 * Update stats.rate.tick to the new tick
			 */
			for (stats.rate.tick += sec; stats.rate.tick < tick; stats.rate.tick += sec) {
				fprintf(stats.rate.file, "%ld 0 0 0 0 0 0 0\n", stats.rate.tick + stats.tzoff);
			}
	}
	
	return(0);
}

void rate_init()
{
	stats.rate.tick = 0;
	stats.rate.up_pkts = 0;
	stats.rate.dw_pkts = 0;
	stats.rate.up_bytes = 0;
	stats.rate.dw_bytes = 0;
	stats.rate.sessions = 0;
}

/*
 * Check if we want to process packet (return 0) or if we want to skip it (return 1).
 * Increment statistics counters.
 */
int filter_packet(u_char *packet, const struct pcap_pkthdr head)
{
	struct tm *tm;
	int mss = 0;
	struct mss_entry *m_entry;

	/* We work only with Ethernet-II frame types */
	if (PKT_IS_ETH_802(packet)) {
		printf("Captured an 802.3 frame !\n");
		return(1);
	}

	/* Discard truncated packets */
	if (head.len - 14 < PKT_IP_TLEN_B(packet)) {
		PRINTDD("[%d] Truncated packet! Lacking %d bytes on a total of %d.\n",
		    stats.pkts, PKT_IP_TLEN_B(packet) - head.len, PKT_IP_TLEN_B(packet));
		stats.truncated++;
		return(1);
	}
		
	/* Discard fragments */
	if (PKT_IS_FRAGMENT(packet)) {
		stats.frags++;
		return(1);
	}

	/* IP Checksum
	if (ip_cksum((u_short *)packet+7, PKT_IP_HLEN_B(packet)) != 0) {
		PRINTD("[%d] Wrong IP checksum: %d\n", stats.pkts,
		    ip_cksum((u_short *)packet+7, PKT_IP_HLEN_B(packet)));
		return(1);
	}
	*/

	/* Discard packets with optional IP headers. XXX We're not able to process them */
	if (PKT_IS_IP_OPTIONS(packet)) {
		stats.ip_options++;
		return(1);
	}

	/* 
	 * Check payload. Warning: this is strictly necessary when processing is done because we
	 * use this value as an index to an array. Wrong values lead to segfaults or buggy data.
	 */
	if ((PKT_TCP_PAYLOAD_B(packet) > MAX_PAYLOAD - 1) || (PKT_TCP_PAYLOAD_B(packet) < 0)) {
		PRINTD("[%qu] Warning, invalid TCP payload size:\t%d\n",
		    stats.pkts, PKT_TCP_PAYLOAD_B(packet));
		stats.err_payload++;
		return(1);
	}else {
		PRINTDD("%d\n", PKT_TCP_PAYLOAD_B(packet));
	}

	/* If we want to catch MSS we must do it before skipping pure TCP packets */
	if (pv.mss) {
		/* 
		 * RFC says MSS TCP option can be in SYN packets only. We do the check
		 * here and not in the called function to speed things up. The test is
		 * fast and we spare a function call.
		 */
		if PKT_TCP_FLAG_SYN(packet)
			if ((mss = detect_mss(packet, head))) {
				PRINTDD("mss: %d\n", mss);
				/* update mss table */
				m_entry = mss_get_entry(packet, mss_table);
				if ((m_entry->mss != 0) && (m_entry->mss != mss)) {
					PRINTDD("%d.%d.%d.%d old mss: %d new mss: %d\n", 
					    packet[26],
					    packet[27],
					    packet[28],
					    packet[29],
					    m_entry->mss,
					    mss);
				}
				m_entry->mss = mss;
			}
	}

	/* If requested discard TCP packets without payload */
	if (PKT_TCP_PAYLOAD_B(packet) == 0) {
		stats.pure_tcp_pkts++;
		if (pv.rate) {
			if (PKT_IS_HTTP_UPSTREAM(packet)) 
				stats.rate.up_tcppkts++;
			else
				stats.rate.dw_tcppkts++;
		}
		if (pv.filter_tcp)
			return(1);
	}

	/* If requested discard pkts outside specified day of week */
	/* XXX: timezone */
	if (pv.day_of_week >= 0) {
		tm = tztime(&(head.ts.tv_sec));
		if (tm->tm_wday != pv.day_of_week)
			return(1);
	}

	/* If requested discard pkts outside specified time range */
	/* XXX: timezone */
	if (pv.time_range) {
		tm = tztime(&(head.ts.tv_sec));
		if (pv.tr_hmin <= pv.tr_hmax) {
			/* Range does not cross a 24h day */
			if (tm->tm_hour < pv.tr_hmin)
				return(1);
			if (tm->tm_hour > pv.tr_hmax)
				return(1);
		} else {
			/* Range crosses a 24h day */
			if ((tm->tm_hour < pv.tr_hmin) && (tm->tm_hour > pv.tr_hmax))
				return(1);
		}
		/* In both of above cases we need to check minutes this way */
		if ((tm->tm_hour == pv.tr_hmin) && (tm->tm_min < pv.tr_mmin))
			return(1);
		if ((tm->tm_hour == pv.tr_hmax) && (tm->tm_min > pv.tr_mmax))
			return(1);
	}

	/* Count pkts with optional TCP headers */
	if (PKT_TCP_HLEN_B(packet) != 20) {
		stats.tcp_options++;
	}
	PRINTDD("tcp header length: %d\n", PKT_TCP_HLEN_B(packet));

	return(0);
}

int detect_mss(u_char *a, const struct pcap_pkthdr head)
{
	int k, mss = 0, flag = 1;
	int robust = 0; /* Suppose we find a packet with errors and that one of length fields below
			   is set to zero. We would enter an infinite loop. This dirty hack prevents it */
	
	/* If there are TCP options */
	if (PKT_TCP_HLEN_B(a) > 20) {
		/* Position to the start of TCP optional fields */
		k = 14 + PKT_IP_HLEN_B(a) + 20;
		while ((flag) && (k - 20 - 14 < PKT_TCP_HLEN_B(a)) && (robust++ < 30))
			switch(a[k]) { 
			case 0:
				flag = 0;
				break;
			case 1:
				k++;
				break;
			case 2:
				mss = (a[k+2] << 8) + a[k+3];
				flag = 0;
				break;
			default:
				/* Increment position using the length field */
				k = k + a[k+1];
			}
	}
	/* sgrudu
	if (PKT_TCP_FLAG_ACK(a)) {
		PRINTD("SYNACK mss: %d\n", mss);
		if (PKT_IS_HTTP_UPSTREAM(a))
			printf("^UPSTREAM^\n");
		else
			printf("^DWSTREAM^\n");
	} else {
		PRINTD("SYN mss: %d\n", mss);
		if (PKT_IS_HTTP_UPSTREAM(a))
			printf("^UPSTREAM^\n");
		else
			printf("^DWSTREAM^\n");
	}
	*/

	return(mss);
}

/*
 * Compute the next sequential output file name suffix and store it
 * into the string `outfile' at the position pointed to by `outfile_mid'.
 */
void next_file_name(struct pcap_pkthdr *hp)
{
  static unsigned n_digits = 2;
  char *p;
  struct tm *tm;

  /* Change any suffix of `z's to `a's.  */
  for (p = pv.destfile_end - 1; *p == 'z'; p--) {
      *p = 'a';
  }

  /* Increment the rightmost non-`z' character that was present before the
     above z/a substitutions.  There is guaranteed to be such a character.  */
  ++(*p);

  /* If the result of that increment operation yielded a `z' and there
     are only `z's to the left of it, then append two more `a' characters
     to the end and add 1 (-1 + 2) to the number of digits (we're taking
     out this `z' and adding two `a's).  */
  if (*p == 'z' && p == pv.destfile_mid) {
      ++n_digits;
      ++pv.destfile_mid;
      *(pv.destfile_end)++ = 'a';
      *(pv.destfile_end)++ = 'a';
  }
	if (hp) {
		tm = tztime(&(hp->ts.tv_sec));
		sprintf(pv.destfile_end,"_%.4d%.2d%.2d%.2d%.2d",
		    tm->tm_year + 1900,
		    tm->tm_mon + 1,
		    tm->tm_mday,
		    tm->tm_hour,
		    tm->tm_min);
	}
}

/* EOF */
