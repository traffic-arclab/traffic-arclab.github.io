FILE(REMOVE_RECURSE
  "CMakeFiles/pythia.dir/lib/checksum.cpp.o"
  "CMakeFiles/pythia.dir/lib/ippolib.cpp.o"
  "CMakeFiles/pythia.dir/lib/generaloption.cpp.o"
  "CMakeFiles/pythia.dir/lib/util.cpp.o"
  "CMakeFiles/pythia.dir/lib/probereply.cpp.o"
  "CMakeFiles/pythia.dir/src/pythia.cpp.o"
  "pythia.pdb"
  "pythia"
)

# Per-language clean rules from dependency scanning.
FOREACH(lang CXX)
  INCLUDE(CMakeFiles/pythia.dir/cmake_clean_${lang}.cmake OPTIONAL)
ENDFOREACH(lang)
