/*
 *   ippo-lib - IP oPtion-based active PrObing
 *   An Active Probing Library for IP Options Equipped probes (http://traffic.comics.unina.it/ippolib)
 *
 *   Copyright    : (C) 2012 by Pietro Marchetta, Walter de Donato, Francesco Cesareo,
 *                                     Antonio Pescape' (PI)
 *                                     of the COMICS (COMputer for Interaction and
 *                                     CommunicationS) Group, Dipartimento di Informatica
 *                                     e Sistemistica of the University of Napoli "Federico II".
 *
 *   email        : pietro.marchetta@unina.it , walter.dedonato@unina.it , cesareo.francesco@gmail.com
 * 										pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "util.h"


bool Util::mnumber2string(uint32 addr, char* toreturn)
{

    char ip[INET_ADDRSTRLEN];

//      char* ip = (char*) malloc(INET_ADDRSTRLEN);
    if (inet_ntop(AF_INET, &addr, ip, INET_ADDRSTRLEN)==NULL)
        return false;
    else
        memcpy(toreturn, ip, INET_ADDRSTRLEN);
        return true;
}


bool Util::mstring2number(std::string &addr, uint32 &num)
{
    if (inet_pton(AF_INET, addr.c_str(),&num)==-1)
        return false;
    else
        return true;
}
