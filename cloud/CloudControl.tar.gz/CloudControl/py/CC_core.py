# -*- coding: utf-8 -*-

##################################################################################
#	copyright:	(C) 2015 by Domenico Grimaldi, Valerio Persico,
#			Antonio Pescapè, Alessandro Salvi, Stefania Santini
#      email: 		dom.grimaldi@studenti.unina.it, valerio.persico@unina.it,
#      			pescape@unina.it, alessandro.salvi@unina.it, stefania.santini@unina.it
#
#      This program is free software; you can redistribute it and/or modify
#      it under the terms of the GNU General Public License as published by
#      the Free Software Foundation; either version 2 of the License, or
#      (at your option) any later version.
##################################################################################

import boto
import boto.ec2
import boto.ec2.elb
import boto.ec2.cloudwatch

import sys
import random
import logging
import datetime
import time
import os
from boto.ec2.elb import HealthCheck
import numpy
from pprint import *

## empty struct for new instances
unset_instance = {
			"pub_ip" : None,
			"pri_ip" : None,
			"placement" : None,
			"type" : None,
			"placement_group" : None,
			"state" : None,
			"launch_time" : None}

## empty history for new instances
unset_history = {
			"now" : None,
			"now-1" : None,
			"now-2" : None,
			"now-3" : None,
			"now-4" : None,
			}


class CCProcess:
	"""
	Interfaccia di sensing/attuazione per EC2
	"""




	#def __init__(self, region, keys):
	#@param keys file con credenziali di accesso AWS (ID\nSECRET)
	def __init__(self, region, DeltaT):
		"""
		Inizializza il processo cloud.
		Instanzia un Load Balancer e vi connette una Macchina Virtuale.
		@param region identificativo regione AWS (e.g. eu-west-1 ...)
		@param DeltaT: passo di campionamento (in secondi) dell'osservazione/attuazione - influisce sulla granularità della misura richiesta a CW -deve essere un multiplo di 60

		"""

		#logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s', filename=region+'.log', level=logging.DEBUG)
		#logging.Formatter.converter = time.gmtime
		#logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.INFO,)

		## Regione di riferimento
		self.region = region

		## availability zone
		self.azones = [region+"a"]

		## dizionario rappresentativo del pool delle istanze
		self.__instancePool = {}

		## Misurazioni storiche (5 campioni) mediate sulle VM facenti parte del processo cloud
		self.__avgVals = unset_history.copy()

		## Nome del Load Balancer
		self.__lbname = None

		#aws_access_key_id, aws_secret_access_key = self.__load_credentials(keys)

		#DeltaT
		self.__DeltaT = int(DeltaT)
		logging.info('Delta_T set to %s',DeltaT)

		## EC2 connection
		self.__conn = boto.ec2.connect_to_region(self.region)
		#self.__conn = boto.ec2.connect_to_region(self.region,
					   #aws_access_key_id=aws_access_key_id,
					   #aws_secret_access_key=aws_secret_access_key)
		logging.info('ec2: connection with %s region esablished', region)

		## Elastic Load Balancer connection
		self.__elb_conn = boto.ec2.elb.connect_to_region(region)
		logging.info('ec2 elb: connection with %s region esablished', region)

		## Cloudwatch connection
		self.__cw_conn = boto.ec2.cloudwatch.connect_to_region(region)
		logging.info('ec2 cloudwatch: connection with %s region esablished', region)


		self.__createLB() # crea load balancer
		logging.info('new load balancer created')

		self.addVM() # add VM
		logging.info('new virtual machine added')

	## funzione per caricare le credenziali da file
	def __load_credentials(self,filename):
		credenziali = open(filename).readlines()

		ID = credenziali[1].split("=")[1].strip()
		pwd = credenziali[2].split("=")[1].strip()

		return ID, pwd



	def __del__(self):
		"""
		distrugge il processo cloud.
		"""
		logging.info("Destroying Objects")
		sys.stderr.write("Destroying Objects\n")
		self.__conn.terminate_instances(instance_ids=self.__instancePool.keys())
		self.__elb_conn.delete_load_balancer(self.__lbname)
		pass
		return True

	def __createLB(self):
		"""
		Crea un load balancer nella regione di riferimento.
		Porti forwarding: 8080:80
		@todo healthcheck
		@todo parametri porti
		"""

		zones = self.azones
		ports = [(8080, 80, 'http')]
		SECURITY_GROUP = "sg-210c8144" #XXX to be previously created on AWS account adopted


		hc = HealthCheck(
		interval=20,
		healthy_threshold=3,
		unhealthy_threshold=5,
		target='HTTP:8080/health'
		)

		LB_name = "LB-CC-"+str(random.randint(0,10000000))
		self.__lbname = LB_name

		## Load Balancer
		self.__lb = self.__elb_conn.create_load_balancer(LB_name, zones, ports)
		self.__elb_conn.apply_security_groups_to_lb(LB_name, [SECURITY_GROUP])
		#lb.configure_health_check(hc)
		#lb.dns_name
		logging.info("LOAD BALANCER DNS NAME: %s","http://"+self.__lb.dns_name+":"+str(ports[0][0]))

	def __str__(self):
		"""
		restituisce l'oggetto  in formato printable
		@remark restituisce il dict instancePool
		"""
		return str(self.__instancePool)

	def get_instancePool(self):
		"""
		Restituisce l'intero oggetto rappresente il processo Cloud.
		per ogni VM:\n
		'meas' : vettore con lo storico delle misurazioni\n
		'info' : dizionario con info generiche associate alla VM\n
		'history' : ultime 5 misure associate alla VM\n
		"""
		return self.__instancePool

	#def updatePoolStatus(self):
		#"""
		#aggiorna lo stato del processo cloud
		#"""
		#self.__updatePoolInfo()
		#self.__updatePoolMeasures()
		#pass

	def __updatePoolInfo(self):
		"""
		Aggiorna pool info
		@remark parte "info" di instancePool
		"""

		logging.info("updating pool info ")
		reservations = self.__conn.get_all_reservations()
		instances = []
		for x in reservations:
			instances += x.instances



		results = {}
		for i in instances:
			results[i.id] = {
				"pub_ip" : i.ip_address,
				"pri_ip" : i.private_ip_address,
				"placement" : i.placement,
				"type" : i.instance_type,
				"placement_group" : i.placement_group,
				"state" : i.state,
				"launch_time" : i.launch_time}


		for k in self.__instancePool.keys():
			if k in results:
				self.__instancePool[k]['info'] = results[k]
			else:
				logging.warning("hmmm...instance %s not found in info",k)


		#pprint (self.__instancePool)

		todelete = [kk for kk in self.__instancePool if (self.__instancePool[kk]['info']["state"] != 'running'
					       and self.__instancePool[kk]['info']["state"] != 'pending') ]


		logging.info("%s instances gone down during the last time interval: %s", len(todelete), ",".join(todelete))
		for idtoremove in todelete:
			del self.__instancePool[idtoremove]


	def updatePoolMeasurments(self):
		"""
		Aggiorna misure
		@todo gestire caso in cui ritorna un vettore vuoto: to check!
		"""

		self.__updatePoolInfo() #controlla per terminazioni inattese (imposte da browser)
#cplp = CCProcess("ap-northeast-1","credentials.dat")
		logging.info("updating Pool Measurements")
		#datapoints = self.__get_monitoring_data(datetime.datetime.utcnow() - datetime.timedelta(0,120,0), datetime.datetime.utcnow(), 'CPUUtilization', self.__instancePool.keys())

		for instance in self.__instancePool.keys():

			datapoints = {}
			#datapoints[instance] = self.__get_monitoring_data(datetime.datetime.utcnow() - datetime.timedelta(0,120,0), datetime.datetime.utcnow(), 'CPUUtilization', instance)
			datapoints[instance] = self.__get_monitoring_data(datetime.datetime.utcnow() - datetime.timedelta(0,self.__DeltaT,0), datetime.datetime.utcnow(), 'CPUUtilization', instance)


			mostRecentSample = [x for x in datapoints[instance] if x[u'Timestamp'] == max( [y['Timestamp'] for y in datapoints[instance]] ) ]

			logging.info("new measurement for instance: %s\n%s", instance, mostRecentSample)

			if len(mostRecentSample) > 0:
				mostRecentSample = mostRecentSample.pop()
				self.__instancePool[instance]['history'] = self.__updateHistory(self.__instancePool[instance]['history'], mostRecentSample[u'Average'])
			else:
				mostRecentSample = None
				logging.warning("Measurement Info not retrieved for %s!",instance)
				self.__instancePool[instance]['history'] = self.__updateHistory(self.__instancePool[instance]['history'], None)

			self.__instancePool[instance]['meas'].append( mostRecentSample)


		self.__computeAVGHistory()


	def __updateHistory(self,history,new_value):
		"""
		Aggiorna history inserendo un nuovo valore eliminando il valore più vecchio.
		@remark implementa politica FIFO

		@param history dizionario da modificare
		@new_value valore nuovo
		"""

		logging.info("updating history ")
		history['now-4'] = history['now-3']
		history['now-3'] = history['now-2']
		history['now-2'] = history['now-1']
		history['now-1'] = history['now']

		history['now'] = new_value

		return history

	def __computeAVGHistory(self):
		"""
		Computa la media tra le misure associate a tutte le macchine virtuali appartenenti al pool.

		@remark computa media aritmetica
		@remark trasla i valori da "now-1" a "now-4" e calcola un valore nuovo per "now"
		"""
		logging.info("computing AVG history ")
		avgVals = {}

		old = self.__avgVals

		avgVals['now-4'] = old['now-3']
		avgVals['now-3'] = old['now-2']
		avgVals['now-2'] = old['now-1']
		avgVals['now-1'] = old['now']

		valuesToAvg = [ self.__instancePool[i]["history"]["now"] for i in self.__instancePool.keys() if self.__instancePool[i]["history"]["now"]!= None  ]

		if valuesToAvg == []:
			avg = None
			logging.warning("Unable to Compute AVG (Too many 'None')")
		else:
			avg = numpy.mean(valuesToAvg)

		avgVals["now"] = avg

		self.__avgVals = avgVals

		old['now'] = avg




	def __get_monitoring_data(self,start, stop, metric, instances):
		'''
		recupera i dati compresi tra start e stop [start, stop)
		non bada al valore dei secondi, tronca ai minuti.
		la granularita' e' pari ad 1 minuto
		i timestamp dei datapoint riportati riportano l'istante di inizio dell'intervallo
		@param start inizio dell'intervallo da monitorare
		@param stop fine dell'intervallo da monitorare
		@param metric metrica da monitorare
		@param instances istanze da monitorare
		'''
		logging.info('requesting cw info (%s) for %s from %s to %s',metric, instances, start, stop)
		datapoints = self.__cw_conn.get_metric_statistics(
			self.__DeltaT, #period [s], min=60s ~ The granularity, in seconds, of the returned datapoints. Period must be at least 60 seconds and must be a multiple of 60. The default value is 60.
			start,
			stop,
			metric,#'CPUUtilization',
			'AWS/EC2',
			'Average', # ['Average', 'Sum', 'SampleCount','Maximum','Minimum'], #60s is the finest granularity. With this period, sample count= 1 and the other statistics have the same value
			dimensions={'InstanceId':instances} # dimensions={'InstanceId':['i-ab13c4eb','i-a4b965e7']}
			)

		for x in datapoints:
			x['Timestamp'] =  str(x['Timestamp'])


		return datapoints


	def addVM(self):
		"""
		Aggiunge una macchina virtuale al pool
		@todo parametrizzare type if needed
		@todo parametrizzare instance type
		@remark AMI_IMAGE_ID è relativa a specifica regione (ireland)
		@remark SECURITY_GROUP deve essere stato creato in precedenza
		"""
		logging.info("adding new VM ")
		AMI_IMAGE_ID = "ami-XXXXX" # Ubuntu Server 14.04 LTS (PV), SSD Volume Type (64bit) - cherrypy - webserver4
		SSH_KEY_NAME = "CC2KEY"
		#INSTANCE_TYPE = "m3.medium" # 3.75 GB RAM, <<moderate>> network performance
		#INSTANCE_TYPE = "m3.large" # 7.5 GB RAM, <<moderate>> network performance
		INSTANCE_TYPE = "t2.micro"
		SECURITY_GROUP = "open_all"

		PLACEMENT = self.azones[0]



		reservation = self.__conn.run_instances(
			AMI_IMAGE_ID,
			#key_name=SSH_KEY_NAME,
			instance_type=INSTANCE_TYPE,
			placement=PLACEMENT, # same availability zone
			#placement=PLACEMENT[iter%3], # different availability zones
			security_groups=[SECURITY_GROUP],
			monitoring_enabled=True # enable monitoring
			)


		instance = reservation.instances[0]

		while True:
			try:
				self.__lb.register_instances([instance.id])
				x = self.__elb_conn.describe_instance_health(self.__lbname)

				expected_instances = len(self.__instancePool)+1
				connected_instances = len(self.__elb_conn.describe_instance_health(self.__lbname))

				logging.info( "instance connected to the LB: %s -- Instances expected: %s", connected_instances, expected_instances  )
				if expected_instances == connected_instances:
					break
				time.sleep(5)


			except:
				logging.warning("Exception caught while registering instance. Retrying...")
				time.sleep(2)

		self.__addToPool(instance.id)

		self.__updatePoolInfo()


	def rmVM(self):
		"""
		rimuove una macchina virtuale da pool.
		@remark impelementa una politica LIFO
		"""
		logging.info("removing VM ")
		idtoremove = [x for x in self.__instancePool.keys() if self.__instancePool[x]["info"]["launch_time"] == max([self.__instancePool[k]["info"]["launch_time"] for k in self.__instancePool.keys() ])].pop()

		#remove from lb
		self.__lb.deregister_instances([idtoremove])

		#terminate VM
		self.__conn.terminate_instances(instance_ids=[idtoremove])

		#remove from vmpool
		del self.__instancePool[idtoremove]



	def __addToPool(self,instanceId):
		"""
		aggiunge nuova VM al pool
		"""
		self.__instancePool[instanceId] = {}
		self.__instancePool[instanceId]['info'] = unset_instance.copy()
		self.__instancePool[instanceId]['meas'] = []
		self.__instancePool[instanceId]['history'] = unset_history.copy()


	def getAvgVals(self):
		"""
		Restituisce il valore rappresentativo lo stato del processo Cloud
		"""
		return self.__avgVals

if __name__ == "__main__":

	####################
	#	TEST MAIN
	####################

	if len(sys.argv) < 2:
		sys.stderr.write("usage: [python] "+sys.argv[0]+ " Delta_T\n")
		sys.exit(1)

	keys = sys.argv[1] # alternatively set credentials in ~/home/.boto


	cplp = CCProcess("eu-west-1",keys)
	cplp.addVM()
	cplp.addVM()

	print "Startup"
	print "please wait..."
	time.sleep(150)
	pprint (cplp.get_instancePool())



	try:
		while True:
			print 'Use Control-C to exit'
			cplp.addVM()
			cplp.updatePoolMeasurments()

			pprint (cplp.get_instancePool())
			pprint(cplp.getAvgVals())
			#time.sleep(60)
			raw_input("press a key to update process measurements\n")

			os.system("clear")
			time.sleep(1)
	except KeyboardInterrupt:
		print 'Exiting'
