#! /usr/bin/python

##################################################################################
#	copyright:	(C) 2015 by Domenico Grimaldi, Valerio Persico,
#			Antonio Pescapè, Alessandro Salvi, Stefania Santini
#      email: 		dom.grimaldi@studenti.unina.it, valerio.persico@unina.it,
#      			pescape@unina.it, alessandro.salvi@unina.it, stefania.santini@unina.it
#
#      This program is free software; you can redistribute it and/or modify
#      it under the terms of the GNU General Public License as published by
#      the Free Software Foundation; either version 2 of the License, or
#      (at your option) any later version.
##################################################################################


import CC_core
import time
import sys
import logging
import os
import numpy
from pprint import *

## funzione attuatore: alloca o dealloca un VM in funzione del segnale di controllo u_k
def act(u_k):
	if u_k >= -3000 and u_k < -1000:
		return 1
	elif u_k >= -5000 and u_k < -3000:
		return 2
	elif u_k >= -7000 and u_k < -5000:
		return 3
	elif u_k < -7000:
		return 4
	elif u_k > 1000 and u_k <= 3000:
		return -1
	elif u_k > 3000 and u_k <= 5000:
		return -2
	elif u_k > 5000 and u_k <= 7000:
		return -3
	elif u_k > 7000:
		return -4
	else: # u_k == 0
		return 0

## importa parametri da file:
## formato:
##1.	y_rif
##2.	delta_t
##3.	Kp
##4.	Ki
##5.	Kd
def import_PID_parameters(filename):
	lista_PID = [float(x.strip()) for x in open(filename).readlines()]
	y_rif = lista_PID[0]					#assegna i parametri del PID contenuti nel file PID.txt a variabili locali
	delta_t = lista_PID[1]
	Kp = lista_PID[2]
	Ki = lista_PID[3]
	Kd = lista_PID[4]
	return y_rif, delta_t, Kp, Ki, Kd

## funzione controllore P: determina l'errore dell'uscita rispetto al riferimento e calcola il segnale di controllo u_k - PROPORZIONALE
def controller(y_rif, delta_t, Kp, Ki, Kd, u_k_1, diz_val_input):

	if None in [diz_val_input[x] for x in ["now","now-1","now-2"]]:
		#print "more values needed"

		logging.info("Startup phase, more values needed")

		return None, None, None


	y_k = diz_val_input["now"]
	y_k_1 = diz_val_input["now-1"]
	y_k_2 = diz_val_input["now-2"]

	e_k = y_rif - y_k 				#calcola il valore dell'errore all'istante k

	u_k = Kp*e_k

	return u_k, e_k, y_k


## funzione controllore PI: determina l'errore dell'uscita rispetto al riferimento e calcola il segnale di controllo u_k - PI - proporzionale al primo giro, PI ai successivi
def controller2(y_rif, delta_t, Kp, Ki, Kd, u_k_1, diz_val_input,CICLO):

	if None in [diz_val_input[x] for x in ["now","now-1","now-2"]]:
		#print "more values needed"

		logging.info("Startup phase, more values needed")

		return None, None, None, CICLO

	CICLO += 1

	Ti = Kp/Ki
	#Td = Kd/Kp

	y_k = diz_val_input["now"]
	y_k_1 = diz_val_input["now-1"]
	y_k_2 = diz_val_input["now-2"]


	e_k = y_rif - y_k 				##calcola il valore dell'errore all'istante k
	e_k_1 = y_rif - y_k_1				##calcola il valore dell'errore all'istante k-1
	e_k_2 = y_rif - y_k_2				##calcola il valore dell'errore all'istante k-2


	if COUNT_CICLO == 1 or abs(e_k) <= SOGLIA_ZERO:

		#P
		logging.info("PI. First round/Inside bound -> solo P")
		u_k = Kp*e_k
	else:
		#PI
		u_k = u_k_1 + Kp*( (1+delta_t/Ti)*e_k - e_k_1 )

	return u_k, e_k, y_k, CICLO

#funzione controllore PID: determina l'errore dell'uscita rispetto al riferimento e calcola il segnale di controllo u_k - PID - proporzionale al primo giro, PID ai successivi
def controller3(y_rif, delta_t, Kp, Ki, Kd, u_k_1, diz_val_input,CICLO):

	if None in [diz_val_input[x] for x in ["now","now-1","now-2"]]:
		#print "more values needed"

		logging.info("Startup phase, more values needed")

		return None, None, None, CICLO

	CICLO += 1

	Ti = Kp/Ki
	Td = Kd/Kp

	y_k = diz_val_input["now"]
	y_k_1 = diz_val_input["now-1"]
	y_k_2 = diz_val_input["now-2"]


	e_k = y_rif - y_k 				#calcola il valore dell'errore all'istante k
	e_k_1 = y_rif - y_k_1				#calcola il valore dell'errore all'istante k-1
	e_k_2 = y_rif - y_k_2				#calcola il valore dell'errore all'istante k-2


	if COUNT_CICLO == 1 or abs(e_k) <= SOGLIA_ZERO:

		#P
		logging.info("PI. First round/Inside bound -> solo P")
		u_k = Kp*e_k
	else:
		#PID
		u_k = u_k_1 + Kp*( ( 1 + delta_t/Ti + Td/delta_t)*e_k + (-1 - 2*Td/delta_t)*e_k_1 + (Td/delta_t)*e_k_2)

	return u_k, e_k, y_k, CICLO

##Stampa su file (e a schermo) gli andamenti dei segnali di interesse: u_k, e_k, y_k
def dump_value(filE_handler,value):

	#if value == None:
		#value = "#None"

	filE_handler.write(str(value)+ "\n")
	#sys.stderr.write(str(value)+ "\n")


SOGLIA_ZERO = 10
max_vm = 20
min_vm = 1

if __name__ == "__main__":

	if len(sys.argv) < 3:
		sys.stderr.write("usage: [python] "+sys.argv[0]+ " radix_name P|PI|PID" +"\n")
		sys.stderr.write("PID.txt must contain the following info:\n")
		sys.stderr.write("y_rif\ndelta_t\nKp\nKi\nKd\n")
		sys.exit(1)

	#keys = sys.argv[1]
	radix_name = sys.argv[1]
	Type = sys.argv[2]

	if Type != "P" and Type != "PI" and Type != "PID":
		sys.stderr.write("Type %s not supported",Type)
		sys.exit(1)


	logging.Formatter.converter = time.gmtime
	logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.INFO, filename=radix_name+".log")

	y_rif, delta_t, Kp, Ki, Kd = import_PID_parameters("PID.txt")

	logging.info("Controller selected: %s", Type)
	logging.info("PID Parameter: P = %s", Kp)
	logging.info("PID Parameter: I = %s", Ki)
	logging.info("PID Parameter: D = %s", Kd)

	ccproc = cippalippa.CCProcess("eu-west-1",delta_t)

	try:
		os.mkdir(radix_name)
	except:
		sys.stderr.write("folder alredy exists\n")
		pass

	f_u = open(radix_name+"/"+radix_name+"_u.txt", "a")
	f_e = open(radix_name+"/"+radix_name+"_e.txt", "a")
	f_y = open(radix_name+"/"+radix_name+"_y.txt", "a")
	f_vmno = open(radix_name+"/"+radix_name+"_vmnum.txt", "a")
	f_vmcpu = open(radix_name+"/"+radix_name+"_vmcpu.txt", "a")

	print "Startup"
	print "please wait..."
	logging.info("Startup")
	logging.info("please wait")
	initial_wait = 150
	logging.info("initial sleep: %ss",initial_wait)
	time.sleep(initial_wait)
	#pprint (ccproc.get_instancePool())

	logging.info("Pool status:\n%s",ccproc.get_instancePool())

	u_k_1 = 0
	COUNT_CICLO = 0 #usato solo da PI - controller2

	iteration = 0

	startWL = False

	sys.stderr.write('Use Control-C to exit\n')
	try:

		while True:
			start = time.time()

			iteration += 1

			logging.info("inizio ciclo %s",iteration)
			#print "inzio ciclo", start
			#os.system("clear")


			ccproc.updatePoolMeasurments()			#aggiorna le misure

			#pprint (ccproc.get_instancePool())

			logging.info("Pool status:\n%s",ccproc.get_instancePool())

			logging.info("Avg Vals:\n%s",ccproc.getAvgVals())

			#pprint(ccproc.getAvgVals())

			num_vm = len(ccproc.get_instancePool())
			#cpu_all = ",".join( [ str(ccproc.get_instancePool()[i]["history"]["now"]) for i in ccproc.get_instancePool() ] )
			cpu_all = ",".join( [ str(ccproc.get_instancePool()[i]["history"]["now"]) for i in sorted(ccproc.get_instancePool(), key=lambda x:ccproc.get_instancePool()[x]["info"]["launch_time"]) ] )


			#CHECK CONTROLLER TYPE
			if Type == "P":
				u_k, e_k, y_k = controller(y_rif, delta_t, Kp, Ki, Kd, u_k_1, ccproc.getAvgVals())
			elif Type == "PI":
				u_k, e_k, y_k, COUNT_CICLO = controller2(y_rif, delta_t, Kp, Ki, Kd, u_k_1, ccproc.getAvgVals(),COUNT_CICLO)
			elif Type == "PID":
				u_k, e_k, y_k, COUNT_CICLO = controller3(y_rif, delta_t, Kp, Ki, Kd, u_k_1, ccproc.getAvgVals(),COUNT_CICLO)

			logging.info("controller output (u_k, e_k, y_k): %s %s %s",u_k, e_k, y_k)

			#dump_value(f_u, u_k)
			#dump_value(f_e, e_k)
			#dump_value(f_y, y_k)
			#dump_value(f_vmno, num_vm)
			#dump_value(f_vmcpu, cpu_all)


			if u_k == None:
				#logging.info("still in startup")
				stop = time.time()
				elapsed = stop - start
				time_to_wait = delta_t - elapsed
				logging.info("%s-second wait",time_to_wait)
				time.sleep(time_to_wait)

				#num_vm = "#"+str(num_vm))
				dump_value(f_u, "#"+str(u_k))
				dump_value(f_e, "#"+str(e_k))
				dump_value(f_y, "#"+str(y_k))
				dump_value(f_vmno, "#"+str(num_vm))
				dump_value(f_vmcpu, "#"+str(cpu_all))

				continue
			else:

				if startWL == False:
					startWL = True
					sys.stderr.write("***START WORK LOAD RIGHT NOW!***\n")

				dump_value(f_u, u_k)
				dump_value(f_e, e_k)
				dump_value(f_y, y_k)
				dump_value(f_vmno, num_vm)
				dump_value(f_vmcpu, cpu_all)

			u_k_1 = u_k

			azione = act(u_k) 				##attiva l'attuatore

			if abs(e_k) > SOGLIA_ZERO:

				if azione > 0 and num_vm < 20:

					logging.info("u_k = %s --> azione = %s",u_k,azione)

					if (num_vm + azione) < max_vm:

						for i in range(azione):
							ccproc.addVM()
							time.sleep(5)
						logging.info("%s VM allocated", (i+1))

					elif (num_vm + azione) > max_vm:

						for i in range((max_vm - num_vm)):
							ccproc.addVM()
							time.sleep(5)
						logging.info("Only %s VM allocated", (i+1))

				elif azione < 0 and num_vm > 1:

					logging.info("u_k = %s --> azione = %s",u_k,azione)

					if (num_vm + azione) > min_vm:
						for i in range(abs(azione)):
							ccproc.rmVM()
							time.sleep(5)
						logging.info("%s VM deallocated", (i+1))

					elif azione < 0 and (num_vm + azione) < min_vm:
						for i in range(num_vm - min_vm):
							ccproc.rmVM()
							time.sleep(5)
						logging.info("Only %s VM deallocated", (i+1))
				elif num_vm == 1:
					logging.info("Cannot deallocate VM: limit reached")

				elif num_vm == 20:
					logging.info("Cannot allocate VM: limit reached")

				elif azione == 0:
					logging.info("u_k lower than 1000: NOTHING TO DO")
					pass
			else:
				logging.info("u_k lower than 1000: NOTHING TO DO")

			stop = time.time()
			elapsed = stop - start
			time_to_wait = delta_t - elapsed

			logging.info("%s-second wait",time_to_wait)
			time.sleep(time_to_wait)


	except KeyboardInterrupt:

		sys.stderr.write('\nExiting\n')
		f_u.close()
		f_e.close()
		f_y.close()
		f_vmno.close()
		f_vmcpu.close()

