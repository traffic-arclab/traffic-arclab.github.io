import os
import multiprocessing as mp
from ConfigParser import SafeConfigParser
import xmlrpclib
import logging
import time
class MonitoringMaster:

    def __init__(self, conf_file=None):

        if not conf_file:
            conf_file = "%s/%s/%s" % (os.path.dirname(os.path.abspath(__file__)), "conf", "monitoring_master.ini")
        else:
            self.conf_file = conf_file

        self.cluster_info = {}
        parser = SafeConfigParser()
        parser.read(conf_file)
        self.server_port = parser.getint('apm', 'port')

        logging.Formatter.converter = time.gmtime
        logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.INFO,)


    @staticmethod
    def __get_ips(cluster_info):
        return cluster_info.values()  # get public IPs

    def __push_cluster_info(self, ip, cluster_info, queue):
        retry = 0
        endpoint = "http://%s:%s" % (ip, self.server_port)
        logging.info("Pushing APM cluster to: %s", endpoint)
        vmproxy = xmlrpclib.ServerProxy(endpoint)
        updated = False
        while retry < 3:
            try:
                vmproxy.set_cluster_info(cluster_info)
                updated = True
                break
            except Exception, e: # TODO: manage timeout error
                logging.error("Exception in push cluster: %s", str(e))
                retry += 1

        queue.put_nowait(updated)
        return updated

    def __set_cluster_info(self, cluster_info):
        """
        Load cluster info.
        :param cluster_info: {pri1: pub1, pri2: pub2}
        :return: True
        """
        try:
            self.cluster_info = cluster_info
            return True
        except:
            return False

    def update_em_all(self, cluster_info):
        """
        Wrapper for private methods.
        Creates a thread for each vm designed to update its state.
        To be called every the active-VM set changes, i.e. every time a VM is shut down or a new VM is created.
        :param cluster_info: dict of active vms {pri1: pub1, pri2: pub2}
        :return:
        """
        self.__set_cluster_info(cluster_info)
        pushers = []
        queue = mp.Queue()
        for vm in self.__get_ips(self.cluster_info):
            pushers.append(mp.Process(target=self.__push_cluster_info, args=(vm, self.cluster_info, queue)))

        for p in pushers:
            p.start()

        for p in pushers:
            p.join()

        push_results = []
        while not queue.empty():
            push_results.append(queue.get_nowait())

        updated = push_results.count(True)
        not_updated = push_results.count(False)
        logging.info("%s/%s APMs updated", updated, len(push_results))