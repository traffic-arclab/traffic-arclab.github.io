#! /usr/bin/python
import sys

def parse_line(line):
	"""
	34600 - - [30/Apr/1998:21:30:17 +0000] "GET /images/hm_bg.jpg HTTP/1.0" 200 24736
	232 - - [30/Apr/1998:21:30:53 +0000] "GET /images/hm_bg.jpg HTTP/1.0" 200 24736
	282 - - [30/Apr/1998:21:31:12 +0000] "GET /images/hm_bg.jpg HTTP/1.0" 200 24736
	9719 - - [30/Apr/1998:21:31:19 +0000] "GET /french/splash_inet.html HTTP/1.0" 200 3781
	9719 - - [30/Apr/1998:21:31:22 +0000] "GET /images/hm_nbg.jpg HTTP/1.0" 304 -
	"""
	date = line.strip().split("[")[1].split("]")[0]
	
	h = date.split(":")[1]
	m = date.split(":")[2]
	s = date.split(":")[3].split()[0]
	minute_of_the_day = int(h)*60 + int(m)
	
	return minute_of_the_day
	

if __name__ == "__main__":
	
	if len(sys.argv) < 2:
		sys.stderr.write("usage: "+sys.argv[0]+" recreat_log\n")
		sys.exit(1)
	
	ht = {}
	for line in open(sys.argv[1]):
		
		minute_of_the_day = parse_line(line)
		
		if minute_of_the_day in ht:
			ht[minute_of_the_day] = ht[minute_of_the_day]+1
		else:
			
			ht[minute_of_the_day] = 1
			
			
	for k in ht:
		print "%s	%s"%(k,ht[k])
