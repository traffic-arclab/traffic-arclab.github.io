reset;

### TERMINAL
#set terminal pngcairo;\
#set output 'fig1.png';
#set termoption dashed;

set terminal postscript eps enhanced color linewidth 1;\
set output 'longone.eps';
set termoption dashed;

### SIZE
set size 0.92, 1


### LEGEND
#set key outside;
#set key top right;
set key font ", 17";


### AXES
# set xrange [0:0.35]
set yrange [0:]
#set logscale y;


## LABELS
set xlabel 'Time [s]';
set ylabel 'Requests per minute' #offset -4
set xlabel font ", 20" 
set ylabel font ", 20"
set ylabel rotate by 0 offset 30,16

## GRID
#set grid;
set grid lc rgb "grey";


## TICS
set xtics font ", 20" 
set ytics font ", 20" 

# set xtics  0,0.07,0.35
# set ytics  0,250,1250


## STYLE
#set style data linespoints
#set style fill pattern border #???

# change a color of border.
set border lw 1 lc rgb "#666666"
 
# change text colors of  tics
set xtics textcolor rgb "#666666"
set ytics textcolor rgb "#666666"
 
# change text colors of labels
set xlabel textcolor rgb "#666666"
set ylabel textcolor rgb "#666666"
 
# change a text color of key
#set key textcolor rgb "white"

#set border 1+2 back
set border 3
set xtics nomirror; set ytics nomirror

set style line 1 lc rgb "orange" lw 5 lt 1 ps 2 pt 7 pi -1
set style line 7 lc rgb 'orange' lt 1 lw 7 pt 7 pi -1 ps 1.5
set style line 8 lc rgb 'grey' lt 1 lw 1 pt 7 pi -1 ps 0.5
set style line 18 lc rgb 'orange' lt 1 lw 4 pt 7 pi -1 ps 1.5
set style line 9 lc rgb 'orange' lt 1 lw 2 
set style line 10 lc rgb 'grey' lt 2 lw 1 
# set pointintervalbox 1

set style line 2 lc 1 lw 2 pt 9 ps 2 lt 1 
set style line 3 lc 1 lw 2 pt 7 ps 2 lt 1 
set style line 4 lc 3 lw 2 pt 5 ps 2 lt 2 
set style line 5 lc 3 lw 2 pt 9 ps 2 lt 2
set style line 6 lc 3 lw 2 pt 7 ps 2 lt 2 

set style arrow 1 nohead ls 9
set style arrow 2 nohead ls 10


# ARROWS and LABEL
# set arrow 10 from 0.07,320 to 0.07,420 as 1
# set label "MEDIUM" at first 0.06,440 font ",10" textcolor rgb "orange"
# 
# set arrow 11 from 0.14,690 to 0.14,790 as 1
# set label "LARGE" at first 0.13,810 font ",10" textcolor rgb "orange"
# 
# set arrow 12 from 0.28,910 to 0.28,810 as 1
# set label "XLARGE" at first 0.27,790 font ",10" textcolor rgb "orange"
# 
# set arrow 13 from 0,0 to 0.3125,1250 as 2


plot '15reqs_perminute.dat' using 1:2 ls 8 with lines title ''#,\
# 'longone2.dat' using ($1-1411639920):($2*8/60000000) ls 18 with linespoints title '',\
# 'longone1.dat' using ($1-1411632780):($2*8/60000000) ls 8 with linespoints title ''



#plot 'trends.dat' using 1:2 lt -1 pi -5 pt 5,\
#'trends.dat' using 1:3 lt 2 lc 1 pt 3 ps 2 w l title 'Cloud (content)',\
#'trends.dat' using 1:4 ls 3 lc 1 pt 4 title 'IoT&Cloud (content)',\
#'trends.dat' using 1:5 lt 1 lc 1 pt 5 title 'IoT (title)',\
#'trends.dat' using 1:6 lt 1 lc 1 pt 6 title 'Cloud (title)',\
#'trends.dat' using 1:7 lt 1 lc 1 pt 7  title 'IoT&Cloud (title)';


