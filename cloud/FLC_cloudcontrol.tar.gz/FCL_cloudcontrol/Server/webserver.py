#! /usr/bin/python
<<<<<<< HEAD
import cherrypy
import os
import random
import numpy
import threading


class HelloWorld(object):

	__MAX_ITER = 1000000

	def burn_cycles(self,iterations):
		for i in range(0,iterations):
			x = random.randint(1,1000)
			y = random.randint(1,1000)
			w = x * y
		return w

        @cherrypy.expose
        def index(self):
                return "Hello World"

        @cherrypy.expose
        def ip(self):
                local_ip = os.popen("ifconfig  eth0 | grep -E 'inet addr:' | awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()
                return "Hello from %s"%local_ip

        @cherrypy.expose
        def burn(self):
                local_ip = os.popen("ifconfig  eth0 | grep -E 'inet addr:' | awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()
                iterationz = random.randint(1,self.__MAX_ITER)
                w = self.burn_cycles(iterationz)
                return "<h1>BURN</h1>\n<h2>%s cycles burned by %s</h2>\n<h2>result: %s</h2>"%(str(iterationz),local_ip,str(w))

=======
import cherrypy, os, random


class HelloWorld(object):
    __MAX_ITER = 1000000

    def __burn_cycles(self, iterations):
        for i in range(0, iterations):
            x = random.randint(1, 1000)
            y = random.randint(1, 1000)
            w = x * y
        return w

    @cherrypy.expose
    def index(self):
        return "Hello World"

    @cherrypy.expose
    def ip(self):
        local_ip = os.popen(
            "ifconfig  eth0 | grep -E 'inet addr:' | awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()
        return "Hello from %s" % local_ip

    @cherrypy.expose
    def burn(self):
        local_ip = os.popen(
            "ifconfig  eth0 | grep -E 'inet addr:' | awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()
        iterationz = random.randint(1, self.__MAX_ITER)
        w = self.__burn_cycles(iterationz)
        return "<h1>BURN</h1>\n<h2>%s cycles burned by %s</h2>\n<h2>result: %s</h2>" % (str(iterationz), local_ip, str(w))
>>>>>>> 28e129223c1831521325c2d66686f4d5e566c8a1

        @cherrypy.expose
        def burnFFT(self):
                local_ip = os.popen("ifconfig  eth0 | grep -E 'inet addr:' | awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()
                x = numpy.fft.fft2(numpy.random.random((5000,5000)))
                return "<h1>BURN_FFT</h1>\n<h2> FFT output computed by %s</h2>\n<p>result: %s</p>"%(str(local_ip),str(x))


        @cherrypy.expose
        def burnT(self, iterations=1000, numthread=100):
		iterations = int(iterations)
		numthread = int(numthread)
		local_ip = os.popen("ifconfig  eth0 | grep -E 'inet addr:' | awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()
		#local_ip = "1.2.3.4"
		#w = self.burn_cycles(iterations)

		threads = []
		results = []
		for i in range(numthread):
			t = myThread(i, "Thread-"+str(i), i, self, iterations)
			threads.append(t)
			#t.daemon = True
			t.start()
			#print "Thread-"+str(i)+" started"


		for t in threads:
			t.join()

		print results

		#return "<h1>BURN</h1>\n<h2>%s cycles burned by %s</h2>\n<h2>result: %s</h2>"%(str(numthread),local_ip,str(w))
		return "<h1>%s: BURN_T</h1>\n<h2>%s iteration</h2>\n<h2>by %s threads</h2>"%( local_ip, str(iterations), str(numthread))









	#def burnT(self, iterations=1000, parallelism=100):
                #local_ip = os.popen("ifconfig  eth0 | grep -E 'inet addr:' | awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()




                ##iterationz = random.randint(1,self.__MAX_ITER)
                #w = self.__burn_cycles(self.__MAX_ITER/2)


		#for i in range(1,10):
			#t = threading.Thread(target=self.__burn_cycles, args = (self.__MAX_ITER/2))
			##t.daemon = True
			#t.start()

                #return "<h1>BURN_T</h1>\n<h2>%s itaration</h2>\n<h2>by %s threads</h2>"%(str(iterations), str(numthread), local_ip,str(w))

class myThread (threading.Thread):
    def __init__(self, threadID, name, counter, ciok, iterations):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.counter = counter
        self.ciok = ciok
        self.iteration = iterations
    def run(self):
        #print "Starting " + self.name
        res = self.ciok.burn_cycles(self.iteration)
        #print "Exiting " + self.name
        print self.name + " : "+ str(res)
        return res



if __name__ == '__main__':
    local_ip = os.popen("ifconfig  eth0 | grep -E 'inet addr:'| awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()
    cherrypy.config.update({'server.socket_host': local_ip,
                            'server.socket_port': 80,
                            })

<<<<<<< HEAD
	local_ip = os.popen("ifconfig  eth0 | grep -E 'inet addr:'| awk '{print $2}' | awk -F':' '{print $2}'").readline().strip()
	#local_ip = "143.225.229.166"
	cherrypy.config.update({'server.socket_host': local_ip,
                        'server.socket_port': 80,
                       })

        cherrypy.quickstart(HelloWorld())


=======
    cherrypy.quickstart(HelloWorld())
>>>>>>> 28e129223c1831521325c2d66686f4d5e566c8a1
