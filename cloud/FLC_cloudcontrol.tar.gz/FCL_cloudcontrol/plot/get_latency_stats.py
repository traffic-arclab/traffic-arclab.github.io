#! /usr/bin/python

import shutil
import os
import sys
import logging
import time
import numpy
from pprint import *


#DELTA_T = 180


def read_latency(infile):

    diz = {} #ts:latency
    for line in open(infile):
        if "throughput" in line and "throughput=0rps" not in line:
            ts = None
            latency = None
            for kv in line.split():
                k = kv.split("=")[0]
                v = kv.split("=")[1]

                if k == "time":
                    ts = v
                if k == "latency":
                    #latency=606:nan:1286:nan:1967:(1286)ms
                    latency = float(v.split(":")[-1].lstrip("(").rstrip(")ms"))

            diz[float(ts)] = int(latency)

    START = min(diz)

    # trasla diz
    diz2 = {} #diz2 shifted
    for k in diz:
        diz2[k-START] = diz[k]

    return diz2


def print_stats(diz): ## {ts : value}
    LEN = len(diz)
    DURATION = max(diz) - min(diz)
    MIN = min(diz.values())
    MAX = max(diz.values())
    AVG = numpy.mean(diz.values())
    DEV = numpy.std(diz.values())
    COV = DEV/abs(AVG)
    MEDIAN = numpy.median(diz.values())
    PCTL25 = numpy.percentile(diz.values(), 25)
    PCTL75 = numpy.percentile(diz.values(), 75)
    PCTL5 = numpy.percentile(diz.values(), 5)
    PCTL95 = numpy.percentile(diz.values(), 95)
    IQR = PCTL75 - PCTL25


    results = {
        "samples": LEN,
        "duration": DURATION,
        "min" : MIN,
        "max" : MAX,
        "avg" : AVG,
        "dev" : DEV,
        "cov" : COV,
        "med" : MEDIAN,
        "pltl25" : PCTL25,
        "pltl75" : PCTL75,
        "pltl5" : PCTL5,
        "pltl95" : PCTL95,
        "iqr" : IQR
        }

    return results

if __name__ == "__main__":

    if len(sys.argv) < 2:
        sys.stderr.write("usage: [python] "+sys.argv[0]+" PATH/TO/HTTPMON.LOG RESTRICTED_SAMPLES_BOUND\n")
        sys.stderr.write("RESTRICTED_SAMPLES_BOUND - lower bound dell'intervallo da considerare al fine di escludere il transitorio iniziale\n")
        sys.exit(1)

    LOGFILE = sys.argv[1]

    if len(sys.argv) > 2:
        BOUND = float(sys.argv[2])
    else:
        BOUND = 0


    lat = read_latency(LOGFILE)
    stat1 = print_stats(lat)

    restricted = {x:lat[x] for x in lat if x > BOUND}
    #restricted_samples = restricted_lat.values()


    #######################
    # OUT
    #######################
    print "-----------------------"
    print "*OVERALL LATENCY STATS*"
    print "-----------------------"

    for k in sorted(stat1):
        print "%s\t%s"%(k, stat1[k])

    if BOUND > 0:

        stat2 = print_stats(restricted)

        print "-----------------------"
        print "*RESTR LATENCY STATS*"
        print "-----------------------"

        for k in sorted(stat2):
            print "%s\t%s"%(k, stat2[k])
