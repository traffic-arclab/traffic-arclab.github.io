#! /bin/bash

LOGFILE_INPUT=$1
CAMPAIGN_NAME=$2

python CC_fuzzy_log_analyzer.py $LOGFILE_INPUT > $CAMPAIGN_NAME
python plot_fuzzy.py $CAMPAIGN_NAME
