#######################################
#
#    Tested with Controller 15.07.23
#
#    input: experiment logfile
#    output: metrics and PID ks for each cycle
#
#######################################


import sys

class cycle_object:

    #def __init__(self, metric_dict, Kp1=None, alfa=None, Kd1=None, P=None, I=None, D=None):
    def __init__(self, **kwargs):

        metric_dict = kwargs.get('metric_dict',{})

        if metric_dict:
            self.icmp_rt_delay = metric_dict.get('icmp-rt-delay', None).get("now", None)
            self.icmp_rt_jitter = metric_dict.get('icmp-rt-jitter', None).get("now", None)
            self.tcp_rt_delay = metric_dict.get('tcp-rt-delay', None).get("now", None)
            self.tcp_rt_jitter = metric_dict.get('tcp-rt-jitter', None).get("now", None)
            self.request_count = metric_dict.get('request-count', None).get("now", None)
            self.NetworkOut = metric_dict.get('NetworkOut', None).get("now", None)
            self.NetworkIn = metric_dict.get('NetworkIn', None).get("now", None)
            self.CPUUtilization = metric_dict.get('CPUUtilization', None).get("now", None)
        else:
            self.icmp_rt_delay = None
            self.icmp_rt_jitter = None
            self.tcp_rt_delay = None
            self.tcp_rt_jitter = None
            self.request_count = None
            self.NetworkOut = None
            self.NetworkIn = None
            self.CPUUtilization = None

        self.Kp1 = kwargs.get('Kp1',None)
        self.alfa = kwargs.get('alfa',None)
        self.Kd1 = kwargs.get('Kd1',None)
        self.P = kwargs.get('P',None)
        self.I = kwargs.get('I',None)
        self.D = kwargs.get('D',None)

        for k in self.__dict__:
            if self.__dict__[k]:
                self.__dict__[k] = round(float(self.__dict__[k]),3)

    @staticmethod
    def strinfo2():
        ret_string = "#"
        ret_string += "Kp1\t\t"
        ret_string += "Kd1\t\t"
        ret_string += "alfa\t\t"

        ret_string += "CPU\t\t"
        ret_string += "NetIn\t\t"
        ret_string += "NetOut\t\t"

        ret_string += "i_del\t\t"
        ret_string += "i_jit\t\t"
        ret_string += "t_del\t\t"
        ret_string += "t_jit\t\t"
        ret_string += "request"

        return ret_string

    def __str2__(self):

        ret_string = ""
        ret_string += "{ciccio.Kp1}\t\t"
        ret_string += "{ciccio.Kd1}\t\t"
        ret_string += "{ciccio.alfa}\t\t"

        ret_string += "{ciccio.CPUUtilization}\t\t"
        ret_string += "{ciccio.NetworkIn}\t\t"
        ret_string += "{ciccio.NetworkOut}\t\t"

        ret_string += "{ciccio.icmp_rt_delay}\t\t"
        ret_string += "{ciccio.icmp_rt_jitter}\t\t"
        ret_string += "{ciccio.tcp_rt_delay}\t\t"
        ret_string += "{ciccio.tcp_rt_jitter}\t\t"
        ret_string += "{ciccio.request_count}"

        return ret_string.format(ciccio=self)

    @staticmethod
    def strinfo():
        ret_string = "#"
        ret_string += "Kp1\t\t"
        ret_string += "Kd1\t\t"
        ret_string += "alfa\t\t"

        ret_string += "CPU\t\t"
        ret_string += "NetIn\t\t"
        ret_string += "NetOut\t\t"

        return ret_string

    def __str__(self):

        ret_string = ""
        ret_string += "{ciccio.Kp1}\t\t"
        ret_string += "{ciccio.Kd1}\t\t"
        ret_string += "{ciccio.alfa}\t\t"

        ret_string += "{ciccio.CPUUtilization}\t\t"
        ret_string += "{ciccio.NetworkIn}\t\t"
        ret_string += "{ciccio.NetworkOut}\t\t"

        return ret_string.format(ciccio=self)


if __name__ == "__main__":

    if len(sys.argv) < 2:
        sys.stderr.write("usage: {nome_script} logfile\n".format(nome_script=sys.argv[0]))
        sys.exit(1)

    input_file = sys.argv[1]
    avg_values = False

    avg_values_sentinel = "[INFO] Avg Vals:"
    PID_parameter_sentinel = "[INFO] PID Parameter:"

    with open(input_file) as f:

        params = {}
        print cycle_object.strinfo()

        for line in f:

            if avg_values:
                dizionario_metriche = eval(line.lstrip("defaultdict(<type 'dict'>, ").rstrip(")\n"))
                params['metric_dict'] = dizionario_metriche
                avg_values = False

            elif avg_values_sentinel in line:
                avg_values = True
                if params:
                    ciclo = cycle_object(**params)
                    print ciclo
                params = {}

            elif PID_parameter_sentinel in line:
                k, v = line.split("PID")[1].split(':')[1].split("=")
                params[k.strip()] = float(v.strip())
