reset;
set terminal postscript eps enhanced color linewidth 1;\
# set termoption dashed;
### SIZE
set size 0.92, 1
### LEGEND
#set key outside;
#set key top right;
set key font ", 17";

set grid lc rgb "grey";
set border lw 1 lc rgb "#666666"
set xtics textcolor rgb "#666666"
set ytics textcolor rgb "#666666"
set xlabel textcolor rgb "#666666"
set ylabel textcolor rgb "#666666"
set y2label textcolor rgb "#666666"

## XLABELS
set xlabel 'Time interval';

set xlabel font ", 20" 
set ylabel font ", 20"
set y2label font ", 20"
# set yrange [0:]

## TICS
set xtics font ", 12" 
set ytics font ", 12" 
set xtics 0,1,50
 
#set border 1+2 back
set border 3
set xtics nomirror; set ytics nomirror; 

set style line 1 lc rgb "orange" lw 5 lt 1 ps 2 pt 7 pi -1
set style line 7 lc rgb 'orange' lt 1 lw 7 pt 7 pi -1 ps 1.5
set style line 8 lc rgb 'red' lt 1 lw 5 pt 7 pi -1 ps 1
set style line 88 lc rgb 'blue' lt 1 lw 5 pt 7 pi -1 ps 1
set style line 69 lc rgb 'blue' lt 2 lw 3 pt 7 pi -1 ps 1
set style line 18 lc rgb 'orange' lt 1 lw 4 pt 7 pi -1 ps 1.5
set style line 9 lc rgb 'orange' lt 1 lw 2 
set style line 10 lc rgb 'grey' lt 2 lw 1 
set pointintervalbox 2

set style line 2 lc 1 lw 2 pt 9 ps 2 lt 1 
set style line 3 lc 1 lw 2 pt 7 ps 2 lt 1 
set style line 4 lc 3 lw 2 pt 5 ps 2 lt 2 
set style line 5 lc 3 lw 2 pt 9 ps 2 lt 2
set style line 6 lc 3 lw 2 pt 7 ps 2 lt 2 

set style arrow 1 nohead ls 9
set style arrow 2 nohead ls 10

