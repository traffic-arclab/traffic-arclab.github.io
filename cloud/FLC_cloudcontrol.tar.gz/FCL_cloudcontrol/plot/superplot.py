#! /usr/bin/python

import shutil,os,sys,logging,time


LB_EK = -0.2
UB_EK = 0.2
REF_YK = 1


#["uk","yk","ek", "vmnr","vmcpu"]
iterations = {0:{'name':"uk", "ylabel":"u_k", "input_suffix": "_u.txt"},
	      1:{'name':"yk", "ylabel":"y_k","input_suffix": "_y.txt"},
	      2:{'name':"ek", "ylabel":"e_k","input_suffix": "_e.txt"}, 
	      3:{'name':"vmnr","ylabel":"VM count","input_suffix": "_vmnum.txt"}#,
	      #4:{'name':"Kp","ylabel":"K_p","input_suffix": "_Kp.txt"},
	      #5:{'name':"Kd","ylabel":"K_d","input_suffix": "_Kd.txt"}
	      }

if __name__ == "__main__":
	
	if len(sys.argv) < 2:
		sys.stderr.write("usage: [python] "+sys.argv[0]+ " PATH/TO/FOLDER\n")
		sys.exit(1)
	
	
	logging.Formatter.converter = time.gmtime
	#logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.INFO)
	logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.DEBUG)
	
	infolder = sys.argv[1].rstrip("/")
	basename = os.path.basename(infolder)
	logging.info('infolder %s', infolder)
	logging.info('basename %s', basename)
	
	baseplot = "plot.gp"
	
	
	outfolder = basename+"_results"
	
	try:
		logging.info('creating %s', outfolder)
		os.mkdir(outfolder)
		
	except:
		logging.warning('folder %s alredy exists', outfolder)
		sys.exit(1)
	
	
	
	for i in iterations: 
		# generate gp
		outfile = outfolder+"/"+basename+"_"+iterations[i]["name"]
		shutil.copyfile("plot.gp",outfile+".gp")
		f = open(outfile+".gp","a")
		
		padd = "set ylabel '"+iterations[i]["ylabel"]+"';\n"
		padd += "set output '"+outfile+".eps';\n"
		
		logging.debug("data file: %s",infolder+"/"+basename+iterations[i]["input_suffix"])
		
		padd += "lb(x) = "+str(LB_EK)+";\n"
		padd += "ub(x) = "+str(UB_EK)+";\n"
		padd += "ref(x) = "+str(REF_YK)+";\n"
		
		padd += "plot '"+infolder+"/"+basename+iterations[i]["input_suffix"]+"' using 1 ls 8 with linespoints title ''"
		
		#padd += "plot '"+infolder+"/"+basename+iterations[i]["input_suffix"]+"' using 1 ls 8 with fsteps title '',"
		#padd += " '"+infolder+"/"+basename+iterations[i]["input_suffix"]+"' using 1 ls 8 with points title ''"
		
		if i == 2: #e_k
			padd += ",\\\nlb(x) ls 69 title '', ub(x) ls 69 title ''"
		
		elif i == 1: #y_k
			padd += ",\\\nref(x) ls 69 title ''"
		
		
		padd += "\n"
		
		f.write(padd)
		f.close()
	
	logging.info("gnuplotting %s",outfolder+"/*.gp")
	runstr = "gnuplot "+outfolder+"/*.gp"
	os.system(runstr)
	
	logging.info("converting to %s",outfolder+"/"+outfolder+".pdf")
	runstr2 = "convert -density 600 " +outfolder+"/*.eps "+outfolder+"/"+outfolder+".pdf"
	os.system(runstr2)
