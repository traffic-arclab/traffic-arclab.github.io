#! /usr/bin/python

import shutil,os,sys,logging,time,numpy
from pprint import *

#DELTA_T = 1
DELTA_T = 360
#INITIAL_EMPTY_SLOTS = 3


def print_workload(INFILE, OUTFILE):

	diz = {} #ts:reqs
	for line in open(INFILE):
		#if "requests" in line and "requests=0" not in line:
		if "requests" in line:
			ts = None
			reqs = None
			for kv in line.split():
				k = kv.split("=")[0]
				v = kv.split("=")[1]
				
				if k == "time":
					ts = v
				if k == "requests":
					reqs = v
				
			diz[float(ts)] = int(reqs)
	
	pprint ("diz")
	pprint (diz)
	
	START = min(diz)
	
	# trasla diz
	diz2 = {} #diz2 shifted
	for k in diz:
		diz2[k-START] = diz[k]
	
	pprint ("diz2")
	pprint (diz2)
	
	# Aggregazione	
		
	DURATION = max(diz2) - min(diz2)
	INTERVALS = int(DURATION)/DELTA_T +1
	
	print DURATION
	print INTERVALS
	
	diz3 = {} #deltat:cumulative_reqs
	
	for i in range(0,INTERVALS):
		diz3[i] = 0
		for ts in diz2:
			if ts >= i*DELTA_T and ts < (i+1)*DELTA_T:
				diz3[i] += diz2[ts]
				
				
	pprint ("diz3")
	pprint (diz3)			
	
	
	# Write out
	fout = open(OUTFILE,'w')
	for x in diz3:
		linetowrite = "%s\t%s\n"%(x,diz3[x])
		fout.write(linetowrite)
	fout.close()


def print_latency(INFILE, OUTFILE):

	diz = {} #ts:reqs
	for line in open(INFILE):
		#if "requests" in line and "requests=0" not in line:
		if "throughput" in line and "throughput=0rps" not in line:
			ts = None
			latency = None
			for kv in line.split():
				k = kv.split("=")[0]
				v = kv.split("=")[1]
				
				if k == "time":
					ts = v
				if k == "latency":
					#latency=606:nan:1286:nan:1967:(1286)ms
					latency = float(v.split(":")[-1].lstrip("(").rstrip(")ms"))
				
			diz[float(ts)] = int(latency)
	
	pprint ("diz")
	pprint (diz)
	
	START = min(diz)
	
	# trasla diz
	diz2 = {} #diz2 shifted
	for k in diz:
		diz2[k-START] = diz[k]
	
	pprint ("diz2")
	pprint (diz2)
	
	# Aggregazione	
		
	DURATION = max(diz2) - min(diz2)
	INTERVALS = int(DURATION)/DELTA_T +1
	
	print DURATION
	print INTERVALS
	
	diz3 = {} #deltat:cumulative_reqs
	
	for i in range(0,INTERVALS):
		diz3[i] = 0
		
		sdf = [diz2[ts] for ts in diz2 if (ts >= i*DELTA_T and ts < (i+1)*DELTA_T)]
		
		diz3[i] = numpy.mean(sdf)
		
				
				
	pprint ("diz3")
	pprint (diz3)			
	
	
	# Write out
	fout = open(OUTFILE,'w')
	for x in diz3:
		linetowrite = "%s\t%s\n"%(x,diz3[x])
		fout.write(linetowrite)
	fout.close()



def create_gp(DATFILE, OUTFILE): #per plot workload
	
	# generate gp
	outfile = OUTFILE
	shutil.copyfile("plot.gp",outfile+".gp")
	f = open(outfile+".gp","a")

	padd = "set ylabel '# requests';\n"
	#padd += "set xtics nomirror; set ytics nomirror;\n"
	padd += "set output '"+outfile+".eps';\n"

	#logging.debug("data file: %s",infolder+"/"+basename+iterations[i]["input_suffix"])

	#padd += "plot '"+infolder+"/"+basename+iterations[i]["input_suffix"]+"' using 1 ls 8 with linespoints title ''\n"
	
	padd += "set xrange [0:]\n"
	#padd += "plot '"+DATFILE+"' using ($1+1):2 ls 8 with fsteps title '',"
	#padd += "plot '"+DATFILE+"' using ($1+1):2 ls 8 with fsteps title ''\n"
	padd += "plot '"+DATFILE+"' using ($1+0.5):2 ls 8 with linespoints title ''\n"
	#padd += " '"+DATFILE+"' using 1 ls 8 with points title ''\n"

	f.write(padd)
	f.close()

def create_gp2(DATFILE, OUTFILE): #per plot workload e latency
	
	# generate gp
	outfile = OUTFILE+"2"
	shutil.copyfile("plot.gp",outfile+".gp")
	f = open(outfile+".gp","a")

	padd = "set ylabel '# requests';\n"
	padd += "set y2label 'avg latency [ms]';\n"
	padd += 'set y2tics nomirror font ", 12;\n'
	padd += "set output '"+outfile+".eps';\n"
	padd += "set border 11;\n"

	#logging.debug("data file: %s",infolder+"/"+basename+iterations[i]["input_suffix"])

	#padd += "plot '"+infolder+"/"+basename+iterations[i]["input_suffix"]+"' using 1 ls 8 with linespoints title ''\n"
	
	padd += "set xrange [0:]\n"
	padd += "set y2range [0:]\n"
	#padd += "plot '"+DATFILE+"' using ($1+1):2 ls 8 with fsteps title '',"
	#padd += "plot '"+DATFILE+"' using ($1+1):2 ls 8 with fsteps title ''\n"
	padd += "plot '"+DATFILE+"' using ($1+0.5):2 ls 8 smooth csplines axes x1y1 title 'workload',\\\n"
	padd += "'"+DATFILE.rstrip(".dat")+"_lat.dat"+"' using ($1+0.5):2 ls 88 smooth csplines axes x1y2 title 'latency'"
	#padd += " '"+DATFILE+"' using 1 ls 8 with points title ''\n"

	f.write(padd)
	f.close()


def create_gp(DATFILE, OUTFILE): #per plot workload
	
	# generate gp
	outfile = OUTFILE
	shutil.copyfile("plot.gp",outfile+".gp")
	f = open(outfile+".gp","a")

	#padd = "set ylabel '# requests';\n"
	#padd += "set xtics nomirror; set ytics nomirror;\n"
	padd = "set output '"+outfile+".eps';\n"

	#logging.debug("data file: %s",infolder+"/"+basename+iterations[i]["input_suffix"])

	#padd += "plot '"+infolder+"/"+basename+iterations[i]["input_suffix"]+"' using 1 ls 8 with linespoints title ''\n"
	
	padd += "set xrange [0:]\n"
	#padd += "plot '"+DATFILE+"' using ($1+1):2 ls 8 with fsteps title '',"
	#padd += "plot '"+DATFILE+"' using ($1+1):2 ls 8 with fsteps title ''\n"
	padd += "plot '"+DATFILE+"' using ($1+0.5):2 ls 8 with linespoints title ''\n"
	#padd += " '"+DATFILE+"' using 1 ls 8 with points title ''\n"

	f.write(padd)
	f.close()



if __name__ == "__main__":
	
	if len(sys.argv) < 3:
		sys.stderr.write("usage: [python] "+sys.argv[0]+ " PATH/TO/HTTPMON.LOG PATH/TO/OUTFILE\n")
		sys.exit(1)

	LOGFILE = sys.argv[1]
	OUTFILE = sys.argv[2]
	
	print_workload(LOGFILE, OUTFILE+".dat") #crea .dat - workload
	print_latency(LOGFILE, OUTFILE+"_lat.dat") #crea .dat - latency

	create_gp(OUTFILE+".dat", OUTFILE) #crea .gp
	
	logging.info("gnuplotting %s",OUTFILE+".gp")
	runstr = "gnuplot "+OUTFILE+".gp"
	os.system(runstr)
	
	
	create_gp2(OUTFILE+".dat", OUTFILE) #crea .gp
	
	logging.info("gnuplotting %s",OUTFILE+".gp")
	runstr = "gnuplot "+OUTFILE+"2"+".gp"
	os.system(runstr)
	
	
	#logging.info("converting to %s",outfolder+"/"+outfolder+".pdf")
	#runstr2 = "convert -density 600 " +outfolder+"/*.eps "+outfolder+"/"+outfolder+".pdf"
	#os.system(runstr2)
