#! /bin/bash -x

IN=$1
python superplot.py $IN


rr=$(basename $IN)
python httpmon-logparser.py $IN/httpmon.log $rr\_results/wl

convert -density 600 $rr\_results/*.eps $rr\_results/all.pdf
