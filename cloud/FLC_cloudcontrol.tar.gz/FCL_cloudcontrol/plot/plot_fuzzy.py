#! /usr/bin/python

import shutil,os,sys,logging,time


#LB_EK = -10
#UB_EK = 10
#REF_YK = 30


#Kp1            Kd1             alfa            Kp              Kd              CPU             NetIn           NetOut

iterations = {0:{'name':"Kp1", "ylabel":"Kp1", "input_suffix": "_kp1.txt", "column": "1"},
              1:{'name':"Kd1", "ylabel":"Kd1","input_suffix": "_kd1.txt", "column": "2"},
              2:{'name':"alpha", "ylabel":"alpha","input_suffix": "_alpha.txt", "column": "3"},
              #3:{'name':"Kp","ylabel":"Kp","input_suffix": "_kp.txt", "column": "4"},
              #4:{'name':"Kd","ylabel":"Kd","input_suffix": "_kd.txt", "column": "5"},
              5:{'name':"CPU","ylabel":"CPUUtilization","input_suffix": "_CPU.txt", "column": "6"},
              6:{'name':"NetIn","ylabel":"NetworkIn","input_suffix": "_netin.txt", "column": "7"},
              7:{'name':"NetOut","ylabel":"NetworkOut","input_suffix": "_netout.txt", "column": "8"}
              }

if __name__ == "__main__":

        if len(sys.argv) < 2:
                sys.stderr.write("usage: [python] {script_name} PATH/TO/FILE\n".format(script_name=sys.argv[0]))
                sys.exit(1)


        logging.Formatter.converter = time.gmtime
        logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.DEBUG)

        infile = sys.argv[1]  # absolute file path
        basename = os.path.basename(infile)  # filename
        infolder = ("./%s" % os.path.dirname(infile).lstrip("./").lstrip("/")).rstrip("/")  # folder

        logging.info('infolder %s', infolder)
        logging.info('basename %s', basename)
        baseplot = "plot.gp"

        outfolder = basename+"_results_fuzzy"

        try:
                logging.info('creating %s', outfolder)
                os.mkdir(outfolder)

        except:
                logging.warning('folder %s alredy exists', outfolder)
                sys.exit(1)



        for i in iterations:
                # generate gp
                outfile = outfolder+"/"+basename+"_"+iterations[i]["name"]
                shutil.copyfile("plot.gp",outfile+".gp")
                f = open(outfile+".gp","a")

                padd = "set ylabel '"+iterations[i]["ylabel"]+"';\n"
                padd += "set output '"+outfile+".eps';\n"

                #logging.debug("data file: %s",infolder+"/"+basename+iterations[i]["input_suffix"])

                #padd += "lb(x) = "+str(LB_EK)+";\n"
                #padd += "ub(x) = "+str(UB_EK)+";\n"
                #padd += "ref(x) = "+str(REF_YK)+";\n"

                padd += "plot '"+infolder+"/"+basename+"' using "+iterations[i]["column"]+" ls 8 with linespoints title ''"


                #if i == 2: #e_k
                        #padd += ",\\\nlb(x) ls 69 title '', ub(x) ls 69 title ''"

                #elif i == 1: #y_k
                        #padd += ",\\\nref(x) ls 69 title ''"


                padd += "\n"

                f.write(padd)
                f.close()

        logging.info("gnuplotting %s",outfolder+"/*.gp")
        runstr = "gnuplot "+outfolder+"/*.gp"
        os.system(runstr)

        logging.info("converting to %s",outfolder+"/"+outfolder+".pdf")
        runstr2 = "convert -density 600 " +outfolder+"/*.eps "+outfolder+"/"+outfolder+".pdf"
        os.system(runstr2)
