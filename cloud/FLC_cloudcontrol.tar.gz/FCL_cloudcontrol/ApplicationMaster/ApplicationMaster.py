from collections import defaultdict
import os
import multiprocessing as mp
from ConfigParser import SafeConfigParser
import xmlrpclib
import logging
import time


class ApplicationMaster:

    def __init__(self, conf_file=None):

        if not conf_file:
            conf_file = "%s/%s/%s" % (os.path.dirname(os.path.abspath(__file__)), "conf", "app_master.ini")
        else:
            self.conf_file = conf_file

        self.cluster_info = {}
        parser = SafeConfigParser()
        parser.read(conf_file)
        self.server_port = parser.getint('appserver', 'port')

        self.overallTraffic = float(parser.get('appmaster', 'overallTrafficVolume'))
        self.communicationDuration = parser.getint('appmaster', 'communicationDuration')
        self.communicationPacketRate = parser.getint('appmaster', 'communicationPacketRate')
        self.communicationPacketSize = parser.getint('appmaster', 'communicationPacketSize')

        logging.Formatter.converter = time.gmtime
        logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.INFO,)

    @staticmethod
    def __get_ips(cluster_info):
        return cluster_info.values()  # get public IPs

    # def __generate_matrix(self):
    #     ip_list = self.__get_ips(self.cluster_info)
    #     matrix = defaultdict(dict)
    #     num_pairs = len(ip_list) * (len(ip_list) - 1)
    #     traffic_per_pair = self.overallTraffic / num_pairs if num_pairs else 0
    #
    #     for src in ip_list:
    #         for dst in ip_list:
    #             matrix[src][dst] = traffic_per_pair if src != dst else 0
    #     return dict(matrix)

    def __generate_matrix(self): # TODO: test me, please
        ip_list = self.__get_ips(self.cluster_info)
        matrix = defaultdict(dict)
        num_pairs = len(ip_list) * (len(ip_list) - 1)
        traffic_per_pair = self.overallTraffic / num_pairs if num_pairs else 0
        for src in ip_list:
            for dst in ip_list:
                matrix[src][dst] = {
                    "rate": self.communicationPacketRate,
                    "volume": traffic_per_pair if src != dst else 0,
                    "duration": self.communicationDuration,
                    "pkt_size": self.communicationPacketSize
                }
        return dict(matrix)


    def __generate_update(self):
        return {
            "cluster_info": self.cluster_info,
            "matrix": self.__generate_matrix()
        }

    def __push_update(self, ip, update, queue):
        print update
        retry = 0
        endpoint = "http://%s:%s" % (ip, self.server_port)
        logging.info("Pushing application update to: %s", endpoint)
        vm_proxy = xmlrpclib.ServerProxy(endpoint)
        updated = False
        while retry < 3:
            try:
                updated = vm_proxy.as_update(update)
                break
            except Exception, e:  # TODO: manage timeout error
                logging.error("Exception in as_update: %s", str(e))
                retry += 1
                time.sleep(2)  # patch - sleep 2 seconds between retries

        queue.put_nowait(updated)
        return updated

    def __set_cluster_info(self, cluster_info):
        """
        Load cluster info.
        :param cluster_info: {pri1: pub1, pri2: pub2}
        :return: True        """
        try:
            self.cluster_info = cluster_info
            return True
        except:
            return False

    def update_em_all(self, cluster_info):
        """
        Wrapper for private methods.
        Generates the matrix, creates a thread for each vm designed to update its state.
        To be called every the active-VM set changes, i.e. every time a VM is shut down or a new VM is created.
        :param cluster_info: dict of active vms {pri1: pub1, pri2: pub2}
        :return:
        """
        self.__set_cluster_info(cluster_info)
        update = self.__generate_update()
        pushers = []
        queue = mp.Queue()
        for vm in self.__get_ips(self.cluster_info):
            pushers.append(mp.Process(target=self.__push_update, args=(vm, update, queue)))

        for p in pushers:
            p.start()

        for p in pushers:
            p.join()

        push_results = []
        while not queue.empty():
            push_results.append(queue.get_nowait())
        updated = push_results.count(True)
        not_updated = push_results.count(False)
        logging.info("%s/%s Application Servers updated", updated, len(push_results))
