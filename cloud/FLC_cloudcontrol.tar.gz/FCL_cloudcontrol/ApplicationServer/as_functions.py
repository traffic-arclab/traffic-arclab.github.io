import requests
import urllib
import json
import os
import time
import multiprocessing as mp
from collections import defaultdict
import xmlrpclib
import subprocess
from ConfigParser import SafeConfigParser
from tools import ditg, Burner


class AppServerConfig:

    cluster_info = None
    full_matrix = None
    local_ip = None
    local_port = None
    res_folder = None
    public_ip = None
    matrix = None

    conf_update_lock = None

    def __init__(self):
        parser = SafeConfigParser()
        parser.read('conf/app_server.ini')
        self.local_port = parser.getint('app_server', 'local_port')
        self.res_folder = parser.get('app_server', 'res_folder')
        if not os.path.exists(self.res_folder):
            os.mkdir(self.res_folder)
            print "Results folder '%s' created" % self.res_folder
        self.conf_update_lock = mp.RLock()
        self.update_configuration()
        self.conf = None

    def __str__(self):
        return str(self.__dict__)

    def update_configuration(self, new_conf=None):
        with self.conf_update_lock:
            if not new_conf:
                try:
                    self.conf = json.load(open('conf/app_servers.json'))
                except IOError:
                    self.conf = None
            else:
                json.dump(new_conf, open('conf/app_servers.json', 'w'))
                self.conf = new_conf
            cmd = "ifconfig | grep 'inet ' | grep -v 127 | sed 's/addr\://g' | awk '{print $2}'"
            task = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.local_ip = task.stdout.read().strip()
            if self.conf:
                self.cluster_info = self.conf["cluster_info"]
                self.public_ip = self.cluster_info[self.local_ip]
                self.full_matrix = self.conf["matrix"]
                self.matrix = self.full_matrix[self.public_ip]


class ApplicationServer:
    exit = False

    def __init__(self):
        self.app_server_config = AppServerConfig()
        self.running_servers_lock = mp.RLock()
        self.running_servers_dict = defaultdict(lambda: 0)
        self.running_servers_processes = []
        self.request_counter = 0
        self.request_counter_lock = mp.RLock()

        self.my_ditg = ditg()
        self.my_ditg.receive()
        self.my_ditg_results_queue = mp.Queue()

        self.my_burner = Burner()

    def get_requests_counter(self):
        """
        Returns the number of requests this Application Server received
        """
        return self.request_counter

    def increment_requests_counter(self):
        """
        Increments the number of requests, locking the variable
        """
        with self.request_counter_lock:
            self.request_counter += 1

    def get_tools_status(self):
        return self.my_ditg.check_ditg()

    def restart_non_working_tools(self):
        """
        Restarts non-running tools
        """
        if not self.get_tools_status()["ITGRecv"]:
            self.my_ditg.receive()
            return "ITGRecv was not running, restarted."
        else:
            return "ITGRecv is running."

    def __do_work(self, recv_ip, rate, volume=None, duration=None, pkt_size=None):
        """
        Runs ITGSend towards a receiver with the fixed rate
        :param recv_ip: the VM which runs ITGRecv
        :param rate: the rate (pkt/s) at which ITGSend generates
        :param volume: total volume to exchange (if None uses tool's default)
        :param duration: total duration of the experiment (if None uses tool's default)
        :return: a dictionary of results (for DITG it's duration of experiment)
        """
        proxy = xmlrpclib.ServerProxy("http://%s:%s/" % (recv_ip, self.app_server_config.local_port))
        print proxy.restart_non_working_tools()
        tic = time.time()

        self.my_ditg.generate(recv_ip,
                              rate=rate,
                              total_volume=volume,
                              total_duration=duration,
                              pkt_size=pkt_size)

        toc = time.time() - tic
        self.my_ditg_results_queue.put((recv_ip, toc))

    # TODO Test me - use logger
    def distribute_jobs(self):
        out_res = dict(success=False, results=[])
        if self.app_server_config.conf:
            self.increment_requests_counter()
            experiment_matrix = self.app_server_config.matrix
            processes = []
            for recv_ip, exp_parameters in experiment_matrix.iteritems():
                rate = exp_parameters.get("rate")
                volume = exp_parameters.get("volume")
                duration = exp_parameters.get("duration")
                pkt_size = exp_parameters.get("pkt_size")
                if volume:
                    p = mp.Process(target=self.__do_work, args=(recv_ip, rate, volume, duration, pkt_size))
                    processes.append(p)
                    p.start()

            for p in processes:
                p.join()

            out_res["success"] = True
            while not self.my_ditg_results_queue.empty():
                out_res["results"].append(self.my_ditg_results_queue.get())
            out_res["results"] = dict(out_res["results"])

        return out_res

    # TODO Test me - use logger
    def get_tools_results(self, start, stop):
        res = defaultdict(dict)
        print "START: ", start, "STOP:", stop
        for f in os.listdir(self.app_server_config.res_folder):
            print f
            if f.endswith(".json"):
                try:
                    ts, _ = f.split(".")[0].split("_")
                    if start <= float(ts) < stop:
                        res[ts].update(json.load(open(os.path.join(self.app_server_config.res_folder, f))))
                except (IndexError, ValueError, IOError):
                    print "Unable to open file '%s'" % f

        return dict(res)

    def __alert_local_web_server(self, caller_port, callback, message, pid, total, request_id, **kwargs):
        local_ip = self.app_server_config.local_ip
        url = "http://%s:%s/%s?" % (local_ip, caller_port, callback)
        uri = urllib.urlencode([("message", message), ("pid", pid), ("total", total), ("request_id", request_id)]
                               + kwargs.items())
        requests.get(url+uri)

    # TODO Test me - use logger
    def __generate_data(self, ip, pid, n_ases, callback, caller_port, request_id):
        proxy = xmlrpclib.ServerProxy("http://%s:%s/" % (ip, self.app_server_config.local_port))
        out_res = proxy.distribute_jobs()
        results_list = out_res["results"]
        success = out_res["success"]

        message = "application server @%s finished its job! Success: %s" % (ip, success)

        # dumps {source_ip: {dest_1: elapsed_time_1, dest_2: elapsed_time_2, ...}}
        out_file_name = '%s/%s_%s.json' % (self.app_server_config.res_folder,
                                                              int(time.time()),
                                                              self.running_servers_dict[pid])
        print "I'm dumping {%s: %s}" % (ip, results_list), "into", out_file_name
        json.dump({ip: results_list}, open(out_file_name, 'w'))

        with self.running_servers_lock:
            self.running_servers_dict[pid] -= 1
            if self.running_servers_dict[pid] <= 0:
                del self.running_servers_dict[pid]
                message += " - and this was the last job!"

        self.__alert_local_web_server(caller_port, callback,
                                      message=message,
                                      pid=pid, total=n_ases, request_id=request_id, results=results_list)

    def as_start_generation(self, callback, caller_port, request_id, iterations):
        """
        It's a generator which launches processes on local and remote ASes and waits
        for their reply. As processes terminate, yields information back to the caller.
        """
        self.app_server_config.update_configuration()
        if self.app_server_config.conf:

            # start cpu-burn process
            print "starting CPU intensive task (%s iterations)" % iterations
            mp.Process(target=self.my_burner.burn_cycles, args=(iterations,)).start()

            ases = self.app_server_config.full_matrix.keys()
            print "Asking %s to generate" % ases
            with self.running_servers_lock:
                try:
                    pid = max(self.running_servers_dict.keys()) + 1
                except ValueError:
                    pid = 0

                for i in ases:
                    print "[AS %s - PID %s] Sending instructions..." % (i, pid)
                    self.running_servers_dict[pid] += 1
                    p = mp.Process(
                        target=self.__generate_data,
                        args=(i, pid, len(ases), callback, caller_port, request_id))
                    self.running_servers_processes.append(p)
                    p.start()

            mex = "All the jobs have been sent!"
        else:
            mex = "I have no info about the others!"
            self.__alert_local_web_server(caller_port, callback,
                                          message="DONE - %s" % mex,
                                          pid=-1, total=-1, request_id=request_id)

        return mex

    def as_update(self, app_serv_config):
        """
        Updates the configuration for this Application Server
        :param app_serv_config: dictionary
        :return: True if no IOErros, else False
        """
        try:
            self.app_server_config.update_configuration(app_serv_config)
            return True
        except IOError:
            return False
