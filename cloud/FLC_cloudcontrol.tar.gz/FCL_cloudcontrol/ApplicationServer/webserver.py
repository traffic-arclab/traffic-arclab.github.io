#! /usr/bin/python
import cherrypy
import multiprocessing as mp
from ConfigParser import SafeConfigParser
import xmlrpclib
import subprocess
import pprint
import os
import sys


class WebServerConfig:
    """
    Provides the configuration parameters for the Web Server.
    Once initialized, the related object reads the configuration file
    at the path 'conf/web_server.ini'.

    It keeps trace of the IP address and port number the Web Server
    is listening on.
    """

    local_port = None
    local_ip = None

    def __init__(self):
        """
        Initialize the configuration, setting the following attributes:

        - local_port: is the port the Web Server is listening to
        - local_ip: the IP of the interface the Web Server is listening on
        """
        self.update_configuration()

    def __str__(self):
        pp = pprint.PrettyPrinter(width=20)
        return pp.pformat(self.__dict__)

    def update_configuration(self):
        """
        Updates the local configuration reading the configuration file.
        """
        parser = SafeConfigParser()
        parser.read('conf/web_server.ini')
        self.local_port = parser.getint('web_server', 'local_port')
        cmd = "ifconfig | grep 'inet ' | grep -v 127 | head -1 | sed 's/addr\://' | awk '{print $2}'"
        task = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.local_ip = task.stdout.read().strip()


class WebServer(object):
    """
    The Web Server handles the requests from a client using HTTP GET/POST
    messages. The Web Server act as a high-level interface for the
    Application Server, which receives requests to perform jobs, and alerts
    the Web Server when jobs are completed.
    The most important methods (which are exposed as URI) are:

    - /: is the index. The Web Server handles a HTTP GET request, calls the
      local Application Server, asking to perform some jobs.
    - work_done: it's a callback called by the Application Server to alert
      the Web Server when a job has been completed.
    """

    def __init__(self, web_server_config):
        """
        :param web_server_config: a WebServerConfig object
        """

        # app server configuration (class WebServerConfig)
        self.web_server_config = web_server_config

        self.requests_ids_dict_lock = mp.RLock()
        self.requests_ids_dict = {}

        self.processes = []
        self.messages = mp.Queue()

    def new_request_key(self):
        """
        Adds a key on a shared dictionary of queues. Each queue will contain
        the results (given by the Application Server) related to the request
        performed by a client to the URI '/'.
        :return: the new key of the dictionary
        """
        with self.requests_ids_dict_lock:
            try:
                next_key = max(self.requests_ids_dict.keys()) + 1
            except ValueError:
                next_key = 0
            self.requests_ids_dict[next_key] = mp.Queue()
        return next_key

    def serve_request(self, request_id, iterations):

        def generate(callback, local_port):
            proxy = xmlrpclib.ServerProxy("http://%s:%s/" % (self.web_server_config.local_ip, 20000))
            print proxy.as_start_generation(callback, local_port, request_id, iterations)

        my_callback = "work_done"
        mp.Process(target=generate,
                   args=(my_callback, self.web_server_config.local_port))\
            .start()
        return "Request ID: %s - Asked local AS to work [Callback: %s - Port: %s - IP: %s]" % \
               (request_id, my_callback, self.web_server_config.local_port, self.web_server_config.local_ip)

    @cherrypy.expose
    def work_done(self, message, pid, total, request_id, **kwargs):
        """
        The AS will call this function to indicate it finished its job
        :param pid: the process pid saved in the running_servers_dict
        :param message: a message from local AS
        """
        print "[PID %s - Request ID %s] a job in %s completed - MESSAGE: %s - ADDITIONAL: %s" % \
              (pid, request_id, total, message, kwargs)

        with self.requests_ids_dict_lock:
            self.requests_ids_dict[int(request_id)].put((int(pid), int(total), message, kwargs))
        return "Thanks!"

    @cherrypy.expose
    def index(self, iterations=26000000):
        """
        The index returns the body of a HTML page showing a set of results and
        status messages. A client issues a request to '/', this method handles
        the request and asks the local Application Server to work. Then listen
        for messages contained in the local shared dictionary of queues, written
        by the AS.
        It uses 'yield' instead of 'return' statement to fill the client response.
        It allows to stream the results as they arrive into the messages queues.
        :return: a formatted HTML page with status messages and results
        """
        yield "<html><head><body style='font-family: arial;'> \
              <script>console.log({0}); window.env = {0};</script>".format(os.environ)

        yield "<div style='width: 100%'> \
                <div style='height: 100%; width: 8%; float: left'> \
                   <img src='/images/cloud.png' width='50px' style='margin: 13px'> \
                </div> \
                <div style='float: right; height: 100%; width: 92%'> \
                    <h1>I'm Alive!</h1>"

        request_key = self.new_request_key()
        status = self.serve_request(request_key, iterations)
        yield "<h4>%s</h4> \
                <p>Waiting for responses...</p>" % status

        yield "<ul>"
        counter = 1
        while True:
            pid, total, message, additional = self.requests_ids_dict[request_key].get()
            yield "<li>[PID %s - %s] %s/%s completed - additional: %s</li>" % \
                  (pid, message, counter, total, additional)
            if counter == total:
                break
            counter += 1
        yield "<li>PID: %s - DONE</ul></div></div></body></head></html></li>" % pid

    index._cp_config = {'response.stream': True}

    @cherrypy.expose
    def echo_test(self, **kwargs):
        """
        Serves all the requests containing query strings. Print the query
        string back within a HTML page.
        :param kwargs: the dictionary mapping of the query string
        :return: the kwargs dictionary formatted
        """
        pp = pprint.PrettyPrinter(width=20)
        ret = pp.pformat(kwargs).replace("\n", "<br/>").replace(" ", "&nbsp;")
        return "<p style='font-family: monospace'>%s</p>" % ret

if __name__ == '__main__':

    web_server = WebServerConfig()
    cherrypy.config.update(
        {'server.socket_host': web_server.local_ip,
         'server.socket_port': web_server.local_port})

    conf = {"/images":
                {"tools.staticdir.on": True,
                 "tools.staticdir.dir": os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "assets/images")
                 }
            }
    print conf

    cherrypy.quickstart(WebServer(web_server), config=conf)
