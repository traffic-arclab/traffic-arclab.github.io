import SocketServer
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
from as_functions import *


class ThreadedXMLRPCServer(SocketServer.ThreadingMixIn, SimpleXMLRPCServer):
    pass

if __name__ == "__main__":

    wrapper = ApplicationServer()
    server = ThreadedXMLRPCServer(
        (wrapper.app_server_config.local_ip,
         wrapper.app_server_config.local_port),
        SimpleXMLRPCRequestHandler,
        logRequests=True,
        allow_none=True)

    server.register_introspection_functions()
    server.register_instance(wrapper)

    while not wrapper.exit:
        if wrapper.exit:
            break
        server.handle_request()