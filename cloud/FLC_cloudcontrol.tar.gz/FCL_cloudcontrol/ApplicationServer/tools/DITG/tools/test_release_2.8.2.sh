#!/bin/bash
# Regression tests for release 2.8.2
#
# TODO: reuse EasyTG as a library


# Configuration
SCRIPT_DIR=$(cd $(dirname $0); pwd)
DITG_SRC_DIR="$SCRIPT_DIR/../src/"
DITG_BIN_DIR="$SCRIPT_DIR/../bin/"
RESULTS_PATH="/tmp/ditgtest"
RESULTS_FILE="$RESULTS_PATH/results.txt"
DEBUG_INFO="$RESULTS_PATH/debug.info"
declare -A METRICS
METRICS=([B]=bitrate [D]=delay [J]=jitter [P]=loss)

## Functions ##

# Start ITGRecv in background
start_receiver()
# $* = receiver options
{
	# Start receiver
	( sudo bash -c "{ $DITG_BIN_DIR/ITGRecv $* ; echo \$? > $R_EXIT ; }" > $R_OUT 2>&1 ) &
	sleep 1
}

# Start ITGSend
start_sender()
# $* = sender options
{
	[ $SU ] && SUDO=sudo
	$SUDO $DITG_BIN_DIR/ITGSend $* > $S_OUT 2>&1 
	echo $? > $S_EXIT
}

# Terminate ITGRecv
stop_receiver()
{
	pgrep ITGRecv 2>&1 >/dev/null && sudo killall ITGRecv 2>&1 >/dev/null
	while sudo netstat -ltnp | awk '($4 ~ ":9000$"){ f=1 } END{ if (!f) exit(1) }' ; do
		sleep 0.1
	done 
}

# Decode logs
decode()
# $1 = sampling rate
# $2 = log file
# $* = decoder options
{
	sr=$1
	lf=$2
	shift 2
	comp=$(basename $lf | cut -d "." -f1)

	if [ $sr -gt 0 ]; then
		# Derive decoded log names from binary log name
		for m in ${!METRICS[@]}; do
			case $comp in
			sender)   eval S_LOG_$m=${lf//.log/}.${METRICS[$m]}.dat ; eval LOG_$m=S_LOG_$m ;;
			receiver) eval R_LOG_$m=${lf//.log/}.${METRICS[$m]}.dat ; eval LOG_$m=R_LOG_$m ;;
			logger)   eval L_LOG_$m=${lf//.log/}.${METRICS[$m]}.dat ; eval LOG_$m=L_LOG_$m ;;
			esac
		done

		# Decode log
		$DITG_BIN_DIR/ITGDec $lf -b $sr ${!LOG_B} \
					 -d $sr ${!LOG_D} \
					 -j $sr ${!LOG_J} \
					 -p $sr ${!LOG_P} $* > $D_OUT 2>&1
		echo $? > $D_EXIT
	else
		# Decode log
		$DITG_BIN_DIR/ITGDec $lf $* > $D_OUT 2>&1
		echo $? > $D_EXIT
	fi
}

# Setup current test
test_setup()
# $1 = test name
{
	TEST=$1
	echo -n "Running regression test #${TEST}..." | tee -a $RESULTS_FILE
	echo "===== test #${TEST} =====" >&2
	S_FLOWS="$RESULTS_PATH/sender.${TEST}.flows"

	S_LOG="$RESULTS_PATH/sender.${TEST}.log"
	R_LOG="$RESULTS_PATH/receiver.${TEST}.log"
	L_LOG="$RESULTS_PATH/logger.${TEST}.log"

	S_OUT="$RESULTS_PATH/sender.${TEST}.out"
	R_OUT="$RESULTS_PATH/receiver.${TEST}.out"
	L_OUT="$RESULTS_PATH/logger.${TEST}.out"
	D_OUT="$RESULTS_PATH/decoder.${TEST}.out"

	S_EXIT="$RESULTS_PATH/sender.${TEST}.exit"
	R_EXIT="$RESULTS_PATH/receiver.${TEST}.exit"
	L_EXIT="$RESULTS_PATH/logger.${TEST}.exit"
	D_EXIT="$RESULTS_PATH/decoder.${TEST}.exit"
	set -v
}

# Clean logs for the current test
clean_logs()
{
	sudo rm -f $S_LOG* $R_LOG* $L_LOG*
	sudo rm -f $S_EXIT $R_EXIT $L_EXIT $D_EXIT
	sudo rm -f $S_OUT $R_OUT $L_OUT $D_OUT
	sudo rm -f $S_FLOWS ${!LOG_B} ${!LOG_D} ${!LOG_J} ${!LOG_P} 
}

# Check exit status of DITG components
check_status()
# $* = components initials (s,r,d,l)
{
	for c in $*; do
		eval status_var=${c^}_EXIT
		eval out_var=${c^}_OUT
		status=$(cat ${!status_var})
		[ $status -eq 0 -o $status -eq 143 ] || return 10
		grep -qi ERROR ${!out_var} && return 11
	done
	return 0
} 

# Declare a test as passed
passed()
{
	set +v
	echo "passed" | tee -a $RESULTS_FILE 
	clean_logs
}

# Declare a test as failed
failed()
{
	set +v
	case $? in
	10) e="exit status" ;;
	11) e="output" ;;
	*)  e="condition" ;;
	esac
	echo "failed ($e)" | tee -a $RESULTS_FILE
}

## MAIN ##

# Parse CLI options
while getopts 'dh' opt; do
	case $opt in
	d)
		DEBUG="debug=1"
	;;
	esac
done
shift $((OPTIND-1))

# Parse test name
testname=$1
[ $testname ] || {
	echo "Syntax: ${0##*/} [options] [all|<test_name>]"
	echo ""
	echo "Options:"
	echo "  -d           use debug binaries"
	exit
}

# Compile DITG for testing
echo -n "Building D-ITG"
( cd $DITG_SRC_DIR && make sctp=on dccp=on $DEBUG ) | awk '{ printf "." ; fflush(stdout) }'
echo done

# Acquire sudo permission
sudo -v

# Parse CLI options
testname=$1

# Prepare for tests
echo "-----------------------------------------------" | tee -a $RESULTS_FILE
echo "Test started on "$( date ) | tee $RESULTS_FILE
echo "-----------------------------------------------" | tee -a $RESULTS_FILE
mkdir -p $RESULTS_PATH
stop_receiver

# Enable and redirect debug output to debug log
exec 2>$DEBUG_INFO
set -x

# 2649
if [ $testname == "all" -o $testname == "2649" ]; then
	test_setup 2649
	RCV_ADDRESS=127.0.0.1

	# Execute test
	start_receiver -a $RCV_ADDRESS
	start_sender -z 10 -x $R_LOG
	stop_receiver
	decode 1000 $R_LOG

	# Check condition
	(set -e
		check_status s r d &&
		rcv_address=$( awk -F"-" '(NR == 1){ print $2 }' $R_LOG_B ) &&
		[ "$rcv_address" == "$RCV_ADDRESS" ] 
	) && passed || failed
fi

# 2650
if [ $testname == "all" -o $testname == "2650" ]; then
	# 2650-1
	test_setup 2650-1
	LOG_FOLDER=/tmp/random
	# Setup pre-conditions
	sudo rm -rf $LOG_FOLDER
	export S_LOG=$LOG_FOLDER/$(basename $S_LOG)
	# Execute test
	start_receiver
	start_sender -z 10 -l $S_LOG
	stop_receiver
	# Check condition
	(set -e
		check_status s r &&
		[ -d $LOG_FOLDER ] 
	) && passed || failed

	# 2650-2
	test_setup 2650-2
	RCV_ADDRESS="::1"
	# Execute test
	start_receiver -a $RCV_ADDRESS
	start_sender -a $RCV_ADDRESS -z 10 -x $R_LOG
	decode 1000 $R_LOG
	stop_receiver
	# Check condition
	(set -e
		check_status s r d &&
		rcv_address=$( awk -F"-" '(NR == 1){ print $2 }' $R_LOG_B ) &&
		[ "$rcv_address" == "$RCV_ADDRESS" ] 
	) && passed || failed
fi

# 2652
if [ $testname == "all" -o $testname == "2652" ]; then
	test_setup 2652
	# Setup pre-conditions
	sudo apt-get install -y valgrind 2>&1 | awk '{ printf "."; fflush(stdout) }'
	# Execute test
	start_receiver 
	start_sender -z 10 -l $S_LOG
	stop_receiver
	# Check condition
	(set -e
		check_status s r &&
		valgrind $DITG_BIN_DIR/ITGDec $S_LOG 2>&1 | grep -q "no leaks are possible"
	) && passed || failed
fi

# 2657
if [ $testname == "all" -o $testname == "2657" ]; then
	test_setup 2657
	# Setup pre-conditions
	ADDR_1="127.1.0.1"
	ADDR_2="127.0.0.1"
	PORT=4000
	cat > $S_FLOWS <<-END
		-z 10 -a $ADDR_1 -rp $PORT
		-z 10 -a $ADDR_1 -rp $(( $PORT + 1 ))
		-z 10 -a $ADDR_2 -rp $PORT 
		-z 10 -a $ADDR_2 -rp $(( $PORT + 1 ))
	END
	# Execute test
	start_receiver 
	start_sender $S_FLOWS 
	stop_receiver
	# Check condition
	(set -e
		check_status s r &&
		notfinished=$(awk '/Starting/{s++} /finished/{f++} END{ print s-f }' $S_OUT) &&
		[ $notfinished -eq 0 ]
	) && passed || failed
fi

# 2663
if [ $testname == "all" -o $testname == "2663" ]; then
	test_setup 2663
	LOG_FOLDER=/tmp/random
	# Setup pre-conditions
	sudo rm -rf $LOG_FOLDER
	export R_LOG=$LOG_FOLDER/$(basename $R_LOG)
	# Execute test
	start_receiver
	start_sender -z 10 -x $R_LOG
	stop_receiver
	# Check condition
	(set -e
		check_status s r &&
		[ -d $LOG_FOLDER ] 
	) && passed || failed
fi

# 2664
if [ $testname == "all" -o $testname == "2664" ]; then
	test_setup 2664
	RCV_ADDRESS="127.0.0.1"
	KBYTES_TO_SEND=5
	# Execute test
	start_receiver 
	start_sender -k $KBYTES_TO_SEND -C 10 -c 1024 -l $S_LOG 
	stop_receiver
	decode 0 $S_LOG
	# Check condition
	(set -e
		check_status s r d &&
		bytes_sent=$( awk -F"=" '/Bytes received/{ print int($2); exit }' $D_OUT ) &&
		[ $bytes_sent -eq $((KBYTES_TO_SEND * 1024)) ]
	) && passed || failed
fi

# 2669
if [ $testname == "all" -o $testname == "2669" ]; then
	test_setup 2669
	RCV_ADDRESS="127.0.0.1"
	PKTS_TO_SEND="10"
	# Execute test
	start_receiver
	SU=1 start_sender -T ICMP 0 -z $PKTS_TO_SEND -x $R_LOG
	stop_receiver
	decode 0 $R_LOG
	# Check condition
	(set -e
		check_status s r d &&
		pkts_sent=$( awk -F"=" '/Total packets/{ print int($2) ; exit }' $D_OUT ) &&
		[ "$pkts_sent" == "$PKTS_TO_SEND" ] 
	) && passed || failed
fi

# 2670
if [ $testname == "all" -o $testname == "2670" ]; then
	test_setup 2670
	PKTS_TO_SEND="10"
	# Execute test
	start_receiver 
	SU=1 start_sender -T ICMP 8 -m rtm -z $PKTS_TO_SEND -x $R_LOG
	stop_receiver
	decode 0 $R_LOG
	# Check condition
	(set -e
		check_status s r d &&
		pkts_sent=$( awk -F"=" '/Total packets/{ print int($2) ; exit }' $D_OUT ) &&
		[ "$pkts_sent" == "$PKTS_TO_SEND" ] 
	) && passed || failed
fi

# 2673
if [ $testname == "all" -o $testname == "2673" ]; then
	test_setup 2673
	PKTS_TO_SEND="10"
	# Execute test
	start_receiver
	start_sender -z $PKTS_TO_SEND -l $S_LOG -x $R_LOG
	stop_receiver
	# Check condition
	(set -e
		check_status s r &&
		decode 0 $S_LOG && 
		pkts_sent=$( awk -F"=" '/Total packets/{ print int($2) ; exit }' $D_OUT ) &&
		[ "$pkts_sent" == "$PKTS_TO_SEND" ] && 
		decode 0 $R_LOG && 
		pkts_rcv=$( awk -F"=" '/Total packets/{ print int($2) ; exit }' $D_OUT ) &&
		[ "$pkts_rcv" == "$PKTS_TO_SEND" ]
	) && passed || failed
fi

# 2674
if [ $testname == "all" -o $testname == "2674" ]; then
	test_setup 2674
	PKTS_TO_SEND="10"
	# Execute test
	start_receiver 
	start_sender -T SCTP 1 1 -z $PKTS_TO_SEND -l $S_LOG -x $R_LOG
	stop_receiver
	# Check condition
	(set -e
		check_status s r &&
		decode 0 $S_LOG && 
		check_status d &&
		pkts_sent=$( awk -F"=" '/Total packets/{ print int($2) ; exit }' $D_OUT ) &&
		[ "$pkts_sent" == "$PKTS_TO_SEND" ] && 
		decode 0 $R_LOG && 
		check_status d &&
		pkts_rcv=$( awk -F"=" '/Total packets/{ print int($2) ; exit }' $D_OUT ) &&
		[ "$pkts_rcv" == "$PKTS_TO_SEND" ]
	) && passed || failed
fi

# 2678
if [ $testname == "all" -o $testname == "2678" ]; then
	test_setup 2678
	ADDR_1="127.1.0.1"
	cat > $S_FLOWS <<-END
		-a $ADDR_1 -rp 10001 VoIP -x G.711.2 -h RTP -VAD
		-a $ADDR_1 -rp 10002 Telnet 
		-a $ADDR_1 -rp 10003 DNS
	END
	# Execute test
	start_receiver
	start_sender $S_FLOWS 
	stop_receiver
	# Check condition
	(set -e
		check_status s r  
	) && passed || failed
fi

