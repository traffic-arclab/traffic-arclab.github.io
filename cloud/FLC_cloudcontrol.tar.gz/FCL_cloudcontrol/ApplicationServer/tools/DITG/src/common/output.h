/*
 *   Component of the D-ITG 2.8.2 (r2717) platform (http://traffic.comics.unina.it/software/ITG)
 *
 *   Copyright     : (C) 2004-2015 by Alessio Botta, Walter de Donato, Alberto Dainotti,
 *                                      Stefano Avallone, Antonio Pescape' (PI)
 *                                      COMICS (COMputer for Interaction and CommunicationS) Group
 *                                      Department of Electrical Engineering and Information Technologies
 *                                      University of Napoli "Federico II".
 *   email         : a.botta@unina.it, walter.dedonato@unina.it, alberto@unina.it,
 *                   stavallo@unina.it, pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 * 
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 * 		     
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *				     
 *   For commercial use please refer to D-ITG Professional.
 */




#ifndef __OUTPUT_H__
#define __OUTPUT_H__

#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include "thread.h"

#define FARGT "%s"
#define FARGV ""


#define I(...)	{ \
			fprintf(stdout, __VA_ARGS__); \
			fprintf(stdout, "\n"); \
			fflush(stdout); \
		}

# define W(...)	{ \
			fprintf(stdout, "WARNING: %s("FARGT"): ", __FUNCTION__, FARGV); \
			fprintf(stdout, __VA_ARGS__); \
			fprintf(stdout, "\n"); \
			fflush(stdout); \
		}
#if defined UNIX  && ! defined __FreeBSD__ && ! defined OSX

# define E(...)	{ \
			fprintf(stderr, "ERROR: %s("FARGT"): " , __FUNCTION__, FARGV); \
			fprintf(stderr, __VA_ARGS__); \
			fprintf(stderr, " (%s)\n", errno > 0 ? strerror(errno) : ""); \
			fflush(stderr); \
			if (syscall(SYS_gettid) == getpid()) \
				exit(errno); \
			else \
				exitThread(); \
		}
#else

# define E(...)	{ \
			fprintf(stderr, "ERROR: %s("FARGT"): ", __FUNCTION__, FARGV); \
			fprintf(stderr, __VA_ARGS__); \
			fprintf(stderr, " (%s)\n", errno > 0 ? strerror(errno) : ""); \
			fflush(stderr); \
			exit(errno); \
		}
#endif

#endif

