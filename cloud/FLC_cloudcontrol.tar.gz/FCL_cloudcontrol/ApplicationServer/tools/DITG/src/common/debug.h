/*
 *   Component of the D-ITG 2.8.2 (r2717) platform (http://traffic.comics.unina.it/software/ITG)
 *
 *   Copyright     : (C) 2004-2015 by Alessio Botta, Walter de Donato, Alberto Dainotti,
 *                                      Stefano Avallone, Antonio Pescape' (PI)
 *                                      COMICS (COMputer for Interaction and CommunicationS) Group
 *                                      Department of Electrical Engineering and Information Technologies
 *                                      University of Napoli "Federico II".
 *   email         : a.botta@unina.it, walter.dedonato@unina.it, alberto@unina.it,
 *                   stavallo@unina.it, pescape@unina.it
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 * 
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 * 		     
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *				     
 *   For commercial use please refer to D-ITG Professional.
 */


#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <stdio.h>

#ifdef DEBUG

	#define PRINTD(level, ...)		if (DEBUG >= level) { fprintf(stderr, __VA_ARGS__); fflush(stderr); }
	#define PD(level, ...)			if (DEBUG >= level) { \
							fprintf(stderr, "%s: ", __FUNCTION__); \
							fprintf(stderr, __VA_ARGS__); \
							fflush(stderr); \
						}
#ifdef UNIX
	#define PDT(level, ...)			if (DEBUG >= level) { \
							fprintf(stderr, "Thread %lu - %s: ", syscall(SYS_gettid), __FUNCTION__); \
							fprintf(stderr, __VA_ARGS__); \
							fprintf(stderr, "\n"); \
							fflush(stderr); \
						}
#elif defined WIN32
	#define PDT(level, ...)			PD(level, __VA_ARGS__)
#endif

#  ifdef UNIX
	#define PRINTDS(level, ...)	    if (DEBUG >= level) { usleep(1000); fprintf(stderr, __VA_ARGS__); fflush(stderr); }
#  elif defined WIN32
	#define PRINTDS(level, ...)	    if (DEBUG >= level) { Sleep(1000); fprintf(stderr, __VA_ARGS__); fflush(stderr); }
#  endif

#else
	#define PD(level, ...)
	#define PDT(level, ...)
	#define PRINTD(level, ...)
	#define PRINTDS(level, ...)
#endif

#endif
