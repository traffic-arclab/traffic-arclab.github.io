from ConfigParser import SafeConfigParser
import os
import subprocess
import logging
import time
import random
import threading

class ditg:

    def __init__(self, conf_file=None):

        if not conf_file:
            self.conf_file = "%s/%s/%s" % (os.path.dirname(os.path.abspath(__file__)), "conf", "tools.ini")
        else:
            self.conf_file = conf_file

        parser = SafeConfigParser()
        parser.read(self.conf_file)

        self.tool_dir = "%s/%s/%s" % (os.path.dirname(os.path.abspath(__file__)), parser.get("DITG", "tool_dir"), "bin")
        self.protocol = parser.get("DITG", "protocol")
        self.pkt_size = parser.getint("DITG", "pkt_size")
        self.rate = parser.getint("DITG", "rate")
        self.total_duration = parser.getint("DITG", "total_duration")
        self.total_volume = parser.getint("DITG", "total_volume")
        self.meter = parser.get("DITG", "meter")
        self.dest_port = parser.getint("DITG", "dest_port")

    def generate(self, dest_address, protocol=None, pkt_size=None, rate=None,
                 total_duration=None, total_volume=None, meter=None, dest_port=None):

        options = dict(
            protocol=protocol if protocol else self.protocol,
            pkt_size=pkt_size if pkt_size else self.pkt_size,
            rate=rate if rate else self.rate,
            total_duration=total_duration if total_duration else self.total_duration,
            total_volume=total_volume if total_volume else self.total_volume,
            meter=meter if meter else self.meter,
            dest_port=dest_port if dest_port else self.dest_port
        )

        sender_cmd = "sudo %s/ITGSend -poll -j 1 -a %s " % (self.tool_dir, dest_address)
        sender_cmd += "-T %(protocol)s -c %(pkt_size)s -C %(rate)s -t %(total_duration)s "
        sender_cmd += "-m %(meter)s -k %(total_volume)s -rp %(dest_port)s"
        sender_cmd = sender_cmd % options

        os.system(sender_cmd)
        logging.info("ITGSend started")

    def receive(self):

        receiver_cmd = "sudo %s/ITGRecv &" % self.tool_dir
        print receiver_cmd
        os.system(receiver_cmd)
        logging.info("ITGRecv started")

    def check_ditg(self):

        running_check = dict(ITGRecv=None, ITGSend=None)
        for tool in running_check.keys():
            try:
                pid = subprocess.check_output(["pgrep", tool]).split("\n")[:-1]
                logging.info("%s is running with pid %s", tool, pid)
                running_check[tool] = pid
            except subprocess.CalledProcessError:
                logging.info("%s is not running", tool)

        return running_check

class Burner:  # TODO test me!
    def __init__(self):
        self.iteration_counter = 0
        self.iteration_counter_Lock = threading.RLock()

    def __increment_counter(self):
        self.iteration_counter_Lock.acquire()
        self.iteration_counter += 1
        self.iteration_counter_Lock.release()

    def burn_cycles(self, iterations):
        for i in range(0, int(iterations)):
            x = random.randint(1, 1000)
            y = random.randint(1, 1000)
            self.__increment_counter()
            w = x * y
        return w

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    logging.Formatter.converter = time.gmtime
    logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s')

    my_ditg = ditg()
    my_ditg.check_ditg()
    my_ditg.generate(dest_address="addresso")
    my_ditg.receive()
