#! /usr/bin/python
import requests,sys,datetime,logging,time

if __name__ == "__main__":
	logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s', level=logging.INFO)
	urla = sys.argv[1]
	
	ora = None
	while True:
		
		try:
			ora = datetime.datetime.utcnow()
			r = requests.get(urla, timeout=2)
			if r.status_code == 200:
				break
			time.sleep(10)	
			
		except:
			continue
	
	logging.warning("\'%s\' |%s| %s",urla,r.status_code,ora)
	
	

	
	