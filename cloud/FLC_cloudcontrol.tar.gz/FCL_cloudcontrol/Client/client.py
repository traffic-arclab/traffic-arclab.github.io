#! /usr/bin/python
# import requests,
import sys, datetime, logging, time

import grequests


def girabotolo(urla, request_file):
    for line in open(request_file):
        num = int(line.strip())
        time_to_wait = float(60) / num
        logging.info('one request every %s seconds expected', time_to_wait)
def girabotolo(urla, request_file):
    for line in open(request_file):
        num = int(line.strip())
        time_to_wait = float(60) / num
        logging.info('one request every %s seconds expected', time_to_wait)

        for n in range(0, num):
            start = time.time()
            logging.info('sending get to: %s', urla)
            rs = (grequests.get(u) for u in urls)
            grequests.map(rs)
        for n in range(0, num):
            start = time.time()
            logging.info('sending get to: %s', urla)
            rs = (grequests.get(u) for u in urls)
            grequests.map(rs)

            stop = time.time()
            elapsed = stop - start
            actual_time_to_wait = time_to_wait - elapsed
            logging.info('%s-second sleep', actual_time_to_wait)

            if actual_time_to_wait > 0:
                time.sleep(actual_time_to_wait)
            else:
                sys.stderr.write("frequency too high!\n")






if __name__ == "__main__":

    if len(sys.argv) < 3:
        sys.stderr.write("usage: [python] " + sys.argv[0] + " url reqests.dat\n")
        sys.exit(1)

    logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s', level=logging.INFO)
    urla = sys.argv[1]
    reqs = sys.argv[2]
    urls = [urla]

    for line in open(reqs):
        num = int(line.strip())
        time_to_wait = float(60) / num
        logging.info('one request every %s seconds expected', time_to_wait)

        for n in range(0, num):
            start = time.time()
            logging.info('get sent to: %s', urla)
            rs = (grequests.get(u) for u in urls)
            grequests.map(rs)

            stop = time.time()
            elapsed = stop - start
            actual_time_to_wait = time_to_wait - elapsed
            logging.info('%s-second sleep', actual_time_to_wait)

            if actual_time_to_wait > 0:
                time.sleep(actual_time_to_wait)
            else:
                sys.stderr.write("frequency too high!\n")

            # ora = None
            # while True:

            # try:
            # ora = datetime.datetime.utcnow()
            # r = requests.get(urla, timeout=2)
            # if r.status_code == 200:
            # break
            # time.sleep(10)

            # except:
            # continue

            # logging.warning("\'%s\' |%s| %s",urla,r.status_code,ora)
