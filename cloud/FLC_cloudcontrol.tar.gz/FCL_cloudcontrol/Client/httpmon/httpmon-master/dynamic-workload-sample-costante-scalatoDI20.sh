#!/bin/bash

# httpmon accepts changing some of the command-line parameters at run-time,
# by accepting commands through stdin. This is an example script that automates
# dynamic workload generation using httpmon. httpmon's output is redirected to
# httpmon.log.

#
# Experiment parameters
#

# URL to generate load for
url=$1

#
# Experiment verbs (see below for usage)
#
function setStart {
	echo [`date +%s`] start
}
function setCount {
	echo [`date +%s`] count=$1
	echo "count=$1" >&9
}
function setOpen {
	echo [`date +%s`] open=$1
	echo "open=$1" >&9
}
function setThinkTime {
	echo [`date +%s`] thinktime=$1
	echo "thinktime=$1" >&9
}
function setConcurrency {
	echo [`date +%s`] concurrency=$1
	echo "concurrency=$1" >&9
}
function setTimeout {
	echo [`date +%s`] timeout=$1
	echo "timeout=$1" >&9
}

#
# Initialization
#

# Create FIFO to communicate with httpmon and start httpmon
rm -f httpmon.fifo
mkfifo httpmon.fifo
#./httpmon --url $url --concurrency 0 --timeout 30 --deterministic < httpmon.fifo &> httpmon.log &
./httpmon --url $url --concurrency 0 --thinktime 1 --open < httpmon.fifo &> httpmon.log &
exec 9> httpmon.fifo

#
# Initialize experiment
#
setOpen 1
setThinkTime 1
setTimeout 4
setCount 120900
setStart

#
# Run experiment
#

#WORKLOAD COSTANTE SCALATO (diviso 20 richeste ogni 6 minuti)

##1° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##2° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##3° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##4° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##5° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##6° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##7° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##8° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##9° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##10° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##11° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##12° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##13° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##14° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##15° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##16° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##17° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##18° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##19° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##20° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##21° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##22° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##23° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##24° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##25° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##26° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##27° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##28° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##29° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

##30° CICLO
setConcurrency 1	#1 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#2 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#3 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#4 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#5 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5

setConcurrency 1	#6 MINUTO
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 10
setConcurrency 1	
sleep 3
setConcurrency 0
sleep 5