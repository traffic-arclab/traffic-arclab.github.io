#!/bin/bash

# httpmon accepts changing some of the command-line parameters at run-time,
# by accepting commands through stdin. This is an example script that automates
# dynamic workload generation using httpmon. httpmon's output is redirected to
# httpmon.log.

#
# Experiment parameters
#

# URL to generate load for
url=$1

#
# Experiment verbs (see below for usage)
#
function setStart {
	echo [`date +%s`] start
}
function setCount {
	echo [`date +%s`] count=$1
	echo "count=$1" >&9
}
function setOpen {
	echo [`date +%s`] open=$1
	echo "open=$1" >&9
}
function setThinkTime {
	echo [`date +%s`] thinktime=$1
	echo "thinktime=$1" >&9
}
function setConcurrency {
	echo [`date +%s`] concurrency=$1
	echo "concurrency=$1" >&9
}
function setTimeout {
	echo [`date +%s`] timeout=$1
	echo "timeout=$1" >&9
}

#
# Initialization
#

# Create FIFO to communicate with httpmon and start httpmon
rm -f httpmon.fifo
mkfifo httpmon.fifo
#./httpmon --url $url --concurrency 0 --timeout 30 --deterministic < httpmon.fifo &> httpmon.log &
./httpmon --url $url --concurrency 0 --thinktime 1 --open < httpmon.fifo &> httpmon.log &
exec 9> httpmon.fifo

#
# Initialize experiment
#
setOpen 1
setThinkTime 1
setTimeout 4
setCount 120900
setStart

#
# Run experiment
#

#WORKLOAD FIFA98 SCALATO (diviso 20 richeste ogni 6 minuti)

##1° ciclo (60 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

##2° ciclo (39 reqs)
setConcurrency 1	#1° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#2° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#3° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#4° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#5° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 6
##3° ciclo (38 reqs)
setConcurrency 1	#1° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#2° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#3° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#4° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#5° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7
##4° ciclo (39 reqs)
setConcurrency 1	#1° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#2° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#3° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#4° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#5° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 6
##5° ciclo (37 reqs)
setConcurrency 1	#1° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#2° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#3° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#4° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#5° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9
setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8
##6° ciclo (43 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

##7° ciclo (42 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

##8° ciclo (45 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

##9° ciclo (47 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

##10° ciclo (48 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

##11° ciclo (48 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

##12° ciclo (47 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

##13° ciclo (45 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

##14° ciclo (42 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

##15° ciclo (43 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

##16° ciclo (37 reqs)
setConcurrency 1	#1° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#2° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#3° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#4° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#5° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 8

##17° ciclo (39 reqs)
setConcurrency 1	#1° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#2° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#3° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#4° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#5° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 6

##18° ciclo (38 reqs)
setConcurrency 1	#1° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#2° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#3° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#4° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#5° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 7

##19° ciclo (39 reqs)
setConcurrency 1	#1° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#2° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#3° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#4° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#5° minuto
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 1
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 9

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 3
setConcurrency 0
sleep 6

##20° ciclo (60 reqs)
setConcurrency 1	#1° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#2° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#3° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#4° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#5° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5

setConcurrency 1	#6° minuto
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 2
setConcurrency 0
sleep 15
setConcurrency 1
sleep 4
setConcurrency 0
sleep 5
sleep 60