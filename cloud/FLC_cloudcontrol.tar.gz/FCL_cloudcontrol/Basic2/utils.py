import xml.etree.ElementTree as XmlParser

def flatten_list(a, result=None):
    """
    Flattens a nested list.
    flatten_list ([ [1, 2, [3, 4] ], [5, 6], 7])
                 = [1, 2, 3, 4, 5, 6, 7]
    :param a: input list
    :param result: output list
    :return: output list
    """
    if not result:
        result = []

    for x in a:
        if isinstance(x, list):
            flatten_list(x, result)
        else:
            result.append(x)

    return result

def instance_terminator(boto, conn, instances):
    try:
        if not isinstance(instances, list):
            instances = [instances]
        conn.terminate_instances(instance_ids=instances)
        message = "Instance(s) %s terminated" % instances
    except boto.exception.EC2ResponseError, e:
        root = XmlParser.fromstring(e[2])
        message = [x[0].findall('Message')[0].text
                   for x in [m.findall('Error') for m in root.findall('Errors')]][0]
    except Exception, e:
        message = str(e)

    return message
