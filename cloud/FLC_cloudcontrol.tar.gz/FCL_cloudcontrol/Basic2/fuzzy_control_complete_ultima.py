#! /usr/bin/python

################################
#
# This script executes fuzzy PID controller, 
# after calling reference signal and PID paramenter from corresponding .txt files.
#
################################


from cloudProcess import *
# import cippalippa
import time
# import boto
# import boto.ec2
# import boto.ec2.elb
# import boto.ec2.cloudwatch

import sys
# import random
import logging
# import datetime
import os
# from boto.ec2.elb import HealthCheck
import numpy
from pprint import *

import fuzzy.storage.fcl.Reader
import sys

# It calls file fuzzy_control.fcl file that implements fuzzy controller
system = fuzzy.storage.fcl.Reader.Reader().load_from_file(
    "/home/domenico/Scrivania/cloudcontrol07012015/fuzzy/cloudcontrol/Basic2/fuzzy_control.fcl")

## Actuation function: allocate o deallocate one or more VM depending on control signal u_k
def act(u_k):
    if u_k >= -150 and u_k < -50:
        return 1
    elif u_k >= -250 and u_k < -150:
        return 2
    elif u_k >= -350 and u_k < -250:
        return 3
    elif u_k < -350:
        return 4
    elif u_k > 50 and u_k <= 150:
        return -1
    elif u_k > 150 and u_k <= 250:
        return -2
    elif u_k > 250 and u_k <= 350:
        return -3
    elif u_k > 350:
        return -4
    else:  # u_k == 0
        return 0


## Import PID parameters from PID.txt file:
## file format: 
##1.	Kpmin
##2.	Kpmax
##3.	Kdmin
##4.	Kdmax
def import_PID_parameters(filename):
    lista_PID = [float(x.strip()) for x in open(filename).readlines()]
    kpmin = lista_PID[0]
    kpmax = lista_PID[1]
    kdmin = lista_PID[2]
    kdmax = lista_PID[3]

    return kpmin, kpmax, kdmin, kdmax


## Import reference signal from ref_signal.txt file:
## format: 
##1.	y_rif = J*
##2.	cpu_ref
##3.	NetIn_ref
##4.	NetOut_ref
def import_signal_ref(filename):
    lista_signal_ref = [float(x.strip()) for x in open(filename).readlines()]
    y_rif = lista_signal_ref[0]
    cpu_ref = lista_signal_ref[1]
    NetIn_ref = lista_signal_ref[2]
    NetOut_ref = lista_signal_ref[3]

    return y_rif, cpu_ref, NetIn_ref, NetOut_ref


# It defines and calculates fitness function FF (functional cost)
def FF(cpu_ref, NetIn_ref, NetOut_ref, diz_val_input):
    alfa1 = 1		# CPU% weight coefficient
    alfa2 = 0	  	# traffic networkin weight coefficient
    alfa3 = 0	 	# traffic networkout weight coefficient

    var1 = "CPUUtilization"
    var2 = "NetworkIn"
    var3 = "NetworkOut"
    
    print "CPUref: ", cpu_ref
    print "NetIn: ", NetIn_ref
    print "NetOut_ref: ", NetOut_ref
    
    cpu_utilization_k = diz_val_input[var1]["now"]	# CPU% at time k
    NetworkIn_k = diz_val_input[var2]["now"]		# NetIn at time k
    NetworkOut_k = diz_val_input[var3]["now"]		# NetOut at time k

    cpu_utilization_k_1 = diz_val_input[var1]["now-1"]		# CPU% at time k-1
    NetworkIn_k_1 = diz_val_input[var2]["now-1"]		# NetIn at time k-1
    NetworkOut_k_1 = diz_val_input[var3]["now-1"]		# NetOut at time k-1

    cpu_utilization_k_2 = diz_val_input[var1]["now-2"]  # CPU% at time k-2
    NetworkIn_k_2 = diz_val_input[var2]["now-2"]  	# NetIn at time k-2
    NetworkOut_k_2 = diz_val_input[var3]["now-2"] 	# NetOut at time k-2

    y_k = (alfa1 * cpu_utilization_k / cpu_ref) + (alfa2 * NetworkIn_k / NetIn_ref) + (
    alfa3 * NetworkOut_k / NetOut_ref)  # FF at time k
    y_k_1 = (alfa1 * cpu_utilization_k_1 / cpu_ref) + (alfa2 * NetworkIn_k_1 / NetIn_ref) + (
    alfa3 * NetworkOut_k_1 / NetOut_ref)  # FF at time k-1
    y_k_2 = (alfa1 * cpu_utilization_k_2 / cpu_ref) + (alfa2 * NetworkIn_k_2 / NetIn_ref) + (
    alfa3 * NetworkOut_k_2 / NetOut_ref)  # FF at time k-2

    return y_k, y_k_1, y_k_2


# PID controller function: It calculates error between reference signal and signal output and control signal u_k - PID - only proportional action on first round, PID in other cases
def controller_fuzzy(y_rif, cpu_ref, NetIn_ref, NetOut_ref, delta_t, Kpmin, Kpmax, Kdmin, Kdmax, u_k_1, diz_val_input,
                     CICLO):
    cpu_utilization = diz_val_input.get("CPUUtilization")
    if not cpu_utilization or None in [cpu_utilization.get(x) for x in ["now", "now-1", "now-2"]]:
        # print "more values needed"

        logging.info("Startup phase, more values needed")

        return None, None, None, CICLO

    CICLO += 1

    y_k, y_k_1, y_k_2 = FF(cpu_ref, NetIn_ref, NetOut_ref,
                           diz_val_input)  # It calls function that calculates fitness function

    e_k = y_rif - y_k 					#errore at current time k
    e_k_1 = y_rif - y_k_1				#errore at time k-1
    e_k_2 = y_rif - y_k_2				#errore at time k-2
	
    # preallocate input and output values
    my_input = {
        "e": 0.0,
        "delta_e": 0.0
    }
    my_output = {
        "Kp1": 0.0,
        "Kd1": 0.0,
        "alfa": 0.0
    }

    e = e_k
    delta_e = e_k - e_k_1

    # set input values
    my_input["e"] = e
    my_input["delta_e"] = delta_e

    # calculate
    system.calculate(my_input, my_output)	#attiva il controllore fuzzy

    output1 = my_output["Kp1"]
    output2 = my_output["Kd1"]
    output3 = my_output["alfa"]

    logging.info("PID Parameter: Kp1  = %s", output1)
    logging.info("PID Parameter: alfa = %s", output3)
    logging.info("PID Parameter: Kd1  = %s", output2)

    Kp = (Kpmax - Kpmin) * output1 + Kpmin
    Kd = (Kdmax - Kdmin) * output2 + Kdmin
    Ki = output3

    logging.info("PID Parameter: Kp  = %s", Kp)
    logging.info("PID Parameter: Kd  = %s", Kd)
    
    Ti = Kp / Ki
    Td = Kd / Kp

    if COUNT_CICLO == 1:

        # P
        logging.info("PI. First round/Inside bound -> solo P")
        u_k = Kp * e_k
    else:
        # PID
        u_k = u_k_1 + Kp * (
        (1 + delta_t / Ti + Td / delta_t) * e_k + (-1 - 2 * Td / delta_t) * e_k_1 + (Td / delta_t) * e_k_2)

    logging.info("PID Parameter: P = %s", Kp)
    logging.info("PID Parameter: I = %s", Ki)
    logging.info("PID Parameter: D = %s", Kd)
	
    print "u_k= ", u_k
    
    return u_k, e_k, y_k, CICLO


## Print file (and screen) interesting signal : u_k, e_k, y_k
def dump_value(filE_handler, value):

    filE_handler.write(str(value) + "\n")


SOGLIA_ZERO = 0.1		#This value is referred to FF value. Reference value is set to 1. It's the bound where actuator is stopped.
max_vm = 20			#max number of allocable VM
min_vm = 2			#min number of allocable VM

if __name__ == "__main__":

    if len(sys.argv) < 2:
        sys.stderr.write("usage: [python] " + sys.argv[0] + "\n")
        sys.stderr.write("PID.txt must contain the following info:\n")
        sys.stderr.write("y_rif\ndelta_t\n")
        sys.exit(1)

    # keys = sys.argv[1]
    radix_name = sys.argv[1]

    logging.Formatter.converter = time.gmtime
    logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.INFO,
                        filename=radix_name + ".log")

    Kpmin, Kpmax, Kdmin, Kdmax = import_PID_parameters("PID.txt")
    y_rif, cpu_ref, NetIn_ref, NetOut_ref = import_signal_ref("ref_signal.txt")

    try:
        os.mkdir(radix_name)
    except:
        sys.stderr.write("folder alredy exists\n")
        pass

    f_u = open(radix_name + "/" + radix_name + "_u.txt", "a")
    f_e = open(radix_name + "/" + radix_name + "_e.txt", "a")
    f_y = open(radix_name + "/" + radix_name + "_y.txt", "a")
    f_vmno = open(radix_name + "/" + radix_name + "_vmnum.txt", "a")
    f_vmcpu = open(radix_name + "/" + radix_name + "_vmcpu.txt", "a")

    logging.getLogger().setLevel(logging.INFO)
    logging.Formatter.converter = time.gmtime
    logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s')
    where_i_am = os.path.dirname(os.path.abspath(sys.argv[0]))
    cfg_file = "%s/conf/cloudProcess.ini" % where_i_am

    print "Startup"
    print "please wait..."
    logging.info("Startup")
    logging.info("please wait")

    cplp = CCProcess(cfg_file, min_vm)
    pprint(cplp.get_instancePool())
    delta_t = cplp.get_delta_t()

    # pprint (cplp.get_instancePool())

    u_k_1 = 0
    COUNT_CICLO = 0  # It only used by PI - controller2

    iteration = 0

    startWL = False

    sys.stderr.write('Use Control-C to exit\n')
    try:

        while True:
            start = time.time()

            iteration += 1

            logging.info("inizio ciclo %s", iteration)
            # print "inzio ciclo", start
            # os.system("clear")

            cplp.update_pool_measurements()  # update measurements

            # pprint (ccproc.get_instancePool())

            logging.info("Pool status:\n%s", cplp.get_instancePool())

            logging.info("Avg Vals:\n%s", cplp.getAvgVals())

            # pprint(cplp.getAvgVals())

            num_vm = len(cplp.get_instancePool())
            # cpu_all = ",".join( [ str(cplp.get_instancePool()[i]["history"]["now"]) for i in cplp.get_instancePool() ] )
            cpu_all = ",".join([str(cplp.get_instancePool()[i]["history"]["now"]) for i in
                                sorted(cplp.get_instancePool(),
                                       key=lambda x: cplp.get_instancePool()[x]["info"]["launch_time"])])

            u_k, e_k, y_k, COUNT_CICLO = controller_fuzzy(y_rif, cpu_ref, NetIn_ref, NetOut_ref, delta_t, Kpmin, Kpmax,
                                                          Kdmin, Kdmax, u_k_1, cplp.getAvgVals(), COUNT_CICLO)

            logging.info("controller output (u_k, e_k, y_k): %s %s %s", u_k, e_k, y_k)

            if u_k == None:
                # logging.info("still in startup")
                stop = time.time()
                elapsed = stop - start
                time_to_wait = delta_t - elapsed
                logging.info("%s-second wait", time_to_wait)
                time.sleep(time_to_wait)

                # num_vm = "#"+str(num_vm))
                dump_value(f_u, "#" + str(u_k))
                dump_value(f_e, "#" + str(e_k))
                dump_value(f_y, "#" + str(y_k))
                dump_value(f_vmno, "#" + str(num_vm))
                dump_value(f_vmcpu, "#" + str(cpu_all))

                continue
            else:

                if startWL == False:
                    startWL = True
                    sys.stderr.write("***START WORK LOAD RIGHT NOW!***\n")

                dump_value(f_u, u_k)
                dump_value(f_e, e_k)
                dump_value(f_y, y_k)
                dump_value(f_vmno, num_vm)
                dump_value(f_vmcpu, cpu_all)

            u_k_1 = u_k

            azione = act(u_k)		## activate actuator

            if abs(e_k) > SOGLIA_ZERO:

                if azione > 0 and num_vm < max_vm:

                    logging.info("u_k = %s --> azione = %s", u_k, azione)

                    if (num_vm + azione) <= max_vm:
                        cplp.add_vm(azione)
                        logging.info("%s VM allocated", (azione))

                    elif (num_vm + azione) > max_vm:
			i = max_vm - num_vm
                        cplp.add_vm(i)
                        logging.info("Only %s VM allocated", i)

                elif azione < 0 and num_vm > min_vm:

                    logging.info("u_k = %s --> azione = %s", u_k, azione)

                    if (num_vm + azione) >= min_vm:
                        cplp.rm_vm(abs(azione))
                        logging.info("%s VM deallocated", (abs(azione)))

                    elif (num_vm + azione) < min_vm:
			j = num_vm - min_vm
                        cplp.rm_vm(i)
                        logging.info("Only %s VM deallocated", j)
                elif num_vm == min_vm:
                    logging.info("Cannot deallocate VM: limit reached")

                elif num_vm == max_vm:
                    logging.info("Cannot allocate VM: limit reached")

                elif azione == 0:
                    logging.info("u_k lower than 1000: NOTHING TO DO")
                    pass
            else:
                logging.info("u_k lower than 1000: NOTHING TO DO")

            stop = time.time()
            elapsed = stop - start
            time_to_wait = delta_t - elapsed
		
	    if time_to_wait < 0:
		    time_to_wait = 0

            logging.info("%s-second wait", time_to_wait)
            time.sleep(time_to_wait)

    except KeyboardInterrupt:

        sys.stderr.write('\nExiting\n')
        f_u.close()
        f_e.close()
        f_y.close()
        f_vmno.close()
        f_vmcpu.close()
