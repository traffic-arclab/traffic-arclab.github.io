# -*- coding: utf-8 -*-

import boto
import boto.resultset
import boto.ec2
import boto.ec2.elb
import boto.ec2.cloudwatch

import sys
sys.path.append("../")
sys.path.append("../ApplicationMaster")
sys.path.append("../MonitoringMaster")
import ApplicationMaster
import MonitoringMaster
import random
import logging
import datetime
import time
import os
from boto.ec2.elb import HealthCheck
import numpy
from pprint import *

import multiprocessing as mp
from multiprocessing.managers import  SyncManager
import signal
import xmlrpclib

from collections import defaultdict
from ConfigParser import SafeConfigParser

from utils import *
import atexit

## empty struct for new instances
unset_instance = {
    "pub_ip": None,
    "pri_ip": None,
    "placement": None,
    "type": None,
    "placement_group": None,
    "state": None,
    "launch_time": None}

## empty history for new instances
unset_history = {
    "now": None,
    "now-1": None,
    "now-2": None,
    "now-3": None,
    "now-4": None,
}


class CCProcess:
    """
    Interfaccia di sensing/attuazione per EC2
    Necessita credenziali in ~/.boto.
    SECURITY_GROUP deve essere creato su account.
    """

    def __init__(self, config_file, initial_vms_number=1):
        # TODO: update doc!
        """
        Inizializza il processo cloud.
        Instanzia un Load Balancer e vi connette una Macchina Virtuale.
        @param region identificativo regione AWS (e.g. eu-west-1 ...)
        @param DeltaT: passo di campionamento (in secondi) dell'osservazione/attuazione - influisce sulla granularità della misura richiesta a CW -deve essere un multiplo di 60
        """

        self.parser = SafeConfigParser()
        self.parser.read(config_file)

        # logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s', filename=region+'.log', level=logging.DEBUG)
        # logging.Formatter.converter = time.gmtime
        # logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s', level=logging.INFO,)

        # Cloud options
        self.region = self.parser.get('cloud', 'region')
        self.security_group_lb = self.parser.get('cloud', 'security_group_lb')
        self.security_group_vm = self.parser.get('cloud', 'security_group_vm')
        self.vm_type = self.parser.get('cloud', 'vm_type')
        self.ami_id = self.parser.get('cloud', 'ami_id')
        self.vm_ssh_key = self.parser.get('cloud', 'vm_ssh_key')
        self.running_check_wait = self.parser.getint('cloud', 'running_check_wait')

        ## availability zone
        self.azones = [self.region + "a"]

        ## dizionario rappresentativo del pool delle istanze
        self.__instancePool = {}

        ## Misurazioni storiche (5 campioni) mediate sulle VM facenti parte del processo cloud
        self.__avgVals = {}

        ## Nome del Load Balancer
        self.__lbname = None

        # Processi che recuperano le misure dalle VM e le inseriscono in una coda
        self.__get_measurement_processes = []
        self.__get_measurement_queue = mp.Queue(maxsize=0)

        self.apm_metrics = self.parser.get('metrics', 'apm_metrics').strip().split(",")
        self.cw_metrics = self.parser.get('metrics', 'cw_metrics').strip().split(",")

        self.chosen_apm_metrics = self.parser.get('experiment', 'apm_metrics').strip().split(",")
        self.chosen_cw_metrics = self.parser.get('experiment', 'cw_metrics').strip().split(",")
        self.chosen_metrics = self.chosen_apm_metrics + self.chosen_cw_metrics

        # DeltaT
        # self.__DeltaT = int(DeltaT)
        self.__DeltaT = self.parser.getint('process', 'deltaT')
        logging.info('Delta_T set to %s', self.__DeltaT)

        ## EC2 connection
        self.__conn = boto.ec2.connect_to_region(self.region)
        # self.__conn = boto.ec2.connect_to_region(self.region,
        # aws_access_key_id=aws_access_key_id,
        # aws_secret_access_key=aws_secret_access_key)
        logging.info('ec2: connection with %s region established', self.region)

        ## Elastic Load Balancer connection
        self.__elb_conn = boto.ec2.elb.connect_to_region(self.region)
        logging.info('ec2 elb: connection with %s region established', self.region)

        ## Cloudwatch connection
        self.__cw_conn = boto.ec2.cloudwatch.connect_to_region(self.region)
        logging.info('ec2 cloudwatch: connection with %s region established', self.region)

        self.__createLB()  # crea load balancer
        logging.info('new load balancer created')

        # Master Zone
        self.application_master = ApplicationMaster.ApplicationMaster()
        self.monitoring_master = MonitoringMaster.MonitoringMaster()

        # pending machines -> you press ctrl+c? maybe there are status checks still running
        self.pending_machines_manager = SyncManager()
        self.pending_machines_manager.start(lambda: signal.signal(signal.SIGINT, signal.SIG_IGN))
        self.pending_machines = self.pending_machines_manager.list()

        atexit.register(self.cleanup)

        self.add_vm(initial_vms_number)  # add VM
        logging.info('new virtual machine added')

    def get_delta_t(self):
        return self.__DeltaT

    def cleanup(self):
        """
        Distrugge il processo cloud.
        """
        logging.info("Destroying Objects")
        sys.stderr.write("Destroying Objects\n")
        self.__elb_conn.delete_load_balancer(self.__lbname)
        logging.info("Load balancer deleted")

        saved_instances = self.__instancePool.keys()
        if saved_instances:
            logging.info("Terminating instances %s" % saved_instances)
            message = instance_terminator(boto, self.__conn, saved_instances)
            logging.info(message)

        logging.info("Terminating pending instances %s", self.pending_machines)

        for pending_machine in self.pending_machines:
            logging.info("Terminating instance %s" % pending_machine)
            message = instance_terminator(boto, self.__conn, pending_machine)
            logging.info(message)

        self.pending_machines_manager.shutdown()

        return True

    def __createLB(self):
        """
        Crea un load balancer nella regione di riferimento.
        Porti forwarding: 8080:80
        @todo healthcheck
        @todo parametri porti
        """

        zones = self.azones
        ports = [(8080, 2000, 'http')]
        # SECURITY_GROUP = "sg-ca4295af" #[pescape]
        # SECURITY_GROUP = "sg-210c8144" #[santini]
        SECURITY_GROUP = self.security_group_lb

        hc = HealthCheck(
            interval=20,
            healthy_threshold=3,
            unhealthy_threshold=5,
            target='HTTP:8080/health'
        )

        LB_name = "LB-CC-" + str(random.randint(0, 10000000))
        self.__lbname = LB_name

        ## Load Balancer
        self.__lb = self.__elb_conn.create_load_balancer(LB_name, zones, ports)
        self.__elb_conn.apply_security_groups_to_lb(LB_name, [SECURITY_GROUP])
        # lb.configure_health_check(hc)
        # lb.dns_name
        logging.info("LOAD BALANCER DNS NAME: %s", "http://" + self.__lb.dns_name + ":" + str(ports[0][0]))
        self.__lb_dns_name = "http://" + self.__lb.dns_name + ":" + str(ports[0][0])

    def get_lb_dns_name(self):
        return self.__lb_dns_name

    def __str__(self):
        """
        restituisce l'oggetto  in formato printable
        @remark restituisce il dict instancePool
        """
        return str(self.__instancePool)

    def get_instancePool(self):
        """
        Restituisce l'intero oggetto rappresente il processo Cloud.
        per ogni VM:\n
        'meas' : vettore con lo storico delle misurazioni\n
        'info' : dizionario con info generiche associate alla VM\n
        'history' : ultime 5 misure associate alla VM\n
        """
        return dict(self.__instancePool)

    # def updatePoolStatus(self):
    # """
    # aggiorna lo stato del processo cloud
    # """
    # self.__updatePoolInfo()
    # self.__updatePoolMeasures()
    # pass

    def __updatePoolInfo(self):
        """
        Aggiorna pool info
        @remark parte "info" di instancePool
        """

        logging.info("Updating pool info")
        reservations = self.__conn.get_all_reservations()
        instances = []
        for x in reservations:
            instances += x.instances

        results = {}
        for i in instances:
            results[i.id] = {
                "pub_ip": i.ip_address,
                "pri_ip": i.private_ip_address,
                "placement": i.placement,
                "type": i.instance_type,
                "placement_group": i.placement_group,
                "state": i.state,
                "launch_time": i.launch_time}

        for k in self.__instancePool.keys():
            if k in results:
                self.__instancePool[k]['info'] = results[k]
            else:
                logging.warning("hmmm...instance %s not found in info", k)

    def update_pool_measurements(self, cloud_watch=True):
        """
        Aggiorna misure
        :param cloud_watch: se True, utilizza le metriche supportate da cloudwatch
        :param metrics: lista metriche, default tutte le metriche
        """

        logging.info("updating Pool Measurements")
        # utc_now = datetime.datetime.utcnow()
        # datapoints = self.__get_monitoring_data(
        #     utc_now - datetime.timedelta(0, self.__DeltaT, 0),
        #     utc_now, self.__instancePool.iterkeys())
        utc_now = time.time()
        datapoints = {}
        error_counter = 0
        time_to_sleep = 3

        datapoints = self.__get_monitoring_data(
                utc_now - self.__DeltaT,
                utc_now, self.__instancePool.iterkeys())

        while len(self.__instancePool) > len(datapoints) and error_counter < 3:
            datapoints = self.__get_monitoring_data(
                utc_now - self.__DeltaT,
                utc_now, self.__instancePool.iterkeys())
            error_counter += 1
            logging.info("no data retrieved - Error 111 (suspected) - waiting %ss for retry #%s",
                         time_to_sleep, error_counter )
            time.sleep(time_to_sleep)

        for instance in self.__instancePool.iterkeys():
            for metric in self.chosen_metrics:
                metric_results = None

                # if boto ERROR 111 happens, key error is raised by dict inspection
                # (no "instance" key in datapoints).
                # Following workaround needed...

                if type(datapoints) == dict and instance in datapoints and metric in datapoints[instance]:
                    metric_results = datapoints[instance][metric]
                else:
                    logging.info("Data not retrieved for: %s\nERROR 111(suspected)", instance)

                meas_history_res = None
                if metric_results:
                    last_metric_timestamp = max(metric_results.keys())
                    mostRecentSample = {last_metric_timestamp: metric_results[last_metric_timestamp]}

                    logging.info("New measurement for instance: %s\n%s", instance, mostRecentSample)
                    meas_history_res = mostRecentSample[last_metric_timestamp]

                    self.__instancePool[instance]['meas'][metric][last_metric_timestamp] = meas_history_res

                self.__instancePool[instance]['history'][metric] = \
                    self.__updateHistory(
                        self.__instancePool[instance]['history'][metric], meas_history_res)

        self.__computeAVGHistory()

    def __updateHistory(self, history, new_value):
        """
        Aggiorna history inserendo un nuovo valore eliminando il valore più vecchio.
        @remark implementa politica FIFO

        @param history dizionario da modificare
        @new_value valore nuovo
        """
        logging.info("updating history ")
        history['now-4'] = history['now-3']
        history['now-3'] = history['now-2']
        history['now-2'] = history['now-1']
        history['now-1'] = history['now']
        history['now'] = new_value
        return history

    def __computeAVGHistory(self):
        """
        Computa la media tra le misure associate a tutte le macchine virtuali appartenenti al pool.

        @remark computa media aritmetica
        """
        logging.info("computing avg history ")
        avgVals = defaultdict(dict)

        for time in ["now", "now-1", "now-2", "now-3", "now-4"]:
            for metric in self.chosen_metrics:
                valuesToAvg = [self.__instancePool[i]["history"][metric][time] for i in self.__instancePool.keys() if
                               self.__instancePool[i]["history"][metric][time] is not None]

                avg = numpy.nanmean([i for i in valuesToAvg if i is not None])
                avgVals[metric][time] = None if numpy.isnan(avg) else avg

        self.__avgVals = avgVals

    def __get_measurement(self, instance_id, start_ts, stop_ts):
        """
        Preleva il risultato delle misure dalla VM che ospita l'APM
        e da cloudwatch e lo salva all'interno di una coda
        :param instance_id: id della VM
        :param start: utcnow - timedelta
        :param stop: utcnow
        :param metric: nome della metrica, es. ICMP_LATENZA
        """

        # prendi elenco metriche da una delle istanze
        # fai un intersect con metrics
        # le restanti in metrics le chiedi a cloud_watch

        apm_ip = self.__instancePool[instance_id]["info"]["pub_ip"]
        proxy = xmlrpclib.ServerProxy("http://%s:%s/" % (apm_ip, 30000))

        metrics = set(self.chosen_metrics)
        apm_metrics = list(metrics.intersection(self.apm_metrics))
        cloud_watch_metrics = list(metrics.intersection(self.cw_metrics))

        logging.info("[%s] Queried APM metrics: %s" % (apm_ip, apm_metrics))

        meas = proxy.get_measurement(start_ts, stop_ts, apm_metrics, self.__DeltaT)

        start = datetime.datetime.utcfromtimestamp(start_ts)
        stop = datetime.datetime.utcfromtimestamp(stop_ts)

        logging.info("[%s] APM Results: %s" % (apm_ip, meas))
        logging.info("[CloudWatch] Queried metrics: %s" % cloud_watch_metrics)

        results_aggregation = 'Average'

        for metric in cloud_watch_metrics:
            cw_res = self.__cw_conn.get_metric_statistics(
                self.__DeltaT,
                start,
                stop,
                metric,
                'AWS/EC2',
                results_aggregation,
                dimensions={'InstanceId': instance_id})
            try:
                cw_res = cw_res[0]
            except IndexError:
                logging.error("[CloudWatch - Instance %s] No results for the given metric: [%s %s]" % (instance_id, results_aggregation, metric))
                # cloudwatch return empty value, use the start measurement timestamp
                meas[metric] = {int(time.mktime(start.timetuple())): None}
            else:
                meas[metric] = {int(time.mktime(cw_res['Timestamp'].timetuple())): cw_res[results_aggregation]}
                # read the timestamp use datetime.fromtimestamp(timestamp) and not utcfromtimestamp

        self.__get_measurement_queue.put((instance_id, meas))

    def __get_statistics(self, start, stop, instances):
        """
        Lancia un processo per ciascuna istanza per recuperare le misure
        Ciascun processo utilizza l'interfaccia del server XMLRPC sulle VM
        :param start: inizio dell'intervallo da monitorare
        :param stop: fine dell'intervallo da monitorare
        :param metrics: metrica da monitorare
        :param instances: id delle istanze da monitorare
        """
        for instance_id in instances:
            p = mp.Process(target=self.__get_measurement, args=(instance_id, start, stop))
            self.__get_measurement_processes.append(p)
            p.start()

    def __get_monitoring_data(self, start, stop, instances):
        '''
        recupera i dati compresi tra start e stop [start, stop)
        non bada al valore dei secondi, tronca ai minuti.
        la granularita' e' pari ad 1 minuto
        i timestamp dei datapoint riportati riportano l'istante di inizio dell'intervallo
        @param start inizio dell'intervallo da monitorare
        @param stop fine dell'intervallo da monitorare
        @param metrics metrica da monitorare
        @param instances istanze da monitorare
        :return datapoints = {instance_id: misure} -> misure = {misura1: {timestamp: valore}, ...}
        '''
        logging.info('requesting cw info (%s) for %s from %s to %s', self.chosen_metrics, instances, start, stop)

        data_points = {}
        self.__get_statistics(start, stop, instances)
        for p in self.__get_measurement_processes:
            p.join()
        del self.__get_measurement_processes[:]
        while not self.__get_measurement_queue.empty():
            instance_results = self.__get_measurement_queue.get()
            data_points[instance_results[0]] = instance_results[1]

        return data_points

    def __running_check_old(self, instance, apm):
        """
        Controlla se la VM è completamente funzionante, ovvero supera entrambi gli status check
        Il controllo sugli status check viene effettuato ogni check_interval secondi
        """
        check_interval = self.running_check_wait
        apm_server_alive = False
        while True:
            state = instance.update()
            status_check = 0
            if state == 'running':
                statuses = self.__conn.get_all_instance_status(instance_ids=[instance.id])[0]
                if not apm_server_alive:
                    try:
                        apm_server_alive = apm.is_alive()
                    except Exception, e:
                        logging.error("APM xmlrpc server is not alive: %s" % e)
                status_check = [
                    statuses.instance_status.details['reachability'] == 'passed',
                    statuses.system_status.details['reachability'] == 'passed',
                    apm_server_alive].count(True)

            print "[%s] %s - status check: %s/3 [APM server %s alive]" % (
                instance, state, status_check, "is" if apm_server_alive else "not")

            if status_check == 3:
                break
            else:
                time.sleep(check_interval)

    def __running_check(self, instance):
        """
        Controlla se la VM è completamente funzionante, ovvero supera entrambi gli status check
        Il controllo sugli status check viene effettuato ogni check_interval secondi
        """
        check_interval = self.running_check_wait
        while True:
            state = instance.update()
            status_check = 0
            if state == 'running':
                statuses = self.__conn.get_all_instance_status(instance_ids=[instance.id])[0]
                status_check = [
                    statuses.instance_status.details['reachability'] == 'passed',
                    statuses.system_status.details['reachability'] == 'passed'].count(True)

            logging.info("%s - %s - status check: %s/2" % (instance, state, status_check))

            if status_check == 2:
                break
            else:
                time.sleep(check_interval)

    def __generate_cluster_info(self):
        return {self.__instancePool[k]["info"]["pri_ip"]:
                self.__instancePool[k]["info"]["pub_ip"]
                for k in self.__instancePool.iterkeys()}

    #TODO remove me, currently unused
    def initialize_apm(self, instance):
        """
        Inizializza l'Active Probing Module sulla macchina virtuale (instance)
        La funziona è bloccante, da lanciare in un thread
            - attende status_check
            - carica le cluster_info
        """
        apm = xmlrpclib.ServerProxy('http://%s:%s/' % (instance.ip_address, 30000))
        self.__running_check(instance, apm)
        while True:
            try:
                cluster_info = self.__generate_cluster_info()
                logging.info("Generated cluster info [%s]" % cluster_info)
                logging.info("Setting cluster info...")
                apm.set_cluster_info(cluster_info)
                break
            except Exception, e:
                logging.error(e)
                logging.info("Sleeping...")
                time.sleep(5)

    def __run_vm(self, processes_queue):
        try:
            logging.info("Adding new VM")
            AMI_IMAGE_ID = self.ami_id
            INSTANCE_TYPE = self.vm_type
            SECURITY_GROUP = self.security_group_vm
            PLACEMENT = self.azones[0]

            reservation = self.__conn.run_instances(
                    AMI_IMAGE_ID,
                    # key_name=SSH_KEY_NAME,
                    instance_type=INSTANCE_TYPE,
                    placement=PLACEMENT,  # same availability zone
                    # placement=PLACEMENT[iter%3], # different availability zones
                    security_groups=[SECURITY_GROUP],
                    monitoring_enabled=True  # enable monitoring
                )

            instance = reservation.instances[0]

            self.pending_machines.append(instance.id)
            self.__running_check(instance)
            self.pending_machines.remove(instance.id)

            processes_queue.put_nowait(instance.id)
        except KeyboardInterrupt:
            logging.info("Adding VM process interrupted")

    def add_vm(self, num_vm=1):

        logging.info("Adding %s new VMs", num_vm)
        processes = []
        processes_queue = mp.Queue(num_vm)
        for i in range(num_vm):
            p = mp.Process(target=self.__run_vm, args=(processes_queue, ))
            processes.append(p)
            p.start()

        for i in processes:
            i.join()

        while not processes_queue.empty():
            instance_id = processes_queue.get_nowait()
            self.__lb.register_instances([instance_id])
            self.__add_to_pool(instance_id)

        self.__updatePoolInfo()

        cinfo = self.__generate_cluster_info()
        self.application_master.update_em_all(cinfo)
        self.monitoring_master.update_em_all(cinfo)

    def rm_vm(self, num_vm=1):
        """
        rimuove una macchina virtuale da pool.
        @remark implementa una politica FIFO
        """
        num_vm_to_rm = min(num_vm, len(self.__instancePool.keys()) - 1) #  always leave one VM up
        logging.info("removing %s VMs", num_vm_to_rm)
        logging.info("old cluster: %s", self.__instancePool.keys())
        ids_to_remove = []
        for i in range(num_vm_to_rm):
            id_to_remove = [x for x in self.__instancePool.keys() if self.__instancePool[x]["info"]["launch_time"] ==
                            min([self.__instancePool[k]["info"]["launch_time"] for k in
                                 self.__instancePool.keys()])].pop()
            logging.info("id to remove: %s", id_to_remove)
            ids_to_remove.append(id_to_remove)

            self.__lb.deregister_instances([id_to_remove])
            del self.__instancePool[id_to_remove]

        if num_vm_to_rm:
            logging.info("new cluster: %s", self.__instancePool.keys())
            cinfo = self.__generate_cluster_info()
            logging.info("new cluster info: %s", cinfo)
            self.application_master.update_em_all(cinfo)
            self.monitoring_master.update_em_all(cinfo)
            self.__conn.terminate_instances(instance_ids=ids_to_remove)

    def __add_to_pool(self, instanceId):
        """
        aggiunge nuova VM al pool
        """
        self.__instancePool[instanceId] = {}
        self.__instancePool[instanceId]['info'] = unset_instance.copy()
        self.__instancePool[instanceId]['meas'] = defaultdict(dict)
        self.__instancePool[instanceId]['history'] = defaultdict(lambda: unset_history.copy())

    def getAvgVals(self):
        """
        Restituisce il valore rappresentativo lo stato del processo Cloud
        """
        return self.__avgVals


if __name__ == "__main__":

    # if len(sys.argv) < 2:
    #     sys.stderr.write("usage: [python] " + sys.argv[0] + " Delta_T\n")
    #     sys.exit(1)

    #keys = sys.argv[1]

    # cplp = CCProcess("ap-northeast-1","credentials.dat")
    logging.getLogger().setLevel(logging.INFO)
    logging.Formatter.converter = time.gmtime
    logging.basicConfig(format='[%(asctime)s] [%(levelname)s] %(message)s')

    # logging.info("ciao")
    # raw_input()

    where_i_am = os.path.dirname(os.path.abspath(sys.argv[0]))

    cfg_file = "%s/conf/cloudProcess.ini" % where_i_am

    try:
        cplp = CCProcess(cfg_file)

        print "Startup"
        print "please wait..."
        pprint(cplp.get_instancePool())

        while True:
            print 'Use Control-C to exit'
            cplp.add_vm()
            cplp.update_pool_measurements()

            pprint(cplp.get_instancePool())
            pprint(cplp.getAvgVals())
            # time.sleep(60)
            raw_input("press a key to update process measurements\n")

            os.system("clear")
            time.sleep(1)
    except KeyboardInterrupt:
        print 'Exiting'
