#! /bin/bash

if [[ $# -lt 5 ]];
	then echo "usage $0 <PACKET SIZE [B]> <DESTINATION> <PCOUNT [s]> <INTERVAL> <OUTFILE>";
	exit 1 ;
fi

PKTSIZE=$1
DESTINATION=$2
PCOUNT=$3
INTERVAL=$4
OUTFILE=$5
PING=ping
PCOUNT=$((PCOUNT))

if [ ! -d $(dirname $OUTFILE) ]; then
    echo "$LOGDIR doesn't exist." > $OUTFILE.err
    exit 1
fi

CMD="$PING -n -i $INTERVAL -s $PKTSIZE -c $PCOUNT $DESTINATION"
${CMD} 2>$OUTFILE.err 1>$OUTFILE.out &
wait
exit 0