#! /bin/bash
if [[ $# -lt 8 ]];
	then echo "usage $0 <PROTOCOL> <FLAGS> <PORT> <PACKET SIZE [B]> <DESTINATION> <PCOUNT [s]> <INTERVAL> <OUTFILE>";
	exit 1 ;
fi

PROTOCOL=$1
FLAGS=$2
PORT=$3
PKTSIZE=$4
DESTINATION=$5
PCOUNT=$6
INTERVAL=$7
OUTFILE=$8
PING=hping3
PCOUNT=$((PCOUNT))

if [ ! -d $(dirname $OUTFILE) ]; then
    echo "$LOGDIR doesn't exist." > $OUTFILE.err
    exit 1
fi
if [ "$PROTOCOL" = "tcp" ]
then
    PROTOCOL=""
    FLAGS="-$FLAGS"
else
    PROTOCOL="--$PROTOCOL"
    FLAGS=""
fi
CMD="$PING $PROTOCOL $FLAGS -p $PORT -i $INTERVAL -d $PKTSIZE -c $PCOUNT $DESTINATION"
$CMD 2>$OUTFILE.err 1>$OUTFILE.out &
wait
exit 0
