import os
import sys
import time
from datetime import datetime
from datetime import timedelta
import traceback
import logging
import json
import numpy
import xmlrpclib
import multiprocessing as mp
from logging.handlers import RotatingFileHandler
import socket
from pprint import pprint


def setup_logger(logger_name, log_file, level=logging.INFO):
    '''
    Utility function for logfile management.
    '''

    l = logging.getLogger(logger_name)

    logging.Formatter.converter = time.gmtime
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')
    # fileHandler = logging.FileHandler(log_file, mode='a')
    # fileHandler.setFormatter(formatter)
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)
    rotatehandler = RotatingFileHandler(log_file, mode='a', maxBytes=10485760, backupCount=10)
    rotatehandler.setFormatter(formatter)

    l.setLevel(level)
    # l.addHandler(fileHandler)
    l.addHandler(streamHandler)
    l.addHandler(rotatehandler)

    return l


class apm:
    def __init__(self, ip_apm, path_tool, res_dir, command_log, state_log, error_log, cinfo_file, final_res_dir):
        self.exit = False
        self.ip_apm = ip_apm
        self.path_tool = path_tool.rstrip('/')
        self.res_dir = res_dir.rstrip('/')
        self.state_dict = {}
        self.c_log = setup_logger('command', command_log, logging.INFO)
        self.s_log = setup_logger('setup', state_log, logging.INFO)
        self.e_log = setup_logger('error', error_log, logging.ERROR)
        self.cluster_info = {}
        self.cluster_info_file = cinfo_file
        self.final_res_dir = final_res_dir

        self.measurement_tk = MeasurementTk(self.res_dir, self.path_tool, self.cluster_info_file, self.final_res_dir,
                                            self.c_log, self.s_log, self.e_log, self.ip_apm
                                            )

    def set_cluster_info(self, c_info):
        self.cluster_info = c_info
        with open(self.cluster_info_file, "w") as f:
            json.dump(c_info, f)
        self.c_log.info("cluster info updated: %s", c_info)
        return self.cluster_info

    def __find_results(self, start, end, metric_filename, granularity=0, stat='Average'):
        """
        Cerca all'interno del file metric_filename i risultati appartenenti
        all'intervallo di osservazione [start, end]
        :param start:
        :param end:
        :param metric_filename: file della metrica monitorata
        :return: dizionario con i risultati richiesti {ts1: val1, ts2: val2, ...}
        """
        start = int(start)
        end = int(end)

        def stica(dd):
            res = {}
            num_intervals = numpy.ceil(float(end-start)/granularity)
            for i in range(int(num_intervals)):

                vals = {x: v for x, v in dd.iteritems()
                        if start + i*granularity
                        <= int(x)
                        < start + (i+1)*granularity}
                timestamp = start+i*granularity

                vals = dict(map(lambda x: (x, numpy.nan) if vals[x] is None else (x, vals[x]), vals))

                if stat == 'Average':
                    v = float(numpy.nanmean(vals.values()))
                elif stat == 'Increment':
                    v = vals[max(vals)] - vals[min(vals)]
                else:
                    self.e_log.error("The stat '%s' does not exist", stat)
                    v = None

                v = float(numpy.nanmean(map(lambda x: numpy.nan if x is None else x, vals.values())))
                res[str(timestamp)] = v if not numpy.isnan(v) else None
            return res

        def get_increments(dd):
            keys = sorted(dd.keys())
            new_dd = {}
            for idx in range(len(keys) - 1):
                ck = keys[idx]
                nk = keys[idx+1]
                new_dd[ck] = dd[nk]-dd[ck]
            return new_dd

        current_metric = json.load(open(metric_filename))
        tempdict = {ts: val for ts, val in current_metric.iteritems() if start <= int(ts) <= end}

        if not granularity:
            if stat == 'Average':
                res = tempdict
            elif stat == 'Increment':
                res =get_increments(tempdict)
            else:
                self.e_log.error("The stat '%s' does not exist", stat)
                res = None
        else:
            res = stica(tempdict)

        return res

    def get_measurement(self, start, end, metrics=(), granularity=0):
        """
        Ritorna le misure che rientrano nell'intervallo temporale start-end
        :param start: di tipo datetime, inizio dell'intervallo di monitoraggio
        :param end: di tipo datetime, fine dell'intervallo di monitoraggio
        :param metrics: metrica da monitorare
        :param granularity: granularita' aggregazione in secondi
        :return: dizionario con i risultati richiesti per ciascuna metrica
                {metrica1:
                    {tsA: valA, ...},
                 metrica2:
                    {tsB: valB, ...},
                 ...}
        """
        res_dict = {}

        for metric in metrics:
            try:
                metric_filename = self.measurement_tk.json_pointers[metric]
                stat = 'Increment' if metric is 'request-count' else 'Average'
                res_dict[metric] = self.__find_results(start, end, metric_filename, granularity, stat)
            except KeyError:
                self.e_log.error("Metrica '%s' inesistente" % metric)
        return res_dict

    def get_metrics(self):
        return OutfileParser.k

    def is_alive(self):
        self.c_log.info("i'm alive!")
        return True


class MeasurementTk:
    def __init__(self, resdir, tooldir, cinfo_file, final_resdir, command_log, state_log, error_log, ip_apm):
        self.resdir = resdir  # raw
        self.tooldir = tooldir
        self.cluster_info_file = cinfo_file
        self.final_resdir = final_resdir  # json file folder
        self.locks = {}
        self.json_pointers = {}  # pointers to json file
        self.c_log = command_log
        self.s_log = state_log
        self.e_log = error_log
        self.ip_apm = ip_apm

        if not os.path.exists(self.resdir):
            os.makedirs(self.resdir)
        if not os.path.exists(self.final_resdir):
            os.makedirs(self.final_resdir)

        self.initialize_final_results()

    def initialize_final_results(self):
        for metric in OutfileParser.k:  # new file for each metric managed by OutfileParser
            fn = "%s/%s.json" % (self.final_resdir, metric)
            with open(fn, 'w') as f:
                json.dump({}, f)  # create new file - init with empty dict
            self.json_pointers[metric] = fn
            self.locks[metric] = mp.RLock()

    def get_cluster_info(self):
        with open(self.cluster_info_file, "r") as f:
            if os.path.exists(self.cluster_info_file):
                return json.load(f)
            else:
                return {}

    def get_ip_list(self):
        """
        Returns the list of the (public) IPs except the IP associated to this APM (if any)
        :return: list of (public) IPs except the ip associated to the current APM
        """
        return [x for y, x in self.get_cluster_info().items() if y is not self.ip_apm]

    def start_daemon(self):
        self.c_log.info("Daemon started")
        ip_list = self.get_ip_list()

        while len(ip_list) == 0:
            time.sleep(10)
            ip_list = self.get_ip_list()

        # i = 0  # DEBUG
        while True:
            # i += 1
            ip_list = self.get_ip_list()
            self.start_round(ip_list)
            # time.sleep(10)

    def start_round(self, iplist):  # TODO: re-load ip_list before each __start_meas()
        round_path = "%s/round_%s" % (self.resdir, int(time.time()))
        self.c_log.info("New Round started: %s", round_path)
        if not os.path.exists(round_path):
            os.makedirs(round_path)

        icmp_path = "%s/%s_%s" % (round_path, "icmp", int(time.time()))
        if not os.path.exists(icmp_path):
            os.makedirs(icmp_path)
        self.__start_meas(iplist, "ICMP", icmp_path)

        tcp_path = "%s/%s_%s" % (round_path, "tcp", int(time.time()))
        if not os.path.exists(tcp_path):
            os.makedirs(tcp_path)
        self.__start_meas(iplist, "TCP", tcp_path)

        req_count_path = "%s/%s_%s" % (round_path, "request-count", int(time.time()))
        if not os.path.exists(req_count_path):
            os.makedirs(req_count_path)
        self.start_request_count(req_count_path)

        # TODO: create HTTP subfolder
        # TODO: launch HTTP latency measurement

    def start_request_count(self, outbase):
        self.do_request_count(outbase)
        summary = OutfileParser(outbase).get_summary()
        print "summary", summary
        self.dump_results(summary)

    def do_request_count(self, outbase):
        endpoint = 'http://%s:%s/' % (self.ip_apm, 20000)
        success, my_as = MeasurementTk.__get_rpc(endpoint)
        if success:
            try:
                res = my_as.get_requests_counter()
            except Exception, e:
                self.e_log.error("Unable to connect to AS. No measure available. Exception on get_requests_counter.")
                res = None
        else:
            self.e_log.error("Unable to connect to AS. No measure available. Exception on connection.")
            res = None

        with open("%s/%s.out" % (outbase, "request-count"), "w") as f:
            f.write("%s\n" % res)

        return res

    @staticmethod
    def __get_rpc(end_point):
        a = xmlrpclib.ServerProxy(end_point)
        try:
            a._()   # Call a fictive method.
        except xmlrpclib.Fault:
            #  connected to the server and the method doesn't exist which is expected.
            pass
        except socket.error:
            # Not connected ; socket error mean that the service is unreachable.
            return False, None
        # Just in case the method is registered in the XmlRPC server
        return True, a

    def __start_meas(self, iplist, protocol, folder_path):  # starts measurements towards multiple destinations

        # Function and args for each measurement
        mappa = {
            "ICMP": {
                "foo": MeasurementTk.ping,
                #"args": "(self, ip, 'icmp', '_', 64, 5, outbase, '_', 1)"
                "args": "(self, ip, 64, 5, outbase, 1)"
            },
            "TCP": {
                "foo": MeasurementTk.hping,
                "args": "(self, ip, 'tcp', 80, 64, 5, outbase, 'S', 1)"
            }
        }

        self.c_log.info("New measurement: %s, %d destinations", protocol, len(iplist))
        threads = []
        actual_paths = []
        for ip in iplist:
            actual_path = "%s/%s" % (folder_path, ip.replace(".", "_"))
            outbase = "%s/%s" % (actual_path, ip.replace(".", "_"))
            if not os.path.exists(actual_path):
                os.makedirs(actual_path)
            actual_paths.append(actual_path)
            threads.append(mp.Process(target=mappa[protocol]["foo"], args=eval(mappa[protocol]["args"])))
        self.c_log.info("%d Meas threads created", len(threads))

        for t in threads:
            t.start()
        self.c_log.info("%d Meas threads started", len(threads))

        for t in threads:
            t.join()
        self.c_log.info("%d Meas threads Terminated", len(threads))

        parse_threads = []
        result_queue = mp.Queue()
        for ap in actual_paths:
            parse_threads.append(mp.Process(target=MeasurementTk.start_parse, args=(self, ap, result_queue)))
        self.c_log.info("%d Parse threads created", len(parse_threads))
        for pt in parse_threads:
            pt.start()
        self.c_log.info("%d Parse threads started", len(parse_threads))
        for pt in parse_threads:
            pt.join()
        self.c_log.info("%d Parse threads terminated", len(parse_threads))

        # Generate a new thread designed to dump the results into a file
        writer = mp.Process(target=MeasurementTk.aggregate_and_dump, args=(self, result_queue))
        writer.daemon = True
        writer.start()

    def start_parse(self, folder_path, result_queue=None):
        """
        Parses the rawfile and puts the results into the queue.
        :param folder_path:
        :return:
        """
        p = OutfileParser(folder_path)
        if result_queue:
            result_queue.put(p.get_summary())
        return p.get_summary()

    def aggregate_and_dump(self, result_queue):
        """
        Wrapper for aggregate_results() and dump_results, to be called by a single thread.
        :param result_queue:
        :return:
        """
        final = self.aggregate_results(result_queue)  # Aggregate
        self.dump_results(final)  # Dump
        return True

    def aggregate_results(self, result_queue):
        """
        Takes the data in the queue and extracts the aggregate results
        :return: avg_results or None
        """
        items = []
        tmp = {}
        final = {}
        while not result_queue.empty():
            items.append(result_queue.get_nowait())
        result_metrics = list(set([item for sublist in [x.keys() for x in items] for item in sublist]))
        for m in result_metrics:
            tmp[m] = [x[m] for x in items if m in x]
            values = [x.values().pop() for x in tmp[m]]
            values = filter(lambda a: a is not None, values)
            tss = [x.keys().pop() for x in tmp[m]]
            result = numpy.nanmean(values) if not numpy.isnan(numpy.nanmean(values)) else None
            final[m] = {tss.pop(): result}

        return final

    def dump_results(self, final):  # write (aggregate) results to file

        for metric in final:

            try:
                self.locks[metric].acquire()
                self.c_log.info("Dump results: lock on %s acquired", metric)
                with open(self.json_pointers[metric], 'r') as f:
                    data = json.load(f)

                toadd = final[metric]
                x, y = toadd.popitem()
                ts = x
                data[ts] = round(y, 3) if y is not None else y

                with open(self.json_pointers[metric], 'w') as f:
                    json.dump(data, f, separators=(',', ':'))

            except:
                traceback.print_exc(file=sys.stdout)
                pass  # TODO: implement except
            finally:
                try:
                    self.locks[metric].release()  # se eccezione sollevata prima di acquire(), finally genera eccezione
                    self.c_log.info("Dump results: lock on %s released", metric)
                except:  # TODO: implement except
                    pass

    def hping_dummy(self, ip_destination, protocol, outdir):
        time.sleep(1)
        with open("%s/%s" % (outdir, ip_destination), 'w') as f:
            for i in range(0, 10):
                f.write("ciao, sono le %s\n" % str(int(time.time())))
        print "%s latency to %s - folder: %s" % (protocol, ip_destination, outdir)

    def hping(
            self,
            ip_receiver,
            protocol,
            port,
            packet_size,
            packet_count,
            outbase,
            flags,
            interval):
        """
        :param ip_receiver:     destination address
        :param protocol:        probing traffic protocol (tcp, udp, icmp)
        :param port:            destination port
        :param packet_size:     probing-traffic packet size
        :param packet_count:    number of probes
        :param outbase:         outfile path - outbase.out and outbase.err will be created
        :param flags:           TCP flags string composed of ("F", "S", "R", "P", "A", "U", "X", "Y)
                                F   set FIN flag
                                S   set SYN flag
                                R   set RST flag
                                P   set PUSH flag
                                A   set ACK flag
                                U   set URG flag
                                X   set X unused flag (0x40)
                                Y   set Y unused flag (0x80)
        :param interval:        time elapsed between two consecutive probes
        :return:
        """

        # Costruzione del comando da lanciare
        # <PROTOCOL> <FLAGS> <PORT> <PACKET SIZE [B]> <DESTINATION> <PCOUNT [s]> <INTERVAL> <OUTFILE>";
        cmd = 'sudo ' + self.tooldir + '/HPING.sh '
        cmd += str(protocol) + ' '
        cmd += str(flags) + ' '
        cmd += str(port) + ' '
        cmd += str(packet_size) + ' '
        cmd += str(ip_receiver) + ' '
        cmd += str(packet_count) + ' '
        cmd += str(interval) + ' '
        cmd += str(outbase) + ' '

        self.c_log.info("hping: %s", cmd)
        os.system(cmd)

        return True

    def ping(
            self,
            ip_receiver,
            packet_size,
            packet_count,
            outbase,
            interval):
        """
        :param ip_receiver:     destination address
        :param packet_size:     probing-traffic packet size
        :param packet_count:    number of probes
        :param outbase:         outfile path - outbase.out and outbase.err will be created
        :param interval:        time elapsed between two consecutive probes
        :return:
        """

        # Costruzione del comando da lanciare
        # <PACKET SIZE [B]> <DESTINATION> <PCOUNT [s]> <INTERVAL> <OUTFILE>";
        cmd = 'sudo ' + self.tooldir + '/PING.sh '
        cmd += str(packet_size) + ' '
        cmd += str(ip_receiver) + ' '
        cmd += str(packet_count) + ' '
        cmd += str(interval) + ' '
        cmd += str(outbase) + ' '

        self.c_log.info("ping: %s", cmd)
        os.system(cmd)

        return True


class OutfileParser:
    """
    Generic parser.
    rawfile --> dict --> json.
    """
    # metric keys
    k = [
        "icmp-rt-delay",
        "icmp-rt-jitter",
        "tcp-rt-delay",
        "tcp-rt-jitter",
        "request-count"
    ]
    # protocol to metric mapping
    w = {
        "icmp": ["icmp-rt-delay", "icmp-rt-jitter"],
        "tcp": ["tcp-rt-delay", "tcp-rt-jitter"],
        "request-count": ["request-count"]
    }

    def __init__(self, folder_path, metric='auto', protocol='auto'):

        self.summary = {}
        self.folder_path = folder_path
        self.ts = self.extract_ts()

        if protocol != 'auto':
            self.protocol = protocol
        else:
            self.protocol = self.extract_protocol()

        if metric != 'auto':
            self.metric = metric
        else:
            if self.protocol in self.w:
                self.metric = self.w[self.protocol]
            else:
                self.metric = None
        # DEBUG
        # print self.summary
        # print self.folder_path
        # print self.ts
        # print self.protocol
        # print self.metric
        self.parse()

    def parse(self):

        if self.protocol is None \
                or self.metric is None \
                or not set(self.metric).issubset(set(self.k)):
            raise ParseException("Unable to Parse - wrong parameters")

        root, _, filenames = os.walk(self.folder_path).next()
        filenames = filter(lambda x: x.endswith(".out"), filenames)
        for f in filenames:
            filename = "%s/%s" % (root, f)

            for w in self.metric:
                res = None

                if w == "icmp-rt-delay":
                    try:
                        res = self.icmp_latency_parser(filename)
                    except ParseException, e:
                        # logging.error(str(e))
                        # traceback.print_exc(file=sys.stdout)
                        pass

                elif w == "icmp-rt-jitter":
                    try:
                        res = self.icmp_jitter_parser(filename)
                    except ParseException, e:
                        # logging.error(str(e))
                        # traceback.print_exc(file=sys.stdout)
                        pass

                elif w == "tcp-rt-delay":
                    try:
                        res = self.tcp_latency_parser(filename)
                    except ParseException, e:
                        # logging.error(str(e))
                        # traceback.print_exc(file=sys.stdout)
                        pass

                elif w == "tcp-rt-jitter":
                    try:
                        res = self.tcp_jitter_parser(filename)
                    except ParseException, e:
                        # logging.error(str(e))
                        # traceback.print_exc(file=sys.stdout)
                        pass
                elif w == "request-count":
                    try:
                        res = self.request_count_parser(filename)
                    except ParseException, e:
                        # logging.error(str(e))
                        # traceback.print_exc(file=sys.stdout)
                        pass

                res = round(res, 3) if res is not None else res

                self.summary[w] = {}
                self.summary[w][self.ts] = res

                # DEBUG
                # print self.folder_path
                # print self.protocol
                # print self.metric
                # print self.ts
                # print self.summary

    def get_summary(self):
        return self.summary

    def extract_ts(self):
        try:
            # self.filename = "/home/valerio/Codice/CC/cloudcontrol/APM/res/round_1432304923/icmp_1432304923/4_3_2_1/4_3_2_1"
            return int([x for x in self.folder_path.split("/") if "round" in x][-1].split("_")[1])
        except IndexError:
            return None

    def extract_protocol(self):
        try:
            # self.filename = "/home/valerio/Codice/CC/cloudcontrol/APM/res/round_1432304923/icmp_1432304923/4_3_2_1/4_3_2_1"
            return [self.folder_path.split("/")[i + 1].split("_")[0] \
                    for i in range(0, len(self.folder_path.split("/"))) \
                    if "round" in self.folder_path.split("/")[i]][-1]

        except IndexError:
            return None

    def request_count_parser(self, filename):
        """

        :param filename:
        :return:
        """
        values = []
        with open(filename, 'r') as f:
            for line in f.readlines():  # TODO-minor: optimize big-file management (no readlines())
                values.append(float(line.strip()))
            if not values:
                raise ParseException
            else:
                return numpy.average(values)

    def icmp_latency_parser(self, filename):
        """
        hping icmp output parser
        :return:    latency_avg
        """
        values = []
        with open(filename, 'r') as f:
            for line in f.readlines():  # TODO-minor: optimize big-file management (no readlines())
                # if not line.startswith("len="):
                if "ttl=" in line:
                    values.append(float(line.split()[-2].split("=")[1]))
            if not values:
                raise ParseException
            else:
                return numpy.average(values)

    def tcp_latency_parser(self, filename):
        """
        hping tcp output parser
        :return:    latency_avg
        """
        values = []
        with open(filename, 'r') as f:
            for line in f.readlines():  # TODO-minor: optimize big-file management (no readlines())
                if not line.startswith("len="):
                    continue
                else:
                    values.append(float(line.split()[9].split("=")[1]))
            if not values:
                raise ParseException
            else:
                return numpy.average(values)

    def icmp_jitter_parser(self, filename):
        """
        hping icmp output parser
        :return:    jitter
        """
        values = []
        with open(filename, 'r') as f:
            for line in f.readlines():  # TODO-minor: optimize big-file management (no readlines())
                if "ttl=" in line:
                    values.append(float(line.split()[-2].split("=")[1]))
            if not values:
                raise ParseException
            else:
                return self._jitter(values)

    def tcp_jitter_parser(self, filename):
        """
        hping tcp output parser
        :return:    jitter
        """
        values = []
        with open(filename, 'r') as f:
            for line in f.readlines():  # TODO-minor: optimize big-file management (no readlines())
                if not line.startswith("len="):
                    continue
                else:
                    values.append(float(line.split()[9].split("=")[1]))
            if not values:
                raise ParseException
            else:
                return self._jitter(values)

    @staticmethod
    def _jitter(values):
        return numpy.average([abs(values[i] - values[i - 1]) for i in range(1, len(values))])


class ParseException(Exception):
    pass
