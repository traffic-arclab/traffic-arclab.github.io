#! /usr/bin/python

import subprocess
import threading

import SocketServer
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
from ConfigParser import SafeConfigParser
from apm_functions import *

# def updating_thread(wrapper):
# '''
# Thread che aggiorna lo stato degli esperimenti sull'agent ogni 'update_sec' secondi.
# '''
# update_sec = parser.getfloat('config_agent', 'update_sec')

# while wrapper.exit == False:
# time.sleep(update_sec)
# wrapper.updating_busy_check()


# XMLRPCServer multithread
class ThreadedXMLRPCServer(SocketServer.ThreadingMixIn, SimpleXMLRPCServer):
    pass

# class ThreadedXMLRPCServer(threading.Thread):
#     def __init__(self):
#          threading.Thread.__init__(self)
#          self.localServer = SimpleThreadedXMLRPCServer(("localhost",10007))
#          self.localServer.register_function(getTextA) #just return a string
#
#     def run(self):
#          self.localServer.serve_forever()

if __name__ == "__main__":

    if len(sys.argv) < 2 or os.geteuid() != 0:
        print "usage: %s <ABSOLUTE_AGENT_PATH>" % (sys.argv[0])
        print "Agent must be run as superuser!"
        sys.exit(0)

    base_path = str(sys.argv[1])

    # Struttura file di configurazione del'agent:
    # [config_apm]
    # port = 30000
    # interface = eth0
    # tool_dir = script_tool
    # res_dir = res
    # log_dir = log
    # hist_dir = history
    # c_info = cluster_info

    # Parser per file di configurazione
    parser = SafeConfigParser()
    parser.read('%s/conf/conf_agent.ini' % base_path)

    port_server = parser.getint('config_agent', 'port')
    interface = parser.get('config_agent', 'interface')
    path_tool = base_path + '/' + parser.get('config_agent', 'tool_dir')
    res_dir = parser.get('config_agent', 'res_dir')
    final_res_dir = parser.get('config_agent', 'final_res_dir')
    cinfo_file = parser.get('config_agent', 'c_info')

    # Sottoprocesso comando shell per ottenere indirizzo ip dell'interfaccia 'interface'
    cmd = ("/sbin/ifconfig %s | grep inet | head -1 | sed 's/\:/ /' | awk '{print $3}'") % (interface)
    task = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ip_agent = task.stdout.read().rstrip('\n')

    # Gestione e creazione log
    log_dir = base_path + '/' + parser.get('config_agent', 'log_dir')
    hist_dir = base_path + '/' + parser.get('config_agent', 'hist_dir')
    if os.path.exists(log_dir):
        old_log_dir = ('%s_%s') % (log_dir, time.time())
        os.rename(log_dir, old_log_dir)
        os.renames(old_log_dir, hist_dir + old_log_dir[old_log_dir.rfind('/'):])
    os.mkdir(log_dir)
    command_log = log_dir + '/command_log.log'
    state_log = log_dir + '/state_log.log'
    error_log = log_dir + '/error_log.log'

    server = ThreadedXMLRPCServer((ip_agent, port_server), SimpleXMLRPCRequestHandler, logRequests=True,
                                  allow_none=True)
    server.register_introspection_functions()
    wrapper = apm(ip_agent, path_tool, res_dir, command_log, state_log, error_log, cinfo_file, final_res_dir)
    # wrapper.measurement_tk.start_daemon()
    #demonio = mp.Process(target=wrapper.measurement_tk.start_daemon)
    demonio = threading.Thread(target=wrapper.measurement_tk.start_daemon)
    demonio.daemon = True
    demonio.start()
    server.register_instance(wrapper)

    try:
        wrapper.c_log.info('APM Started: use Control-C to exit...')

        while wrapper.exit == False:
            if (wrapper.exit == True):
                break
            server.handle_request()  # N.B. server.serve_forever() richiama la server.handle_request() in un loop infinito.

        wrapper.c_log.info('APM Exiting...')

    except KeyboardInterrupt:
        wrapper.c_log.info('APM Exiting...')
