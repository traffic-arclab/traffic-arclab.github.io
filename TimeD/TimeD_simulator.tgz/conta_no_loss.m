function [l v] = no_loss(m)

c = [];
t = 0;

for i=1:(length(m)-1)
    if (m(i) == (m(i+1)-1))
        t = t+1;
    else t = t+1;
        c = [c ; t];
        t = 0;
    end
end

if m(length(m)) == (m(length(m)-1)+1)
    t = t+1;
    c = [c ; t];
end

l = mean(c);
v = var(c);
