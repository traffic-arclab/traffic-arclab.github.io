% Conta il numero di occorrenze di burst di un determinato elemento

function Distr_burst = countburst(I,k)

% I : sequenza di numeri
% k : numero di cui voglio calcolare le occorrenze di burst,
%     nel nostro modello di canale '0' equivale ad una perdita. 
% Distr_burst : array strutturato in modo che l'elemento di 
%               posto i-esimo corrisponde al numero di occorrenze 
%               di un burst di lunghezza i
% NB :la dimensione di questo array � pari a quella di 'I';
%     statisticamente servirebbero meno casi ma io li devo inglobare 
%     tutti considerando anche il caso di un unico burst lungo quanto
%     l'intera sequenza

      

L=size(I,2);

U=zeros(1,L); 

lenght=0;

for i=1:L
    if I(i)==k & i ~=L
       lenght=lenght+1;
      elseif I(i)==k & i==L  U(lenght+1)=U(lenght+1)+1;
    elseif lenght  ~=0
        U(lenght)=U(lenght)+1;
        lenght=0;
    end 
end

Distr_burst=U;

 