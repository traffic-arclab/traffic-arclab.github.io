% Channel 2-MM
%produce perdite su di una sequenza di "pacchetti" secondo un modello di Gilbert


function U = path(I,loss,rho)

%I : sequenza dei pacchetti da trasmettere indicati con 1  
%    (presenza del pacchetto) e 0 (assenza del pacchetto, ovvero perdita) o con dei numeri
%    relativi alle posizioni nella sequenza originaria (senza interleaving)
% IN GENERALE
%p : probabilit� di perdere un pacchetto dato che il precedente non � stato
%    perso
%q : probabilit� di non perdere un pacchetto dato che il precedente � stato
%    perso

% loss : probabilit� di perdita (media)
% rho : memoria del sistema (1 : bernoulliano ; >1 : presenza di bursts) :

% NEL NOSTRO CASO ....  � cos� ma adesso non so perk�!!!!!!!!!! :)

%q : probabilit� di generare una perdita da uno stato 'no-loss'
%    perso
%p : probabilit� di non generare una perdita da uno stato 'loss'

p = (1-loss)/(1+(rho-1)*loss);
q = loss/(1+(rho-1)*loss);

L = size(I,2);

Q= [1-p, p;
    q, 1-q];
            
 e = [1, 0; 0, 1];   %� nell'utlizzo di questo vettore la chiave dello strano comportamento di questa funzione secondo me!
 
 
[seq, states] = hmmgenerate(L,Q,e); %,'Symbols',...
                 % {1,0},...
                  % 'Statenames',{'noloss';'loss'});
        
seq=seq-1;

U=I.*seq;
