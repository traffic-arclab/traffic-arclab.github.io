%funzione che conta il numero di perdite in una sequenza di pacchetti (contassegnate con '0')


function nlosses=countlosses(I)

%I : sequenza in ingresso con delle perdite '0'
%nlosses : numero perdite

nlosses=size(I,2)-nnz(I);