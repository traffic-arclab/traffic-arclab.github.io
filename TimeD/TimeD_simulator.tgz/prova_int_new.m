%simulazioni di vari casi di path_diversity+interleaving al variare di loss e rho

%U � una matrice multidimensionale : 
%           U(profondit� interleaving,loss,rho)
%


function [U1,U2,U3,U4,U5,U6,U7]=prova_int_new(l,L,Depths,Losses,Rhos,times)



m=size(Depths,2);
n=size(Losses,2);
o=size(Rhos,2);


for a=1:m
    for b=1:n
        for c=1:o
                [Dmedia_F,Dmedia_C,LmediaB,VarB,LmediaNL,VarNL,Nlosses]=test_int_new(l,L,Depths(a),Losses(b),Rhos(c),times);
                
                U1(a,b,c)=Dmedia_F;
                U2(a,b,c)=Dmedia_C;
                U3(a,b,c)=LmediaB;
                U4(a,b,c)=VarB;
                U5(a,b,c)=LmediaNL;
                U6(a,b,c)=VarNL;
                U7(a,b,c)=Nlosses;
                
        end
    end
end
        
