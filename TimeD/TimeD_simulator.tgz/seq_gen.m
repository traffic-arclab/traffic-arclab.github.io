%seq_gen
% Generatore di n arrey lunghi l per block interleaving


function S = seq_gen(l,n)

S=zeros([1 l n]);
 for i=1:n;
   S(:,:,i) = [((i-1)*l)+1:i*l];
 end 