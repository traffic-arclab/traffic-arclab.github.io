%Deinterleaving

%riordina un array di elementi su cui � stato effettuato l'interleaving
%restituisce l'array cos� riordina

%I : array su cui � stato effettuato l'interleaving
%Di : array risequenziato


function Di = deinterleaving(I,m,n) %NB inverto n ed m rispetto al modulo interleaving


l=n*m;

%creo il blocco n*m

B = reshape(I,m,n)  ;  

%lo riaggiusto nell'ordine originario

Di = reshape(B',1,l);  

