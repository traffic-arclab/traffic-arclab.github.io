% INTERLEAVING
%accetta in ingresso una stringa di numeri che indicano l'ordine originario
%dei pacchetti
%riordina i pacchetti secondo un classico schema di "block interleaving"
%restituisce la stringa cos� riordianta


function U = interleaving(I,n,m)

% I sequenza in ingresso : array di l pacchetti
% U sequenza in uscita : array di l pacchetti risistemati in base allo
%                        schema dell' interleaving richiesto
% n deph dell'interleaving : numero righe
% m block size dell'interleaving : numero colonne

l = size(I,2);


%devo verificare che  l=n*m
%if l ~=m*n error('non � possibile applicare l'interleaving a blocchi')
%end


B = reshape(I,m,n)  ;  %creo il blocco n*m
U = reshape(B',1,l);  %creo la sequenza di uscita



