%riceve in ingresso un array multidimensionale di q stringhe lunghe l
%restituisce una array multidimensionale di q stringhe lunghe l riordinate


function SU = deinterleaving_all(S,n,m)

L=size(S,2);

l=n*m;

q=L/l;  %controllare che sia intero

%divido la sequenza in q blocchi lunghi l
for i=1:q
   Si(:,:,i) = S(((i-1)*l)+1:i*l);
 end 


h=size(Si,3);

% riaggiusto l'ordine dei pacchetti all'interno dei blocchi
for i=1:h
    Su(:,:,i)=deinterleaving(Si(:,:,i),n,m);
end


%riunisco tutti i blocchi in un'unica sequenza
SU=Su(:,:,1);

for i=2:q 
      SU=[SU,Su(:,:,i)];
end
   