% Conta le occorrenze delle lunghezze 
% delle sequenze no-loss

function Distr_nolossesl = nolossesl(I,k)

% I : traccia relativa ad una sequenza di pacchetti 
% k : numero che contraddisitingue una perdita 
%     ('0' nel nostro caso)
% Distr_nolossesl : array strutturato in modo che l'elemento di 
%               posto i-esimo corrisponde al numero di occorrenze 
%               di inter-loss distance pari ad i
% NB :la dimensione di questo array � pari a quella di 'I';
%     statisticamente servirebbero meno casi ma io li devo inglobare 
%     tutti considerando anche il caso 'I' non ha perdite
   
      
L=size(I,2);

U=zeros(1,L); %statisticamente servirebbero meno casi ma io li devo inglobare tutti
lenght=0;

for i=1:L
    if I(i)~=k & i ~=L
       lenght=lenght+1;
      elseif I(i)~=k & i==L  U(lenght+1)=U(lenght+1)+1;
    elseif lenght  ~=0
        U(lenght)=U(lenght)+1;
        lenght=0;
    end 
end

Distr_nolossesl=U;