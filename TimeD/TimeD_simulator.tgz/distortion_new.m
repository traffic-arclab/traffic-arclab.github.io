% Distorsione
%funzione per il calcolo della distorsione pesando opportunamente le perdite a burst
%Ci sono diversi possibili configurazioni di distorioni

%DEVO  mantenere la stessa interfaccia della vecchia funzione di calcolo
%della distrosione per non riscrivere tutti i moduli che la chiamano!!!!!

%Dtot_F : caso Foreman
%Dtot_C: caso Claire

function [Dtot_F,Dtot_C]=distortion_new(I)

%I sequenza in ingresso di 1(presenza del pacchetto) 0 (assenza di
%pacchetto e quindi errore)
%NB : per default e=0 ma se le cose cambiano devo tenerne conto!!!!!!!

%NB : per funzionare bene la sequenza I deve avere almeno un numero di
%     elementi pari al valore max contenuto in linghezze_burst


%Pesi=ones(1,L);% MODELLO ADDITIVO

%Pesi=[1:1:L];  % MODELLO di DEFAULT

%D1=1;   %sto assumendo unitaria la distorsione per la perdita di un pacchetto

%Di=zeros(1,L);
%for i=1:L
%    Di(i)=Db(i)*i;
%end


L=size(I,2);

Db=countburst(I,0); %ho assunto che '0' contraddistingue l'errore

%CASO FOREMAN
lunghezze_burst_F = [2 5 10 18];
distorsioni_associate_F = [3.1 9.1 18.1 31.6];

%CASO CLAIRE
lunghezze_burst_C = [2 5 10 18];
distorsioni_associate_C = [2.8 11.1 22.5 33.8];

Di_F=calcola_distorsioni(lunghezze_burst_F,distorsioni_associate_F,L);
Di_C=calcola_distorsioni(lunghezze_burst_C,distorsioni_associate_C,L);


Dtot_F=sum(Di_F.*Db);
Dtot_C=sum(Di_C.*Db);
